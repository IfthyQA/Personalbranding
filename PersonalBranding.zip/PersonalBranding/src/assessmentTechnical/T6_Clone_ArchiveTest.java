package assessmentTechnical;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import screenshotOnFailure.FailScreenshot;

@Listeners(screenshotListners.EventList.class)
public class T6_Clone_ArchiveTest extends FailScreenshot{

	  	@Test
	  	public void TA_Test_ArchiveClone() throws InterruptedException{
	  	
  		/* Login to the Application - PBC */ 		
	  	driver.findElement(By.xpath("(//button[normalize-space()='Login'])[1]")).click();
  		driver.findElement(By.xpath("//input[@id='Username']")).click();
  		driver.findElement(By.xpath("//input[@id='Username']")).sendKeys("john.doe005");
  		driver.findElement(By.xpath("//input[@id='password-field']")).click();
  		driver.findElement(By.xpath("//input[@id='password-field']")).sendKeys("Rockon123");
  		driver.findElement(By.xpath("//button[@id='loginButton']")).click();
  		Thread.sleep(2000);
  		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(120));
	    
	    /* Naviagte to the Business Page */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[normalize-space()='Business Automati...']")));
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()='Business Automati...']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//span[normalize-space()='Business Automati...']")).click();
	    Thread.sleep(2000);
	    
	    /* Navigate to the Technical Assessment */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[normalize-space()=\'Administer Test\']")));
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()=\'Administer Test\']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//span[normalize-space()=\'Administer Test\']")).click();
	    Thread.sleep(2000);
	    
	    /* Archive Test */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".fa-ellipsis-v")));
	    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".fa-ellipsis-v")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".fa-ellipsis-v")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".smallCardActionButton:nth-child(2) > .ml-2")).click();Thread.sleep(2000);
	    driver.findElement(By.xpath("//span[normalize-space()=\'Archived Assessment\']")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".fa-ellipsis-v")).click();Thread.sleep(2000);
	    driver.findElement(By.xpath("//span[normalize-space()=\'Technical Assessment\']")).click();;Thread.sleep(2000);
	    
	    /* Un-Archive Test */
	    driver.findElement(By.xpath("//span[normalize-space()=\'Archived Assessment\']")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".fa-ellipsis-v")).click();Thread.sleep(2000);
	    driver.findElement(By.xpath("//span[contains(.,\'Unarchive Test\')]")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".fa-ellipsis-v")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".fa-times")).click();Thread.sleep(2000);
	    Thread.sleep(2000);
	    
	    /* Clone Test */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".fa-ellipsis-v")));
	    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".fa-ellipsis-v")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".fa-ellipsis-v")).click();Thread.sleep(2000);	
	    driver.findElement(By.xpath("//span[contains(.,\'Clone Test\')]")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".close > span")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".fa-ellipsis-v")).click();Thread.sleep(2000);
	    driver.findElement(By.xpath("//span[contains(.,\'Clone Test\')]")).click();Thread.sleep(2000);
	    driver.findElement(By.xpath("//button[@class=\'next-btn-share-test\']")).click();Thread.sleep(2000);
	    driver.findElement(By.name("testInfoModel.name")).click();Thread.sleep(2000);
	    driver.findElement(By.name("testInfoModel.name")).clear();Thread.sleep(2000);
	    driver.findElement(By.name("testInfoModel.name")).sendKeys("Clone Test ");Thread.sleep(2000);
	    driver.findElement(By.name("duration")).click();Thread.sleep(2000);
	    driver.findElement(By.name("duration")).sendKeys("0");Thread.sleep(2000);
	    driver.findElement(By.id("createTestNextBtn")).click();Thread.sleep(2000);
	    
	    /* Video Proctoring and Performance Categories */
	    driver.findElement(By.cssSelector(".custom-control-label")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".custom-control-label")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".close > span")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".btn-primary")).click();Thread.sleep(2000);
	    driver.findElement(By.xpath("//button[@class=\'next-btn-share-test\']")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".close > span")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".btn-primary")).click();Thread.sleep(2000);
	    driver.findElement(By.xpath("//button[@class=\'next-btn-share-test\']")).click();Thread.sleep(2000);
	    
	    /* Share Test one User on Edit View */
	    driver.findElement(By.xpath("//button[normalize-space()=\'Share\']")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".btn-primary")).click();Thread.sleep(2000);
	    driver.findElement(By.xpath("//button[normalize-space()=\'Share\']")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".margin-right-15")).click();Thread.sleep(2000);
	    driver.findElement(By.xpath("//button[@class=\'btn-primary float-right shareTestLinkButton\']")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".ReactTags__tagInputField")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".ReactTags__tagInputField")).sendKeys("ifthytest+1@gmail.com");Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".ReactTags__tagInputField")).sendKeys(Keys.ENTER);Thread.sleep(2000);
	    driver.findElement(By.xpath("//button[@class=\'btn-primary float-right shareTestLinkButton\']")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".modal-error-btny")).click();Thread.sleep(2000);
	    driver.findElement(By.xpath("//button[@class=\'btn-primary float-right shareTestLinkButton\']")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".margin-right-10")).click();Thread.sleep(2000);
	    
	    /* Edit View */
	    driver.findElement(By.cssSelector(".fa-ellipsis-v")).click();Thread.sleep(2000);
	    driver.findElement(By.xpath("//span[normalize-space()=\'Edit Test\']")).click();Thread.sleep(2000);
	    
	    /* Delete Clone Test */
	    driver.findElement(By.xpath("//button[@class=\'deleteBtn\']//i[@class=\'fa fa-trash\']")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".margin-right-10")).click();Thread.sleep(2000);
	    
	    /* Share Original Test */
	      {
	        WebElement element = driver.findElement(By.xpath("//*[@id=\"root\"]/div[2]/div/div/div[2]/div[3]/div/div/div/div[2]/div/div/div[2]/div/div/div[2]/p[2]/span[1]"));
	        Actions builder = new Actions(driver);
	        builder.moveToElement(element).perform();
	      }
	      Thread.sleep(2000);
	      driver.findElement(By.xpath("//span[contains(text(),\'Share Link\')]")).click();Thread.sleep(2000);
	      driver.findElement(By.cssSelector(".margin-right-15")).click();Thread.sleep(2000);
	      driver.findElement(By.xpath("//button[@class=\'btn-primary float-right shareTestLinkButton\']")).click();Thread.sleep(2000);
	      driver.findElement(By.cssSelector(".ReactTags__tagInputField")).click();Thread.sleep(2000);
	      driver.findElement(By.cssSelector(".ReactTags__tagInputField")).sendKeys("ifthytest+1@gmail.com");Thread.sleep(2000);
	      driver.findElement(By.cssSelector(".ReactTags__tagInputField")).sendKeys(Keys.ENTER);Thread.sleep(2000);
	      driver.findElement(By.cssSelector(".ReactTags__tagInputField")).click();Thread.sleep(2000);
	      driver.findElement(By.cssSelector(".ReactTags__tagInputField")).sendKeys("ifthytest+2@gmail.com");Thread.sleep(2000);
	      driver.findElement(By.cssSelector(".ReactTags__tagInputField")).sendKeys(Keys.ENTER);Thread.sleep(2000);
	      driver.findElement(By.xpath("//button[@class=\'btn-primary float-right shareTestLinkButton\']")).click();Thread.sleep(2000);
	      driver.findElement(By.cssSelector(".margin-right-10")).click();Thread.sleep(2000);
	    
	    /* Revoke Test */
	        {
	          WebElement element = driver.findElement(By.xpath("//*[@id=\"root\"]/div[2]/div/div/div[2]/div[3]/div/div/div/div[2]/div/div/div[2]/div/div/div[2]/p[1]"));
	          Actions builder = new Actions(driver);
	          builder.moveToElement(element).perform();
	        }
	        Thread.sleep(2000);
	        driver.findElement(By.xpath("//span[normalize-space()=\'Test Takers\']")).click();Thread.sleep(2000);
	        driver.findElement(By.xpath("//td[@class=\'py-4\']//span[2]")).click();Thread.sleep(2000);
	        driver.findElement(By.xpath("//tbody//tr//span[3]")).click();Thread.sleep(2000);
	        driver.findElement(By.xpath("//div[@class=\'revokeTest\']")).click();Thread.sleep(2000);
	        driver.findElement(By.xpath("//button[@class=\'btn-primary modal-error-btny\']")).click();Thread.sleep(2000);
	        driver.findElement(By.xpath("//div[@class=\'revokeTest\']")).click();Thread.sleep(2000);
	        driver.findElement(By.xpath("//button[@class=\'margin-right-10 modal-error-btnn\']")).click();Thread.sleep(2000);
	        
	        /* Cancel the Create Test - TEST TAKERS Page */
		    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[normalize-space()=\'Create New Test\']")));
		    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[normalize-space()=\'Create New Test\']")));Thread.sleep(2000);
		    driver.findElement(By.xpath("//button[normalize-space()=\'Create New Test\']")).click();Thread.sleep(2000);
		    driver.findElement(By.cssSelector(".close > span")).click();Thread.sleep(2000);
		    driver.findElement(By.xpath("//button[normalize-space()=\'Create New Test\']")).click();Thread.sleep(2000);
		    driver.findElement(By.xpath("//label[normalize-space()=\'No\']//input[@name=\'optradio\']")).click();Thread.sleep(2000);
		    driver.findElement(By.xpath("//label[normalize-space()=\'Yes\']//input[@name=\'optradio\']")).click();Thread.sleep(2000);
		    driver.findElement(By.cssSelector(".close > span")).click();Thread.sleep(2000);
	        driver.findElement(By.xpath("//span[normalize-space()=\'Back\']")).click();Thread.sleep(2000);
	    
	    /* Delete Test - Original Test */
	    driver.findElement(By.cssSelector(".fa-ellipsis-v")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".smallCardActionButton:nth-child(4) > .ml-2")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".btn-primary")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".smallCardActionButton:nth-child(4) > .ml-2")).click();Thread.sleep(2000);
	    driver.findElement(By.xpath("//button[normalize-space()=\'Yes\']")).click();
	    Thread.sleep(2000);
	    
	    /* Delete Question Bank */
	    driver.findElement(By.xpath("//div[1]/div[2]/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/a[2]/div[1]/span[2]")).click();Thread.sleep(2000);
	    driver.findElement(By.xpath("//i[@class=\'fa fa-trash\']")).click();Thread.sleep(2000);
	    driver.findElement(By.xpath("//button[@class=\'margin-right-10 modal-error-btnn\']")).click();Thread.sleep(2000);
	    
	    /* Sign Out */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//i[@class='fa fa-sign-out menu-logout-icon']")));
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//i[@class='fa fa-sign-out menu-logout-icon']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//i[@class='fa fa-sign-out menu-logout-icon']")).click();
	    Thread.sleep(2000);
	  	}
	  	}





