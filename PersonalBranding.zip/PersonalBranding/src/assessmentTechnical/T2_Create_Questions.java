package assessmentTechnical;

import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import screenshotOnFailure.FailScreenshot;

@Listeners(screenshotListners.EventList.class)
public class T2_Create_Questions extends FailScreenshot{
	
	@Test
  	public void TA_AddEdit_Duplicate() throws InterruptedException{
  	
	/* Login to the Application - PBC */ 		
	driver.findElement(By.xpath("(//button[normalize-space()='Login'])[1]")).click();
	driver.findElement(By.xpath("//input[@id='Username']")).click();
	driver.findElement(By.xpath("//input[@id='Username']")).sendKeys("john.doe005");
	driver.findElement(By.xpath("//input[@id='password-field']")).click();
	driver.findElement(By.xpath("//input[@id='password-field']")).sendKeys("Rockon123");
	driver.findElement(By.xpath("//button[@id='loginButton']")).click();
	Thread.sleep(2000);
	WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(120));
    
    /* Naviagte to the Business Page */
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[normalize-space()='Business Automati...']")));
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()='Business Automati...']")));Thread.sleep(2000);
    driver.findElement(By.xpath("//span[normalize-space()='Business Automati...']")).click();
    Thread.sleep(2000);
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[normalize-space()=\'Administer Test\']")));
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()=\'Administer Test\']")));Thread.sleep(2000);
    driver.findElement(By.xpath("//span[normalize-space()=\'Administer Test\']")).click();
    Thread.sleep(2000);
    
    /* Upload Question and Cancel */
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[1]/div[2]/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/a[3]/div[1]/span[2]")));
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[1]/div[2]/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/a[3]/div[1]/span[2]")));Thread.sleep(2000);
	driver.findElement(By.xpath("//div[1]/div[2]/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/a[3]/div[1]/span[2]")).click();
	Thread.sleep(2000);
    driver.findElement(By.xpath("//span[contains(.,\'Upload Questions\')]")).click();Thread.sleep(2000);
    driver.findElement(By.cssSelector(".backButton > .margin-left-5")).click();Thread.sleep(2000);
    
    /* Create Questions */
    driver.findElement(By.xpath("//span[normalize-space()=\'Create Questions\']")).click();Thread.sleep(2000);
    driver.findElement(By.cssSelector(".close > span")).click();Thread.sleep(2000);
    
    /* Add Skill to Questions */
    driver.findElement(By.xpath("//span[normalize-space()=\'Create Questions\']")).click();Thread.sleep(2000);
    driver.findElement(By.xpath("//div[@class=\'mainSkill margin-top-10\']//input[contains(@placeholder,\'\')]")).click();Thread.sleep(2000);
    driver.findElement(By.xpath("//div[@class=\'mainSkill margin-top-10\']//input[contains(@placeholder,\'\')]")).sendKeys("BDD");Thread.sleep(2000);
    driver.findElement(By.xpath("//div[@class=\'secondSubskill margin-top-30\']//input[contains(@placeholder,\'\')]")).click();Thread.sleep(2000);
    driver.findElement(By.xpath("//div[@class=\'secondSubskill margin-top-30\']//input[contains(@placeholder,\'\')]")).sendKeys("Ifthy");Thread.sleep(2000);
    driver.findElement(By.cssSelector(".saveBtn")).click();Thread.sleep(2000);
    driver.findElement(By.xpath("//div[@class=\'secondSubskill margin-top-30\']//input[contains(@placeholder,\'\')]")).clear();
    Thread.sleep(2000);
    driver.findElement(By.xpath("//div[@class=\'firstSubskill margin-top-30\']//input[contains(@placeholder,\'\')]")).click();Thread.sleep(2000);
    driver.findElement(By.xpath("//div[@class=\'firstSubskill margin-top-30\']//input[contains(@placeholder,\'\')]")).sendKeys("Automation");Thread.sleep(2000);
    driver.findElement(By.xpath("//div[@class=\'secondSubskill margin-top-30\']//input[contains(@placeholder,\'\')]")).clear();
    driver.findElement(By.cssSelector(".saveBtn")).click();Thread.sleep(2000);
    
    /* 1st Question - Add */
    driver.findElement(By.xpath("//span[normalize-space()=\'Add Question\']")).click();Thread.sleep(2000);
    driver.findElement(By.xpath("//textarea[@placeholder=\'Enter Question Content Here...\']")).click();Thread.sleep(2000);
    driver.findElement(By.xpath("//textarea[@placeholder=\'Enter Question Content Here...\']")).sendKeys("What does BDD stand for ......... ?");Thread.sleep(2000);
    driver.findElement(By.xpath("//input[@placeholder=\'Enter option no 1\']")).click();Thread.sleep(2000);
    driver.findElement(By.xpath("//input[@placeholder=\'Enter option no 1\']")).sendKeys("Behaviour Driven Deployment");Thread.sleep(2000);
    driver.findElement(By.xpath("//input[@placeholder=\'Enter option no 2\']")).click();Thread.sleep(2000);
    driver.findElement(By.xpath("//input[@placeholder=\'Enter option no 2\']")).sendKeys("Behaviour Driven Development");Thread.sleep(2000);
    driver.findElement(By.xpath("//i[@class=\'fa fa-plus-circle\']")).click();Thread.sleep(2000);
    driver.findElement(By.xpath("//input[@placeholder=\'Enter option no 3\']")).click();Thread.sleep(2000);
    driver.findElement(By.xpath("//input[@placeholder=\'Enter option no 3\']")).sendKeys("Behaviour Driven Discussion");Thread.sleep(2000);
    driver.findElement(By.xpath("//i[@class=\'fa fa-times\']")).click();Thread.sleep(2000);
    driver.findElement(By.xpath("//button[@class=\'btn-primary modal-error-btny\']")).click();Thread.sleep(2000);
    driver.findElement(By.xpath("//span[normalize-space()=\'Save\']")).click();Thread.sleep(2000);
    driver.findElement(By.xpath("//input[@value=\'Difficult\']")).click();Thread.sleep(2000);
    driver.findElement(By.xpath("//span[normalize-space()=\'Save\']")).click();Thread.sleep(2000);
    driver.findElement(By.xpath("//div[1]/div[2]/div[1]/div[1]/div[2]/div[3]/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/div[2]/div[1]/div[3]/div[2]/div[2]/input[1]")).click();Thread.sleep(2000);
    driver.findElement(By.xpath("//span[normalize-space()=\'Save\']")).click();
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@role=\'alert\']")));Thread.sleep(2000);
	driver.findElement(By.xpath("//div[@role=\'alert\']")).click();
    Thread.sleep(2000);
    
    /* 2nd Question - Add Questions - Duplicate Question */
    driver.findElement(By.xpath("//span[normalize-space()=\'Add Question\']")).click();Thread.sleep(2000);
    driver.findElement(By.xpath("//textarea[@placeholder=\'Enter Question Content Here...\']")).click();Thread.sleep(2000);
    driver.findElement(By.xpath("//textarea[@placeholder=\'Enter Question Content Here...\']")).sendKeys("What does BDD stand for ......... ?");Thread.sleep(2000);
    
    /* Add 3 Options */
    driver.findElement(By.xpath("//input[@placeholder=\'Enter option no 1\']")).click();Thread.sleep(2000);
    driver.findElement(By.xpath("//input[@placeholder=\'Enter option no 1\']")).sendKeys("Behaviour Driven Deployment");Thread.sleep(2000);
    driver.findElement(By.xpath("//input[@placeholder=\'Enter option no 2\']")).click();Thread.sleep(2000);
    driver.findElement(By.xpath("//input[@placeholder=\'Enter option no 2\']")).sendKeys("Behaviour Driven Development");Thread.sleep(2000);
    driver.findElement(By.xpath("//i[@class=\'fa fa-plus-circle\']")).click();Thread.sleep(2000);
    driver.findElement(By.xpath("//input[@placeholder=\'Enter option no 3\']")).click();Thread.sleep(2000);
    driver.findElement(By.xpath("//input[@placeholder=\'Enter option no 3\']")).sendKeys("Behaviour Driven Discussion");Thread.sleep(2000);
    driver.findElement(By.xpath("//i[@class=\'fa fa-times\']")).click();Thread.sleep(2000);
    driver.findElement(By.xpath("//button[@class=\'btn-primary modal-error-btny\']")).click();Thread.sleep(2000);
    driver.findElement(By.xpath("//input[@value=\'Difficult\']")).click();Thread.sleep(2000);
    driver.findElement(By.xpath("//span[normalize-space()=\'Save\']")).click();Thread.sleep(2000);
    driver.findElement(By.xpath("//div[1]/div[2]/div[1]/div[1]/div[2]/div[3]/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/div[2]/div[3]/div[3]/div[2]/div[2]/input[1]")).click();Thread.sleep(2000);
    driver.findElement(By.xpath("//span[normalize-space()=\'Save\']")).click();
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@role=\'alert\']")));Thread.sleep(2000);
	driver.findElement(By.xpath("//div[@role=\'alert\']")).click();
    Thread.sleep(2000);
    
    /* Edit Above Question to Add Second Question */
    driver.findElement(By.xpath("//textarea[@placeholder=\'Enter Question Content Here...\']")).click();Thread.sleep(2000);
    driver.findElement(By.xpath("//textarea[@placeholder=\'Enter Question Content Here...\']")).clear();Thread.sleep(2000);
    driver.findElement(By.xpath("//textarea[@placeholder=\'Enter Question Content Here...\']")).sendKeys("What is BDD ?");Thread.sleep(2000);   
    /* Add 4th Options */
    driver.findElement(By.xpath("//i[@class=\'fa fa-plus-circle\']")).click();Thread.sleep(2000);
    driver.findElement(By.xpath("//input[@placeholder=\'Enter option no 4\']")).click();Thread.sleep(2000);
    driver.findElement(By.xpath("//input[@placeholder=\'Enter option no 4\']")).sendKeys("Barbarian Driven Discussion");Thread.sleep(2000);
    driver.findElement(By.xpath("//i[@class=\'fa fa-times\']")).click();Thread.sleep(2000);
    driver.findElement(By.xpath("//button[@class=\'btn-primary modal-error-btny\']")).click();Thread.sleep(2000);
    driver.findElement(By.xpath("//input[@value=\'Medium\']")).click();Thread.sleep(2000);
    driver.findElement(By.xpath("//div[1]/div[2]/div[1]/div[1]/div[2]/div[3]/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/div[2]/div[3]/div[3]/div[3]/div[2]/input[1]")).click();Thread.sleep(2000);
    driver.findElement(By.xpath("//span[normalize-space()=\'Save\']")).click();
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@role=\'alert\']")));Thread.sleep(2000);
	driver.findElement(By.xpath("//div[@role=\'alert\']")).click();
    Thread.sleep(2000);
    
    /* Delete Second Question */
    driver.findElement(By.xpath("//div[1]/div[2]/div[1]/div[1]/div[2]/div[3]/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/div[2]/div[3]/div[4]/button[2]/i[1]")).click();Thread.sleep(2000);
    driver.findElement(By.xpath("//button[@class=\'btn-primary modal-error-btny\']")).click();Thread.sleep(2000);
    driver.findElement(By.xpath("//div[1]/div[2]/div[1]/div[1]/div[2]/div[3]/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/div[2]/div[3]/div[4]/button[2]/i[1]")).click();Thread.sleep(2000);
    driver.findElement(By.xpath("//button[@class='margin-right-10 modal-error-btnn']")).click();
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@role=\'alert\']")));
	Thread.sleep(2000);
    
    /* 3rd Question - Add */
    driver.findElement(By.xpath("//span[normalize-space()=\'Add Question\']")).click();Thread.sleep(2000);
    driver.findElement(By.xpath("//textarea[@placeholder=\'Enter Question Content Here...\']")).click();Thread.sleep(2000);
    driver.findElement(By.xpath("//textarea[@placeholder=\'Enter Question Content Here...\']")).sendKeys("What are the 3 Practices of BDD ?");Thread.sleep(2000);
    
    /* Add 3 Options */
    driver.findElement(By.xpath("//input[@placeholder=\'Enter option no 1\']")).click();Thread.sleep(2000);
    driver.findElement(By.xpath("//input[@placeholder=\'Enter option no 1\']")).sendKeys("Discovery, Integration, Development");Thread.sleep(2000);
    driver.findElement(By.xpath("//input[@placeholder=\'Enter option no 2\']")).click();Thread.sleep(2000);
    driver.findElement(By.xpath("//input[@placeholder=\'Enter option no 2\']")).sendKeys("Discovery, Formulation, Development");Thread.sleep(2000);
    driver.findElement(By.xpath("//i[@class=\'fa fa-plus-circle\']")).click();Thread.sleep(2000);
    driver.findElement(By.xpath("//input[@placeholder=\'Enter option no 3\']")).click();Thread.sleep(2000);
    driver.findElement(By.xpath("//input[@placeholder=\'Enter option no 3\']")).sendKeys("Discovery, Formulation, Automation");Thread.sleep(2000);
    driver.findElement(By.xpath("//i[@class=\'fa fa-times\']")).click();Thread.sleep(2000);
    driver.findElement(By.xpath("//button[@class=\'btn-primary modal-error-btny\']")).click();Thread.sleep(2000);
    driver.findElement(By.xpath("//input[@value=\'Difficult\']")).click();Thread.sleep(2000);
    driver.findElement(By.xpath("//span[normalize-space()=\'Save\']")).click();Thread.sleep(2000);
    driver.findElement(By.xpath("//div[1]/div[2]/div[1]/div[1]/div[2]/div[3]/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/div[2]/div[3]/div[3]/div[2]/div[2]/input[1]")).click();Thread.sleep(2000);
    driver.findElement(By.xpath("//span[normalize-space()=\'Save\']")).click();
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@role=\'alert\']")));Thread.sleep(2000);
	driver.findElement(By.xpath("//div[@role=\'alert\']")).click();
    Thread.sleep(2000);
    
    /* Edit Questions */
    driver.findElement(By.xpath("//div[1]/div[2]/div[1]/div[1]/div[2]/div[3]/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/div[2]/div[3]/div[4]/button[1]/i[1]")).click();Thread.sleep(2000);
    driver.findElement(By.xpath("//textarea[@placeholder=\'Enter Question Content Here...\']")).click();Thread.sleep(2000);
    driver.findElement(By.xpath("//textarea[@placeholder=\'Enter Question Content Here...\']")).clear();Thread.sleep(2000);
    driver.findElement(By.xpath("//textarea[@placeholder=\'Enter Question Content Here...\']")).sendKeys("Why are you always Editing? Don't you have any other work?");Thread.sleep(2000);
    driver.findElement(By.xpath("//i[@class=\'fa fa-plus-circle\']")).click();Thread.sleep(2000);
    driver.findElement(By.xpath("//input[@placeholder=\'Enter option no 4\']")).click();Thread.sleep(2000);
    driver.findElement(By.xpath("//input[@placeholder=\'Enter option no 4\']")).clear();Thread.sleep(2000);
    driver.findElement(By.xpath("//input[@placeholder=\'Enter option no 4\']")).sendKeys("Barbeque Driven Discussion");Thread.sleep(2000);
    driver.findElement(By.xpath("//button[@title='Update Question']")).click();
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@role=\'alert\']")));Thread.sleep(2000);
	driver.findElement(By.xpath("//div[@role=\'alert\']")).click();
    Thread.sleep(2000);
    
    /* Logout */
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//i[@class='fa fa-sign-out menu-logout-icon']")));
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//i[@class='fa fa-sign-out menu-logout-icon']")));Thread.sleep(2000);
    driver.findElement(By.xpath("//i[@class='fa fa-sign-out menu-logout-icon']")).click();
    Thread.sleep(2000);
}
}
