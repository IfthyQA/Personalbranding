package assessmentTechnical;

import java.io.IOException;
import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import screenshotOnFailure.FailScreenshot;

@Listeners(screenshotListners.EventList.class)
public class T4_Upload_Questions extends FailScreenshot{

	  	@Test
	  	public void TA_UploadQns_AddtoBank() throws InterruptedException, IOException{
	  	
  		/* Login to the Application - PBC */ 		
	  	driver.findElement(By.xpath("(//button[normalize-space()='Login'])[1]")).click();
  		driver.findElement(By.xpath("//input[@id='Username']")).click();
  		driver.findElement(By.xpath("//input[@id='Username']")).sendKeys("john.doe005");
  		driver.findElement(By.xpath("//input[@id='password-field']")).click();
  		driver.findElement(By.xpath("//input[@id='password-field']")).sendKeys("Rockon123");
  		driver.findElement(By.xpath("//button[@id='loginButton']")).click();
  		Thread.sleep(2000);
  		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(120));
	    
	    /* Naviagte to the Business Page */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[normalize-space()='Business Automati...']")));
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()='Business Automati...']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//span[normalize-space()='Business Automati...']")).click();
	    Thread.sleep(2000);
	    
	    /* Navigate to the Technical Assessment */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[normalize-space()=\'Administer Test\']")));
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()=\'Administer Test\']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//span[normalize-space()=\'Administer Test\']")).click();
	    Thread.sleep(2000);
	    
	    /* Create New Test - Job Association */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[normalize-space()=\'Create New Test\']")));
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[normalize-space()=\'Create New Test\']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//button[normalize-space()=\'Create New Test\']")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".close > span")).click();Thread.sleep(2000);
	    
	    /* Upload Question and Cancel */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[1]/div[2]/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/a[3]/div[1]/span[2]")));
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[1]/div[2]/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/a[3]/div[1]/span[2]")));Thread.sleep(2000);
		driver.findElement(By.xpath("//div[1]/div[2]/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/a[3]/div[1]/span[2]")).click();
		Thread.sleep(2000);
	    driver.findElement(By.xpath("//span[contains(.,\'Upload Questions\')]")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".backButton > .margin-left-5")).click();Thread.sleep(2000);
	    
	    /* Upload Question */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[1]/div[2]/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/a[3]/div[1]/span[2]")));
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[1]/div[2]/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/a[3]/div[1]/span[2]")));Thread.sleep(2000);
		driver.findElement(By.xpath("//div[1]/div[2]/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/a[3]/div[1]/span[2]")).click();Thread.sleep(2000);
		driver.findElement(By.xpath("//span[contains(.,\'Upload Questions\')]")).click();Thread.sleep(2000);
		
		/* Invalid Question */
		driver.findElement(By.xpath("//div[@class=\'labelText\']")).click();Thread.sleep(2000);
		Runtime.getRuntime().exec("C:\\Users\\dev\\Documents\\AutoScripts\\Question1.exe");Thread.sleep(2000);
		driver.findElement(By.xpath("//button[@class='margin-right-10 modal-error-btnn']")).click();Thread.sleep(2000);
		
		/* Valid Question */
		driver.findElement(By.xpath("//div[@class=\'labelText\']")).click();Thread.sleep(9000);
		Runtime.getRuntime().exec("C:\\Users\\dev\\Documents\\AutoScripts\\Question.exe");
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@role=\'alert\']")));Thread.sleep(2000);
		driver.findElement(By.xpath("//div[@role=\'alert\']")).click();  
		Thread.sleep(2000);
		
		/* Add Questions - Qustion Bank */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[@title=\'Delete Skill\']//i[@class=\'fa fa-trash\']")));
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[@title=\'Delete Skill\']//i[@class=\'fa fa-trash\']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//button[@title=\'Delete Skill\']//i[@class=\'fa fa-trash\']")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("//button[@class=\'btn-primary modal-error-btny\']")).click();Thread.sleep(2000);
	    driver.findElement(By.xpath("//span[normalize-space()=\'Add to Question Bank\']")).click();Thread.sleep(2000);
	    driver.findElement(By.xpath("//button[@class=\'btn-primary noBtn\']")).click();Thread.sleep(2000);
	    driver.findElement(By.xpath("//span[normalize-space()=\'Add to Question Bank\']")).click();Thread.sleep(2000);
	    driver.findElement(By.xpath("//button[@class=\'margin-right-15 yesBtn\']")).click();
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@role=\'alert\']")));Thread.sleep(2000);
		driver.findElement(By.xpath("//div[@role=\'alert\']")).click();
	    Thread.sleep(2000);
	    
	    /* Sign Out */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//i[@class='fa fa-sign-out menu-logout-icon']")));
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//i[@class='fa fa-sign-out menu-logout-icon']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//i[@class='fa fa-sign-out menu-logout-icon']")).click();
	    Thread.sleep(2000);
	  	}
  	}






