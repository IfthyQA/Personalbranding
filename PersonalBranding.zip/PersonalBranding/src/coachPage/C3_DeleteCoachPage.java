package coachPage;

import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import screenshotOnFailure.FailScreenshot;

@Listeners(screenshotListners.EventList.class)
public class C3_DeleteCoachPage extends FailScreenshot{

@Test
public void CP_DeleteCoachPage() throws InterruptedException {
		
	/* Login to the Application - PBC */ 		
  	driver.findElement(By.xpath("(//button[normalize-space()='Login'])[1]")).click();
	driver.findElement(By.xpath("//input[@id='Username']")).click();
	driver.findElement(By.xpath("//input[@id='Username']")).sendKeys("test.doe001");
	driver.findElement(By.xpath("//input[@id='password-field']")).click();
	driver.findElement(By.xpath("//input[@id='password-field']")).sendKeys("Rockon123");
	driver.findElement(By.xpath("//button[@id='loginButton']")).click();
	Thread.sleep(2000);
	WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(120));
	
	/* Delete Created Coach Page */  
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[normalize-space()='Redo Coach Basic']")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()='Redo Coach Basic']")));Thread.sleep(2000);
    driver.findElement(By.xpath("//span[normalize-space()='Redo Coach Basic']")).click();
	Thread.sleep(2000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//div[contains(text(),'Settings')])[1]")));
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//div[contains(text(),'Settings')])[1]")));Thread.sleep(2000);
	driver.findElement(By.xpath("(//div[contains(text(),'Settings')])[1]")).click();
	Thread.sleep(2000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".btn-outline-grey")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".btn-outline-grey")));Thread.sleep(2000);
	driver.findElement(By.cssSelector(".btn-outline-grey")).click();
	Thread.sleep(2000);
	wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector("form > #btnYesConfirmYesNo")));Thread.sleep(2000);
	driver.findElement(By.cssSelector("form > #btnYesConfirmYesNo")).click();
	Thread.sleep(2000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("Password")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.id("Password")));Thread.sleep(2000);
	driver.findElement(By.id("Password")).click();
	driver.findElement(By.id("Password")).sendKeys("Rockon123");
	Thread.sleep(2000);
	wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector("form > #btnYesConfirmYesNo")));Thread.sleep(2000);
	driver.findElement(By.cssSelector("form > #btnYesConfirmYesNo")).click();
    wait.until(ExpectedConditions.invisibilityOfElementLocated(By.cssSelector("form > #btnYesConfirmYesNo")));
	Thread.sleep(2000);
	
	/* Logout from Account */
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'My Profile')]")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'My Profile')]")));Thread.sleep(2000);
	driver.findElement(By.xpath("//div[contains(text(),'My Profile')]")).click();  
	Thread.sleep(2000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//div[contains(text(),'Logout')])[1]")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//div[contains(text(),'Logout')])[1]")));Thread.sleep(2000);
	driver.findElement(By.xpath("(//div[contains(text(),'Logout')])[1]")).click();  
	Thread.sleep(2000);
	}
}
