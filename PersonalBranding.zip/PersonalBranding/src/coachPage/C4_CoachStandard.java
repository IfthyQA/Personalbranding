package coachPage;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import screenshotOnFailure.FailScreenshot;

@Listeners(screenshotListners.EventList.class)
public class C4_CoachStandard extends FailScreenshot{

	@Test
	public void CP_CoachStandard() throws InterruptedException {
		
	/* Login to the Application - PBC */ 		
	driver.findElement(By.xpath("(//button[normalize-space()='Login'])[1]")).click();
	driver.findElement(By.xpath("//input[@id='Username']")).click();
	driver.findElement(By.xpath("//input[@id='Username']")).sendKeys("test.doe001");
	driver.findElement(By.xpath("//input[@id='password-field']")).click();
	driver.findElement(By.xpath("//input[@id='password-field']")).sendKeys("Rockon123");
	driver.findElement(By.xpath("//button[@id='loginButton']")).click();
	Thread.sleep(2000);
	WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(120));

	/* Create Coach Page from the  Hub */    
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[normalize-space()='Create a Business']")));
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[normalize-space()='Create a Business']")));Thread.sleep(2000);
    driver.findElement(By.xpath("//button[normalize-space()='Create a Business']")).click();
    Thread.sleep(2000);
    driver.findElement(By.xpath("//span[normalize-space()='COACH']")).click();
    Thread.sleep(2000);
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("Name")));
    wait.until(ExpectedConditions.elementToBeClickable(By.id("Name")));Thread.sleep(2000);
    driver.findElement(By.id("Name")).click();
    driver.findElement(By.id("Name")).sendKeys("Redo Coach Standard");
    Thread.sleep(2000);
    driver.findElement(By.id("BusinessTag")).click();
    driver.findElement(By.id("BusinessTag")).sendKeys("Do something Repeatedly, One day you will be master in it!");
    Thread.sleep(2000);
    driver.findElement(By.id("WebsiteUrl")).click();
    driver.findElement(By.id("WebsiteUrl")).sendKeys("www.redocoach.com");
    Thread.sleep(2000);
    driver.findElement(By.id("Description")).click();
    driver.findElement(By.id("Description")).sendKeys("I am a UIUX Designer by trade, and a tech, art, and design enthusiast at heart. After a fulfilling career as a professor of art and design at Syracuse University (2011-2016), I transitioned professionally into software development - a longstanding, very serious passion of mine. The combination of analytical abilities, conceptual breadth, passion for mentoring others and deep research skills that defined my work in academia informs my approach to programming. A precise understanding of the consultative and");
    Thread.sleep(2000);    
    driver.findElement(By.xpath("//div[@class='filter-option-inner-inner']")).click();
    Thread.sleep(2000);   
    driver.findElement(By.xpath("//input[@aria-label='Search']")).click();
    Thread.sleep(2000);   
    driver.findElement(By.xpath("//input[@aria-label='Search']")).sendKeys("busin");
    Thread.sleep(2000);
    driver.findElement(By.xpath("//input[@aria-label='Search']")).sendKeys(Keys.ENTER);
    Thread.sleep(2000);   
    driver.findElement(By.xpath("//div[@class='filter-option-inner-inner']")).click();
    Thread.sleep(2000);   
    driver.findElement(By.xpath("//input[@aria-label='Search']")).click();
    Thread.sleep(2000);   
    driver.findElement(By.xpath("//input[@aria-label='Search']")).sendKeys("Education");
    Thread.sleep(2000);
    driver.findElement(By.xpath("//input[@aria-label='Search']")).sendKeys(Keys.ENTER);
    Thread.sleep(2000);   
    driver.findElement(By.xpath("//div[@class='filter-option-inner-inner']")).click();
    Thread.sleep(2000);   
    driver.findElement(By.xpath("//input[@aria-label='Search']")).click();
    Thread.sleep(2000);   
    driver.findElement(By.xpath("//input[@aria-label='Search']")).sendKeys("Fina");
    Thread.sleep(2000);
    driver.findElement(By.xpath("//input[@aria-label='Search']")).sendKeys(Keys.ENTER);
    Thread.sleep(2000);
    driver.findElement(By.xpath("//a[@class='tagit-close']")).click();
    Thread.sleep(2000);
    driver.findElement(By.xpath("//div[@class='filter-option-inner-inner']")).click();
    Thread.sleep(2000);   
    driver.findElement(By.xpath("//input[@aria-label='Search']")).click();
    Thread.sleep(2000);   
    driver.findElement(By.xpath("//input[@aria-label='Search']")).sendKeys("busin");
    Thread.sleep(2000);
    driver.findElement(By.xpath("//input[@aria-label='Search']")).sendKeys(Keys.ENTER);
    Thread.sleep(2000);  
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[@id='biz-form-btn']")));Thread.sleep(2000);
    driver.findElement(By.xpath("//button[@id='biz-form-btn']")).click();
    Thread.sleep(2000);
  
	/* Subscription Standard Trail with Coupons */
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".modal-md .fa")));
	wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".modal-md .fa")));Thread.sleep(2000);
	driver.findElement(By.cssSelector(".modal-md .fa")).click();
	Thread.sleep(2000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.linkText("Subscription & Orders")));
	wait.until(ExpectedConditions.elementToBeClickable(By.linkText("Subscription & Orders")));Thread.sleep(2000);
	driver.findElement(By.linkText("Subscription & Orders")).click();
	Thread.sleep(2000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".col-centered > .btn-sm")));
	wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".col-centered > .btn-sm")));Thread.sleep(2000);
	driver.findElement(By.cssSelector(".col-centered > .btn-sm")).click();
	Thread.sleep(2000);
	
	/* Standard Trail */
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("td:nth-child(3) > .biz-plans-head .btn-sm")));
	wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector("td:nth-child(3) > .biz-plans-head .btn-sm")));Thread.sleep(2000);
	driver.findElement(By.cssSelector("td:nth-child(3) > .biz-plans-head .btn-sm")).click();
	Thread.sleep(2000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("#btnBillingDetails > .fa")));
	wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector("#btnBillingDetails > .fa")));Thread.sleep(2000);
	driver.findElement(By.cssSelector("#btnBillingDetails > .fa")).click();
	Thread.sleep(2000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".col-5 > .btn-sm")));
	wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".col-5 > .btn-sm")));Thread.sleep(2000);
	driver.findElement(By.cssSelector(".col-5 > .btn-sm")).click();
	Thread.sleep(2000);
	driver.findElement(By.xpath("//input[@id=\'CouponCode\']")).click();
	driver.findElement(By.xpath("//input[@id=\'CouponCode\']")).sendKeys("IULyaLR1Vt");
	Thread.sleep(2000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".col-5 > .btn-sm")));
	wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".col-5 > .btn-sm")));Thread.sleep(2000);
	driver.findElement(By.cssSelector(".col-5 > .btn-sm")).click();
	Thread.sleep(2000);
	
	/* Navigating to Paypal */
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("paypalRadioBtn")));
	wait.until(ExpectedConditions.elementToBeClickable(By.id("paypalRadioBtn")));Thread.sleep(2000);
	driver.findElement(By.id("paypalRadioBtn")).click();
	Thread.sleep(2000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//img[@alt='Pay with PayPal']")));
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//img[@alt='Pay with PayPal']")));
	Thread.sleep(2000);
    String winHandleBefore = driver.getWindowHandle();
    driver.findElement(By.xpath("//img[@alt='Pay with PayPal']")).click();
    Thread.sleep(2000);
    for(String winHandle : driver.getWindowHandles()){
	        driver.switchTo().window(winHandle); 
    }
    Thread.sleep(2000);     /* Pay thru Paypal */
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[@id='return_url']")));
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[@id='return_url']")));
    driver.findElement(By.xpath("//a[@id='return_url']")).click();
    Thread.sleep(2000);
    driver.switchTo().window(winHandleBefore);
    Thread.sleep(2000);
    
    /* Click Review Order after PayPal Payment */
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[contains(text(),\'Review Order\')]")));
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[contains(text(),\'Review Order\')]")));Thread.sleep(2000);	
	driver.findElement(By.xpath("//span[contains(text(),\'Review Order\')]")).click();
	Thread.sleep(2000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[contains(text(),\'Complete Order\')]")));
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[contains(text(),\'Complete Order\')]")));Thread.sleep(2000);	
	driver.findElement(By.xpath("//span[contains(text(),\'Complete Order\')]")).click();Thread.sleep(2000);
	Thread.sleep(2000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[contains(text(),\'Okay\')]")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[contains(text(),\'Okay\')]")));Thread.sleep(2000);	
	driver.findElement(By.xpath("//span[contains(text(),\'Okay\')]")).click();
	Thread.sleep(2000);
	
	/* Page will Navigate to Coach Verification & CLOSE - Coach Verification Window */
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[@aria-label='Close']//i[@class='fa fa-times']")));
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[@aria-label='Close']//i[@class='fa fa-times']")));Thread.sleep(1500);
	driver.findElement(By.xpath("//a[@aria-label='Close']//i[@class='fa fa-times']")).click();
	Thread.sleep(1500);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[normalize-space()='Menu']")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()='Menu']")));Thread.sleep(2000);
    driver.findElement(By.xpath("//span[normalize-space()='Menu']")).click();
    Thread.sleep(2000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[normalize-space()='Subscription']")));
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[normalize-space()='Subscription']")));Thread.sleep(2000);
	driver.findElement(By.xpath("//a[normalize-space()='Subscription']")).click();
	JavascriptExecutor jse = (JavascriptExecutor)driver;
	
	/* Cancel the Trail Subscription */
	Thread.sleep(2000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.linkText("Subscription & Orders")));
	wait.until(ExpectedConditions.elementToBeClickable(By.linkText("Subscription & Orders")));Thread.sleep(2000);
	driver.findElement(By.linkText("Subscription & Orders")).click();
	Thread.sleep(2000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[normalize-space()=\'Cancel Subscription\']")));
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()=\'Cancel Subscription\']")));Thread.sleep(2000);
	driver.findElement(By.xpath("//span[normalize-space()=\'Cancel Subscription\']")).click();
	Thread.sleep(2000);
	driver.findElement(By.cssSelector(".btn-outline-maroon")).click();
	wait.until(ExpectedConditions.invisibilityOfElementLocated(By.cssSelector(".btn-outline-maroon")));
	Thread.sleep(2000);
	
	/* Purchase Standard with Coupons */
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".col-centered > .btn-sm")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".col-centered > .btn-sm")));Thread.sleep(2000);
	driver.findElement(By.cssSelector(".col-centered > .btn-sm")).click();
	Thread.sleep(2000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("td:nth-child(3) > .biz-plans-head .btn-sm")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector("td:nth-child(3) > .biz-plans-head .btn-sm")));Thread.sleep(2000);
	driver.findElement(By.cssSelector("td:nth-child(3) > .biz-plans-head .btn-sm")).click();
	Thread.sleep(2000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".col-5 > .btn-sm")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".col-5 > .btn-sm")));Thread.sleep(2000);
	driver.findElement(By.cssSelector(".col-5 > .btn-sm")).click();
	Thread.sleep(2000);
	driver.findElement(By.xpath("//input[@id=\'CouponCode\']")).click();
	driver.findElement(By.xpath("//input[@id=\'CouponCode\']")).sendKeys("fyjmDCbIAD");
	Thread.sleep(2000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".col-5 > .btn-sm")));
	wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".col-5 > .btn-sm")));Thread.sleep(2000);
	driver.findElement(By.cssSelector(".col-5 > .btn-sm")).click();
	Thread.sleep(2000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[contains(text(),\'Review Order\')]")));
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[contains(text(),\'Review Order\')]")));Thread.sleep(2000);	
	driver.findElement(By.xpath("//span[contains(text(),\'Review Order\')]")).click();
	Thread.sleep(2000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[contains(text(),\'Complete Order\')]")));
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[contains(text(),\'Complete Order\')]")));Thread.sleep(2000);
	driver.findElement(By.xpath("//span[contains(text(),\'Complete Order\')]")).click();
	Thread.sleep(2000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[contains(text(),\'Okay\')]")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[contains(text(),\'Okay\')]")));Thread.sleep(2000);
	driver.findElement(By.xpath("//span[contains(text(),\'Okay\')]")).click();
	
	/* Naviagte to the Business Hub */
	Thread.sleep(2000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[@aria-label='Close']//i[@class='fa fa-times']")));
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[@aria-label='Close']//i[@class='fa fa-times']")));Thread.sleep(1500);
	driver.findElement(By.xpath("//a[@aria-label='Close']//i[@class='fa fa-times']")).click();
	Thread.sleep(1500);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[normalize-space()='Menu']")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()='Menu']")));Thread.sleep(2000);
    driver.findElement(By.xpath("//span[normalize-space()='Menu']")).click();
    Thread.sleep(2000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[normalize-space()='Coaching Services']")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[normalize-space()='Coaching Services']")));
    Thread.sleep(2000);
	driver.navigate().refresh();
	Thread.sleep(2000);
	jse.executeScript("window.scrollBy(0,250)");
	
	/* Observe the Reciept from bottom of the page */
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[normalize-space()='Menu']")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()='Menu']")));Thread.sleep(2000);
    driver.findElement(By.xpath("//span[normalize-space()='Menu']")).click();
    Thread.sleep(2000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[normalize-space()='Payments']")));
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[normalize-space()='Payments']")));Thread.sleep(2000);
	driver.findElement(By.xpath("//a[normalize-space()='Payments']")).click();
	Thread.sleep(2000);
	driver.navigate().refresh();
	Thread.sleep(2000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@id=\'divAddPaymentMethod\']//button[@type=\'button\']")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@id=\'divAddPaymentMethod\']//button[@type=\'button\']")));
	Thread.sleep(2000);
	jse.executeScript("window.scrollBy(0,250)");
	Thread.sleep(2000);
	WebElement element = driver.findElement(By.cssSelector(".fa-plus-circle"));
	jse.executeScript("arguments[0].scrollIntoView();", element);Thread.sleep(2000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".fa-plus-circle")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".fa-plus-circle")));Thread.sleep(2000);
	driver.findElement(By.cssSelector(".fa-plus-circle")).click();
	Thread.sleep(2000);
	
	/* Delete Page */
	jse.executeScript("window.scrollBy(0,250)");
	Thread.sleep(2000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//div[contains(text(),'Settings')])[1]")));
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//div[contains(text(),'Settings')])[1]")));Thread.sleep(2000);
	driver.findElement(By.xpath("(//div[contains(text(),'Settings')])[1]")).click();
	Thread.sleep(2000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".btn-outline-grey")));
	wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".btn-outline-grey")));Thread.sleep(2000);
	driver.findElement(By.cssSelector(".btn-outline-grey")).click();
	Thread.sleep(2000);
	driver.findElement(By.id("Password")).click();
	driver.findElement(By.id("Password")).sendKeys("Rockon123");
	Thread.sleep(2000);
	wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector("form > #btnYesConfirmYesNo")));Thread.sleep(2000);
	driver.findElement(By.cssSelector("form > #btnYesConfirmYesNo")).click();
    wait.until(ExpectedConditions.invisibilityOfElementLocated(By.cssSelector("form > #btnYesConfirmYesNo")));
	Thread.sleep(2000);
	
	/* Logout from Account */
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'My Profile')]")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'My Profile')]")));Thread.sleep(2000);
	driver.findElement(By.xpath("//div[contains(text(),'My Profile')]")).click();  
	Thread.sleep(2000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//div[contains(text(),'Logout')])[1]")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//div[contains(text(),'Logout')])[1]")));Thread.sleep(2000);
	driver.findElement(By.xpath("(//div[contains(text(),'Logout')])[1]")).click();  
	Thread.sleep(2000);
	}
}
