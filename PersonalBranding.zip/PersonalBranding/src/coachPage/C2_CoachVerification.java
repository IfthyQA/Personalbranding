package coachPage;

import org.testng.annotations.Test;
import java.io.IOException;
import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Listeners;
import screenshotOnFailure.FailScreenshot;
		
	@Listeners(screenshotListners.EventList.class)
	public class C2_CoachVerification extends FailScreenshot{
	
	@Test
	public void CP_CoachVerification() throws InterruptedException, IOException {
			
	/* Login to the Application - PBC */ 		
		driver.findElement(By.xpath("(//button[normalize-space()='Login'])[1]")).click();
		driver.findElement(By.xpath("//input[@id='Username']")).click();
		driver.findElement(By.xpath("//input[@id='Username']")).sendKeys("test.doe001");
		driver.findElement(By.xpath("//input[@id='password-field']")).click();
		driver.findElement(By.xpath("//input[@id='password-field']")).sendKeys("Rockon123");
		driver.findElement(By.xpath("//button[@id='loginButton']")).click();
		Thread.sleep(2000);
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(120));
		
		/* Navigate to the Coach page */   
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[normalize-space()='Redo Coach Basic']")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()='Redo Coach Basic']")));Thread.sleep(2000);
		driver.findElement(By.xpath("//span[normalize-space()='Redo Coach Basic']")).click();
		Thread.sleep(2000);
		
		/* Coach Verification */
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[normalize-space()='Menu']")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()='Menu']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//span[normalize-space()='Menu']")).click();
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[normalize-space()='Coaching Services']")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[normalize-space()='Coaching Services']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//a[normalize-space()='Coaching Services']")).click();
	    Thread.sleep(2000);
		
		/* Submit without Cerificates */
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".col-xl-6 > .btn-sm")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".col-xl-6 > .btn-sm")));Thread.sleep(2000);
		driver.findElement(By.cssSelector(".col-xl-6 > .btn-sm")).click();
		Thread.sleep(2000);
		wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".toast-message")));
		driver.findElement(By.cssSelector(".toast-message")).click();
		
		/* Upload FAKE Certificate - 3 Times */
		driver.findElement(By.xpath("//div[@id=\'modalCoachVerification\']//div[@class=\'row\']//div[1]//div[1]//div[2]//button[1]")).click();
		Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[contains(.,\' Attach\')]")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[contains(.,\' Attach\')]")));Thread.sleep(2000);
		driver.findElement(By.xpath("//span[contains(.,\' Attach\')]")).click();Thread.sleep(2000);
		driver.findElement(By.xpath("//span[contains(.,\'Local Device\')]")).click();
		Thread.sleep(2000);
		Runtime.getRuntime().exec("C:\\Users\\dev\\Documents\\AutoScripts\\Upload.exe");  
		Thread.sleep(2000);
		wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".toast-message")));
		driver.findElement(By.cssSelector(".toast-message")).click();
		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[contains(.,\' Attach\')]")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[contains(.,\' Attach\')]")));Thread.sleep(2000);
		driver.findElement(By.xpath("//span[contains(.,\' Attach\')]")).click();Thread.sleep(2000);
		driver.findElement(By.xpath("//span[contains(.,\'Local Device\')]")).click();
		Thread.sleep(2000);
		Runtime.getRuntime().exec("C:\\Users\\dev\\Documents\\AutoScripts\\Upload.exe");  
		Thread.sleep(2000);
		wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".toast-message")));
		driver.findElement(By.cssSelector(".toast-message")).click();
		
		/* 3rd Time Fake Certificate - Modal Pop-up */
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[contains(.,\' Attach\')]")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[contains(.,\' Attach\')]")));Thread.sleep(2000);
		driver.findElement(By.xpath("//span[contains(.,\' Attach\')]")).click();Thread.sleep(2000);
		driver.findElement(By.xpath("//span[contains(.,\'Local Device\')]")).click();
		Thread.sleep(2000);
		Runtime.getRuntime().exec("C:\\Users\\dev\\Documents\\AutoScripts\\Upload.exe");	  
		Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".btn-sm:nth-child(3)")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".btn-sm:nth-child(3)")));Thread.sleep(2000);
		driver.findElement(By.cssSelector(".btn-sm:nth-child(3)")).click();
		Thread.sleep(2000);
		
		/* From 4th Time Accept any File - Certificate */
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[contains(.,\' Attach\')]")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[contains(.,\' Attach\')]")));Thread.sleep(2000);
		driver.findElement(By.xpath("//span[contains(.,\' Attach\')]")).click();Thread.sleep(2000);
		driver.findElement(By.xpath("//span[contains(.,\'Local Device\')]")).click();
		Thread.sleep(2000);
		Runtime.getRuntime().exec("C:\\Users\\dev\\Documents\\AutoScripts\\Upload.exe");	  
		Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@id=\'outfineuploader\']/div/span/i[2]")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@id=\'outfineuploader\']/div/span/i[2]")));Thread.sleep(2000);
		driver.findElement(By.xpath("//div[@id=\'outfineuploader\']/div/span/i[2]")).click();Thread.sleep(2000);
		
		/* Valid - Upload Certificate */
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[contains(.,\' Attach\')]")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[contains(.,\' Attach\')]")));Thread.sleep(2000);
		driver.findElement(By.xpath("//span[contains(.,\' Attach\')]")).click();Thread.sleep(2000);
		driver.findElement(By.xpath("//span[contains(.,\'Local Device\')]")).click();
		Thread.sleep(2000);
		Runtime.getRuntime().exec("C:\\Users\\dev\\Documents\\AutoScripts\\Coach_Certificate.exe");
		Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@id=\'outfineuploader\']/div/span/i[2]")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@id=\'outfineuploader\']/div/span/i[2]")));Thread.sleep(2000);
		driver.findElement(By.cssSelector(".btnDone")).click();
		Thread.sleep(2000);
		
		/* Fake Upload Photo ID - 3 times */
		driver.findElement(By.xpath("//div[@class=\'col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12\']//div[2]//div[1]//div[2]//button[1]//span[1]")).click();
		Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[contains(.,\' Attach\')]")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[contains(.,\' Attach\')]")));Thread.sleep(2000);
		driver.findElement(By.xpath("//span[contains(.,\' Attach\')]")).click();Thread.sleep(2000);
		driver.findElement(By.xpath("//span[contains(.,\'Local Device\')]")).click();
		Thread.sleep(2000);
		Runtime.getRuntime().exec("C:\\Users\\dev\\Documents\\AutoScripts\\PhotoID.exe");
		Thread.sleep(2000);
		wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".toast-message")));
		driver.findElement(By.cssSelector(".toast-message")).click();
		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[contains(.,\' Attach\')]")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[contains(.,\' Attach\')]")));Thread.sleep(2000);
		driver.findElement(By.xpath("//span[contains(.,\' Attach\')]")).click();Thread.sleep(2000);
		driver.findElement(By.xpath("//span[contains(.,\'Local Device\')]")).click();
		Thread.sleep(2000);
		Runtime.getRuntime().exec("C:\\Users\\dev\\Documents\\AutoScripts\\PhotoID.exe");
		Thread.sleep(2000);
		wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".toast-message")));
		driver.findElement(By.cssSelector(".toast-message")).click();
		
		/* 3rd time Fake Photo ID _ Modal Pop Up */
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[contains(.,\' Attach\')]")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[contains(.,\' Attach\')]")));Thread.sleep(2000);
		driver.findElement(By.xpath("//span[contains(.,\' Attach\')]")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//span[contains(.,\'Local Device\')]")).click();
		Thread.sleep(2000);
		Runtime.getRuntime().exec("C:\\Users\\dev\\Documents\\AutoScripts\\PhotoID.exe");
		Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".search-modal .fa")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".search-modal .fa")));Thread.sleep(2000);
		driver.findElement(By.cssSelector(".search-modal .fa")).click();Thread.sleep(2000);
		
		/* From 4th Time Accept any File - Fake Photo ID */
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[contains(.,\' Attach\')]")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[contains(.,\' Attach\')]")));Thread.sleep(2000);
		driver.findElement(By.xpath("//span[contains(.,\' Attach\')]")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//span[contains(.,\'Local Device\')]")).click();
		Thread.sleep(2000);
		Runtime.getRuntime().exec("C:\\Users\\dev\\Documents\\AutoScripts\\PhotoID.exe");	  
		Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@id=\'outfineuploader\']/div/span/i[2]")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@id=\'outfineuploader\']/div/span/i[2]")));Thread.sleep(2000);
		driver.findElement(By.xpath("//div[@id=\'outfineuploader\']/div/span/i[2]")).click();
		Thread.sleep(2000);
		
		/* Valid - Upload Photo ID */
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[contains(.,\' Attach\')]")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[contains(.,\' Attach\')]")));Thread.sleep(2000);
		driver.findElement(By.xpath("//span[contains(.,\' Attach\')]")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//span[contains(.,\'Local Device\')]")).click();
		Thread.sleep(2000);
		Runtime.getRuntime().exec("C:\\Users\\dev\\Documents\\AutoScripts\\Coach_PhotoID.exe");Thread.sleep(2000);
		Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@id=\'outfineuploader\']/div/span/i[2]")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@id=\'outfineuploader\']/div/span/i[2]")));
		Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".btnDone")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".btnDone")));Thread.sleep(2000);
		driver.findElement(By.cssSelector(".btnDone")).click();
		Thread.sleep(2000);
		
		/* Add Certificate and School Name */
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("CoachCertificateViewModel_CertificateName")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.id("CoachCertificateViewModel_CertificateName")));Thread.sleep(2000);
		driver.findElement(By.id("CoachCertificateViewModel_CertificateName")).click();
		driver.findElement(By.id("CoachCertificateViewModel_CertificateName")).clear();Thread.sleep(2000);
		driver.findElement(By.id("CoachCertificateViewModel_CertificateName")).sendKeys("Selenium Cert");
		Thread.sleep(2000);
		driver.findElement(By.cssSelector(".col-12:nth-child(2) > .form-group > label")).click();
		Thread.sleep(2000);
		driver.findElement(By.id("CoachCertificateViewModel_School")).clear();Thread.sleep(2000);
		driver.findElement(By.id("CoachCertificateViewModel_School")).sendKeys("SpaceX School");
		Thread.sleep(2000);
		driver.findElement(By.cssSelector(".divStartDatePicker label")).click();
		Thread.sleep(2000);
		driver.findElement(By.cssSelector(".year:nth-child(2)")).click();
		Thread.sleep(2000);
		driver.findElement(By.cssSelector(".month:nth-child(1)")).click();
		Thread.sleep(2000);
		driver.findElement(By.id("CoachCertificateViewModel_IsOnGoing")).click();
		Thread.sleep(2000);
		driver.findElement(By.id("CoachCertificateViewModel_IsAddToEducation")).click();
		Thread.sleep(2000);
		wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".col-xl-6 > .btn-sm")));Thread.sleep(2000);
		driver.findElement(By.cssSelector(".col-xl-6 > .btn-sm")).click();
		Thread.sleep(2000);
		
		/* Receiving Payment Details */
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("select2-AccountType-container")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.id("select2-AccountType-container")));Thread.sleep(2000);
		driver.findElement(By.id("select2-AccountType-container")).click();
		Thread.sleep(2000);
		driver.findElement(By.cssSelector(".select2-search__field")).click();
		driver.findElement(By.cssSelector(".select2-search__field")).sendKeys("person");
		Thread.sleep(2000);
		driver.findElement(By.cssSelector(".select2-search__field")).sendKeys(Keys.ENTER);
		Thread.sleep(2000);
		driver.findElement(By.cssSelector(".select2-search__field")).click();
		driver.findElement(By.cssSelector(".select2-search__field")).sendKeys("stat");
		Thread.sleep(2000);
		driver.findElement(By.cssSelector(".select2-search__field")).sendKeys(Keys.ENTER);
		Thread.sleep(2000);
		wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".col-md-12 > .btn-sm")));Thread.sleep(2000);
		driver.findElement(By.cssSelector(".col-md-12 > .btn-sm")).click();
		Thread.sleep(2000);		
		
		/* Navigating back to the PBC and then Business page */
		driver.navigate().back();
		Thread.sleep(2000);
		
		//			/* Test Mode - Phone and Email */
		//			wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("phone")));	
		//			wait.until(ExpectedConditions.elementToBeClickable(By.id("phone")));
		//			Thread.sleep(2000);	
		//			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[contains(text(),'the test phone number')]")));	
		//			wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[contains(text(),'the test phone number')]")));Thread.sleep(2000);
		//			driver.findElement(By.xpath("//span[contains(text(),'the test phone number')]")).click();
		//			Thread.sleep(2000);
		//			wait.until(ExpectedConditions.elementToBeClickable(By.id("email")));Thread.sleep(2000);
		//			driver.findElement(By.id("email")).click();
		//			driver.findElement(By.id("email")).sendKeys("ifthy@test.com");
		//			Thread.sleep(2000);
		//			wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[contains(text(),'Continue')]")));Thread.sleep(2000);
		//			driver.findElement(By.xpath("//span[contains(text(),'Continue')]")).click();
		//			Thread.sleep(2000);
		//			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[contains(text(),'Resend message')]")));	
		//			wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[contains(text(),'Resend message')]")));Thread.sleep(2000);
		//			driver.findElement(By.xpath("//span[contains(text(),'Resend message')]")).click();
		//			Thread.sleep(2000);
		//			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[contains(text(),'Use test code')]")));	
		//			wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[contains(text(),'Use test code')]")));Thread.sleep(2000);
		//			driver.findElement(By.xpath("//span[contains(text(),'Use test code')]")).click();
		//			Thread.sleep(2000);
		//		
		//			/* Return from STRIPE Page */
		//			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[contains(text(),'Return to Achnet Inc')]")));	
		//			wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[contains(text(),'Return to Achnet Inc')]")));Thread.sleep(2000);
		//			driver.findElement(By.xpath("//span[contains(text(),'Return to Achnet Inc')]")).click();
		//			Thread.sleep(2000);
		//				
		//			try 
		//			{           
		//	            Alert alert = driver.switchTo().alert(); // Check for the presence of an alert
		//	           
		//	            System.out.println("Alert is present!");  // If an alert is present, handle it by clicking OK
		//	            alert.accept();
		//	        } 
		//			catch (Exception e) 
		//			{         
		//	            System.out.println("No alert is present. Moving on to the next element."); // No alert is present, move on to the next element
		//	           
		//	            WebElement button = driver.findElement(By.xpath("//input[@id='AccountNumber']"));  // Example: Click on a button
		//	            button.click();
		//	        }	
		
		/* Navbigate to Coach VErification Menu*/
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[normalize-space()='Menu']")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()='Menu']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//span[normalize-space()='Menu']")).click();
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[normalize-space()='Coaching Services']")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[normalize-space()='Coaching Services']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//a[normalize-space()='Coaching Services']")).click();
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("menuitemverification")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.id("menuitemverification")));Thread.sleep(2000);
		driver.findElement(By.id("menuitemverification")).click();
		Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@title='Redo Coach Basic']")));	// Business Hub Logo Bavigation
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@title='Redo Coach Basic']")));Thread.sleep(2000);
		driver.findElement(By.xpath("//div[@title='Redo Coach Basic']")).click();
		Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[normalize-space()='Menu']")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()='Menu']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//span[normalize-space()='Menu']")).click();
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[normalize-space()='Payments']")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[normalize-space()='Payments']")));Thread.sleep(2000);
		driver.findElement(By.xpath("//a[normalize-space()='Payments']")).click();
		Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[normalize-space()='RECEIVING BANK']")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()='RECEIVING BANK']")));Thread.sleep(2000);
		driver.findElement(By.xpath("//span[normalize-space()='RECEIVING BANK']")).click();
		Thread.sleep(2000);	
			
		/* Account and Routing Number */
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("AccountNumber")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.id("AccountNumber")));Thread.sleep(2000);
		driver.findElement(By.id("AccountNumber")).click();
		driver.findElement(By.id("AccountNumber")).sendKeys("000123456789");
		Thread.sleep(2000);
		driver.findElement(By.cssSelector(".col-12:nth-child(2) > .form-group > label")).click();
		Thread.sleep(2000);
		driver.findElement(By.id("BankAccount_RoutingNumber")).click();
		driver.findElement(By.id("BankAccount_RoutingNumber")).sendKeys("110000000");
		Thread.sleep(2000);
		driver.findElement(By.cssSelector(".col-md-12 > .btn-sm")).click();
		wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".toast-message")));
		driver.findElement(By.cssSelector(".toast-message")).click();
		Thread.sleep(2000);
		
		/* Add one more Bank Account Number - PAYOUT Fails */
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[@id='add-bank']")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[@id='add-bank']")));Thread.sleep(2000);
		driver.findElement(By.xpath("//button[@id='add-bank']")).click();Thread.sleep(2000);
		driver.findElement(By.id("AccountNumber")).click();
		driver.findElement(By.id("AccountNumber")).sendKeys("000111111116");
		Thread.sleep(2000);
		driver.findElement(By.cssSelector(".col-12:nth-child(2) > .form-group > label")).click();
		Thread.sleep(2000);
		driver.findElement(By.id("BankAccount_RoutingNumber")).click();
		driver.findElement(By.id("BankAccount_RoutingNumber")).sendKeys("110000000");
		Thread.sleep(2000);
		driver.findElement(By.cssSelector(".col-md-12 > .btn-sm")).click();Thread.sleep(2000);
		
		/* Make Default */
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".fa-ellipsis-v")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".fa-ellipsis-v")));Thread.sleep(2000);
		driver.findElement(By.cssSelector(".fa-ellipsis-v")).click();
		Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[contains(.,\'Make Default\')]")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[contains(.,\'Make Default\')]")));Thread.sleep(2000);
		driver.findElement(By.xpath("//button[contains(.,\'Make Default\')]")).click();
		wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".toast-message")));
		driver.findElement(By.cssSelector(".toast-message")).click();
		Thread.sleep(2000);
		driver.findElement(By.cssSelector(".fa-ellipsis-v")).click();
		Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[contains(.,\'Make Default\')]")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[contains(.,\'Make Default\')]")));Thread.sleep(2000);
		driver.findElement(By.xpath("//button[contains(.,\'Make Default\')]")).click();
		wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".toast-message")));
		driver.findElement(By.cssSelector(".toast-message")).click();
		
		/* Delete Bank Account */
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".fa-ellipsis-v")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".fa-ellipsis-v")));Thread.sleep(2000);
		driver.findElement(By.cssSelector(".fa-ellipsis-v")).click();
		Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[contains(.,'Delete')]")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[contains(.,'Delete')]")));Thread.sleep(2000);
		driver.findElement(By.xpath("//span[contains(.,'Delete')]")).click();
		Thread.sleep(2000);
		driver.findElement(By.id("btnYesConfirmYesNo")).click();
		wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".toast-message")));
		driver.findElement(By.cssSelector(".toast-message")).click();
		
		/* Edit Bank Information and Retrun from STRIPE */
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[contains(.,\'Edit\')]")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[contains(.,\'Edit\')]")));Thread.sleep(2000);
		driver.findElement(By.xpath("//span[contains(.,\'Edit\')]")).click();
		Thread.sleep(2000);
		driver.navigate().back();
		Thread.sleep(2000);		
		
		/* Make Default */
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[contains(.,'Transfer to Bank')]")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[contains(.,'Transfer to Bank')]")));Thread.sleep(2000);
		WebElement button = driver.findElement(By.xpath("//span[contains(.,'Transfer to Bank')]"));  // Example: Click on a button
		button.click();
		Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".modal-lg .modal-header .fa")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".modal-lg .modal-header .fa")));Thread.sleep(2000);
		driver.findElement(By.cssSelector(".modal-lg .modal-header .fa")).click();
		Thread.sleep(2000);
		driver.findElement(By.cssSelector(".transforHistory > span")).click();
		
		Thread.sleep(2000);
		driver.findElement(By.cssSelector(".coach-receiving-payment .fa")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//span[contains(.,'Transfer to Bank')]")).click();
		Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.linkText("Setup Bank")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.linkText("Setup Bank")));Thread.sleep(2000);	
		driver.findElement(By.linkText("Setup Bank")).click();
		Thread.sleep(2000);
		driver.navigate().back();
		Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[contains(.,'Transfer to Bank')]")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[contains(.,'Transfer to Bank')]")));Thread.sleep(2000);						
		
		/* Setup Bank to STRIPE */
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[contains(.,'Transfer to Bank')]")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[contains(.,'Transfer to Bank')]")));Thread.sleep(2000);
		driver.findElement(By.xpath("//span[contains(.,'Transfer to Bank')]")).click();  // Example: Click on a button
		Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//b[contains(.,'here')]")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//b[contains(.,'here')]")));Thread.sleep(2000);
		driver.findElement(By.xpath("//b[contains(.,'here')]")).click();
		Thread.sleep(2000);
		driver.navigate().back();
		Thread.sleep(2000);
		
		/* Setup Bank to STRIPE */
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[contains(.,\'Transfer to Bank\')]")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[contains(.,\'Transfer to Bank\')]")));Thread.sleep(2000);
		driver.findElement(By.xpath("//span[contains(.,\'Transfer to Bank\')]")).click();  // Example: Click on a button
		Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".modal-lg .modal-header .fa")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".modal-lg .modal-header .fa")));Thread.sleep(2000);
		driver.findElement(By.cssSelector(".modal-lg .modal-header .fa")).click();				
		
		/* Logout from Coach Page */
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'My Profile')]")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'My Profile')]")));Thread.sleep(2000);
		driver.findElement(By.xpath("//div[contains(text(),'My Profile')]")).click();  
		Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//div[contains(text(),'Logout')])[1]")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//div[contains(text(),'Logout')])[1]")));Thread.sleep(2000);
		driver.findElement(By.xpath("(//div[contains(text(),'Logout')])[1]")).click();  
		Thread.sleep(2000);
		}
	}
