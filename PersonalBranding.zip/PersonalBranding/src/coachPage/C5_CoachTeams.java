	package coachPage;
	
	import java.time.Duration;
	import org.openqa.selenium.By;
	import org.openqa.selenium.JavascriptExecutor;
	import org.openqa.selenium.Keys;
	import org.openqa.selenium.WebElement;
	import org.openqa.selenium.support.ui.ExpectedConditions;
	import org.openqa.selenium.support.ui.WebDriverWait;
	import org.testng.annotations.Listeners;
	import org.testng.annotations.Test;
	import screenshotOnFailure.FailScreenshot;
	
	@Listeners(screenshotListners.EventList.class)
	public class C5_CoachTeams extends FailScreenshot{
	
	@Test
	public void CP_CoachTeams() throws InterruptedException {
			
	/* Login to the Application - PBC */ 		
	driver.findElement(By.xpath("(//button[normalize-space()='Login'])[1]")).click();
	driver.findElement(By.xpath("//input[@id='Username']")).click();
	driver.findElement(By.xpath("//input[@id='Username']")).sendKeys("test.doe001");
	driver.findElement(By.xpath("//input[@id='password-field']")).click();
	driver.findElement(By.xpath("//input[@id='password-field']")).sendKeys("Rockon123");
	driver.findElement(By.xpath("//button[@id='loginButton']")).click();
	Thread.sleep(1500);
	WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(120));
	JavascriptExecutor jse = (JavascriptExecutor)driver;

	/* Create Coach Page */
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[normalize-space()='Create a Business']")));
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[normalize-space()='Create a Business']")));Thread.sleep(1500);
    driver.findElement(By.xpath("//button[normalize-space()='Create a Business']")).click();
    Thread.sleep(1500);
    driver.findElement(By.xpath("//span[normalize-space()='COACH']")).click();
    Thread.sleep(1500);
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("Name")));
    wait.until(ExpectedConditions.elementToBeClickable(By.id("Name")));Thread.sleep(1500);
    driver.findElement(By.id("Name")).click();
    driver.findElement(By.id("Name")).sendKeys("Redo Coach Teams");
    Thread.sleep(1500);
    driver.findElement(By.id("BusinessTag")).click();
    driver.findElement(By.id("BusinessTag")).sendKeys("Do something Repeatedly, One day you will be master in it!");
    Thread.sleep(1500);
    driver.findElement(By.id("WebsiteUrl")).click();
    driver.findElement(By.id("WebsiteUrl")).sendKeys("www.redocoach.com");
    Thread.sleep(1500);
    driver.findElement(By.id("Description")).click();
    driver.findElement(By.id("Description")).sendKeys("I am a UIUX Designer by trade, and a tech, art, and design enthusiast at heart. After a fulfilling career as a professor of art and design at Syracuse University (2011-2016), I transitioned professionally into software development - a longstanding, very serious passion of mine. The combination of analytical abilities, conceptual breadth, passion for mentoring others and deep research skills that defined my work in academia informs my approach to programming. A precise understanding of the consultative and");
    Thread.sleep(1500);    
    driver.findElement(By.xpath("//div[@class='filter-option-inner-inner']")).click();
    Thread.sleep(1500);   
    driver.findElement(By.xpath("//input[@aria-label='Search']")).click();
    Thread.sleep(1500);   
    driver.findElement(By.xpath("//input[@aria-label='Search']")).sendKeys("busin");
    Thread.sleep(1500);
    driver.findElement(By.xpath("//input[@aria-label='Search']")).sendKeys(Keys.ENTER);
    Thread.sleep(1500);   
    driver.findElement(By.xpath("//div[@class='filter-option-inner-inner']")).click();
    Thread.sleep(1500);   
    driver.findElement(By.xpath("//input[@aria-label='Search']")).click();
    Thread.sleep(1500);   
    driver.findElement(By.xpath("//input[@aria-label='Search']")).sendKeys("Education");
    Thread.sleep(1500);
    driver.findElement(By.xpath("//input[@aria-label='Search']")).sendKeys(Keys.ENTER);
    Thread.sleep(1500);   
    driver.findElement(By.xpath("//div[@class='filter-option-inner-inner']")).click();
    Thread.sleep(1500);   
    driver.findElement(By.xpath("//input[@aria-label='Search']")).click();
    Thread.sleep(1500);   
    driver.findElement(By.xpath("//input[@aria-label='Search']")).sendKeys("Fina");
    Thread.sleep(1500);
    driver.findElement(By.xpath("//input[@aria-label='Search']")).sendKeys(Keys.ENTER);
    Thread.sleep(1500);
    driver.findElement(By.xpath("//a[@class='tagit-close']")).click();
    Thread.sleep(1500);
    driver.findElement(By.xpath("//div[@class='filter-option-inner-inner']")).click();
    Thread.sleep(1500);   
    driver.findElement(By.xpath("//input[@aria-label='Search']")).click();
    Thread.sleep(1500);   
    driver.findElement(By.xpath("//input[@aria-label='Search']")).sendKeys("busin");
    Thread.sleep(1500);
    driver.findElement(By.xpath("//input[@aria-label='Search']")).sendKeys(Keys.ENTER);
    Thread.sleep(1500);  
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[@id='biz-form-btn']")));Thread.sleep(1500);
    driver.findElement(By.xpath("//button[@id='biz-form-btn']")).click();
    Thread.sleep(1500);

	/* Standard Trail */
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".col-centered > .btn-sm")));
	wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".col-centered > .btn-sm")));Thread.sleep(1500);
	driver.findElement(By.cssSelector(".col-centered > .btn-sm")).click();
	Thread.sleep(1500);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("td:nth-child(4) > .biz-plans-head .btn-sm")));
	wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector("td:nth-child(4) > .biz-plans-head .btn-sm")));Thread.sleep(1500);
	driver.findElement(By.cssSelector("td:nth-child(4) > .biz-plans-head .btn-sm")).click();
	Thread.sleep(1500);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("#btnBillingDetails > .fa")));
	wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector("#btnBillingDetails > .fa")));Thread.sleep(1500);
	driver.findElement(By.cssSelector("#btnBillingDetails > .fa")).click();
	Thread.sleep(1500);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".col-5 > .btn-sm")));
	wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".col-5 > .btn-sm")));Thread.sleep(1500);
	driver.findElement(By.cssSelector(".col-5 > .btn-sm")).click();
	Thread.sleep(1500);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@id=\'CouponCode\']")));
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@id=\'CouponCode\']")));Thread.sleep(1500);	
	driver.findElement(By.xpath("//input[@id=\'CouponCode\']")).click();
	driver.findElement(By.xpath("//input[@id=\'CouponCode\']")).sendKeys("k0bsRFCfLZ");
	Thread.sleep(1500);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".col-5 > .btn-sm")));
	wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".col-5 > .btn-sm")));Thread.sleep(2000);
	driver.findElement(By.cssSelector(".col-5 > .btn-sm")).click();
	Thread.sleep(1500);
	driver.findElement(By.id("PaymentInformation_CreditCardNumber")).click();
	driver.findElement(By.id("PaymentInformation_CreditCardNumber")).sendKeys("4005519200000004");
	Thread.sleep(1500);
	driver.findElement(By.id("select2-PaymentInformation_ExpirationMonth-container")).click();
	Thread.sleep(1500);
	driver.findElement(By.cssSelector(".select2-search__field")).click();
	driver.findElement(By.cssSelector(".select2-search__field")).sendKeys("05");
	driver.findElement(By.cssSelector(".select2-search__field")).sendKeys(Keys.ENTER);
	Thread.sleep(1500);
	driver.findElement(By.id("select2-PaymentInformation_ExpirationYear-container")).click();
	Thread.sleep(1500);
	driver.findElement(By.cssSelector(".select2-search__field")).click();
	driver.findElement(By.cssSelector(".select2-search__field")).sendKeys("25");
	driver.findElement(By.cssSelector(".select2-search__field")).sendKeys(Keys.ENTER);
	Thread.sleep(1500);
	driver.findElement(By.xpath("//div[@id=\'checkoutCard\']/div/div[3]/div/div[4]/div/label")).click();
	Thread.sleep(1500);
	driver.findElement(By.id("PaymentInformation_CVV")).sendKeys("498");
	Thread.sleep(1500);
	driver.findElement(By.xpath("//div[@id=\'checkoutCard\']/div/div[4]/div/label")).click();
	Thread.sleep(1500);
	driver.findElement(By.id("PaymentInformation_BillingDetailsData_Address")).sendKeys("2400 Camino Ramon, San Ramon");
	Thread.sleep(1500);
	driver.findElement(By.id("PaymentInformation_BillingDetailsData_City")).click();
	Thread.sleep(1500);
	driver.findElement(By.id("PaymentInformation_BillingDetailsData_City")).clear();
	Thread.sleep(1500);
	driver.findElement(By.id("PaymentInformation_BillingDetailsData_City")).sendKeys("San B");
	Thread.sleep(1500);
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//body[1]/ul[1]/li[2]/div[1]")));
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//body[1]/ul[1]/li[2]/div[1]")));Thread.sleep(1500);
    driver.findElement(By.xpath("//body[1]/ul[1]/li[2]/div[1]")).click(); 
    Thread.sleep(1500);
    
    /* Click Review Order after Credit Card Payment */    
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[contains(text(),\'Review Order\')]")));
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[contains(text(),\'Review Order\')]")));Thread.sleep(1500);	
	driver.findElement(By.xpath("//span[contains(text(),\'Review Order\')]")).click();
	Thread.sleep(1500);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[contains(text(),\'Complete Order\')]")));
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[contains(text(),\'Complete Order\')]")));Thread.sleep(1500);
	driver.findElement(By.xpath("//span[contains(text(),\'Complete Order\')]")).click();
	Thread.sleep(1500);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[contains(text(),\'Okay\')]")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[contains(text(),\'Okay\')]")));Thread.sleep(1500);
	driver.findElement(By.xpath("//span[contains(text(),\'Okay\')]")).click();
	Thread.sleep(1500);
	
	/* Page will Navigate to Coach Verification & CLOSE - Coach Verification Window */
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".col-xl-6 > .btn-sm")));
	wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".col-xl-6 > .btn-sm")));Thread.sleep(1500);
	driver.findElement(By.cssSelector(".col-xl-6 > .btn-sm")).click();
	Thread.sleep(1500);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[@aria-label='Close']//i[@class='fa fa-times']")));
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[@aria-label='Close']//i[@class='fa fa-times']")));Thread.sleep(1500);
	driver.findElement(By.xpath("//a[@aria-label='Close']//i[@class='fa fa-times']")).click();
	Thread.sleep(1500);
	
	/* Cancel the Trail Subscription */
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[normalize-space()='Menu']")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()='Menu']")));Thread.sleep(2000);
    driver.findElement(By.xpath("//span[normalize-space()='Menu']")).click();
    Thread.sleep(2000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[normalize-space()='Subscription']")));
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[normalize-space()='Subscription']")));Thread.sleep(2000);
	driver.findElement(By.xpath("//a[normalize-space()='Subscription']")).click();
	Thread.sleep(1500);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.linkText("Subscription & Orders")));
	wait.until(ExpectedConditions.elementToBeClickable(By.linkText("Subscription & Orders")));Thread.sleep(2000);
	driver.findElement(By.linkText("Subscription & Orders")).click();
	Thread.sleep(2000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[normalize-space()=\'Cancel Subscription\']")));
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()=\'Cancel Subscription\']")));Thread.sleep(2000);
	driver.findElement(By.xpath("//span[normalize-space()=\'Cancel Subscription\']")).click();
	Thread.sleep(2000);
	driver.findElement(By.cssSelector(".btn-outline-maroon")).click();
	wait.until(ExpectedConditions.invisibilityOfElementLocated(By.cssSelector(".btn-outline-maroon")));
	Thread.sleep(1500);
	
	/* Purchase Teams Subscription with Coupons */
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".col-centered > .btn-sm")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".col-centered > .btn-sm")));Thread.sleep(1500);
	driver.findElement(By.cssSelector(".col-centered > .btn-sm")).click();
	Thread.sleep(1500);		
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("td:nth-child(4) > .biz-plans-head .btn-sm")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector("td:nth-child(4) > .biz-plans-head .btn-sm")));Thread.sleep(1500);						   
	driver.findElement(By.cssSelector("td:nth-child(4) > .biz-plans-head .btn-sm")).click();
	Thread.sleep(1500);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".col-5 > .btn-sm")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".col-5 > .btn-sm")));Thread.sleep(1500);
	driver.findElement(By.cssSelector(".col-5 > .btn-sm")).click();
	Thread.sleep(1500);
	driver.findElement(By.xpath("//input[@id=\'CouponCode\']")).click();
	driver.findElement(By.xpath("//input[@id=\'CouponCode\']")).sendKeys("KWzm9p2dTh");
	Thread.sleep(1500);
	driver.findElement(By.cssSelector(".col-5 > .btn-sm")).click();
	Thread.sleep(1500);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[contains(text(),\'Review Order\')]")));
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[contains(text(),\'Review Order\')]")));Thread.sleep(1500);	
	driver.findElement(By.xpath("//span[contains(text(),\'Review Order\')]")).click();
	Thread.sleep(1500);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[contains(text(),\'Complete Order\')]")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[contains(text(),\'Complete Order\')]")));Thread.sleep(1500);
	driver.findElement(By.xpath("//span[contains(text(),\'Complete Order\')]")).click();Thread.sleep(1500);
	Thread.sleep(1500);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[contains(text(),\'Okay\')]")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[contains(text(),\'Okay\')]")));Thread.sleep(1500);
	driver.findElement(By.xpath("//span[contains(text(),\'Okay\')]")).click();
	Thread.sleep(1500);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[@aria-label='Close']//i[@class='fa fa-times']")));
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[@aria-label='Close']//i[@class='fa fa-times']")));Thread.sleep(1500);
	driver.findElement(By.xpath("//a[@aria-label='Close']//i[@class='fa fa-times']")).click();
	Thread.sleep(1500);
	
	/* Observe the Reciept at bottom of the page */
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[normalize-space()='Menu']")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()='Menu']")));Thread.sleep(2000);
    driver.findElement(By.xpath("//span[normalize-space()='Menu']")).click();
    Thread.sleep(2000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[normalize-space()='Payments']")));
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[normalize-space()='Payments']")));Thread.sleep(2000);
	driver.findElement(By.xpath("//a[normalize-space()='Payments']")).click();
	Thread.sleep(1500);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@id=\'divAddPaymentMethod\']//button[@type=\'button\']")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@id=\'divAddPaymentMethod\']//button[@type=\'button\']")));Thread.sleep(1500);
	jse.executeScript("window.scrollBy(0,250)");
	Thread.sleep(1500);
	WebElement element = driver.findElement(By.cssSelector(".fa-plus-circle"));
	jse.executeScript("arguments[0].scrollIntoView();", element);Thread.sleep(1500);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".fa-plus-circle")));
	wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".fa-plus-circle")));Thread.sleep(1500);
	jse.executeScript("window.scrollBy(0,250)");
	Thread.sleep(1500);
	driver.findElement(By.cssSelector(".fa-plus-circle")).click();
	Thread.sleep(1500);
	
	/* Delete Page */
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//div[contains(text(),'Settings')])[1]")));
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//div[contains(text(),'Settings')])[1]")));Thread.sleep(2000);
	driver.findElement(By.xpath("(//div[contains(text(),'Settings')])[1]")).click();
	Thread.sleep(2000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".btn-outline-grey")));
	wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".btn-outline-grey")));Thread.sleep(2000);
	driver.findElement(By.cssSelector(".btn-outline-grey")).click();
	Thread.sleep(1500);
	driver.findElement(By.id("Password")).click();
	driver.findElement(By.id("Password")).sendKeys("Rockon123");
	Thread.sleep(1500);
	wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector("form > #btnYesConfirmYesNo")));Thread.sleep(1500);
	driver.findElement(By.cssSelector("form > #btnYesConfirmYesNo")).click();
    wait.until(ExpectedConditions.invisibilityOfElementLocated(By.cssSelector("form > #btnYesConfirmYesNo")));
	Thread.sleep(1500);
	
	/* Logout from Account */
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'My Profile')]")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'My Profile')]")));Thread.sleep(2000);
	driver.findElement(By.xpath("//div[contains(text(),'My Profile')]")).click();  
	Thread.sleep(2000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//div[contains(text(),'Logout')])[1]")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//div[contains(text(),'Logout')])[1]")));Thread.sleep(2000);
	driver.findElement(By.xpath("(//div[contains(text(),'Logout')])[1]")).click();  
	Thread.sleep(2000);
	}
}
