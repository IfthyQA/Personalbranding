package coachPage;

import org.testng.annotations.Test;
import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Listeners;
import screenshotOnFailure.FailScreenshot;

@Listeners(screenshotListners.EventList.class)
public class C1_CreateCoach extends FailScreenshot{

	@Test
	public void CP_CoachBasic() throws InterruptedException {
		
	/* Login to the Application - PBC */ 		
	driver.findElement(By.xpath("(//button[normalize-space()='Login'])[1]")).click();
	driver.findElement(By.xpath("//input[@id='Username']")).click();
	driver.findElement(By.xpath("//input[@id='Username']")).sendKeys("test.doe001");
	driver.findElement(By.xpath("//input[@id='password-field']")).click();
	driver.findElement(By.xpath("//input[@id='password-field']")).sendKeys("Rockon123");
	driver.findElement(By.xpath("//button[@id='loginButton']")).click();
	Thread.sleep(2000);
	WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(120));
	
	/* Navigate to the Strategic Hub */    
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[normalize-space()='Create a Business']")));
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[normalize-space()='Create a Business']")));Thread.sleep(2000);
    driver.findElement(By.xpath("//button[normalize-space()='Create a Business']")).click();
    Thread.sleep(2000);
    driver.findElement(By.xpath("//span[normalize-space()='COACH']")).click();
    Thread.sleep(2000);
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("Name")));
    wait.until(ExpectedConditions.elementToBeClickable(By.id("Name")));Thread.sleep(2000);
    driver.findElement(By.id("Name")).click();
    driver.findElement(By.id("Name")).sendKeys("Redo Coach Basic");
    Thread.sleep(2000);
    driver.findElement(By.id("BusinessTag")).click();
    driver.findElement(By.id("BusinessTag")).sendKeys("Do something Repeatedly, One day you will be master in it!");
    Thread.sleep(2000);
    driver.findElement(By.id("WebsiteUrl")).click();
    driver.findElement(By.id("WebsiteUrl")).sendKeys("www.redocoach.com");
    Thread.sleep(2000);
    driver.findElement(By.id("Description")).click();
    driver.findElement(By.id("Description")).sendKeys("I am a UIUX Designer by trade, and a tech, art, and design enthusiast at heart. After a fulfilling career as a professor of art and design at Syracuse University (2011-2016), I transitioned professionally into software development - a longstanding, very serious passion of mine. The combination of analytical abilities, conceptual breadth, passion for mentoring others and deep research skills that defined my work in academia informs my approach to programming. A precise understanding of the consultative and");
    Thread.sleep(2000);   
    driver.findElement(By.xpath("//div[@class='filter-option-inner-inner']")).click();
    Thread.sleep(2000);   
    driver.findElement(By.xpath("//input[@aria-label='Search']")).click();
    Thread.sleep(2000);   
    driver.findElement(By.xpath("//input[@aria-label='Search']")).sendKeys("busin");
    Thread.sleep(2000);
    driver.findElement(By.xpath("//input[@aria-label='Search']")).sendKeys(Keys.ENTER);
    Thread.sleep(2000);   
    driver.findElement(By.xpath("//div[@class='filter-option-inner-inner']")).click();
    Thread.sleep(2000);   
    driver.findElement(By.xpath("//input[@aria-label='Search']")).click();
    Thread.sleep(2000);   
    driver.findElement(By.xpath("//input[@aria-label='Search']")).sendKeys("Education");
    Thread.sleep(2000);
    driver.findElement(By.xpath("//input[@aria-label='Search']")).sendKeys(Keys.ENTER);
    Thread.sleep(2000);   
    driver.findElement(By.xpath("//div[@class='filter-option-inner-inner']")).click();
    Thread.sleep(2000);   
    driver.findElement(By.xpath("//input[@aria-label='Search']")).click();
    Thread.sleep(2000);   
    driver.findElement(By.xpath("//input[@aria-label='Search']")).sendKeys("Fina");
    Thread.sleep(2000);
    driver.findElement(By.xpath("//input[@aria-label='Search']")).sendKeys(Keys.ENTER);
    Thread.sleep(2000);
    driver.findElement(By.xpath("//a[@class='tagit-close']")).click();
    Thread.sleep(2000);
    driver.findElement(By.xpath("//div[@class='filter-option-inner-inner']")).click();
    Thread.sleep(2000);   
    driver.findElement(By.xpath("//input[@aria-label='Search']")).click();
    Thread.sleep(2000);   
    driver.findElement(By.xpath("//input[@aria-label='Search']")).sendKeys("busin");
    Thread.sleep(2000);
    driver.findElement(By.xpath("//input[@aria-label='Search']")).sendKeys(Keys.ENTER);
    Thread.sleep(2000);   
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[@id='biz-form-btn']")));Thread.sleep(2000);
    driver.findElement(By.xpath("//button[@id='biz-form-btn']")).click();
    Thread.sleep(2000);
	
	/* Try to opt Coach Prime Basic Subscription */
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".modal-md .fa")));
	wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".modal-md .fa")));Thread.sleep(2000);
	driver.findElement(By.cssSelector(".modal-md .fa")).click();
	Thread.sleep(2000);
	driver.findElement(By.linkText("Subscription & Orders")).click();
	Thread.sleep(2000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".col-centered > .btn-sm")));
	wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".col-centered > .btn-sm")));Thread.sleep(2000);
	driver.findElement(By.cssSelector(".col-centered > .btn-sm")).click();
	Thread.sleep(2000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@title='Redo Coach Basic']")));	// Business Hub Logo Bavigation
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@title='Redo Coach Basic']")));Thread.sleep(2000);
	driver.findElement(By.xpath("//div[@title='Redo Coach Basic']")).click();
	Thread.sleep(2000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".col-centered > .btn-sm")));
	wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".col-centered > .btn-sm")));Thread.sleep(2000);
	driver.findElement(By.cssSelector(".col-centered > .btn-sm")).click();
	Thread.sleep(2000);
	driver.findElement(By.cssSelector("form:nth-child(4) .btn-sm")).click();Thread.sleep(10000);
	Thread.sleep(2000);
	driver.findElement(By.id("btnReviewOrder")).click();Thread.sleep(2000);
	Thread.sleep(2000);
	driver.navigate().refresh();
	Thread.sleep(2000);
	
	/* Opt to Prime Basic Subscriptons */
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".col-centered > .btn-sm")));
	wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".col-centered > .btn-sm")));Thread.sleep(2000);
	driver.findElement(By.cssSelector(".col-centered > .btn-sm")).click();
	Thread.sleep(2000);
	driver.findElement(By.cssSelector("form:nth-child(4) .btn-sm")).click();
	Thread.sleep(2000);
	driver.findElement(By.cssSelector("#btnBillingDetails > .fa")).click();
	Thread.sleep(2000);
	driver.findElement(By.cssSelector(".col-5 > .btn-sm")).click();
	Thread.sleep(2000);
	driver.findElement(By.xpath("//input[@id=\'CouponCode\']")).click();
	driver.findElement(By.xpath("//input[@id=\'CouponCode\']")).sendKeys("APStdF49l4");
	Thread.sleep(2000);
	driver.findElement(By.cssSelector(".col-5 > .btn-sm")).click();
	Thread.sleep(5000);
	
	/* Navigating to Paypal */
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("paypalRadioBtn")));
	wait.until(ExpectedConditions.elementToBeClickable(By.id("paypalRadioBtn")));Thread.sleep(2000);
	driver.findElement(By.id("paypalRadioBtn")).click();
	Thread.sleep(5000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//img[@alt='Pay with PayPal']")));
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//img[@alt='Pay with PayPal']")));
	Thread.sleep(2000);
    String winHandleBefore = driver.getWindowHandle();
    driver.findElement(By.xpath("//img[@alt='Pay with PayPal']")).click();
    Thread.sleep(2000);
    for(String winHandle : driver.getWindowHandles()){
	        driver.switchTo().window(winHandle); 
    }
    Thread.sleep(2000);     /* Pay thru Paypal */
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[@id='return_url']")));
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[@id='return_url']")));
    driver.findElement(By.xpath("//a[@id='return_url']")).click();
    Thread.sleep(2000);
    driver.switchTo().window(winHandleBefore);
    Thread.sleep(2000);
    
    /* Click Review Order after PayPal Payment */       
	driver.findElement(By.xpath("//span[contains(text(),\'Review Order\')]")).click();Thread.sleep(2000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[contains(text(),\'Edit Order\')]")));
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[contains(text(),\'Edit Order\')]")));Thread.sleep(2000);	
	driver.findElement(By.xpath("//span[contains(text(),\'Edit Order\')]")).click();
	Thread.sleep(2000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[contains(text(),\'Review Order\')]")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[contains(text(),\'Review Order\')]")));Thread.sleep(2000);
	driver.findElement(By.xpath("//span[contains(text(),\'Review Order\')]")).click();
	Thread.sleep(2000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[contains(text(),\'Complete Order\')]")));
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[contains(text(),\'Complete Order\')]")));Thread.sleep(2000);
	driver.findElement(By.xpath("//span[contains(text(),\'Complete Order\')]")).click();
	Thread.sleep(2000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[contains(text(),\'Okay\')]")));
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[contains(text(),\'Okay\')]")));Thread.sleep(2000);
	driver.findElement(By.xpath("//span[contains(text(),\'Okay\')]")).click();
	Thread.sleep(2000);
	
	/* Page will Navigate to Coach Verification & CLOSE - Coach Verification Window */
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".col-xl-6 > .btn-sm")));
	wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".col-xl-6 > .btn-sm")));Thread.sleep(2000);
	driver.findElement(By.cssSelector(".col-xl-6 > .btn-sm")).click();
	Thread.sleep(2000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[@aria-label='Close']//i[@class='fa fa-times']")));
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[@aria-label='Close']//i[@class='fa fa-times']")));Thread.sleep(1500);
	driver.findElement(By.xpath("//a[@aria-label='Close']//i[@class='fa fa-times']")).click();
	Thread.sleep(1500);
	
	/* Coaching Dashboard */
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[normalize-space()='Menu']")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()='Menu']")));Thread.sleep(2000);
    driver.findElement(By.xpath("//span[normalize-space()='Menu']")).click();
    Thread.sleep(2000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[normalize-space()='Coaching Services']")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[normalize-space()='Coaching Services']")));Thread.sleep(2000);
    driver.findElement(By.xpath("//a[normalize-space()='Coaching Services']")).click();
    Thread.sleep(2000);
	
	/* Coach Verification Window */
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".col-xl-6 > .btn-sm")));
	wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".col-xl-6 > .btn-sm")));Thread.sleep(2000);
	driver.findElement(By.cssSelector(".col-xl-6 > .btn-sm")).click();
	Thread.sleep(2000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[@aria-label='Close']//i[@class='fa fa-times']")));
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[@aria-label='Close']//i[@class='fa fa-times']")));Thread.sleep(1500);
	driver.findElement(By.xpath("//a[@aria-label='Close']//i[@class='fa fa-times']")).click();
	Thread.sleep(1500);
	
	/* Manage Payments */
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[normalize-space()='Menu']")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()='Menu']")));Thread.sleep(2000);
    driver.findElement(By.xpath("//span[normalize-space()='Menu']")).click();
    Thread.sleep(2000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[normalize-space()='Payments']")));
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[normalize-space()='Payments']")));Thread.sleep(2000);
	driver.findElement(By.xpath("//a[normalize-space()='Payments']")).click();
	Thread.sleep(2000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.linkText("RECEIVING BANK")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.linkText("RECEIVING BANK")));Thread.sleep(2000);
	driver.findElement(By.linkText("RECEIVING BANK")).click();
	Thread.sleep(2000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("btnAddReceivingPaymentMethod")));
	wait.until(ExpectedConditions.elementToBeClickable(By.id("btnAddReceivingPaymentMethod")));Thread.sleep(2000);
	driver.findElement(By.id("btnAddReceivingPaymentMethod")).click();
	Thread.sleep(2000);
	driver.findElement(By.linkText("OK")).click();
	Thread.sleep(2000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".col-xl-6 > .btn-sm")));
	wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".col-xl-6 > .btn-sm")));Thread.sleep(2000);
	driver.findElement(By.cssSelector(".col-xl-6 > .btn-sm")).click();
	Thread.sleep(2000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[@aria-label='Close']//i[@class='fa fa-times']")));
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[@aria-label='Close']//i[@class='fa fa-times']")));Thread.sleep(1500);
	driver.findElement(By.xpath("//a[@aria-label='Close']//i[@class='fa fa-times']")).click();
	Thread.sleep(1500);
	
	/* Logout from Coach Page */
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'My Profile')]")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'My Profile')]")));Thread.sleep(2000);
	driver.findElement(By.xpath("//div[contains(text(),'My Profile')]")).click();  
	Thread.sleep(2000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//div[contains(text(),'Logout')])[1]")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//div[contains(text(),'Logout')])[1]")));Thread.sleep(2000);
	driver.findElement(By.xpath("(//div[contains(text(),'Logout')])[1]")).click();  
	Thread.sleep(2000);
	}
}
