package coachStripe;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import screenshotOnFailure.FailScreenshot;

@Listeners(screenshotListners.EventList.class)
public class CS21_RequestPayment extends FailScreenshot{

	@Test
	public void CS_Payment_Requesting() throws InterruptedException {
		
		/* Login to the Application - PBC */ 		
	  	driver.findElement(By.xpath("(//button[normalize-space()='Login'])[1]")).click();
		driver.findElement(By.xpath("//input[@id='Username']")).click();
		driver.findElement(By.xpath("//input[@id='Username']")).sendKeys("john.doe007");
		driver.findElement(By.xpath("//input[@id='password-field']")).click();
		driver.findElement(By.xpath("//input[@id='password-field']")).sendKeys("Rockon123");
		driver.findElement(By.xpath("//button[@id='loginButton']")).click();
		Thread.sleep(2000);
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(120));
	    
	    /* Navigate to the Coach Page */
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[2]/div[1]/div[1]/div[2]/div[1]/div[1]/a[1]/span[1]")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[2]/div[1]/div[1]/div[2]/div[1]/div[1]/a[1]/span[1]")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[2]/div[1]/div[1]/div[2]/div[1]/div[1]/a[1]/span[1]")).click();
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[normalize-space()='Menu']")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()='Menu']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//span[normalize-space()='Menu']")).click();
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[normalize-space()='Coaching Services']")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[normalize-space()='Coaching Services']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//a[normalize-space()='Coaching Services']")).click();
	    Thread.sleep(2000);
		
		/* Work in Progress */
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("menuiteminprogress")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.id("menuiteminprogress")));Thread.sleep(2000);
		driver.findElement(By.id("menuiteminprogress")).click();
		Thread.sleep(2000);
			String winHandleBefore = driver.getWindowHandle();
			driver.findElement(By.linkText("Adam Isa")).click();
			Thread.sleep(2000); // Navigate to New window
	    	for(String winHandle : driver.getWindowHandles()){
	        driver.switchTo().window(winHandle);
	    	}								
			driver.close();
			driver.switchTo().window(winHandleBefore);
			Thread.sleep(2000);
		driver.findElement(By.cssSelector(".proposal-title")).click();
		Thread.sleep(2000);
		driver.findElement(By.cssSelector(".text-right > .btn-blue-link-12")).click();
		Thread.sleep(2000);
		driver.findElement(By.cssSelector("li > .btn-blue-link-12 > span")).click();
		Thread.sleep(2000);
		driver.findElement(By.cssSelector("li:nth-child(3) > .form-inline span")).click();
		Thread.sleep(2000);
		driver.findElement(By.cssSelector(".form-inline .my-meeting-text")).click();
		Thread.sleep(2000);
		
		/* Edit Scheduled Meeting */
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".editmeeting-icon")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".editmeeting-icon")));Thread.sleep(2000);
		driver.findElement(By.cssSelector(".editmeeting-icon")).click();
		Thread.sleep(2000);
		driver.findElement(By.id("MeetingName")).clear();Thread.sleep(2000);
		driver.findElement(By.id("MeetingName")).click();
		driver.findElement(By.id("MeetingName")).sendKeys("Coaching Meeting 123");
		Thread.sleep(2000);
		driver.findElement(By.id("submitbtn")).click();
		Thread.sleep(2000);
		driver.findElement(By.cssSelector(".biz-admin-overlay > .modal-header .fa")).click();
		Thread.sleep(2000);
		
		/* Links and Buttons in WIP */ 
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[3]/div/span")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[3]/div/span")));Thread.sleep(2000);
		driver.findElement(By.xpath("//div[3]/div/span")).click();
		Thread.sleep(2000);
		wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector("#coachingcancelpopup > .modal-header .fa")));Thread.sleep(2000);
		driver.findElement(By.cssSelector("#coachingcancelpopup > .modal-header .fa")).click();
		Thread.sleep(2000);
		driver.findElement(By.linkText("Back to Work In Progress")).click();
		Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".col-12:nth-child(2) > .btn-blue-link-12")));	// view detail
		wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".col-12:nth-child(2) > .btn-blue-link-12")));Thread.sleep(2000);
		driver.findElement(By.cssSelector(".col-12:nth-child(2) > .btn-blue-link-12")).click();
		Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".btn-blue")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".btn-blue")));Thread.sleep(2000);
		driver.findElement(By.cssSelector(".btn-blue")).click();
		Thread.sleep(2000);
		wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".modal-lg .modal-header .fa")));Thread.sleep(2000);
		driver.findElement(By.cssSelector(".modal-lg .modal-header .fa")).click();
		Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".margin-left-15 > .btn-sm")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".margin-left-15 > .btn-sm")));Thread.sleep(2000);
		driver.findElement(By.cssSelector(".margin-left-15 > .btn-sm")).click();
		Thread.sleep(2000);
		driver.findElement(By.id("btnNoConfirmYesNo")).click();
		Thread.sleep(2000);
		
		/* Discussion */
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("menuiteminprogress")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.id("menuiteminprogress")));Thread.sleep(2000);
		driver.findElement(By.id("menuiteminprogress")).click();
		Thread.sleep(2000);
		driver.findElement(By.cssSelector(".float-right > .d-none")).click();
		Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("discussiontextarea")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.id("discussiontextarea")));Thread.sleep(2000);
		driver.findElement(By.id("discussiontextarea")).click();
		driver.findElement(By.id("discussiontextarea")).sendKeys("Thanks you for the acceptance");
		Thread.sleep(2000);
		driver.findElement(By.xpath("//span[@class=\'titleAttach\']")).click();
		Thread.sleep(2000);
	    driver.findElement(By.xpath("//button[@type=\'button\']//span[contains(text(),\'Business Vault\')]")).click();
		Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[2]/div/div/div[2]/i")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[2]/div/div/div[2]/i")));Thread.sleep(2000);
		driver.findElement(By.xpath("//div[2]/div/div/div[2]/i")).click();
		Thread.sleep(2000);
		driver.findElement(By.cssSelector(".btn")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//button[contains(.,\'Send Message\')]")).click();
		Thread.sleep(2000);
		driver.findElement(By.cssSelector(".btn-blue-link-12")).click();
		Thread.sleep(2000);
		
		/* Work in Progress - buttons and Arrows */
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".fa-angle-down")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".fa-angle-down")));Thread.sleep(2000);
		driver.findElement(By.cssSelector(".fa-angle-down")).click();
		Thread.sleep(2000);
		driver.findElement(By.cssSelector(".fa-angle-up")).click();
		Thread.sleep(2000);
		driver.findElement(By.cssSelector(".float-md-right > .btn-blue-link-12:nth-child(1)")).click();
		Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".biz-admin-overlay > .modal-header .fa")).click();
		Thread.sleep(2000);
		driver.findElement(By.cssSelector(".proposal-title")).click();
		Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".btn-lg")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".btn-lg")));Thread.sleep(2000);
		driver.findElement(By.cssSelector(".btn-lg")).click();
		Thread.sleep(2000);
		driver.findElement(By.cssSelector(".float-right > .btn-sm")).click();
		Thread.sleep(2000);
		driver.findElement(By.cssSelector("#coachingcancelpopup > .modal-header .fa")).click();
		Thread.sleep(2000);
		driver.findElement(By.id("menuiteminprogress")).click();
		Thread.sleep(2000);
		
		/* Request Payment */
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[contains(.,\'Request Payment\')]")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[contains(.,\'Request Payment\')]")));Thread.sleep(2000);
		driver.findElement(By.xpath("//button[contains(.,\'Request Payment\')]")).click();
		Thread.sleep(2000);
		driver.findElement(By.cssSelector(".modal-lg .modal-header .fa")).click();
		Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[contains(.,\'Request Payment\')]")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[contains(.,\'Request Payment\')]")));Thread.sleep(2000);
		driver.findElement(By.xpath("//button[contains(.,\'Request Payment\')]")).click();
		Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".col-md-12 > form > .btn-sm")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".col-md-12 > form > .btn-sm")));Thread.sleep(2000);
		driver.findElement(By.cssSelector(".col-md-12 > form > .btn-sm")).click();
		Thread.sleep(2000);
		driver.findElement(By.cssSelector(".margin-top-10 > .btn-blue-link-12")).click();
		Thread.sleep(2000);
		driver.findElement(By.cssSelector("#coachingcancelpopup > .modal-header .fa")).click();
		Thread.sleep(2000);
		
		/* View Details */
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//button[contains(.,'View Details')])[2]")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//button[contains(.,'View Details')])[2]")));Thread.sleep(2000);
		driver.findElement(By.xpath("(//button[contains(.,'View Details')])[2]")).click();
		Thread.sleep(2000);
		driver.findElement(By.cssSelector("#modalMilestoneDetails .modal-header .fa")).click();
		Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".col-12:nth-child(2) > .btn-blue-link-12")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".col-12:nth-child(2) > .btn-blue-link-12")));Thread.sleep(2000);
		driver.findElement(By.cssSelector(".col-12:nth-child(2) > .btn-blue-link-12")).click();
		Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".margin-left-15 > .btn-sm")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".margin-left-15 > .btn-sm")));Thread.sleep(2000);
		driver.findElement(By.cssSelector(".margin-left-15 > .btn-sm")).click();
		Thread.sleep(2000);
		driver.findElement(By.id("btnNoConfirmYesNo")).click();
		Thread.sleep(2000);
		driver.findElement(By.linkText("Back to Work In Progress")).click();
		Thread.sleep(2000);
		
		/* Logout */
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'My Profile')]")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'My Profile')]")));Thread.sleep(2000);
		driver.findElement(By.xpath("//div[contains(text(),'My Profile')]")).click();  
		Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//div[contains(text(),'Logout')])[1]")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//div[contains(text(),'Logout')])[1]")));Thread.sleep(2000);
		driver.findElement(By.xpath("(//div[contains(text(),'Logout')])[1]")).click();  
		Thread.sleep(2000);
		}
	}
