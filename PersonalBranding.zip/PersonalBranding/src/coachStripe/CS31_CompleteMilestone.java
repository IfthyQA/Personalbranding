package coachStripe;

import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import screenshotOnFailure.FailScreenshot;

@Listeners(screenshotListners.EventList.class)
public class CS31_CompleteMilestone extends FailScreenshot{
	
	@Test
	public void CS_Milestone_Complete() throws InterruptedException {
		
		/* Login to the Application - PBC */ 		
	  	driver.findElement(By.xpath("(//button[normalize-space()='Login'])[1]")).click();
		driver.findElement(By.xpath("//input[@id='Username']")).click();
		driver.findElement(By.xpath("//input[@id='Username']")).sendKeys("john.doe007");
		driver.findElement(By.xpath("//input[@id='password-field']")).click();
		driver.findElement(By.xpath("//input[@id='password-field']")).sendKeys("Rockon123");
		driver.findElement(By.xpath("//button[@id='loginButton']")).click();
		Thread.sleep(2000);
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(120));
	    
	    /* Navigate to the Coach Page */
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[2]/div[1]/div[1]/div[2]/div[1]/div[1]/a[1]/span[1]")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[2]/div[1]/div[1]/div[2]/div[1]/div[1]/a[1]/span[1]")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[2]/div[1]/div[1]/div[2]/div[1]/div[1]/a[1]/span[1]")).click();
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[normalize-space()='Menu']")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()='Menu']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//span[normalize-space()='Menu']")).click();
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[normalize-space()='Coaching Services']")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[normalize-space()='Coaching Services']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//a[normalize-space()='Coaching Services']")).click();
	    Thread.sleep(2000);
	    
	    /* Work in Progress */
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("menuiteminprogress")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.id("menuiteminprogress")));Thread.sleep(2000);
	    driver.findElement(By.id("menuiteminprogress")).click();
	    
	    	String winHandleBefore = driver.getWindowHandle();
		    driver.findElement(By.linkText("Adam Isa")).click();
		    Thread.sleep(2000);	    	// Navigate to New window
	    	for(String winHandle : driver.getWindowHandles()){
	        driver.switchTo().window(winHandle);
	    	}
	    	Thread.sleep(2000);
		    driver.close();
		    driver.switchTo().window(winHandleBefore);
		    Thread.sleep(2000);

		wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".proposal-title")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".proposal-title")));Thread.sleep(2000);    
	    driver.findElement(By.cssSelector(".proposal-title")).click();
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[3]/div/span")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[3]/div/span")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[3]/div/span")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector("#coachingcancelpopup > .modal-header .fa")).click();
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".btn-outline-blue")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".btn-outline-blue")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".btn-outline-blue")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".btn-blue-link-14")).click();
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("menuiteminprogress")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.id("menuiteminprogress")));Thread.sleep(2000);
	    driver.findElement(By.id("menuiteminprogress")).click();
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".float-md-right > .btn-blue-link-12:nth-child(1)")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".float-md-right > .btn-blue-link-12:nth-child(1)")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".float-md-right > .btn-blue-link-12:nth-child(1)")).click();
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".deletemeeting-icon")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".deletemeeting-icon")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".deletemeeting-icon")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.id("btnYesConfirmYesNo")).click();Thread.sleep(2000);
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector("li > .btn-blue-link-12 > span")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.id("MeetingName")).click();
	    driver.findElement(By.id("MeetingName")).sendKeys("Complete Milestone - Coach");
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("//span[@class=\'input-group-append set-date set-date-birth\']//i[@class=\'fa fa-calendar set-date-icon\']")).click();Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[contains(@class, \'datetimepicker datetimepicker-\')][last()]/div[3]/table/tbody/tr/td[@class=\'day active\']")).click();Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[contains(@class, \'datetimepicker datetimepicker-\')][last()]/div[2]/table/tbody/tr/td/fieldset/span[contains(@class,\'hour active \')]")).click();Thread.sleep(2000);
	   
	    if(!driver.findElements(By.xpath("//div[contains(@class, 'datetimepicker datetimepicker-')][last()]/div[1]/table/tbody/tr/td/fieldset/span[11][contains(@class, 'minute disabled')]")).isEmpty())
		{	    		    
			Thread.sleep(2000);
			driver.findElement(By.xpath("//div[@class='datetimepicker-minutes']//th[@class='next']")).click();
		    Thread.sleep(2000);
		    driver.findElement(By.xpath("//div[contains(@class, \'datetimepicker datetimepicker-\')][last()]/div[1]/table/tbody/tr/td/fieldset/span[@class=\'minute\'][2]")).click();	    		    
		}		
		else {
			Thread.sleep(2000);
		    driver.findElement(By.xpath("//div[contains(@class, \'datetimepicker datetimepicker-\')][last()]/div[1]/table/tbody/tr/td/fieldset/span[@class=\'minute\'][2]")).click();
		}
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("//form[@id=\'myForm\']/div[2]/div[2]/div/div[2]/div/span/span/span")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".select2-search__field")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".select2-search__field")).sendKeys("30");
	    driver.findElement(By.cssSelector(".select2-search__field")).sendKeys(Keys.ENTER);  
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.elementToBeClickable(By.id("submitbtn")));Thread.sleep(2000);
	    driver.findElement(By.id("submitbtn")).click();
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[contains(text(),'Meeting History')]")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//span[contains(text(),'Meeting History')]")).click();
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[contains(text(),'My Meetings')]")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//span[contains(text(),'My Meetings')]")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".biz-admin-overlay > .modal-header .fa")).click();
	    Thread.sleep(2000);
	    
	    /* Discussions */
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".float-right > .d-none")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".float-right > .d-none")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".float-right > .d-none")).click();
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("discussiontextarea")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.id("discussiontextarea")));Thread.sleep(2000);
	    driver.findElement(By.id("discussiontextarea")).click();
	    driver.findElement(By.id("discussiontextarea")).sendKeys("we have completed the cousrse");
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("//button[contains(.,\'Send Message\')]")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".fa-arrow-left")).click();
	    Thread.sleep(2000);
	    
	    /* Complete Milestone */
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[2]/div/form/button")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[2]/div/form/button")));Thread.sleep(2000);	
	    driver.findElement(By.xpath("//div[2]/div/form/button")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("form > .btn-blue")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector("form > .btn-blue")));Thread.sleep(2000);	
	    driver.findElement(By.cssSelector("form > .btn-blue")).click();
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@class='toast-message']")));
	    driver.findElement(By.xpath("//div[@class='toast-message']")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.invisibilityOfElementLocated(By.cssSelector("form > .btn-blue")));
	    
	    /* History */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".btn-outline-blue")));
	    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".btn-outline-blue")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".btn-outline-blue")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".btn-blue-link-14")).click();
	    Thread.sleep(2000);
	    
	    /* Delete Meeting */
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@title='Stripe Test Automation']")));	// Business Hub Logo Bavigation
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@title='Stripe Test Automation']")));Thread.sleep(2000);
		driver.findElement(By.xpath("//div[@title='Stripe Test Automation']")).click();
		Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[normalize-space()='Menu']")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()='Menu']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//span[normalize-space()='Menu']")).click();
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[normalize-space()='Meetings']")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[normalize-space()='Meetings']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//a[normalize-space()='Meetings']")).click();
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".deletemeeting-icon")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".deletemeeting-icon")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".deletemeeting-icon")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.id("btnYesConfirmYesNo")).click();
	    wait.until(ExpectedConditions.invisibilityOfElementLocated(By.id("btnYesConfirmYesNo")));
	    Thread.sleep(2000);
	    
	    /* Logout */
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'My Profile')]")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'My Profile')]")));Thread.sleep(2000);
		driver.findElement(By.xpath("//div[contains(text(),'My Profile')]")).click();  
		Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//div[contains(text(),'Logout')])[1]")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//div[contains(text(),'Logout')])[1]")));Thread.sleep(2000);
		driver.findElement(By.xpath("(//div[contains(text(),'Logout')])[1]")).click();  
		Thread.sleep(2000);
	  }
	}


