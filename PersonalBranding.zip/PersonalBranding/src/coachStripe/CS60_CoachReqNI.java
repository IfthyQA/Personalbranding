package coachStripe;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import screenshotOnFailure.FailScreenshot;

@Listeners(screenshotListners.EventList.class)
public class CS60_CoachReqNI extends FailScreenshot{
	
	@Test
	public void CS_CoachRequestNI() throws InterruptedException {

		/* Login to the Application - PBC */ 		
		driver.findElement(By.xpath("//button[normalize-space()='Login']")).click();
		driver.findElement(By.xpath("//input[@id='Username']")).click();
		driver.findElement(By.xpath("//input[@id='Username']")).sendKeys("john.doe003");
		driver.findElement(By.xpath("//input[@id='password-field']")).click();
		driver.findElement(By.xpath("//input[@id='password-field']")).sendKeys("Rockon123");
		driver.findElement(By.xpath("//button[@id='loginButton']")).click();
		Thread.sleep(2000);

		 WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(120));		
	    /* Navigate to Coaching Support Page */
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'My Profile')]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'My Profile')]")));
		Thread.sleep(2000);
		{
		     WebElement element = driver.findElement(By.xpath("//div[@class='menu-item menu-item-active']"));
		     Actions builder = new Actions(driver);
		     builder.moveToElement(element).perform();
		}
		Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'Coaching Support')]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'Coaching Support')]")));Thread.sleep(2000);
		driver.findElement(By.xpath("//div[contains(text(),'Coaching Support')]")).click();
	    Thread.sleep(2000);
	    
	    /* Send New Coach request */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[contains(text(),\'New Request\')]")));
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[contains(text(),\'New Request\')]")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//span[contains(text(),\'New Request\')]")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("TermsAndCondition")));
	    wait.until(ExpectedConditions.elementToBeClickable(By.id("TermsAndCondition")));Thread.sleep(2000);
	    driver.findElement(By.id("TermsAndCondition")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".btn-lg")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("Title")));
	    wait.until(ExpectedConditions.elementToBeClickable(By.id("Title")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".next-btn")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.id("Title")).click();
	    driver.findElement(By.id("Title")).sendKeys("abcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyz");
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".next-btn")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.id("Title")).clear();Thread.sleep(2000);
	    driver.findElement(By.id("Title")).sendKeys("Automation Testing");
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".next-btn")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.id("RequestSpecialities")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector("li:nth-child(2) .text-muted")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.id("RequestSpecialities")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector("li:nth-child(3) .text-muted")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.id("RequestSpecialities")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector("li:nth-child(9) .text-muted")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".mce-i-bold")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".mce-i-bullist")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".next-btn")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.id("Countries_All_")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.id("Countries_India_")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".next-btn")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.id("select2-Frequency-container")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".select2-search__field")).sendKeys("Weekly");
	    driver.findElement(By.cssSelector(".select2-search__field")).sendKeys(Keys.ENTER);
	    Thread.sleep(2000);
	    driver.findElement(By.id("select2-Preference_TimeZone-container")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".select2-search__field")).sendKeys("Dhaka");
	    driver.findElement(By.cssSelector(".select2-search__field")).sendKeys(Keys.ENTER);
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".days:nth-child(1)")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".days:nth-child(7)")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.id("Preference_Evening")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.id("Preference_IsConnectPerson")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.id("Preference_IsConnectPhone")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.id("Preference_IsConnectOnline")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".next-btn")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.id("Preference_IsConnectPerson")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".form-group > label:nth-child(2)")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.id("pac-input")).sendKeys("Bengaluru");
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".days:nth-child(4)")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".next-btn")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".btn-outline-blue")));
	    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".btn-outline-blue")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//div/form/button")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".form-group > #Title")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".modal-lg .modal-header .fa")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".btn-outline-blue")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[@class=\'btn-sm btn-outline-blue margin-right-15\']")));
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[@class=\'btn-sm btn-outline-blue margin-right-15\']")));Thread.sleep(2000);
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector("a > .btn-blue-link-12")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.linkText("Back to Draft Requests")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.linkText("Edit")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".btn-lg > span")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[@class=\'btn-sm btn-outline-blue margin-right-15\']")));Thread.sleep(2000);
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[@class=\'btn-sm btn-outline-blue margin-right-15\']")));
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector("a > .btn-blue-link-12")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.linkText("Back To My Requests")).click();
	    Thread.sleep(2000);
	    
	    /* Logout */
		 wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'My Profile')]")));
		 wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'My Profile')]")));
		 driver.findElement(By.xpath("//div[contains(text(),'My Profile')]")).click();
		 Thread.sleep(2000);
		 wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//div[contains(text(),'Logout')])[2]")));
		 wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//div[contains(text(),'Logout')])[2]")));
		 driver.findElement(By.xpath("(//div[contains(text(),'Logout')])[2]")).click();
		 Thread.sleep(2000);
	  }
	}

