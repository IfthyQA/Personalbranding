package coachStripe;

import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import screenshotOnFailure.FailScreenshot;

@Listeners(screenshotListners.EventList.class)
public class CS14_SendProposal extends FailScreenshot{
	
	@Test
	public void CS_SendProposal() throws InterruptedException {

		/* Login to the Application - PBC */ 		
	  	driver.findElement(By.xpath("(//button[normalize-space()='Login'])[1]")).click();
		driver.findElement(By.xpath("//input[@id='Username']")).click();
		driver.findElement(By.xpath("//input[@id='Username']")).sendKeys("john.doe007");
		driver.findElement(By.xpath("//input[@id='password-field']")).click();
		driver.findElement(By.xpath("//input[@id='password-field']")).sendKeys("Rockon123");
		driver.findElement(By.xpath("//button[@id='loginButton']")).click();
		Thread.sleep(2000);
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(120));
	    
	    /* Navigate to the Coach Page */
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[2]/div[1]/div[1]/div[2]/div[1]/div[1]/a[1]/span[1]")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[2]/div[1]/div[1]/div[2]/div[1]/div[1]/a[1]/span[1]")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[2]/div[1]/div[1]/div[2]/div[1]/div[1]/a[1]/span[1]")).click();
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[normalize-space()='Menu']")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()='Menu']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//span[normalize-space()='Menu']")).click();
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[normalize-space()='Coaching Services']")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[normalize-space()='Coaching Services']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//a[normalize-space()='Coaching Services']")).click();
	    Thread.sleep(2000);
	    
	    /* Draft Menu and Send Proposal */
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("menuitemdraft")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.id("menuitemdraft")));Thread.sleep(2000);
	    driver.findElement(By.id("menuitemdraft")).click();
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".form-inline > .btn-maroon")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".form-inline > .btn-maroon")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".form-inline > .btn-maroon")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.id("btnYesConfirmYesNo")).click();
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@title='Stripe Test Automation']")));	// Business Hub Logo Bavigation
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@title='Stripe Test Automation']")));Thread.sleep(2000);
		driver.findElement(By.xpath("//div[@title='Stripe Test Automation']")).click();
		Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[normalize-space()='Menu']")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()='Menu']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//span[normalize-space()='Menu']")).click();
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[normalize-space()='Coaching Services']")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[normalize-space()='Coaching Services']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//a[normalize-space()='Coaching Services']")).click();
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("menuitemreview")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.id("menuitemreview")));Thread.sleep(2000);
	    driver.findElement(By.id("menuitemreview")).click();
	    Thread.sleep(2000);
	    
	    /* Edit Proposal after Sent */
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.linkText("Edit")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.linkText("Edit")));Thread.sleep(2000);
	    driver.findElement(By.linkText("Edit")).click();
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("ProposalTitle")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.id("ProposalTitle")));Thread.sleep(2000);
	    driver.findElement(By.id("ProposalTitle")).clear();Thread.sleep(2000);
	    driver.findElement(By.id("ProposalTitle")).click();
	    driver.findElement(By.id("ProposalTitle")).sendKeys("ML with Deep Learning");
	    Thread.sleep(2000);
	    driver.findElement(By.id("HourlyRate")).click();
	    driver.findElement(By.id("HourlyRate")).sendKeys("5");
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".btn-blue")).click();
	    Thread.sleep(2000);
	    
	    /* Pending Prposal */
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".menu-list-active > a")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".menu-list-active > a")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".menu-list-active > a")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".col-12 > .form-inline > .btn-blue-link-12")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".btn-outline-grey")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.id("btnNoConfirmYesNo")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[3]/div/span")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".float-right:nth-child(1) > .btn-blue-link-12")).click();
	    Thread.sleep(2000);
	    
	    /* Edit Schedule meet from Draft Prposal */
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".editmeeting-icon")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".editmeeting-icon")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".editmeeting-icon")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.id("MeetingName")).clear();Thread.sleep(2000);
	    driver.findElement(By.id("MeetingName")).click();
	    driver.findElement(By.id("MeetingName")).sendKeys("Draft Send Proposal MACHINE LEARNING MEETING");
	    Thread.sleep(2000);
	    driver.findElement(By.id("submitbtn")).click();Thread.sleep(2000);
	    wait.until(ExpectedConditions.invisibilityOfElementLocated(By.id("submitbtn")));
	    
	    /* Delete Meeting */
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".deletemeeting-icon")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".deletemeeting-icon")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".deletemeeting-icon")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.id("btnYesConfirmYesNo")).click();
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".biz-admin-overlay > .modal-header .fa")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".biz-admin-overlay > .modal-header .fa")).click();
	    Thread.sleep(2000);
	    
	    /* Discussions */
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".float-right:nth-child(1) .form-inline span:nth-child(2)")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".float-right:nth-child(1) .form-inline span:nth-child(2)")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".float-right:nth-child(1) .form-inline span:nth-child(2)")).click();
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("discussiontextarea")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.id("discussiontextarea")));
		Thread.sleep(2000);
	    driver.findElement(By.xpath("//button[contains(.,\'Send Message\')]")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.id("discussiontextarea")).click();
	    driver.findElement(By.id("discussiontextarea")).sendKeys("Hello, thanks for the Coaching request, Please check the Proposal");
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("//span[@class=\'titleAttach\']")).click();Thread.sleep(2000);
	    driver.findElement(By.xpath("//button[@type=\'button\']//span[contains(text(),\'Business Vault\')]")).click();Thread.sleep(2000);
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[3]/div/div/div[2]/span")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".btn")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[@id=\'outfineuploader\']/div/span/i[2]")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("//button[contains(.,\'Send Message\')]")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".btn-blue-link-12")).click();
	    Thread.sleep(2000);
	    
	    /* Edit Prposal After Sent */
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.linkText("Edit")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.linkText("Edit")));Thread.sleep(2000);
	    driver.findElement(By.linkText("Edit")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.id("ProposalTitle")).clear();Thread.sleep(2000);	    
	    driver.findElement(By.id("ProposalTitle")).click();
	    driver.findElement(By.id("ProposalTitle")).sendKeys("Nothing");
	    driver.findElement(By.id("ProposalTitle")).clear();Thread.sleep(2000);
	    driver.findElement(By.id("ProposalTitle")).sendKeys("Machine Learning and DL with Neural");
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".btn-blue")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.id("menuitemreview")).click();
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".proposal-title")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".proposal-title")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".proposal-title")).click();
	    Thread.sleep(2000);
	    
	    /* Send Discussion */
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".btn-blue-link-12 > span:nth-child(2)")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".btn-blue-link-12 > span:nth-child(2)")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".btn-blue-link-12 > span:nth-child(2)")).click();
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("discussiontextarea")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.id("discussiontextarea")));Thread.sleep(2000);
	    driver.findElement(By.id("discussiontextarea")).click();
	    driver.findElement(By.id("discussiontextarea")).sendKeys("Hello");
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("//button[contains(.,\'Send Message\')]")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("//button[contains(.,\'Send Message\')]")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".btn-blue-link-12")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.linkText("Back to Pending Proposals")).click();
	    Thread.sleep(2000);
	        
	    /* Schedule Meeting */
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".float-md-right > .btn-blue-link-12:nth-child(1)")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".float-md-right > .btn-blue-link-12:nth-child(1)")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".float-md-right > .btn-blue-link-12:nth-child(1)")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.id("MeetingName")).click();
	    driver.findElement(By.id("MeetingName")).sendKeys("Proposal Meeting");
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("//span[@class=\'input-group-append set-date set-date-birth\']//i[@class=\'fa fa-calendar set-date-icon\']")).click();Thread.sleep(5000);
	    driver.findElement(By.xpath("//div[contains(@class, 'datetimepicker datetimepicker-')][last()]/div[3]/table/tbody/tr/td[@class='day active']")).click();Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[contains(@class, 'datetimepicker datetimepicker-')][last()]/div[2]/table/tbody/tr/td/fieldset/span[contains(@class,'hour active ')]")).click();Thread.sleep(2000);

	    if(!driver.findElements(By.xpath("//div[contains(@class, 'datetimepicker datetimepicker-')][last()]/div[1]/table/tbody/tr/td/fieldset/span[10][contains(@class, 'minute disabled')]")).isEmpty())
		{	    		    
			Thread.sleep(2000);
			driver.findElement(By.xpath("//div[@class='datetimepicker-minutes']//th[@class='next']")).click();
		    Thread.sleep(2000);
		    driver.findElement(By.xpath("//div[contains(@class, \'datetimepicker datetimepicker-\')][last()]/div[1]/table/tbody/tr/td/fieldset/span[@class=\'minute\'][3]")).click();	    		    
		}
		
		else {
			Thread.sleep(2000);
		    driver.findElement(By.xpath("//div[contains(@class, \'datetimepicker datetimepicker-\')][last()]/div[1]/table/tbody/tr/td/fieldset/span[@class=\'minute\'][3]")).click();
		}
		Thread.sleep(2000);
		driver.findElement(By.xpath("//form[@id=\'myForm\']/div[2]/div[2]/div/div[2]/div/span/span/span")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".select2-search__field")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".select2-search__field")).sendKeys("60");
	    driver.findElement(By.cssSelector(".select2-search__field")).sendKeys(Keys.ENTER);  
	    
	    /* Recurrence Meeting - Daily */
	    Thread.sleep(2000);
	    driver.findElement(By.id("select2-PlannedSchedule_StartSchedule_TypeOfSchedule-container")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".select2-search__field")).click();
	    driver.findElement(By.cssSelector(".select2-search__field")).sendKeys("da");
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".select2-search__field")).sendKeys(Keys.ENTER);
	    Thread.sleep(2000);
	    driver.findElement(By.id("submitbtn")).click();
	    Thread.sleep(2000);	    
	    wait.until(ExpectedConditions.elementToBeClickable(driver.findElement(By.xpath("//i[@class='editmeeting-icon']"))));	  
	    Thread.sleep(2000);	    
	    driver.findElement(By.cssSelector(".biz-admin-overlay > .modal-header .fa")).click();
	    Thread.sleep(2000);
	    
	    /* Logout */
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'My Profile')]")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'My Profile')]")));Thread.sleep(2000);
		driver.findElement(By.xpath("//div[contains(text(),'My Profile')]")).click();  
		Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//div[contains(text(),'Logout')])[1]")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//div[contains(text(),'Logout')])[1]")));Thread.sleep(2000);
		driver.findElement(By.xpath("(//div[contains(text(),'Logout')])[1]")).click();  
		Thread.sleep(2000);
	  }
	}

