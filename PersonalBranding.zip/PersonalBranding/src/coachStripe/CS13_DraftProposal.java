package coachStripe;

import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import screenshotOnFailure.FailScreenshot;

@Listeners(screenshotListners.EventList.class)
public class CS13_DraftProposal extends FailScreenshot{
	
	@Test
	public void CS_DraftProposal() throws InterruptedException {

	/* Login to the Application - PBC */ 		
	driver.findElement(By.xpath("(//button[normalize-space()='Login'])[1]")).click();
	driver.findElement(By.xpath("//input[@id='Username']")).click();
	driver.findElement(By.xpath("//input[@id='Username']")).sendKeys("john.doe007");
	driver.findElement(By.xpath("//input[@id='password-field']")).click();
	driver.findElement(By.xpath("//input[@id='password-field']")).sendKeys("Rockon123");
	driver.findElement(By.xpath("//button[@id='loginButton']")).click();
	Thread.sleep(2000);
	WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(120));
    
    /* Navigate to the Coach Page */
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[2]/div[1]/div[1]/div[2]/div[1]/div[1]/a[1]/span[1]")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[2]/div[1]/div[1]/div[2]/div[1]/div[1]/a[1]/span[1]")));Thread.sleep(2000);
    driver.findElement(By.xpath("//div[2]/div[1]/div[1]/div[2]/div[1]/div[1]/a[1]/span[1]")).click();
    Thread.sleep(2000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[normalize-space()='Menu']")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()='Menu']")));Thread.sleep(2000);
    driver.findElement(By.xpath("//span[normalize-space()='Menu']")).click();
    Thread.sleep(2000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[normalize-space()='Coaching Services']")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[normalize-space()='Coaching Services']")));Thread.sleep(2000);
    driver.findElement(By.xpath("//a[normalize-space()='Coaching Services']")).click();
    Thread.sleep(2000);
    
    /* Create Proposal - Draft */
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[normalize-space()='Machine Learning']")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()='Machine Learning']")));Thread.sleep(2000);   
    driver.findElement(By.xpath("//span[normalize-space()='Machine Learning']")).click();
    Thread.sleep(2000); 
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[contains(.,\'Create Proposal\')]")));Thread.sleep(2000);  
    driver.findElement(By.xpath("//button[contains(.,\'Create Proposal\')]")).click();
    Thread.sleep(2000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("TermsAndCondition")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.id("TermsAndCondition")));Thread.sleep(2000); 
    driver.findElement(By.id("TermsAndCondition")).click();
    Thread.sleep(2000);
    driver.findElement(By.cssSelector(".btn-lg")).click();
    Thread.sleep(2000);
    driver.findElement(By.cssSelector(".float-right > .btn-sm")).click();
    Thread.sleep(2000);
    driver.findElement(By.id("ProposalTitle")).click();
    driver.findElement(By.id("ProposalTitle")).sendKeys("M");
    driver.findElement(By.id("ProposalTitle")).clear();Thread.sleep(2000);
    driver.findElement(By.id("ProposalTitle")).sendKeys("abcdefghijklmnopqrstuvwxyz-abcdefghijklmnopqrstuvwxyz");
    driver.findElement(By.id("ProposalTitle")).clear();Thread.sleep(2000);
    driver.findElement(By.id("ProposalTitle")).sendKeys("Machine and Deep Learning with AI");
    Thread.sleep(2000);
    driver.findElement(By.id("HourlyRate")).click();
    driver.findElement(By.id("HourlyRate")).sendKeys("10");
    Thread.sleep(2000);
    JavascriptExecutor js = (JavascriptExecutor) driver;
    js.executeScript("document.querySelector(\'textarea.proposalHourlyDescription\').value=\"hi\";");
    Thread.sleep(2000);
    /* Attachment for the proposal */
    driver.findElement(By.xpath("//span[@class=\'titleAttach\']")).click();Thread.sleep(2000);
    driver.findElement(By.xpath("//button[@type=\'button\']//span[contains(text(),\'Business Vault\')]")).click();Thread.sleep(2000);
    Thread.sleep(2000);
    driver.findElement(By.xpath("//div[3]/div/div/div[2]/span")).click();
    Thread.sleep(2000);
    driver.findElement(By.cssSelector(".btn")).click();
    Thread.sleep(2000);
    driver.findElement(By.xpath("//div[@id=\'addblanktask\']/div/div/input")).click();
    driver.findElement(By.xpath("//div[@id=\'addblanktask\']/div/div/input")).sendKeys("123456789abcdefghijklmnopqrstuvwxyz12345678ABCDEFGI");
    driver.findElement(By.xpath("//div[@id=\'addblanktask\']/div/div/input")).clear();Thread.sleep(2000);
    driver.findElement(By.xpath("//div[@id=\'addblanktask\']/div/div/input")).sendKeys("Coach for ML & DL");
    driver.findElement(By.xpath("//div[@id=\'addblanktask\']/div/div/input")).click();
    Thread.sleep(2000);
    js.executeScript("document.querySelector(\'textarea.proposalFixedTaskDescription\').value=\"hi\";");
    js.executeScript("document.querySelector(\'textarea.proposalFixedTaskDescription\').value");
    Thread.sleep(2000);
    driver.findElement(By.cssSelector(".divStartDatePicker .fa")).click();
    Thread.sleep(2000);
    driver.findElement(By.cssSelector(".year:nth-child(12)")).click();
    Thread.sleep(2000);
    driver.findElement(By.cssSelector(".month:nth-child(9)")).click();
    Thread.sleep(2000);
    driver.findElement(By.cssSelector("tr:nth-child(2) > .day:nth-child(1)")).click();
    Thread.sleep(2000);
    driver.findElement(By.xpath("//div[@id=\'addblanktask\']/div/div[2]/div[2]/div/div[4]/div/label")).click();
    driver.findElement(By.xpath("//div[@id=\'addblanktask\']/div/div[2]/div[2]/div/div[4]/div/input")).sendKeys("24");
    Thread.sleep(2000);
    driver.findElement(By.xpath("//div[@id=\'addblanktask\']/div/div/input")).click();
    Thread.sleep(2000);
    driver.findElement(By.linkText("Add Milestone")).click();
    Thread.sleep(2000);
    driver.findElement(By.linkText("Delete Milestone")).click();
    Thread.sleep(2000);
    driver.findElement(By.cssSelector(".col-9 > .btn-outline-blue")).click();
    Thread.sleep(2000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("menuitemdraft")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.id("menuitemdraft")));Thread.sleep(2000);
    driver.findElement(By.id("menuitemdraft")).click();
    
    /* Observing Client's Detail in Coach Request */
    Thread.sleep(2000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".form-inline > .btn-maroon")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".form-inline > .btn-maroon")));
	Thread.sleep(2000);
    driver.findElement(By.cssSelector(".col-12 > .btn-blue-link-12")).click();
    Thread.sleep(2000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("#coachingcancelpopup > .modal-header .fa")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector("#coachingcancelpopup > .modal-header .fa")));
    driver.findElement(By.cssSelector("#coachingcancelpopup > .modal-header .fa")).click();
    
    /* Logout */
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'My Profile')]")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'My Profile')]")));Thread.sleep(2000);
	driver.findElement(By.xpath("//div[contains(text(),'My Profile')]")).click();  
	Thread.sleep(2000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//div[contains(text(),'Logout')])[1]")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//div[contains(text(),'Logout')])[1]")));Thread.sleep(2000);
	driver.findElement(By.xpath("(//div[contains(text(),'Logout')])[1]")).click();  
	Thread.sleep(2000);
  }
}

