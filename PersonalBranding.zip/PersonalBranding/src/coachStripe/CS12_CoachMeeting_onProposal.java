package coachStripe;

import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import screenshotOnFailure.FailScreenshot;

@Listeners(screenshotListners.EventList.class)
public class CS12_CoachMeeting_onProposal extends FailScreenshot{
	
	@Test
	public void CS_Meeting_OnProposals() throws InterruptedException {

	/* Login to the Application - PBC */ 		
	driver.findElement(By.xpath("(//button[normalize-space()='Login'])[1]")).click();
	driver.findElement(By.xpath("//input[@id='Username']")).click();
	driver.findElement(By.xpath("//input[@id='Username']")).sendKeys("john.doe007");
	driver.findElement(By.xpath("//input[@id='password-field']")).click();
	driver.findElement(By.xpath("//input[@id='password-field']")).sendKeys("Rockon123");
	driver.findElement(By.xpath("//button[@id='loginButton']")).click();
	Thread.sleep(2000);
	WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(120));
    
    /* Navigate to the Coach Page */
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[2]/div[1]/div[1]/div[2]/div[1]/div[1]/a[1]/span[1]")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[2]/div[1]/div[1]/div[2]/div[1]/div[1]/a[1]/span[1]")));Thread.sleep(2000);
    driver.findElement(By.xpath("//div[2]/div[1]/div[1]/div[2]/div[1]/div[1]/a[1]/span[1]")).click();
    Thread.sleep(2000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[normalize-space()='Menu']")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()='Menu']")));Thread.sleep(2000);
    driver.findElement(By.xpath("//span[normalize-space()='Menu']")).click();
    Thread.sleep(2000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[normalize-space()='Coaching Services']")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[normalize-space()='Coaching Services']")));Thread.sleep(2000);
    driver.findElement(By.xpath("//a[normalize-space()='Coaching Services']")).click();
    Thread.sleep(2000);
    
    /* Schedule Meeting */
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[normalize-space()='Machine Learning']")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()='Machine Learning']")));Thread.sleep(2000);   
    driver.findElement(By.xpath("//span[normalize-space()='Machine Learning']")).click();
    Thread.sleep(2000); 
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[3]/div[1]/span/span")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[3]/div[1]/span/span")));Thread.sleep(2000);
    driver.findElement(By.xpath("//div[3]/div[1]/span/span")).click();
    Thread.sleep(2000);
	wait.until(ExpectedConditions.elementToBeClickable(By.id("submitbtn")));Thread.sleep(2000);
    driver.findElement(By.id("submitbtn")).click();
    Thread.sleep(2000);
    driver.findElement(By.cssSelector("li:nth-child(2) > .form-inline span")).click();
    Thread.sleep(2000);
    driver.findElement(By.cssSelector("li:nth-child(3) > .form-inline span")).click();
    Thread.sleep(2000);
    driver.findElement(By.cssSelector("li:nth-child(2) > .form-inline span")).click();
    Thread.sleep(2000);
    driver.findElement(By.cssSelector("li > .btn-blue-link-12 > span")).click();
    Thread.sleep(2000);
    driver.findElement(By.cssSelector(".biz-admin-overlay > .modal-header .fa")).click();
    Thread.sleep(2000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[3]/div[1]/span/span")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[3]/div[1]/span/span")));Thread.sleep(2000);
    driver.findElement(By.xpath("//div[3]/div[1]/span/span")).click();
    Thread.sleep(2000);
    driver.findElement(By.id("submitbtn")).click();
    Thread.sleep(2000);
    driver.findElement(By.id("MeetingName")).click();
    driver.findElement(By.id("MeetingName")).sendKeys("Draft Proposal MEETING");
    Thread.sleep(2000);
	wait.until(ExpectedConditions.elementToBeClickable(By.id("submitbtn")));Thread.sleep(2000);
    driver.findElement(By.id("submitbtn")).click();
    Thread.sleep(2000);
    driver.findElement(By.xpath("//span[@class=\'input-group-append set-date set-date-birth\']//i[@class=\'fa fa-calendar set-date-icon\']")).click();Thread.sleep(2000);
    driver.findElement(By.xpath("//div[contains(@class, \'datetimepicker datetimepicker-\')][last()]/div[3]/table/tbody/tr/td[@class=\'day active\']")).click();Thread.sleep(2000);
    driver.findElement(By.xpath("//div[contains(@class, \'datetimepicker datetimepicker-\')][last()]/div[2]/table/tbody/tr/td/fieldset/span[contains(@class,\'hour active \')]")).click();Thread.sleep(2000);

    if(!driver.findElements(By.xpath("//div[contains(@class, 'datetimepicker datetimepicker-')][last()]/div[1]/table/tbody/tr/td/fieldset/span[10][contains(@class, 'minute disabled')]")).isEmpty())
	{	    		    
		Thread.sleep(4000);
		driver.findElement(By.xpath("//div[@class='datetimepicker-minutes']//th[@class='next']")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[contains(@class, \'datetimepicker datetimepicker-\')][last()]/div[1]/table/tbody/tr/td/fieldset/span[@class=\'minute\'][3]")).click();	    		    
	}	
	else 
	{
		Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[contains(@class, \'datetimepicker datetimepicker-\')][last()]/div[1]/table/tbody/tr/td/fieldset/span[@class=\'minute\'][3]")).click();
	}
	Thread.sleep(2000);
	driver.findElement(By.xpath("//form[@id=\'myForm\']/div[2]/div[2]/div/div[2]/div/span/span/span")).click();Thread.sleep(2000);
    driver.findElement(By.cssSelector(".select2-search__field")).click();Thread.sleep(2000);
    driver.findElement(By.cssSelector(".select2-search__field")).sendKeys("50");
    driver.findElement(By.cssSelector(".select2-search__field")).sendKeys(Keys.ENTER);  
    Thread.sleep(2000);
	wait.until(ExpectedConditions.elementToBeClickable(By.id("submitbtn")));Thread.sleep(2000);
    driver.findElement(By.id("submitbtn")).click();
    wait.until(ExpectedConditions.invisibilityOfElementLocated(By.id("submitbtn")));
    Thread.sleep(2000);
    
    /* My Meetings - Histories */
    driver.findElement(By.cssSelector(".meeting-history-text")).click();
    Thread.sleep(2000);
    driver.findElement(By.cssSelector(".form-inline .my-meeting-text")).click();
    Thread.sleep(2000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".editmeeting-icon")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".editmeeting-icon")));Thread.sleep(2000);
    driver.findElement(By.cssSelector(".editmeeting-icon")).click();
    Thread.sleep(2000);
    driver.findElement(By.id("MeetingName")).click();Thread.sleep(2000);
    driver.findElement(By.id("MeetingName")).clear();Thread.sleep(2000);  
    driver.findElement(By.id("MeetingName")).sendKeys("Coach Opportunities MEETING");
    Thread.sleep(2000);
	wait.until(ExpectedConditions.elementToBeClickable(By.id("submitbtn")));Thread.sleep(2000);
    driver.findElement(By.id("submitbtn")).click();
    Thread.sleep(2000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".addParticipant-icon")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".addParticipant-icon")));Thread.sleep(2000);
    driver.findElement(By.cssSelector(".addParticipant-icon")).click();
    Thread.sleep(2000);
    driver.findElement(By.cssSelector(".commendations-overlay > #modalCreateMeeting > .modal-header .fa")).click();
    Thread.sleep(2000);
    driver.findElement(By.cssSelector(".biz-admin-overlay > .modal-header .fa")).click();
    Thread.sleep(2000);
    
    /* Cancel Creating Proposal */
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[contains(.,\'Create Proposal\')]")));Thread.sleep(2000); 
    driver.findElement(By.xpath("//button[contains(.,\'Create Proposal\')]")).click();
    Thread.sleep(2000);
    driver.findElement(By.cssSelector(".btn-lg")).click();
    Thread.sleep(2000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("TermsAndCondition")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.id("TermsAndCondition")));Thread.sleep(2000); 
    driver.findElement(By.id("TermsAndCondition")).click();
    Thread.sleep(2000);
    driver.findElement(By.cssSelector(".btn-lg")).click();
    Thread.sleep(2000);
    driver.findElement(By.cssSelector(".float-right > .btn-sm")).click();
    Thread.sleep(2000);
    driver.findElement(By.id("ProposalTitle")).click();
    driver.findElement(By.id("ProposalTitle")).sendKeys("Life Coaching");
    Thread.sleep(2000);
    driver.findElement(By.id("HourlyRate")).click();
    driver.findElement(By.id("HourlyRate")).sendKeys("10");
    Thread.sleep(2000);
    driver.findElement(By.cssSelector(".btn-outline-grey")).click();
    Thread.sleep(2000);
    driver.findElement(By.id("btnNoConfirmYesNo")).click();
    Thread.sleep(2000);
    driver.findElement(By.cssSelector(".btn-outline-grey")).click();
    Thread.sleep(2000);
    driver.findElement(By.id("btnYesConfirmYesNo")).click();
    wait.until(ExpectedConditions.invisibilityOfElementLocated(By.id("btnYesConfirmYesNo")));
    Thread.sleep(2000);
    driver.findElement(By.id("menuitemreview")).click();
    Thread.sleep(2000);
    
    /* Logout */
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'My Profile')]")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'My Profile')]")));Thread.sleep(2000);
	driver.findElement(By.xpath("//div[contains(text(),'My Profile')]")).click();  
	Thread.sleep(2000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//div[contains(text(),'Logout')])[1]")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//div[contains(text(),'Logout')])[1]")));Thread.sleep(2000);
	driver.findElement(By.xpath("(//div[contains(text(),'Logout')])[1]")).click();  
	Thread.sleep(2000);
  }
}

