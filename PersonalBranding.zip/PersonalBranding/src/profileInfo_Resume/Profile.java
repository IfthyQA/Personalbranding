package profileInfo_Resume;

import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import screenshotOnFailure.FailScreenshot;

@Listeners(screenshotListners.EventList.class)
public class Profile extends FailScreenshot {

	@Test
	public void Member_ProfileInfo() throws InterruptedException {				
		
		/* Login to the Application */ 			
	  	driver.findElement(By.xpath("(//button[normalize-space()='Login'])[1]")).click();
		driver.findElement(By.xpath("//input[@id='Username']")).click();
		driver.findElement(By.xpath("//input[@id='Username']")).sendKeys("john.doe001");
		driver.findElement(By.xpath("//input[@id='password-field']")).click();
		driver.findElement(By.xpath("//input[@id='password-field']")).sendKeys("Rockon123");
		driver.findElement(By.xpath("//button[@id='loginButton']")).click();
		Thread.sleep(2000);
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(120));
	    	    
		/* Navigate to the Resume from Hub */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'My Profile')]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'My Profile')]")));Thread.sleep(2000);
	    {
		     WebElement element = driver.findElement(By.xpath("//div[@class='menu-item menu-item-active']"));
		     Actions builder = new Actions(driver);
		     builder.moveToElement(element).perform();
		}
		Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'Resume')]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'Resume')]")));Thread.sleep(2000);
		driver.findElement(By.xpath("//div[contains(text(),'Resume')]")).click();
		Thread.sleep(2000);	
		
		/* Header Settings */
			    
		/* Change Profile Pic */
		
	    /* Profile Info Change First and Last name */ 
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//i[@title='Edit Profile Info']")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//i[@title='Edit Profile Info']")));Thread.sleep(2000);    
	    driver.findElement(By.xpath("//div[1]/div[1]/div[2]/div[2]/div[1]/div[1]/div[1]/i[1]")).click();	    
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[normalize-space()='Cancel']")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[normalize-space()='Cancel']")));Thread.sleep(2000);
		driver.findElement(By.xpath("//button[normalize-space()='Cancel']")).click();
		Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[normalize-space()='Go Back']")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[normalize-space()='Go Back']")));Thread.sleep(2000);
		driver.findElement(By.xpath("//button[normalize-space()='Go Back']")).click();
		Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[normalize-space()='Cancel']")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[normalize-space()='Cancel']")));Thread.sleep(2000);
		driver.findElement(By.xpath("//button[normalize-space()='Cancel']")).click();
		Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[contains(@class,'modal-btn btn-cancel')]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[contains(@class,'modal-btn btn-cancel')]")));Thread.sleep(2000);
		driver.findElement(By.xpath("//button[contains(@class,'modal-btn btn-cancel')]")).click();
		Thread.sleep(2000);
		 
		/* Profile Info Changes - EDIT */  
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//i[@title='Edit Profile Info']")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//i[@title='Edit Profile Info']")));Thread.sleep(2000);   
	    driver.findElement(By.xpath("//i[@title='Edit Profile Info']")).click();	    
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("first-name")));
		wait.until(ExpectedConditions.elementToBeClickable(By.id("first-name")));Thread.sleep(2000); 
	    driver.findElement(By.id("first-name")).click();
	    driver.findElement(By.id("first-name")).clear();
	    driver.findElement(By.id("first-name")).sendKeys("Ahmedddddddddddddddd");
	    Thread.sleep(2000);
	    driver.findElement(By.id("first-name")).clear();
	    driver.findElement(By.id("first-name")).sendKeys("Chigumbura");
	    Thread.sleep(2000);
	    driver.findElement(By.id("last-name")).click();
	    driver.findElement(By.id("last-name")).clear();
	    driver.findElement(By.id("last-name")).sendKeys("Tescrassssssssssssss");
	    Thread.sleep(2000);
	    driver.findElement(By.id("last-name")).clear();
	    driver.findElement(By.id("last-name")).sendKeys("Maskadza");
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("//input[@id='pi-title']")).click();
	    driver.findElement(By.xpath("//input[@id='pi-title']")).clear();
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("//input[@id='pi-title']")).sendKeys("Test");
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("//li[normalize-space()='Test Engineer at Delloite']")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("//input[@id='pi-phone']")).click();
	    driver.findElement(By.xpath("//input[@id='pi-phone']")).clear();
	    driver.findElement(By.xpath("//input[@id='pi-phone']")).sendKeys("8976874364564549567457");
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("//input[@id='pi-phone']")).click();
	    driver.findElement(By.xpath("//input[@id='pi-phone']")).clear();
	    driver.findElement(By.xpath("//input[@id='pi-phone']")).sendKeys("9787865645");
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[normalize-space()='Save']")));Thread.sleep(2000);
		driver.findElement(By.xpath("//button[normalize-space()='Save']")).click();
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(@role,'alert')]")));
	    driver.findElement(By.xpath("//div[contains(@role,'alert')]")).click();
	    Thread.sleep(2000);
	    
	    /* Change Brand Statement and About Me */ 	
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(@class,'res-content-container')]/div[4]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(@class,'res-content-container')]/div[4]")));Thread.sleep(2000);
	    {
		     WebElement element = driver.findElement(By.xpath("//div[contains(@class,'res-content-container')]/div[4]"));
		     Actions builder = new Actions(driver);
		     builder.moveToElement(element).perform();
		}
		Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(@class,'delete-card-btn description-edit-button')]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(@class,'delete-card-btn description-edit-button')]")));Thread.sleep(2000);
		driver.findElement(By.xpath("//div[contains(@class,'delete-card-btn description-edit-button')]")).click();
		Thread.sleep(2000);
	    driver.findElement(By.id("brand-statement")).click();
	    driver.findElement(By.id("brand-statement")).clear();
	    driver.findElement(By.id("brand-statement")).sendKeys("Make everything Possible.");
	    Thread.sleep(2000);
	    driver.findElement(By.id("brand-statement")).clear();
	    driver.findElement(By.id("brand-statement")).sendKeys("abcdefghijklmnopqrstuvwxyz123456789abcdefghijklmnopqrstuvwxyz123456789ABCDEFGHIJK");
	    Thread.sleep(2000);
	    driver.findElement(By.id("brand-statement")).clear();
	    driver.findElement(By.id("brand-statement")).sendKeys("Do not Rush, Keep Calm and Hit Back.");
	    Thread.sleep(2000);
	    driver.findElement(By.id("about-me")).click();
	    driver.findElement(By.id("about-me")).clear();
	    driver.findElement(By.id("about-me")).sendKeys("For Express and Custom accounts, use the following test bank and debit card numbers to trigger certain events during testing of payouts.&nbsp;These values can only be used when creating or updating Custom accounts via the API in test mode or with Express in test mode.&nbsp;To create test mode payouts for a Standard Stripe account, use any valid bank account details (e.g., your own). Test mode payouts simulate a live payout but are not processed with the bank. Test mode always has payouts enabled, as long as valid external bank information and other relevant conditions are met, and never requires real identity verification or other interactive steps that are part of the Custom account workflow.&nbsp;For Express and Custom accounts, use the following test bank and debit card numbers to trigger certain events during testing of payouts.&nbsp;These values can only be used when creating or updating Custom accounts via the API in test mode or with Express in test mode. For Express and Custom accounts, use the following test bank and debit card numbers to trigger certain events during testing of payouts.&nbsp;These values can only be used when creating or updating Custom accounts via the API in test mode or with Express in test mode.&nbsp;To create test mode payouts for a Standard Stripe account, use any valid bank account details (e.g., your own). Test mode payouts simulate a live payout but are not processed with the bank. Test mode always has payouts enabled, as long as valid external bank information and other relevant conditions are met, and never requires real identity verification or other interactive steps that are part of the Custom account workflow.&nbsp;For Express and Custom accounts, use the following test bank and debit card numbers to trigger certain events during testing of payouts.&nbsp;These values can only be used when creating or updating Custom accounts via the API in test mode or with Express in test mode.");
	    Thread.sleep(2000);
	    driver.findElement(By.id("about-me")).clear();
	    driver.findElement(By.id("about-me")).sendKeys("abcdefghijklmnopqrstuvwxyz123456789abcdefghijklmnopqrstuvwxyz123456789ABCDEFGHIJK");
	    Thread.sleep(2000);
	    driver.findElement(By.id("about-me")).clear();
	    driver.findElement(By.id("about-me")).sendKeys("For Express and Custom accounts, use the following test bank and debit card numbers to trigger certain events during testing of payouts.&nbsp;These values can only be used when creating or updating Custom accounts via the API in test mode or with Express in test mode.&nbsp;To create test mode payouts for a Standard Stripe account, use any valid bank account details (e.g., your own). Test mode payouts simulate a live payout but are not processed with the bank. Test mode always has payouts enabled, as long as valid external bank information and other relevant conditions are met, and never requires real identity verification or other interactive steps that are part of the Custom account workflow.&nbsp;For Express and Custom accounts, use the following test bank and debit card numbers to trigger certain events during testing of payouts.&nbsp;These values can only be used when creating or updating Custom accounts via the API in test mode or with Express in test mode.");
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[normalize-space()='Save']")));Thread.sleep(2000);
		driver.findElement(By.xpath("//button[normalize-space()='Save']")).click();
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(@role,'alert')]")));
	    driver.findElement(By.xpath("//div[contains(@role,'alert')]")).click();
	    Thread.sleep(2000);	 
	    
	    /* Change name from settings */
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'My Profile')]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'My Profile')]")));Thread.sleep(2000);
		driver.findElement(By.xpath("//div[contains(text(),'My Profile')]")).click();
		Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'Settings')]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'Settings')]")));Thread.sleep(2000);
		driver.findElement(By.xpath("//div[contains(text(),'Settings')]")).click();
		Thread.sleep(2000);	
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("FirstName")));
		wait.until(ExpectedConditions.elementToBeClickable(By.id("FirstName")));Thread.sleep(2000);
	    driver.findElement(By.id("FirstName")).click();
	    driver.findElement(By.id("FirstName")).clear();
	    Thread.sleep(2000);
	    driver.findElement(By.id("FirstName")).sendKeys("Ahmed");
	    Thread.sleep(2000);
	    driver.findElement(By.id("LastName")).click();
	    driver.findElement(By.id("LastName")).clear();
	    driver.findElement(By.id("LastName")).sendKeys("Tescra");
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".set-personal-savebtn")).click();
		wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".toast-message")));
	    driver.findElement(By.cssSelector(".toast-message")).click();
	    
	    /* Log Out */ 
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'My Profile')]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'My Profile')]")));Thread.sleep(2000);
		driver.findElement(By.xpath("//div[contains(text(),'My Profile')]")).click();
		Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//div[contains(text(),'Logout')])[2]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//div[contains(text(),'Logout')])[2]")));Thread.sleep(2000);
		driver.findElement(By.xpath("(//div[contains(text(),'Logout')])[2]")).click();
		Thread.sleep(2000);
	  }
	}


