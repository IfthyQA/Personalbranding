package SocialPower;

import java.io.IOException;
import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import screenshotOnFailure.FailScreenshot;

@Listeners(screenshotListners.EventList.class)
public class S2_CreateCustom_Post extends FailScreenshot{

	@Test
	public void Social_CreateCustom_Post() throws InterruptedException, IOException {
		
		/* Login to the Application - PBC */ 		
		driver.findElement(By.xpath("//button[normalize-space()='Login']")).click();
		driver.findElement(By.xpath("//input[@id='Username']")).click();
		driver.findElement(By.xpath("//input[@id='Username']")).sendKeys("john.doe004a");
		driver.findElement(By.xpath("//input[@id='password-field']")).click();
		driver.findElement(By.xpath("//input[@id='password-field']")).sendKeys("Rockon123");
		driver.findElement(By.xpath("//button[@id='loginButton']")).click();
		Thread.sleep(2000);
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(120));
		 
		/* Navigate to the Social Power */
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'My Profile')]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'My Profile')]")));Thread.sleep(2000);
		{
		    WebElement element = driver.findElement(By.xpath("//div[@class='menu-item menu-item-active']"));
		    Actions builder = new Actions(driver);
		    builder.moveToElement(element).perform();
		}
		Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'Social Power')]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'Social Power')]")));Thread.sleep(2000);
		driver.findElement(By.xpath("//div[contains(text(),'Social Power')]")).click();
		Thread.sleep(2000);    
	    
		/* Create Custom Post and Delete */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//div[@class='blue-border-btn-with-blue-icon-large-text-label'][normalize-space()='Create a New Post'])[1]")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//div[@class='blue-border-btn-with-blue-icon-large-text-label'][normalize-space()='Create a New Post'])[1]")));Thread.sleep(2000);
	    driver.findElement(By.xpath("(//div[@class='blue-border-btn-with-blue-icon-large-text-label'][normalize-space()='Create a New Post'])[1]")).click();
	    Thread.sleep(2000);	
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("description")));
		wait.until(ExpectedConditions.elementToBeClickable(By.id("description")));Thread.sleep(2000);
		driver.findElement(By.id("description")).click();
		driver.findElement(By.id("description")).clear();
		driver.findElement(By.id("description")).sendKeys("Hello All, its Custom post from the Automation Regression suite. But it will be deleted for the CRUD operations");
		Thread.sleep(2000);  	    
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='power-share-textstyle']"))); /* Upload from Power share */
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@class='power-share-textstyle']")));Thread.sleep(2000);	    
	    driver.findElement(By.xpath("//div[@class='power-share-textstyle']")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[normalize-space()='Cancel']")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[normalize-space()='Cancel']")));
		Thread.sleep(2000);	  
	    driver.findElement(By.xpath("(//input[@class='item-checkbox checkbox-green'])[1]")).click(); /* Select First File */
	    Thread.sleep(2000); 
	    driver.findElement(By.xpath("(//div[normalize-space()='Post'])[1]")).click(); // click POST folder
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'jawa-42.jpg')]")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'jawa-42.jpg')]")));	 
	    Thread.sleep(2000); 
	    driver.findElement(By.xpath("(//input[@class='item-checkbox checkbox-green'])[1]")).click(); /* Select First File */
	    Thread.sleep(2000); 
	    driver.findElement(By.xpath("//button[normalize-space()='Folder Root']")).click(); /* Go Back to Main Folder - FOLDER ROOT */
	    Thread.sleep(2000);  
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[contains(text(),'Add To Post')]")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[contains(text(),'Add To Post')]")));	 
	    driver.findElement(By.xpath("//button[contains(text(),'Add To Post')]")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@id='Custom']")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@id='Custom']")));	
	    driver.findElement(By.xpath("(//input[@id='autofill-inp'])[1]")).click();
		driver.findElement(By.xpath("(//input[@id='autofill-inp'])[1]")).sendKeys("Test");
		driver.findElement(By.xpath("(//input[@id='autofill-inp'])[1]")).sendKeys(Keys.ENTER);
		Thread.sleep(2000);
		driver.findElement(By.xpath("(//input[@id='autofill-inp'])[1]")).click();
		driver.findElement(By.xpath("(//input[@id='autofill-inp'])[1]")).sendKeys("Automation");
	    driver.findElement(By.xpath("(//input[@id='autofill-inp'])[1]")).sendKeys(Keys.ENTER);
	 	Thread.sleep(2000);	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@id='Custom']")));	 
	    driver.findElement(By.xpath("//input[@id='Custom']")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("(//input[@id='autofill-inp'])[2]")).click();
		driver.findElement(By.xpath("(//input[@id='autofill-inp'])[2]")).sendKeys("ilhan");Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[contains(text(),'Ilhan Lolita')]")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[normalize-space()='Post']")));	 
	    driver.findElement(By.xpath("//button[normalize-space()='Post']")).click();
	    Thread.sleep(2000);
	    
	    /* Logout from the social power */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'My Profile')]")));
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'My Profile')]")));Thread.sleep(2000);
		driver.findElement(By.xpath("//div[contains(text(),'My Profile')]")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//div[contains(text(),'Logout')]")).click();
		Thread.sleep(2000);
	  }
	}
