package SocialPower;

import java.io.IOException;
import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import screenshotOnFailure.FailScreenshot;

@Listeners(screenshotListners.EventList.class)
public class S1_CreatePublic_Post extends FailScreenshot{

	@Test
	public void Social_CreatePublic_Post() throws InterruptedException, IOException {
		
		/* Login to the Application - PBC */ 		
		 driver.findElement(By.xpath("//button[normalize-space()='Login']")).click();
		 driver.findElement(By.xpath("//input[@id='Username']")).click();
		 driver.findElement(By.xpath("//input[@id='Username']")).sendKeys("john.doe004");
		 driver.findElement(By.xpath("//input[@id='password-field']")).click();
		 driver.findElement(By.xpath("//input[@id='password-field']")).sendKeys("Rockon123");
		 driver.findElement(By.xpath("//button[@id='loginButton']")).click();
		 Thread.sleep(2000);
		 WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(120));
		 
		 /* Navigate to the Social Power */
		    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'My Profile')]")));
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'My Profile')]")));Thread.sleep(2000);
		 {
		     WebElement element = driver.findElement(By.xpath("//div[@class='menu-item menu-item-active']"));
		     Actions builder = new Actions(driver);
		     builder.moveToElement(element).perform();
		 }
		 Thread.sleep(2000);
		 wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'Social Power')]")));
		 wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'Social Power')]")));Thread.sleep(2000);
		 driver.findElement(By.xpath("//div[contains(text(),'Social Power')]")).click();
		 Thread.sleep(2000);
	    
	    /* Create Public Post and Close Icon */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//div[@class='blue-border-btn-with-blue-icon-large-text-label'][normalize-space()='Create a New Post'])[1]")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//div[@class='blue-border-btn-with-blue-icon-large-text-label'][normalize-space()='Create a New Post'])[1]")));Thread.sleep(2000);
	    driver.findElement(By.xpath("(//div[@class='blue-border-btn-with-blue-icon-large-text-label'][normalize-space()='Create a New Post'])[1]")).click();
	    Thread.sleep(2000);	 
	    driver.findElement(By.xpath("//div[@class='close-img']")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("//button[normalize-space()='Yes, Cancel']")).click();
	    Thread.sleep(2000);
	    
	    /* Create Public Post and Cancel */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//div[@class='blue-border-btn-with-blue-icon-large-text-label'][normalize-space()='Create a New Post'])[1]")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//div[@class='blue-border-btn-with-blue-icon-large-text-label'][normalize-space()='Create a New Post'])[1]")));Thread.sleep(2000);
	    driver.findElement(By.xpath("(//div[@class='blue-border-btn-with-blue-icon-large-text-label'][normalize-space()='Create a New Post'])[1]")).click();
	    Thread.sleep(2000);	
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[normalize-space()='Cancel']")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[normalize-space()='Cancel']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//button[normalize-space()='Cancel']")).click();
	    Thread.sleep(2000);	
	    driver.findElement(By.xpath("//button[normalize-space()='Go Back']")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[normalize-space()='Cancel']")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[normalize-space()='Cancel']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//button[normalize-space()='Cancel']")).click();
	    Thread.sleep(2000);	
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[normalize-space()='Yes, Cancel']")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[normalize-space()='Yes, Cancel']")));
	    driver.findElement(By.xpath("//button[normalize-space()='Yes, Cancel']")).click();
	    Thread.sleep(2000);
	    
	    /* Create Public Post and Delete */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//div[@class='blue-border-btn-with-blue-icon-large-text-label'][normalize-space()='Create a New Post'])[1]")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//div[@class='blue-border-btn-with-blue-icon-large-text-label'][normalize-space()='Create a New Post'])[1]")));Thread.sleep(2000);
	    driver.findElement(By.xpath("(//div[@class='blue-border-btn-with-blue-icon-large-text-label'][normalize-space()='Create a New Post'])[1]")).click();
	    Thread.sleep(2000);	
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='power-share-textstyle']")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@class='power-share-textstyle']")));Thread.sleep(2000);	    
	    driver.findElement(By.xpath("//div[@class='power-share-textstyle']")).click();
	    Thread.sleep(2000);	 
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[normalize-space()='Back']")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[normalize-space()='Back']")));Thread.sleep(2000);	    
	    driver.findElement(By.xpath("//div[normalize-space()='Back']")).click();
	    Thread.sleep(2000);	 	 
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("description")));
		wait.until(ExpectedConditions.elementToBeClickable(By.id("description")));Thread.sleep(2000);
		driver.findElement(By.id("description")).click();
		driver.findElement(By.id("description")).clear();
		driver.findElement(By.id("description")).sendKeys("Hello All, its Public post from the Automation Regression suite, and it will be deleted for the CRUD operations");
		Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[@class='browse-blue']")));	/* Upload from local Device */
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[@class='browse-blue']")));
	    driver.findElement(By.xpath("//span[@class='browse-blue']")).click();
	    Thread.sleep(2000);
	    Runtime.getRuntime().exec("C:\\Users\\dev\\Documents\\AutoScripts\\Upload.exe");
	    Thread.sleep(2000);	   	    
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//i[@class='fa fa-times-circle delete-img-icon']"))); /* Till the image load with X icon */
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//i[@class='fa fa-times-circle delete-img-icon']")));Thread.sleep(2000);	    
	    driver.findElement(By.xpath("//i[@class='fa fa-times-circle delete-img-icon']")).click(); /* Remove the Uploaded File */
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[@class='browse-blue']")));	/* Again Upload from local Device */
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[@class='browse-blue']")));
	    driver.findElement(By.xpath("//span[@class='browse-blue']")).click();
	    Thread.sleep(2000);
	    Runtime.getRuntime().exec("C:\\Users\\dev\\Documents\\AutoScripts\\Upload.exe");
	    Thread.sleep(2000);	   	    
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//i[@class='fa fa-times-circle delete-img-icon']"))); /* Till the image load with X icon */
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//i[@class='fa fa-times-circle delete-img-icon']")));Thread.sleep(2000);	
	    Thread.sleep(2000);    	    
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='power-share-textstyle']"))); /* Upload from Power share */
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@class='power-share-textstyle']")));Thread.sleep(2000);	    
	    driver.findElement(By.xpath("//div[@class='power-share-textstyle']")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[normalize-space()='Cancel']")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[normalize-space()='Cancel']")));
		Thread.sleep(2000);	  
	    driver.findElement(By.xpath("(//input[@class='item-checkbox checkbox-green'])[2]")).click(); /* Select First File */
	    Thread.sleep(2000); 
	    driver.findElement(By.xpath("//div[5]/div[1]/div[1]/input[1]")).click(); /* unselect from bottom Tray */
	    Thread.sleep(2000); 
	    driver.findElement(By.xpath("(//input[@class='item-checkbox checkbox-green'])[2]")).click(); /* Select First File */
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("(//div[normalize-space()='Post'])[1]")).click(); // click POST folder
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'avatar2.jpg')]")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'avatar2.jpg')]")));	 
	    Thread.sleep(2000); 
	    driver.findElement(By.xpath("(//input[@class='item-checkbox checkbox-green'])[3]")).click(); /* Select First File */
	    Thread.sleep(2000); 
	    driver.findElement(By.xpath("//div[5]/div[1]/div[1]/input[1]")).click(); /* unselect from bottom Tray */
	    Thread.sleep(2000); 
	    driver.findElement(By.xpath("//div[5]/div[1]/div[1]/input[1]")).click(); /* unselect from bottom Tray */
	    Thread.sleep(2000); 
	    driver.findElement(By.xpath("(//input[@class='item-checkbox checkbox-green'])[3]")).click(); /* Select Third File on POST Folder */
	    Thread.sleep(2000); 
	    driver.findElement(By.xpath("//button[normalize-space()='Folder Root']")).click(); /* Go Back to Main Folder - FOLDER ROOT */
	    Thread.sleep(2000);   
	    driver.findElement(By.xpath("(//input[@class='item-checkbox checkbox-green'])[2]")).click(); /* Select First File */
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[contains(text(),'Add To Post')]")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[contains(text(),'Add To Post')]")));	 
	    driver.findElement(By.xpath("//button[contains(text(),'Add To Post')]")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("(//input[@id='autofill-inp'])[1]")).click();
		driver.findElement(By.xpath("(//input[@id='autofill-inp'])[1]")).sendKeys("Test");
		driver.findElement(By.xpath("(//input[@id='autofill-inp'])[1]")).sendKeys(Keys.ENTER);
		Thread.sleep(2000);
		driver.findElement(By.xpath("(//input[@id='autofill-inp'])[1]")).click();
		driver.findElement(By.xpath("(//input[@id='autofill-inp'])[1]")).sendKeys("Automation");
	    driver.findElement(By.xpath("(//input[@id='autofill-inp'])[1]")).sendKeys(Keys.ENTER);
	 	Thread.sleep(2000);
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[normalize-space()='Post']")));	 
	    driver.findElement(By.xpath("//button[normalize-space()='Post']")).click();
	    Thread.sleep(2000);
	    
	    /* Delete the Post */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[3]/div[1]/div[1]/div[1]/div[1]/div[1]/div[2]/*[name()='svg'][1]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[3]/div[1]/div[1]/div[1]/div[1]/div[1]/div[2]/*[name()='svg'][1]")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[3]/div[1]/div[1]/div[1]/div[1]/div[1]/div[2]/*[name()='svg'][1]")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//li[normalize-space()='Delete']")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//li[normalize-space()='Delete']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//li[normalize-space()='Delete']")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[normalize-space()='Delete']")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[normalize-space()='Delete']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//button[normalize-space()='Delete']")).click();
	    Thread.sleep(2000);
	    
	    /* Logout from the social power */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'My Profile')]")));
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'My Profile')]")));Thread.sleep(2000);
		driver.findElement(By.xpath("//div[contains(text(),'My Profile')]")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//div[contains(text(),'Logout')]")).click();
		Thread.sleep(2000);
	  }
	}
