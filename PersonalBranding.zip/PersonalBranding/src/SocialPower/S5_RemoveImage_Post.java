package SocialPower;

import java.io.IOException;
import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import screenshotOnFailure.FailScreenshot;

@Listeners(screenshotListners.EventList.class)
public class S5_RemoveImage_Post extends FailScreenshot{

	@Test
	public void Social_RemoveImage_from_Post() throws InterruptedException, IOException {
		
		/* Login to the Application - PBC */ 		
		driver.findElement(By.xpath("//button[normalize-space()='Login']")).click();
		driver.findElement(By.xpath("//input[@id='Username']")).click();
		driver.findElement(By.xpath("//input[@id='Username']")).sendKeys("john.doe004");
		driver.findElement(By.xpath("//input[@id='password-field']")).click();
		driver.findElement(By.xpath("//input[@id='password-field']")).sendKeys("Rockon123");
		driver.findElement(By.xpath("//button[@id='loginButton']")).click();
		Thread.sleep(2000);
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(120));
	    
		/* Navigate to the Social Power */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'My Profile')]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'My Profile')]")));Thread.sleep(2000);
		{
		     WebElement element = driver.findElement(By.xpath("//div[@class='menu-item menu-item-active']"));
		     Actions builder = new Actions(driver);
		     builder.moveToElement(element).perform();
		}
		Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'Social Power')]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'Social Power')]")));Thread.sleep(2000);
		driver.findElement(By.xpath("//div[contains(text(),'Social Power')]")).click();
		Thread.sleep(2000);
	    
		/* Scroll Up the page */
	    JavascriptExecutor jse = (JavascriptExecutor)driver;
	    jse.executeScript("scroll(0, -250);");	    	    
	    Thread.sleep(2000); 
	    
	    /* Click "See All My Activity" and Edit */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='see-all-activity']")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@class='see-all-activity']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[@class='see-all-activity']")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'Back')]")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'Back')]")));
	    driver.findElement(By.xpath("//div[contains(text(),'Back')]")).click();
		Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='see-all-activity']")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@class='see-all-activity']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[@class='see-all-activity']")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'Back')]")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'Back')]")));
		Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[4]/div[1]/div[1]/div[1]/div[1]/div[2]/*[name()='svg'][1]/*[name()='path'][1]")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//li[normalize-space()='Edit']")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//li[normalize-space()='Edit']")));    	     
	    driver.findElement(By.xpath("//li[normalize-space()='Edit']")).click();
	    Thread.sleep(2000);
	    	  
	    /* Remove Image from First Post */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//i[@class='fa fa-times-circle delete-img-icon']")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//i[@class='fa fa-times-circle delete-img-icon']"))); 
	    driver.findElement(By.xpath("//i[@class='fa fa-times-circle delete-img-icon']")).click();	    
	    Thread.sleep(2000);	
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@id='autofill-inp']")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@id='autofill-inp']")));
	    driver.findElement(By.xpath("//div[@title='Achnet']//div[@class='close-icon-blue']")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("//input[@id='autofill-inp']")).click();
	    driver.findElement(By.xpath("//input[@id='autofill-inp']")).sendKeys("Achnet");
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("//input[@id='autofill-inp']")).sendKeys(Keys.ENTER);
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[@title='Coaching']//div[@class='close-icon-blue']")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("//input[@id='autofill-inp']")).click();
	    driver.findElement(By.xpath("//input[@id='autofill-inp']")).sendKeys("Coaching");
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("//input[@id='autofill-inp']")).sendKeys(Keys.ENTER);
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[contains(text(),'Post')]")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[contains(text(),'Post')]")));
	    driver.findElement(By.xpath("//button[contains(text(),'Post')]")).click();
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@role='alert']")));
	    driver.findElement(By.xpath("//button[@aria-label='close']//*[name()='svg']")).click();
	    Thread.sleep(2000);
	    
	    /* Tabs - Posts - Like and Unlike */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@title='Posts']//div[contains(text(),'Posts')]")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@title='Posts']//div[contains(text(),'Posts')]")));
	    driver.findElement(By.xpath("//div[@title='Posts']//div[contains(text(),'Posts')]")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@title='Unlike']")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@title='Unlike']")));
	    driver.findElement(By.xpath("//div[@title='Unlike']")).click();
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@role='alert']")));
	    driver.findElement(By.xpath("//button[@aria-label='close']//*[name()='svg']")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@title='Like']")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@title='Like']")));
	    driver.findElement(By.xpath("//div[@title='Like']")).click();
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@role='alert']")));
	    driver.findElement(By.xpath("//button[@aria-label='close']//*[name()='svg']")).click();
	    Thread.sleep(2000);
	    
	    /* Tabs - Liked by ME - Unlike */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'Liked By Me')]")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'Liked By Me')]")));
	    driver.findElement(By.xpath("//div[contains(text(),'Liked By Me')]")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@title='Unlike']")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@title='Unlike']")));
	    driver.findElement(By.xpath("//div[@title='Unlike']")).click();
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@role='alert']")));
	    driver.findElement(By.xpath("//button[@aria-label='close']//*[name()='svg']")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'Back')]")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'Back')]")));
	    driver.findElement(By.xpath("//div[contains(text(),'Back')]")).click();
		Thread.sleep(2000);
	    
	    /* Click See All Activity */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='see-all-activity']")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@class='see-all-activity']")));
	    driver.findElement(By.xpath("//div[@class='see-all-activity']")).click();
	    Thread.sleep(2000);
	    
	    /* Sort by Hastags*/
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[normalize-space()='#coaching']")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[normalize-space()='#coaching']")));
	    driver.findElement(By.xpath("//div[normalize-space()='#coaching']")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'Create a New Post')]")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'Create a New Post')]")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[contains(text(),'Create a New Post')]")).click();
	    Thread.sleep(2000);	 
	    driver.findElement(By.xpath("//div[@class='close-img']")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("//button[normalize-space()='Yes, Cancel']")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'Back')]")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'Back')]")));
	    driver.findElement(By.xpath("//div[contains(text(),'Back')]")).click();
	    Thread.sleep(2000);
	    
	    /* Logout from the Social Power */
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'My Profile')]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'My Profile')]")));Thread.sleep(2000);
		driver.findElement(By.xpath("//div[contains(text(),'My Profile')]")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//div[contains(text(),'Logout')]")).click();
		Thread.sleep(2000);
	  }
	}
