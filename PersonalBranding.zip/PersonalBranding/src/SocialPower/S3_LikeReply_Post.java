package SocialPower;

import java.io.IOException;
import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import screenshotOnFailure.FailScreenshot;

@Listeners(screenshotListners.EventList.class)
public class S3_LikeReply_Post extends FailScreenshot{

	@Test
	public void Social_LikeReply_Others_Post() throws InterruptedException, IOException {
		
		/* Login to the Application - PBC */ 		
		driver.findElement(By.xpath("//button[normalize-space()='Login']")).click();
		driver.findElement(By.xpath("//input[@id='Username']")).click();
		driver.findElement(By.xpath("//input[@id='Username']")).sendKeys("john.doe004");
		driver.findElement(By.xpath("//input[@id='password-field']")).click();
		driver.findElement(By.xpath("//input[@id='password-field']")).sendKeys("Rockon123");
		driver.findElement(By.xpath("//button[@id='loginButton']")).click();
		Thread.sleep(2000);
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(120));
	    
		/* Navigate to the Social Power */
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'My Profile')]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'My Profile')]")));Thread.sleep(2000);
		{
		    WebElement element = driver.findElement(By.xpath("//div[@class='menu-item menu-item-active']"));
		    Actions builder = new Actions(driver);
		    builder.moveToElement(element).perform();
		}
		Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'Social Power')]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'Social Power')]")));Thread.sleep(2000);
		driver.findElement(By.xpath("//div[contains(text(),'Social Power')]")).click();
		Thread.sleep(2000);	 
	    
	    /* Like - Comment - Share My FEED - Other's Post*/
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[1]/div[3]/div[1]/div[1]/div[1]/div[1]/div[3]/div[1]/div[1]/div[1]/div[1]/*[name()='svg'][1]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[1]/div[3]/div[1]/div[1]/div[1]/div[1]/div[3]/div[1]/div[1]/div[1]/div[1]/*[name()='svg'][1]")));Thread.sleep(2000);
		driver.findElement(By.xpath("//div[1]/div[3]/div[1]/div[1]/div[1]/div[1]/div[3]/div[1]/div[1]/div[1]/div[1]/*[name()='svg'][1]")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//div[1]/div[3]/div[1]/div[1]/div[1]/div[1]/div[3]/div[1]/div[1]/div[1]/div[1]/*[name()='svg'][1]")).click();Thread.sleep(2000); 	    
	    
	    driver.findElement(By.xpath("//div[1]/div[3]/div[1]/div[1]/div[1]/div[1]/div[3]/div[1]/div[2]/div[1]/div[1]/*[name()='svg'][1]")).click();
	    Thread.sleep(2000); 	    
	    WebElement element = driver.findElement(By.xpath("//div[3]/div[1]/div[1]/div[1]/div[1]/div[2]/div[1]/div[1]/div[2]/div[1]/img[1]"));
	    ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", element);
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//textarea[@name='comment']")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//textarea[@name='comment']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//textarea[@name='comment']")).click();
	    driver.findElement(By.xpath("//textarea[@name='comment']")).sendKeys("The Posts looks amazing, beautiful content and pictures");
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[contains(text(),'Send')]")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//button[contains(text(),'Send')]")).click();Thread.sleep(2000);
		
	    driver.findElement(By.xpath("//div[1]/div[3]/div[1]/div[1]/div[1]/div[1]/div[3]/div[2]/div[1]/div[1]/div[2]")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[contains(text(),'Cancel')]")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[contains(text(),'Cancel')]")));
	    Thread.sleep(2000);
	    driver.findElement(By.id("email")).click();
		driver.findElement(By.id("email")).sendKeys("Sadam");Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[contains(text(),'Sadam Eve')]")).click();
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//button[contains(text(),'Send')])[1]")));Thread.sleep(2000);
	    driver.findElement(By.xpath("(//button[contains(text(),'Send')])[1]")).click();
	    Thread.sleep(2000);
	    JavascriptExecutor jse = (JavascriptExecutor)driver;	    	    	    
	    
	    /* Scroll Up*/	    
	    WebElement Scroll = driver.findElement(By.xpath("(//div[@class='blue-border-btn-with-blue-icon-large-text-label'][normalize-space()='Create a New Post'])[1]"));
	    ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", Scroll);
	    Thread.sleep(2000);
	    
	    /* Follow and Unfollow, First Post - Sadam Eve */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[1]/div[3]/div[1]/div[1]/div[1]/div[1]/div[1]/div[2]/*[name()='svg'][1]")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[1]/div[3]/div[1]/div[1]/div[1]/div[1]/div[1]/div[2]/*[name()='svg'][1]")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[1]/div[3]/div[1]/div[1]/div[1]/div[1]/div[1]/div[2]/*[name()='svg'][1]")).click();
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//li[normalize-space()='Follow']")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//li[normalize-space()='Follow']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//li[normalize-space()='Follow']")).click();
	    Thread.sleep(2000);	
	    driver.findElement(By.xpath("//div[1]/div[3]/div[1]/div[1]/div[1]/div[1]/div[1]/div[2]/*[name()='svg'][1]")).click();
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//li[normalize-space()='Unfollow']")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//li[normalize-space()='Unfollow']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//li[normalize-space()='Unfollow']")).click();
	    Thread.sleep(2000);	
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[normalize-space()='Unfollow']")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[normalize-space()='Unfollow']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//button[normalize-space()='Unfollow']")).click();
	    Thread.sleep(2000);	
	    
	    /* Scroll till the Edit Message Section */ 	
		WebElement scroll = driver.findElement(By.xpath("//div[1]/div[3]/div[1]/div[1]/div[1]/div[1]/div[2]/div[1]/div[1]/div[2]/div[1]/img[1]"));
		Thread.sleep(2000);
		jse.executeScript("arguments[0].scrollIntoView(true);",scroll);
		Thread.sleep(2000);
	    	    
	    /* Delete the Comment with attachment */
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[1]/div[1]/div[1]/div[2]/div[2]/div[1]/div[1]/div[1]/*[name()='svg'][1]/*[name()='path'][1]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[1]/div[1]/div[1]/div[2]/div[2]/div[1]/div[1]/div[1]/*[name()='svg'][1]/*[name()='path'][1]")));Thread.sleep(2000);
		Actions action = new Actions(driver); 	
		WebElement attach= driver.findElement(By.xpath("//div[3]/div/div[1]/div[1]/div[2]/div[1]/div/div/div[2]/div[2]/div/div/div[1]"));
		action.moveToElement(attach).build().perform();
		Thread.sleep(2000);
		attach.click();
		Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//li[contains(text(),'Power Share')]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//li[contains(text(),'Power Share')]")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//li[contains(text(),'Power Share')]")).click();
	    Thread.sleep(2000);	
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[normalize-space()='Cancel']")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[normalize-space()='Cancel']")));
		Thread.sleep(2000);	  
	    driver.findElement(By.xpath("(//input[@class='item-checkbox checkbox-green'])[2]")).click(); /* Select First File */
	    Thread.sleep(2000); 
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[normalize-space()='Add To Comment']")));	 
	    driver.findElement(By.xpath("//button[normalize-space()='Add To Comment']")).click();
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//i[@class='fa fa-times-circle delete-img-icon']"))); 	 
	    driver.findElement(By.xpath("//i[@class='fa fa-times-circle delete-img-icon']")).click(); // Remove the attached file
	    Thread.sleep(2000);

		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[1]/div[1]/div[1]/div[2]/div[2]/div[1]/div[1]/div[1]/*[name()='svg'][1]/*[name()='path'][1]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[1]/div[1]/div[1]/div[2]/div[2]/div[1]/div[1]/div[1]/*[name()='svg'][1]/*[name()='path'][1]")));Thread.sleep(2000);
		action.moveToElement(attach).build().perform();
		Thread.sleep(2000);
		attach.click();
		Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//li[contains(text(),'Power Share')]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//li[contains(text(),'Power Share')]")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//li[contains(text(),'Power Share')]")).click();
	    Thread.sleep(2000);	
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[normalize-space()='Cancel']")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[normalize-space()='Cancel']")));
		Thread.sleep(2000);	  
	    driver.findElement(By.xpath("(//input[@class='item-checkbox checkbox-green'])[2]")).click(); /* Select First File */
	    Thread.sleep(2000); 
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[normalize-space()='Add To Comment']")));	 
	    driver.findElement(By.xpath("//button[normalize-space()='Add To Comment']")).click();
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[contains(text(),'Send')]")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//button[contains(text(),'Send')]")).click();Thread.sleep(2000);
	    
	    /* Scroll till the Edit Message Section */ 	
		WebElement scroll1 = driver.findElement(By.xpath("//div[1]/div[3]/div[1]/div[1]/div[1]/div[1]/div[2]/div[1]/div[1]/div[2]/div[1]/img[1]"));
		Thread.sleep(2000);
		jse.executeScript("arguments[0].scrollIntoView(true);",scroll1);
		Thread.sleep(2000);
		
	    /* Edit - Delete the Comment */
	    driver.findElement(By.xpath("//div[1]/div[3]/div[1]/div[1]/div[1]/div[2]/div[3]/div[1]/div[1]/div[1]/div[2]/span[1]/*[name()='svg'][1]")).click();
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//li[normalize-space()='Edit']")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//li[normalize-space()='Edit']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//li[normalize-space()='Edit']")).click();
	    Thread.sleep(2000);	
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//textarea[@name='comment'])[2]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//textarea[@name='comment'])[2]")));Thread.sleep(2000);
	    driver.findElement(By.xpath("(//textarea[@name='comment'])[2]")).click();
	    driver.findElement(By.xpath("(//textarea[@name='comment'])[2]")).sendKeys("Hi");
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[@type='button']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//button[@type='button']")).click();
	    Thread.sleep(2000);	
	    driver.findElement(By.xpath("//div[1]/div[3]/div[1]/div[1]/div[1]/div[2]/div[3]/div[1]/div[1]/div[1]/div[2]/span[1]/*[name()='svg'][1]")).click();
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//li[normalize-space()='Edit']")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//li[normalize-space()='Edit']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//li[normalize-space()='Edit']")).click();
	    Thread.sleep(2000);	
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//textarea[@name='comment'])[2]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//textarea[@name='comment'])[2]")));Thread.sleep(2000);
	    driver.findElement(By.xpath("(//textarea[@name='comment'])[2]")).click();
	    driver.findElement(By.xpath("(//textarea[@name='comment'])[2]")).sendKeys("Hi");
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//i[@class='fa fa-times-circle delete-img-icon']")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//i[@class='fa fa-times-circle delete-img-icon']"))); 	 
	    driver.findElement(By.xpath("//i[@class='fa fa-times-circle delete-img-icon']")).click(); // Remove the attached file
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("(//textarea[@name='comment'])[2]")).click();
	    driver.findElement(By.xpath("(//textarea[@name='comment'])[2]")).clear();Thread.sleep(2000);
	    driver.findElement(By.xpath("(//textarea[@name='comment'])[2]")).sendKeys("Deleted the attachment");
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//button[contains(text(),'Send')])[2]")));Thread.sleep(2000);
	    driver.findElement(By.xpath("(//button[contains(text(),'Send')])[2]")).click();
	    Thread.sleep(2000);

	    /* Scroll till the Edit Message Section */ 	
		WebElement scroll2 = driver.findElement(By.xpath("//div[1]/div[3]/div[1]/div[1]/div[1]/div[1]/div[2]/div[1]/div[1]/div[2]/div[1]/img[1]"));
		Thread.sleep(2000);
		jse.executeScript("arguments[0].scrollIntoView(true);",scroll2);
		Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[1]/div[3]/div[1]/div[1]/div[1]/div[2]/div[3]/div[1]/div[1]/div[1]/div[2]/span[1]/*[name()='svg'][1]")).click();
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//li[normalize-space()='Delete']")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//li[normalize-space()='Delete']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//li[normalize-space()='Delete']")).click();
	    Thread.sleep(2000);	
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[normalize-space()='Delete']")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[normalize-space()='Delete']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//button[normalize-space()='Delete']")).click();
	    Thread.sleep(2000);
	    
	    /* Scroll the Page Up */
	    jse.executeScript("scroll(0, -250);");
	    Thread.sleep(2000);
	    
	    /* Report and Block */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[1]/div[3]/div[1]/div[1]/div[1]/div[1]/div[1]/div[2]/*[name()='svg'][1]")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[1]/div[3]/div[1]/div[1]/div[1]/div[1]/div[1]/div[2]/*[name()='svg'][1]")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[1]/div[3]/div[1]/div[1]/div[1]/div[1]/div[1]/div[2]/*[name()='svg'][1]")).click();
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//li[normalize-space()='Block']")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//li[normalize-space()='Block']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//li[normalize-space()='Block']")).click();
	    Thread.sleep(2000);	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[normalize-space()='Cancel']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//button[normalize-space()='Cancel']")).click();
	    Thread.sleep(2000);	 	    
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[1]/div[3]/div[1]/div[1]/div[1]/div[1]/div[1]/div[2]/*[name()='svg'][1]")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[1]/div[3]/div[1]/div[1]/div[1]/div[1]/div[1]/div[2]/*[name()='svg'][1]")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[1]/div[3]/div[1]/div[1]/div[1]/div[1]/div[1]/div[2]/*[name()='svg'][1]")).click();
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//li[normalize-space()='Report']")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//li[normalize-space()='Report']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//li[normalize-space()='Report']")).click();
	    Thread.sleep(2000);	
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'Select your Reason/Violation')]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'Select your Reason/Violation')]")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[contains(text(),'Select your Reason/Violation')]")).click();
	    Thread.sleep(2000);	
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//form/div/div/div/div[2]/div/div[1]/div[2]/div/div[2]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//form/div/div/div/div[2]/div/div[1]/div[2]/div/div[2]")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//form/div/div/div/div[2]/div/div[1]/div[2]/div/div[2]")).click();
	    Thread.sleep(2000);	
	    driver.findElement(By.xpath("//button[@class='swiper-button-next-custom']")).click(); // image Right --> Arrow
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[normalize-space()='Report']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//button[normalize-space()='Report']")).click();
	    Thread.sleep(2000);	    
	    	    	    
	    /* Logout from the social power */
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'My Profile')]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'My Profile')]")));Thread.sleep(2000);
		driver.findElement(By.xpath("//div[contains(text(),'My Profile')]")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//div[contains(text(),'Logout')]")).click();
		Thread.sleep(2000);
	  }
	}
