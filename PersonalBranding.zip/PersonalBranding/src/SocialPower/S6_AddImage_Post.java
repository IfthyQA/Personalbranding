package SocialPower;

import java.io.IOException;
import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import screenshotOnFailure.FailScreenshot;

@Listeners(screenshotListners.EventList.class)
public class S6_AddImage_Post extends FailScreenshot{

	@Test
	public void Social_AddImage_To_Post() throws InterruptedException, IOException {
	
		/* Login to the Application - PBC */ 		
		driver.findElement(By.xpath("//button[normalize-space()='Login']")).click();
		driver.findElement(By.xpath("//input[@id='Username']")).click();
	    driver.findElement(By.xpath("//input[@id='Username']")).sendKeys("john.doe004");
		driver.findElement(By.xpath("//input[@id='password-field']")).click();
		driver.findElement(By.xpath("//input[@id='password-field']")).sendKeys("Rockon123");
		driver.findElement(By.xpath("//button[@id='loginButton']")).click();
		Thread.sleep(2000);
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(120));
	    
		/* Navigate to the Social Power */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'My Profile')]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'My Profile')]")));Thread.sleep(2000);
		{
		     WebElement element = driver.findElement(By.xpath("//div[@class='menu-item menu-item-active']"));
		     Actions builder = new Actions(driver);
		     builder.moveToElement(element).perform();
		}
		Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'Social Power')]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'Social Power')]")));Thread.sleep(2000);
		driver.findElement(By.xpath("//div[contains(text(),'Social Power')]")).click();
		Thread.sleep(2000);	    
	    
	    /* Add Image to the first post - My Posts */
		/* Click "See All My Activity" */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='see-all-activity']")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@class='see-all-activity']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[@class='see-all-activity']")).click();
	    Thread.sleep(2000);
	    
		    /* PUBLIC VIEW - Handle Windows - New Window */ 
	    	String winHandleBefore1 = driver.getWindowHandle();
	    	driver.findElement(By.xpath("//div[@class='posts-view-content']//div[1]//div[1]//div[1]//div[1]//div[1]//a[1]")).click();
	    	for(String winHandle : driver.getWindowHandles()){
	        driver.switchTo().window(winHandle);
	    	}
	    	Thread.sleep(2000);
	    	driver.close();
	    	driver.switchTo().window(winHandleBefore1);
	    	Thread.sleep(2000);
		    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'Back')]")));	
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'Back')]")));Thread.sleep(2000);
		    driver.findElement(By.xpath("//div[contains(text(),'Back')]")).click();
		    Thread.sleep(2000);
	    	
    	/* Switch back to original browser (first window) */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[2]/div[1]/div[1]/div[1]/div[1]/div[1]/div[2]/*[name()='svg'][1]/*[name()='path'][1]")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[2]/div[1]/div[1]/div[1]/div[1]/div[1]/div[2]/*[name()='svg'][1]/*[name()='path'][1]")));
	    driver.findElement(By.xpath("//div[2]/div[1]/div[1]/div[1]/div[1]/div[1]/div[2]/*[name()='svg'][1]/*[name()='path'][1]")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//li[normalize-space()='Edit']")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//li[normalize-space()='Edit']")));    	     
	    driver.findElement(By.xpath("//li[normalize-space()='Edit']")).click();
	    Thread.sleep(2000);  
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='power-share-textstyle']")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@class='power-share-textstyle']"))); 
	    driver.findElement(By.xpath("//div[@class='power-share-textstyle']")).click();	    
	    Thread.sleep(2000);	    
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'Back')]")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'Back')]")));
	    driver.findElement(By.xpath("//div[contains(text(),'Back')]")).click();	    
	    Thread.sleep(2000);	    
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='power-share-textstyle']")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@class='power-share-textstyle']"))); 
	    driver.findElement(By.xpath("//div[@class='power-share-textstyle']")).click();	    
	    Thread.sleep(2000);	 
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//img[@class='uploaded-img-preview'])[6]")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//img[@class='uploaded-img-preview'])[6]")));
	    driver.findElement(By.xpath("(//img[@class='uploaded-img-preview'])[6]")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[contains(text(),'Add To Post')]")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[contains(text(),'Add To Post')]")));
	    driver.findElement(By.xpath("//button[contains(text(),'Add To Post')]")).click();
	    Thread.sleep(2000); 
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@id='autofill-inp']")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@id='autofill-inp']")));
	    driver.findElement(By.xpath("//div[@title='Achnet']//div[@class='close-icon-blue']")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("//input[@id='autofill-inp']")).click();
	    driver.findElement(By.xpath("//input[@id='autofill-inp']")).sendKeys("Achnet");
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("//input[@id='autofill-inp']")).sendKeys(Keys.ENTER);
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[@title='Coaching']//div[@class='close-icon-blue']")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("//input[@id='autofill-inp']")).click();
	    driver.findElement(By.xpath("//input[@id='autofill-inp']")).sendKeys("Coaching");
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("//input[@id='autofill-inp']")).sendKeys(Keys.ENTER);
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[contains(text(),'Post')]")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[contains(text(),'Post')]")));
	    driver.findElement(By.xpath("//button[contains(text(),'Post')]")).click();
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@role='alert']")));
	    driver.findElement(By.xpath("//button[@aria-label='close']//*[name()='svg']")).click();
	    Thread.sleep(2000);
	    
	    /* Logout from the social power */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'My Profile')]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'My Profile')]")));Thread.sleep(2000);
		driver.findElement(By.xpath("//div[contains(text(),'My Profile')]")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//div[contains(text(),'Logout')]")).click();
		Thread.sleep(2000);
	  }
	}
