package screenshotListners;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;
import screenshotOnFailure.FailScreenshot;

public class EventList implements ITestListener {

	@Override
	public void onTestFailure(ITestResult result) {
		
		String methodName = result.getMethod().getMethodName();
        WebDriver driver = FailScreenshot.listenerDriver; // Assuming FailScreenshot.listenerDriver is your WebDriver instance

        if (driver instanceof TakesScreenshot) {
            TakesScreenshot screenshotDriver = (TakesScreenshot) driver;

            SimpleDateFormat format = new SimpleDateFormat("dd MMM yyyy HH_mm_ss");
            String date = format.format(new Date(System.currentTimeMillis()));

            try {
                File src = screenshotDriver.getScreenshotAs(OutputType.FILE);
                File dest = new File("./ScreenShots/" + date + "_" + methodName + ".png");

                org.apache.commons.io.FileUtils.copyFile(src, dest);
                System.out.println("Uh-ho!! its failed buddy! No worries, Screenshot is taken on Failure!!!!");
            } 
            catch (Exception e)
            {
                e.printStackTrace();
            }
        }
    }
	
	@Override
	public void onTestStart(ITestResult result) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onTestSuccess(ITestResult result) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onTestSkipped(ITestResult result) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onTestFailedButWithinSuccessPercentage(ITestResult result) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onStart(ITestContext context) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onFinish(ITestContext context) {
		// TODO Auto-generated method stub
		
	}

}


