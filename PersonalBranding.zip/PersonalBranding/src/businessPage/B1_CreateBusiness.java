package businessPage;

import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import screenshotOnFailure.FailScreenshot;

@Listeners(screenshotListners.EventList.class)
public class B1_CreateBusiness extends FailScreenshot {

	@Test
	public void Biz_CreatePage() throws InterruptedException {
	
	/* Login to the Application - PBC */ 		
	driver.findElement(By.xpath("(//button[normalize-space()='Login'])[1]")).click();
	driver.findElement(By.xpath("//input[@id='Username']")).click();
	driver.findElement(By.xpath("//input[@id='Username']")).sendKeys("test.doe001");
	driver.findElement(By.xpath("//input[@id='password-field']")).click();
	driver.findElement(By.xpath("//input[@id='password-field']")).sendKeys("Rockon123");
	driver.findElement(By.xpath("//button[@id='loginButton']")).click();
	Thread.sleep(2000);
	WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(120));
   
    /* Create Non Coach Business Page */
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[normalize-space()='Create a Business']")));
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[normalize-space()='Create a Business']")));Thread.sleep(2000);
    driver.findElement(By.xpath("//button[normalize-space()='Create a Business']")).click();
    Thread.sleep(2000);
    driver.findElement(By.xpath("//button[@type='button']")).click();
    Thread.sleep(2000);
    driver.findElement(By.xpath("//button[normalize-space()='Go Back']")).click();
    Thread.sleep(2000);
    driver.findElement(By.xpath("//button[@type='button']")).click();
    Thread.sleep(2000);
    driver.findElement(By.xpath("//button[@class='modal-btn btn-cancel']")).click();
    Thread.sleep(2000);
    driver.findElement(By.xpath("//button[normalize-space()='Create a Business']")).click();
    Thread.sleep(2000);
    driver.findElement(By.xpath("//div[@class='close-img']")).click();
    Thread.sleep(2000);
    driver.findElement(By.xpath("//button[@class='modal-btn btn-cancel']")).click();
    Thread.sleep(2000);
    driver.findElement(By.xpath("//button[normalize-space()='Create a Business']")).click();
    Thread.sleep(2000);
    driver.findElement(By.xpath("//span[normalize-space()='NON-COACHING BUSINESS']")).click();
    Thread.sleep(2000);
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("Name")));
    wait.until(ExpectedConditions.elementToBeClickable(By.id("Name")));Thread.sleep(2000);
    driver.findElement(By.id("Name")).click();
    driver.findElement(By.id("Name")).sendKeys("Redo Automation");
    Thread.sleep(2000);
    driver.findElement(By.id("BusinessTag")).click();
    driver.findElement(By.id("BusinessTag")).sendKeys("Do something Repeatedly, One day you will be master in it!");
    Thread.sleep(2000);
    driver.findElement(By.id("WebsiteUrl")).click();
    driver.findElement(By.id("WebsiteUrl")).sendKeys("www.redo.com");
    Thread.sleep(2000);
    driver.findElement(By.id("Description")).click();
    driver.findElement(By.id("Description")).sendKeys("I am a UIUX Designer by trade, and a tech, art, and design enthusiast at heart. After a fulfilling career as a professor of art and design at Syracuse University (2011-2016), I transitioned professionally into software development - a longstanding, very serious passion of mine. The combination of analytical abilities, conceptual breadth, passion for mentoring others and deep research skills that defined my work in academia informs my approach to programming. A precise understanding of the consultative and");
    Thread.sleep(2000);   
    driver.findElement(By.xpath("//div[@class='filter-option']")).click();
    Thread.sleep(2000);   
    driver.findElement(By.xpath("//input[@aria-label='Search']")).click();
    Thread.sleep(2000);   
    driver.findElement(By.xpath("//input[@aria-label='Search']")).sendKeys("Tech");
    Thread.sleep(2000);
    driver.findElement(By.xpath("//input[@aria-label='Search']")).sendKeys(Keys.ENTER);
    Thread.sleep(2000);
    driver.findElement(By.cssSelector(".ui-autocomplete-input")).click();
    driver.findElement(By.cssSelector(".ui-autocomplete-input")).sendKeys("Entrepreneur");
    driver.findElement(By.cssSelector(".ui-autocomplete-input")).sendKeys(Keys.ENTER);
    Thread.sleep(2000);
    driver.findElement(By.xpath("//a[@class='tagit-close']")).click();
    Thread.sleep(2000);
    driver.findElement(By.cssSelector(".ui-autocomplete-input")).click();
    driver.findElement(By.cssSelector(".ui-autocomplete-input")).sendKeys("UI Designer");
    driver.findElement(By.cssSelector(".ui-autocomplete-input")).sendKeys(Keys.ENTER);
    Thread.sleep(2000);
    driver.findElement(By.xpath("//button[normalize-space()='+ Add Another Category']")).click();
    Thread.sleep(2000);
    driver.findElement(By.xpath("//div[@class='close-button-specialization hide-on-small-screen']")).click();
    Thread.sleep(2000);
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[@id='biz-form-btn']")));Thread.sleep(2000);
    driver.findElement(By.xpath("//button[@id='biz-form-btn']")).click();
    Thread.sleep(2000);
    
    /* Logout */
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'My Profile')]")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'My Profile')]")));Thread.sleep(2000);
	driver.findElement(By.xpath("//div[contains(text(),'My Profile')]")).click();  
	Thread.sleep(2000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//div[contains(text(),'Logout')])[1]")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//div[contains(text(),'Logout')])[1]")));Thread.sleep(2000);
	driver.findElement(By.xpath("(//div[contains(text(),'Logout')])[1]")).click();  
	Thread.sleep(2000);
  }
}

