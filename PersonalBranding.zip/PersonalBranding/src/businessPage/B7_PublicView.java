package businessPage;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import screenshotOnFailure.FailScreenshot;

@Listeners(screenshotListners.EventList.class)
public class B7_PublicView extends FailScreenshot{
	
	@Test
	public void Biz_PublicView() throws InterruptedException {

		/* Login to the Application - PBC */ 		
	  	driver.findElement(By.xpath("(//button[normalize-space()='Login'])[1]")).click();
		driver.findElement(By.xpath("//input[@id='Username']")).click();
		driver.findElement(By.xpath("//input[@id='Username']")).sendKeys("test.doe001");
		driver.findElement(By.xpath("//input[@id='password-field']")).click();
		driver.findElement(By.xpath("//input[@id='password-field']")).sendKeys("Rockon123");
		driver.findElement(By.xpath("//button[@id='loginButton']")).click();
		Thread.sleep(2000);
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(120));
	    
	    /* Navigate Business Page */
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[normalize-space()='Repeat Automation']")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()='Repeat Automation']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//span[normalize-space()='Repeat Automation']")).click();
	    Thread.sleep(2000); 
	    
	    /* Public View */
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[normalize-space()='Menu']")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()='Menu']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//span[normalize-space()='Menu']")).click();
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[normalize-space()='Business Page']")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[normalize-space()='Business Page']")));
	    Thread.sleep(2000);	
	    driver.getWindowHandle();Thread.sleep(2000);
	    driver.findElement(By.xpath("//a[normalize-space()='Business Page']")).click();Thread.sleep(2000);
	    for(String winHandle : driver.getWindowHandles()){
	        driver.switchTo().window(winHandle);
	    }    
	    
	    /* Message Button */
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".btn-sm:nth-child(2)")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".btn-sm:nth-child(2)")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".btn-sm:nth-child(2)")).click();
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".biz-admin-overlay > .modal-header .fa")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".biz-admin-overlay > .modal-header .fa")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".biz-admin-overlay > .modal-header .fa")).click();
	    Thread.sleep(2000);
	    
	    /* Follow Button */
		wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".form-inline > .btn-sm")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".form-inline > .btn-sm")).click();
	    Thread.sleep(2000);
	    
	    /* Share Button */
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".btn-sm:nth-child(3)")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".btn-sm:nth-child(3)")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".btn-sm:nth-child(3)")).click();
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".SPbtnshare")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".SPbtnshare")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".SPbtnshare")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".SPcontent > .modal-header .fa")).click();
	    Thread.sleep(2000);
	    
	    /* Report Button */
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".btn-sm:nth-child(4)")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".btn-sm:nth-child(4)")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".btn-sm:nth-child(4)")).click();
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("#modalreportpage .modal-header .fa")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector("#modalreportpage .modal-header .fa")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector("#modalreportpage .modal-header .fa")).click();
	    Thread.sleep(2000);
	    
	    /* Send a Message - Button */
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".btn-sm:nth-child(2)")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".btn-sm:nth-child(2)")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".btn-sm:nth-child(2)")).click();
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//textarea")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//textarea")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//textarea")).click();Thread.sleep(2000);
	    driver.findElement(By.xpath("//textarea")).sendKeys("Hey this looks good Initiative. Great keep it up");Thread.sleep(2000);
		wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".btn-blue")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".btn-blue")).click();
	    Thread.sleep(2000);
	    
	    /* Unfollow Button */
	    driver.findElement(By.xpath("(//a[normalize-space()='Home'])[1]")).click();
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".form-inline > .btn-sm")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".form-inline > .btn-sm")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".form-inline > .btn-sm")).click();
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("btnYesConfirmYesNo")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.id("btnYesConfirmYesNo")));Thread.sleep(2000);
	    driver.findElement(By.id("btnYesConfirmYesNo")).click();
	    Thread.sleep(2000);
	    
	    /* Share Page to user */
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".btn-sm:nth-child(3)")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".btn-sm:nth-child(3)")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".btn-sm:nth-child(3)")).click();
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//form[@id='formSelectedContacts']/div/div[2]/div/label")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//form[@id='formSelectedContacts']/div/div[2]/div/label")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//form[@id='formSelectedContacts']/div/div[2]/div/label")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".txtMemberInvite")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".txtMemberInvite")).sendKeys("ahmed");
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//li/div/div[2]/div")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//li/div/div[2]/div")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//li/div/div[2]/div")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.id("ToFollowers")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".SPbtnshare")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.invisibilityOfElementLocated(By.cssSelector(".SPbtnshare")));
	    
	    /* Report the Business page */
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".btn-sm:nth-child(4)")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".btn-sm:nth-child(4)")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".btn-sm:nth-child(4)")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.id("select2-ReportReason-container")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".select2-search__field")).sendKeys("inappro");Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".select2-search__field")).sendKeys(Keys.ENTER);Thread.sleep(2000);
	    driver.findElement(By.id("ReportText")).click();Thread.sleep(2000);
	    driver.findElement(By.id("ReportText")).sendKeys("Yeah sometimes i will feel like this is Spam");Thread.sleep(2000);
	    driver.findElement(By.id("btnPageReport")).click();Thread.sleep(2000);
	    driver.findElement(By.id("btnYesConfirmYesNo")).click();
	    Thread.sleep(2000);
	    
	    /* Testimonials */
	    driver.findElement(By.cssSelector("#idAddTestimonial > #btnWriteTestimonial")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector("#newRating > img:nth-child(4)")).click();Thread.sleep(2000);
	    driver.findElement(By.id("Testimonial")).click();Thread.sleep(2000);
	    driver.findElement(By.id("Testimonial")).sendKeys("Good Initiative");Thread.sleep(2000);
	    driver.findElement(By.id("btnAddTestimonial")).click();
	    Thread.sleep(2000);
	    
	    /* Header */
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//a[normalize-space()='Home'])[1]")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//a[normalize-space()='Home'])[1]")));Thread.sleep(2000);
	    driver.findElement(By.xpath("(//a[normalize-space()='Home'])[1]")).click();
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//a[normalize-space()='Teams'])[1]")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//a[normalize-space()='Teams'])[1]")));Thread.sleep(2000);
	    driver.findElement(By.xpath("(//a[normalize-space()='Teams'])[1]")).click();
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//a[normalize-space()='Careers'])[1]")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//a[normalize-space()='Careers'])[1]")));Thread.sleep(2000);
	    driver.findElement(By.xpath("(//a[normalize-space()='Careers'])[1]")).click();
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//a[normalize-space()='Home'])[1]")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//a[normalize-space()='Home'])[1]")));Thread.sleep(2000);
	    driver.findElement(By.xpath("(//a[normalize-space()='Home'])[1]")).click();
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@title='Repeat Automation']")));	// Business Hub Logo Bavigation
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@title='Repeat Automation']")));Thread.sleep(2000);
		driver.findElement(By.xpath("//div[@title='Repeat Automation']")).click();
		Thread.sleep(2000);
	    
    	/* Logout */
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'My Profile')]")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'My Profile')]")));Thread.sleep(2000);
		driver.findElement(By.xpath("//div[contains(text(),'My Profile')]")).click();  
		Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//div[contains(text(),'Logout')])[1]")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//div[contains(text(),'Logout')])[1]")));Thread.sleep(2000);
		driver.findElement(By.xpath("(//div[contains(text(),'Logout')])[1]")).click(); 
	    Thread.sleep(2000);
	  }
	}
