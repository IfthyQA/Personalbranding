package businessPage;

import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import screenshotOnFailure.FailScreenshot;

@Listeners(screenshotListners.EventList.class)
public class B8_Delete_Business extends FailScreenshot{
	
	@Test
	public void Biz_Delete_Page() throws InterruptedException{

	/* Login to the Application - PBC */ 		
	driver.findElement(By.xpath("(//button[normalize-space()='Login'])[1]")).click();
	driver.findElement(By.xpath("//input[@id='Username']")).click();
	driver.findElement(By.xpath("//input[@id='Username']")).sendKeys("test.doe001");
	driver.findElement(By.xpath("//input[@id='password-field']")).click();
	driver.findElement(By.xpath("//input[@id='password-field']")).sendKeys("Rockon123");
	driver.findElement(By.xpath("//button[@id='loginButton']")).click();
	Thread.sleep(2000);
	WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(120));
    
    /* Navigate to the Business page */
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[normalize-space()='Repeat Automation']")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()='Repeat Automation']")));Thread.sleep(2000);
    driver.findElement(By.xpath("//span[normalize-space()='Repeat Automation']")).click();
    Thread.sleep(2000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[normalize-space()='Menu']")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()='Menu']")));Thread.sleep(2000);
    driver.findElement(By.xpath("//span[normalize-space()='Menu']")).click();
    Thread.sleep(2000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//a[normalize-space()='Team Central'])[1]")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//a[normalize-space()='Team Central'])[1]")));Thread.sleep(2000);
    driver.findElement(By.xpath("(//a[normalize-space()='Team Central'])[1]")).click();
    Thread.sleep(2000);   
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@title='Repeat Automation']")));	// Business Hub Logo Bavigation
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@title='Repeat Automation']")));Thread.sleep(2000);
	driver.findElement(By.xpath("//div[@title='Repeat Automation']")).click();
	Thread.sleep(2000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[normalize-space()='Menu']")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()='Menu']")));Thread.sleep(2000);
    driver.findElement(By.xpath("//span[normalize-space()='Menu']")).click();
    Thread.sleep(2000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[normalize-space()='Edit Business Page']")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[normalize-space()='Edit Business Page']")));Thread.sleep(2000);
    driver.findElement(By.xpath("//a[normalize-space()='Edit Business Page']")).click();
    Thread.sleep(2000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@title='Repeat Automation']")));	// Business Hub Logo Bavigation
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@title='Repeat Automation']")));Thread.sleep(2000);
	driver.findElement(By.xpath("//div[@title='Repeat Automation']")).click();
	Thread.sleep(2000);
    
    /* Delete Business Page */
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//div[contains(text(),'Settings')])[1]")));
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//div[contains(text(),'Settings')])[1]")));Thread.sleep(2000);
	driver.findElement(By.xpath("(//div[contains(text(),'Settings')])[1]")).click();
	Thread.sleep(2000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[contains(.,\'Delete Page\')]")));
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[contains(.,\'Delete Page\')]")));Thread.sleep(2000);
    driver.findElement(By.xpath("//button[contains(.,\'Delete Page\')]")).click();
    Thread.sleep(2000);
    driver.findElement(By.id("Password")).click();
    driver.findElement(By.id("Password")).sendKeys("Rockon123");
    Thread.sleep(2000);
    driver.findElement(By.cssSelector("form > #btnYesConfirmYesNo")).click();
    wait.until(ExpectedConditions.invisibilityOfElementLocated(By.cssSelector("form > #btnYesConfirmYesNo")));
    Thread.sleep(2000);
    
    /* Logout from Account */
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'My Profile')]")));
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'My Profile')]")));Thread.sleep(2000);
	driver.findElement(By.xpath("//div[contains(text(),'My Profile')]")).click();
	Thread.sleep(2000);
	driver.findElement(By.xpath("//div[contains(text(),'Logout')]")).click();
	Thread.sleep(2000);
  }
}
