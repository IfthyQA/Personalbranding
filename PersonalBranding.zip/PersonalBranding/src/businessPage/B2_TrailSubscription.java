package businessPage;

import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import screenshotOnFailure.FailScreenshot;

@Listeners(screenshotListners.EventList.class)
public class B2_TrailSubscription extends FailScreenshot {
	
	@Test
	public void Biz_Subscription_Trail() throws InterruptedException {

	/* Login to the Application - PBC */ 		
	driver.findElement(By.xpath("(//button[normalize-space()='Login'])[1]")).click();
	driver.findElement(By.xpath("//input[@id='Username']")).click();
	driver.findElement(By.xpath("//input[@id='Username']")).sendKeys("test.doe001");
	driver.findElement(By.xpath("//input[@id='password-field']")).click();
	driver.findElement(By.xpath("//input[@id='password-field']")).sendKeys("Rockon123");
	driver.findElement(By.xpath("//button[@id='loginButton']")).click();
	Thread.sleep(2000);
	WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(120));
    
    /* Navigate to the Business page */  
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[normalize-space()='Redo Automation']")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()='Redo Automation']")));Thread.sleep(2000);
    driver.findElement(By.xpath("//span[normalize-space()='Redo Automation']")).click();
    Thread.sleep(2000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[normalize-space()='Menu']")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()='Menu']")));Thread.sleep(2000);
    driver.findElement(By.xpath("//span[normalize-space()='Menu']")).click();
    Thread.sleep(2000);
    
    /* Try Free subscription */  
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[normalize-space()='Subscription']")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[normalize-space()='Subscription']")));Thread.sleep(2000);
    driver.findElement(By.xpath("//a[normalize-space()='Subscription']")).click();
    Thread.sleep(2000);
    driver.navigate().refresh();
    Thread.sleep(2000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("td:nth-child(3) .btn:nth-child(2)")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector("td:nth-child(3) .btn:nth-child(2)")));Thread.sleep(2000);
    driver.findElement(By.cssSelector("td:nth-child(3) .btn:nth-child(2)")).click();
    Thread.sleep(2000);
    driver.findElement(By.cssSelector("td:nth-child(3) .btn:nth-child(1)")).click();
    Thread.sleep(2000);
    driver.navigate().refresh();
    Thread.sleep(2000);
    driver.findElement(By.cssSelector("td > .biz-plans-head > form .btn-outline-maroon")).click();
    Thread.sleep(2000);
    
    /* Standard yearly trail subscription with 20% Coupon */
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("#btnBillingDetails > .fa")));	
    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector("#btnBillingDetails > .fa")));Thread.sleep(2000);	
    driver.findElement(By.cssSelector("#btnBillingDetails > .fa")).click();
    Thread.sleep(2000);
    
    /* Add Coupon and Remove it */
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@id=\'divCouponContainer\']/div/div/div/form/div/div/div[2]/div[2]/button")));	
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@id=\'divCouponContainer\']/div/div/div/form/div/div/div[2]/div[2]/button")));Thread.sleep(2000);
    driver.findElement(By.xpath("//div[@id=\'divCouponContainer\']/div/div/div/form/div/div/div[2]/div[2]/button")).click();
    Thread.sleep(2000);
    driver.findElement(By.id("CouponCode")).click();Thread.sleep(2000);
    driver.findElement(By.id("CouponCode")).sendKeys("kuotedIbQe");Thread.sleep(3000);
    driver.findElement(By.xpath("//div[@id=\'divCouponContainer\']/div/div/div/form/div/div/div[2]/div[2]/button")).click();
    Thread.sleep(2000);
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("btnRemoveCoupon")));	
    wait.until(ExpectedConditions.elementToBeClickable(By.id("btnRemoveCoupon")));Thread.sleep(2000);	
    driver.findElement(By.id("btnRemoveCoupon")).click();Thread.sleep(2000);
    
    /* Invalid Coupon - Try to Add */
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@id=\'divCouponContainer\']/div/div/div/form/div/div/div[2]/div[2]/button")));	
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@id=\'divCouponContainer\']/div/div/div/form/div/div/div[2]/div[2]/button")));Thread.sleep(2000);
    driver.findElement(By.xpath("//div[@id=\'divCouponContainer\']/div/div/div/form/div/div/div[2]/div[2]/button")).click();
    Thread.sleep(2000);
    driver.findElement(By.id("CouponCode")).click();Thread.sleep(2000);
    driver.findElement(By.id("CouponCode")).sendKeys("VTP94t3m5n");Thread.sleep(2000);
    driver.findElement(By.xpath("//div[@id=\'divCouponContainer\']/div/div/div/form/div/div/div[2]/div[2]/button")).click();
    Thread.sleep(2000);
    
    /* Review Order */
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("btnReviewOrder")));	
    wait.until(ExpectedConditions.elementToBeClickable(By.id("btnReviewOrder")));Thread.sleep(2000);
    driver.findElement(By.id("btnReviewOrder")).click();
    Thread.sleep(2000);
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("paypalRadioBtn")));	
    wait.until(ExpectedConditions.elementToBeClickable(By.id("paypalRadioBtn")));Thread.sleep(2000);
    driver.findElement(By.id("paypalRadioBtn")).click();
    Thread.sleep(2000);
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("btnReviewOrder")));	
    wait.until(ExpectedConditions.elementToBeClickable(By.id("btnReviewOrder")));Thread.sleep(2000);
    driver.findElement(By.id("btnReviewOrder")).click();
    Thread.sleep(2000);
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("cardRadioBtn")));	
    wait.until(ExpectedConditions.elementToBeClickable(By.id("cardRadioBtn")));Thread.sleep(2000);
    driver.findElement(By.id("cardRadioBtn")).click();
    Thread.sleep(2000);
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("btnReviewOrder")));	
    wait.until(ExpectedConditions.elementToBeClickable(By.id("btnReviewOrder")));Thread.sleep(2000);
    driver.findElement(By.id("btnReviewOrder")).click();
    Thread.sleep(2000);
    
    /* Navigating to Paypal */
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("paypalRadioBtn")));
	wait.until(ExpectedConditions.elementToBeClickable(By.id("paypalRadioBtn")));Thread.sleep(2000);
	driver.findElement(By.id("paypalRadioBtn")).click();
	Thread.sleep(2000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//img[@alt='Pay with PayPal']")));
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//img[@alt='Pay with PayPal']")));
	Thread.sleep(2000);
    String winHandleBefore = driver.getWindowHandle();
    driver.findElement(By.xpath("//img[@alt='Pay with PayPal']")).click();
    Thread.sleep(2000);
    for(String winHandle : driver.getWindowHandles()){
	        driver.switchTo().window(winHandle); 
    }
    Thread.sleep(2000);     /* Pay thru Paypal */
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[@id='return_url']")));
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[@id='return_url']")));
    driver.findElement(By.xpath("//a[@id='return_url']")).click();
    Thread.sleep(2000);
    driver.switchTo().window(winHandleBefore);
    Thread.sleep(2000);
    
    /* Click Review Order after PayPal Payment */  
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[contains(text(),\'Review Order\')]")));	
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[contains(text(),\'Review Order\')]")));
    driver.findElement(By.xpath("//span[contains(text(),\'Review Order\')]")).click();
    Thread.sleep(2000);
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[contains(text(),\'Complete Order\')]")));	
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[contains(text(),\'Complete Order\')]")));
    Thread.sleep(2000);
    wait.until(ExpectedConditions.elementToBeClickable(By.id("btnEditOrder")));
    driver.findElement(By.id("btnEditOrder")).click();
    Thread.sleep(2000);
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[contains(text(),\'Review Order\')]")));	
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[contains(text(),\'Review Order\')]")));Thread.sleep(2000);
    driver.findElement(By.xpath("//span[contains(text(),\'Review Order\')]")).click();
    Thread.sleep(2000);
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[contains(text(),\'Complete Order\')]")));
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[contains(text(),\'Complete Order\')]")));Thread.sleep(2000);
    driver.findElement(By.xpath("//span[contains(text(),\'Complete Order\')]")).click();
    Thread.sleep(2000);
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[contains(text(),\'Okay\')]")));	
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[contains(text(),\'Okay\')]")));Thread.sleep(2000);
    driver.findElement(By.xpath("//span[contains(text(),\'Okay\')]")).click();
    Thread.sleep(2000);
    
    /* Cancel Trail Subscriptions */ 
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[normalize-space()='Menu']")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()='Menu']")));Thread.sleep(2000);
    driver.findElement(By.xpath("//span[normalize-space()='Menu']")).click();
    Thread.sleep(2000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[normalize-space()='Subscription']")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[normalize-space()='Subscription']")));Thread.sleep(2000);
    driver.findElement(By.xpath("//a[normalize-space()='Subscription']")).click();
    Thread.sleep(2000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.linkText("Subscription & Orders")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.linkText("Subscription & Orders")));Thread.sleep(2000);
    driver.findElement(By.linkText("Subscription & Orders")).click();
    Thread.sleep(2000);
    driver.navigate().refresh();
    Thread.sleep(2000);
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[normalize-space()=\'Cancel Subscription\']")));	
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()=\'Cancel Subscription\']")));Thread.sleep(2000);
    driver.findElement(By.xpath("//span[normalize-space()=\'Cancel Subscription\']")).click();
    Thread.sleep(2000);
    driver.findElement(By.cssSelector(".btn-maroon")).click();
    Thread.sleep(2000);
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[normalize-space()=\'Cancel Subscription\']")));	
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()=\'Cancel Subscription\']")));Thread.sleep(2000);
    driver.findElement(By.xpath("//span[normalize-space()=\'Cancel Subscription\']")).click();
    Thread.sleep(2000);
    driver.findElement(By.cssSelector(".btn-outline-maroon")).click();    
    wait.until(ExpectedConditions.invisibilityOfElementLocated(By.cssSelector(".btn-outline-maroon")));
    Thread.sleep(2000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@title='Redo Automation']")));	// Business Hub Logo Bavigation
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@title='Redo Automation']")));Thread.sleep(2000);
	driver.findElement(By.xpath("//div[@title='Redo Automation']")).click();
	Thread.sleep(2000);
    
    /* Logout */
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'My Profile')]")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'My Profile')]")));Thread.sleep(2000);
	driver.findElement(By.xpath("//div[contains(text(),'My Profile')]")).click();  
	Thread.sleep(2000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//div[contains(text(),'Logout')])[1]")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//div[contains(text(),'Logout')])[1]")));Thread.sleep(2000);
	driver.findElement(By.xpath("(//div[contains(text(),'Logout')])[1]")).click();  
    Thread.sleep(30000);    // Purposely making it to wait for 30 Secs //
  }
}

