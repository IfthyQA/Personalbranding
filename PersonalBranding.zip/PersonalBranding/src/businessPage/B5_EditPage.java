package businessPage;

import java.io.IOException;
import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import screenshotOnFailure.FailScreenshot;

@Listeners(screenshotListners.EventList.class)
public class B5_EditPage extends FailScreenshot{
	
	@Test
	public void Biz_Edit() throws InterruptedException, IOException {

		/* Login to the Application - PBC */ 		
	  	driver.findElement(By.xpath("(//button[normalize-space()='Login'])[1]")).click();
		driver.findElement(By.xpath("//input[@id='Username']")).click();
		driver.findElement(By.xpath("//input[@id='Username']")).sendKeys("test.doe001");
		driver.findElement(By.xpath("//input[@id='password-field']")).click();
		driver.findElement(By.xpath("//input[@id='password-field']")).sendKeys("Rockon123");
		driver.findElement(By.xpath("//button[@id='loginButton']")).click();
		Thread.sleep(2000);
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(120));
	    
	    /* Navigate to the Business Page */
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[normalize-space()='Redo Automation']")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()='Redo Automation']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//span[normalize-space()='Redo Automation']")).click();
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[normalize-space()='Menu']")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()='Menu']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//span[normalize-space()='Menu']")).click();
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[normalize-space()='Edit Business Page']")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[normalize-space()='Edit Business Page']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//a[normalize-space()='Edit Business Page']")).click();
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".btn-edit-content")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".btn-edit-content")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".btn-edit-content")).click();
	    Thread.sleep(2000);
	    
	    /* Edit Page */
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.linkText("Page Name")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.linkText("Page Name")));Thread.sleep(2000);
	    driver.findElement(By.linkText("Page Name")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.id("Name")).click();
	    driver.findElement(By.id("Name")).clear();
	    Thread.sleep(2000);
	    driver.findElement(By.id("Name")).sendKeys("1");
	    Thread.sleep(2000);
	    driver.findElement(By.id("Name")).clear();
	    Thread.sleep(2000);
	    driver.findElement(By.id("Name")).sendKeys("Repeat Automation");
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".btn-blue")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".btn-blue")).click();
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".btn-edit-content")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".btn-edit-content")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.linkText("Logo and Brand Statement")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.id("BrandStatement")).click();
	    driver.findElement(By.id("BrandStatement")).clear();
	    Thread.sleep(2000);
	    driver.findElement(By.id("BrandStatement")).sendKeys("1234");
	    Thread.sleep(2000);
	    driver.findElement(By.id("BrandStatement")).clear();
	    Thread.sleep(2000);
	    driver.findElement(By.id("BrandStatement")).sendKeys("The Applications are Smart to Automate");
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[@id=\'modalLogoStatement\']/div/div/div[2]/div/div/form/div/div[4]/span/button/span")).click();
	    Thread.sleep(2000);
	    
	    /* Add Edit Optional Features */
		wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".btn-edit-content")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".btn-edit-content")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.linkText("Optional Features")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.id("AllowFollow")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.id("AllowMsg")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.id("AllowFollow")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.id("AllowMsg")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[@id=\'modalEditAudience\']/div/div/div[2]/div/div/form/div[2]/div/span/button")).click();
	    Thread.sleep(9000);
	    driver.findElement(By.cssSelector(".btn-edit-content")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.linkText("Optional Features")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.id("AllowFollow")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.id("AllowMsg")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[@id=\'modalEditAudience\']/div/div/div[2]/div/div/form/div[2]/div/span/button")).click();
	    Thread.sleep(2000);
	    
	    /* Edit Description */
		wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".btn-edit-content")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".btn-edit-content")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.linkText("Video and Description")).click();	    
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[3]/div/div/button/i")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[4]/div/div/button/i")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".modal-dialog:nth-child(2) .modal-header .fa")).click();
	    Thread.sleep(2000);
	    
	    /* Add Specialties */
		wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".btn-edit-content")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".btn-edit-content")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.linkText("Specialties")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".fa-bars")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".bs-searchbox > .form-control")).click();
	    driver.findElement(By.cssSelector(".bs-searchbox > .form-control")).sendKeys("educa");Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".bs-searchbox > .form-control")).sendKeys(Keys.ENTER);Thread.sleep(2000);	    
	    driver.findElement(By.id("Item1_SpecialitiesCSV")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".margin-top-20 label")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.id("Item1_SpecialitiesCSV")).click();
	    driver.findElement(By.id("Item1_SpecialitiesCSV")).sendKeys("Command Line Runner");
	    Thread.sleep(2000);
	    driver.findElement(By.id("Item1_SpecialitiesCSV")).sendKeys(Keys.ENTER);
	    Thread.sleep(2000);
	    driver.findElement(By.id("Item1_SpecialitiesCSV")).click();
	    driver.findElement(By.id("Item1_SpecialitiesCSV")).clear();
	    Thread.sleep(2000);
	    driver.findElement(By.id("Item1_SpecialitiesCSV")).sendKeys("123456789abcdeijklmnopqrstuvwxyz12345678ABCDEFGI");
	    Thread.sleep(2000);
	    driver.findElement(By.id("Item1_SpecialitiesCSV")).sendKeys(Keys.ENTER);
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".next-btn")).click();
	    Thread.sleep(2000);
	    
	    /* Add Custom Section */
		wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".btn-edit-content")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".btn-edit-content")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.linkText("Custom Section")).click();
	    Thread.sleep(2000);	    
	    driver.findElement(By.linkText("Add Custom Section")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("//input[@type=\'radio\']")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector("#mceu_6 > button:nth-child(1)")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".mce-i-bold")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[@id=\'modalAddSectionContent\']/div/div/div[2]/form/div/div/div/label")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.id("Title")).sendKeys("Image Upload from AutoIT");
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("//img[@alt='Upload Files']")).click();
	    Thread.sleep(2000);   
	    Runtime.getRuntime().exec("C:\\Users\\dev\\Documents\\AutoScripts\\Upload.exe");	  
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@id='uploadvideo']//span[@class='pb-remove-video'][normalize-space()='Remove Image']")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@id='uploadvideo']//span[@class='pb-remove-video'][normalize-space()='Remove Image']")));
	    driver.findElement(By.cssSelector(".btnSaveCustomSection")).click();
	    Thread.sleep(2000);
	    
	    /* Logout */
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'My Profile')]")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'My Profile')]")));Thread.sleep(2000);
		driver.findElement(By.xpath("//div[contains(text(),'My Profile')]")).click();  
		Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//div[contains(text(),'Logout')])[1]")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//div[contains(text(),'Logout')])[1]")));Thread.sleep(2000);
		driver.findElement(By.xpath("(//div[contains(text(),'Logout')])[1]")).click(); 
	    Thread.sleep(2000);
	  }
	}

