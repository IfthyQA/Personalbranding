package businessPage;

import org.testng.annotations.Test;
import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Listeners;
import screenshotOnFailure.FailScreenshot;

@Listeners(screenshotListners.EventList.class)
public class B4_AutoRenew_Subscription extends FailScreenshot {
	
	@Test
	public void Biz_Subscription_AutoRenew() throws InterruptedException {

	/* Login to the Application - PBC */ 		
	driver.findElement(By.xpath("(//button[normalize-space()='Login'])[1]")).click();
	driver.findElement(By.xpath("//input[@id='Username']")).click();
	driver.findElement(By.xpath("//input[@id='Username']")).sendKeys("test.doe001");
	driver.findElement(By.xpath("//input[@id='password-field']")).click();
	driver.findElement(By.xpath("//input[@id='password-field']")).sendKeys("Rockon123");
	driver.findElement(By.xpath("//button[@id='loginButton']")).click();
	Thread.sleep(2000);
	WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(120));
    
    /* Navigate to the Business page */  
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[normalize-space()='Redo Automation']")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()='Redo Automation']")));Thread.sleep(2000);
    driver.findElement(By.xpath("//span[normalize-space()='Redo Automation']")).click();
    Thread.sleep(2000); 
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[normalize-space()='Menu']")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()='Menu']")));Thread.sleep(2000);
    driver.findElement(By.xpath("//span[normalize-space()='Menu']")).click();
    Thread.sleep(2000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[normalize-space()='Subscription']")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[normalize-space()='Subscription']")));Thread.sleep(2000);
    driver.findElement(By.xpath("//a[normalize-space()='Subscription']")).click();
    Thread.sleep(2000);
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.linkText("Subscription & Orders")));	
    wait.until(ExpectedConditions.elementToBeClickable(By.linkText("Subscription & Orders")));Thread.sleep(2000);
    driver.findElement(By.linkText("Subscription & Orders")).click();
    Thread.sleep(2000); 
    driver.navigate().refresh();  
    
    /* Auto Renew the plan */
    Thread.sleep(2000);
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".btn-blue-link-12:nth-child(3)")));
    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".btn-blue-link-12:nth-child(3)")));Thread.sleep(2000);
    driver.findElement(By.cssSelector(".btn-blue-link-12:nth-child(3)")).click();
    Thread.sleep(2000);
    driver.findElement(By.cssSelector("#btnBillingDetails > .fa")).click();
    Thread.sleep(2000);
    driver.findElement(By.cssSelector(".modal-prime > .modal-header .fa")).click();
    Thread.sleep(2000);
    driver.navigate().refresh();
    Thread.sleep(2000);
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".btn-blue-link-12:nth-child(3)")));
    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".btn-blue-link-12:nth-child(3)")));Thread.sleep(2000);
    driver.findElement(By.cssSelector(".btn-blue-link-12:nth-child(3)")).click();
    Thread.sleep(2000);
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[contains(text(),\'Review Order\')]")));	
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[contains(text(),\'Review Order\')]")));
    driver.findElement(By.xpath("//span[contains(text(),\'Review Order\')]")).click();
    Thread.sleep(2000);
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[contains(text(),\'Complete Order\')]")));	
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[contains(text(),\'Complete Order\')]")));Thread.sleep(2000);
    driver.findElement(By.xpath("//span[contains(text(),\'Complete Order\')]")).click();
    Thread.sleep(2000);
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[contains(text(),\'Okay\')]")));	
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[contains(text(),\'Okay\')]")));    Thread.sleep(2000);
    driver.findElement(By.xpath("//span[contains(text(),\'Okay\')]")).click();
    Thread.sleep(2000);
    
    /* Logout */
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'My Profile')]")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'My Profile')]")));Thread.sleep(2000);
	driver.findElement(By.xpath("//div[contains(text(),'My Profile')]")).click();  
	Thread.sleep(2000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//div[contains(text(),'Logout')])[1]")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//div[contains(text(),'Logout')])[1]")));Thread.sleep(2000);
	driver.findElement(By.xpath("(//div[contains(text(),'Logout')])[1]")).click(); 
    Thread.sleep(2000);
  }
}

