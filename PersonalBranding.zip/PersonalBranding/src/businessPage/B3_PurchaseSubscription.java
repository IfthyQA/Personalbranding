package businessPage;

import org.testng.annotations.Test;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Listeners;
import screenshotOnFailure.FailScreenshot;

@Listeners(screenshotListners.EventList.class)
public class B3_PurchaseSubscription extends FailScreenshot {
	
	@Test
	public void Biz_Subscription_Purchase() throws InterruptedException {

	/* Login to the Application - PBC */ 		
	driver.findElement(By.xpath("(//button[normalize-space()='Login'])[1]")).click();
	driver.findElement(By.xpath("//input[@id='Username']")).click();
	driver.findElement(By.xpath("//input[@id='Username']")).sendKeys("test.doe001");
	driver.findElement(By.xpath("//input[@id='password-field']")).click();
	driver.findElement(By.xpath("//input[@id='password-field']")).sendKeys("Rockon123");
	driver.findElement(By.xpath("//button[@id='loginButton']")).click();
	Thread.sleep(2000);
	WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(120));
    
    /* Navigate to the Business page */  
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[normalize-space()='Redo Automation']")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()='Redo Automation']")));Thread.sleep(2000);
    driver.findElement(By.xpath("//span[normalize-space()='Redo Automation']")).click();
    Thread.sleep(2000); 
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[normalize-space()='Menu']")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()='Menu']")));Thread.sleep(2000);
    driver.findElement(By.xpath("//span[normalize-space()='Menu']")).click();
    Thread.sleep(2000);     
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[normalize-space()='Payments']")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[normalize-space()='Payments']")));Thread.sleep(2000);
    driver.findElement(By.xpath("//a[normalize-space()='Payments']")).click();
    Thread.sleep(2000);
    
    /* Purchase plan - Prime Standard Monthly */
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.linkText("Subscribe To Prime Now!")));
    wait.until(ExpectedConditions.elementToBeClickable(By.linkText("Subscribe To Prime Now!")));
    driver.findElement(By.linkText("Subscribe To Prime Now!")).click();
    Thread.sleep(2000);
    driver.findElement(By.cssSelector("td:nth-child(3) .btn:nth-child(2)")).click();
    Thread.sleep(2000);
    driver.findElement(By.cssSelector("td > .biz-plans-head > form .btn-outline-maroon")).click();
    Thread.sleep(2000);
    driver.findElement(By.xpath("//div[@id='divCouponContainer']/div/div/div/form/div/div/div[2]/div[2]/button")).click();
    Thread.sleep(2000);
    driver.findElement(By.id("CouponCode")).click();
    driver.findElement(By.id("CouponCode")).sendKeys("BUYTVJ5xO7");
    Thread.sleep(2000);
    driver.findElement(By.xpath("//div[@id='divCouponContainer']/div/div/div/form/div/div/div[2]/div[2]/button")).click();
    Thread.sleep(2000);
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("btnReviewOrder")));	
    wait.until(ExpectedConditions.elementToBeClickable(By.id("btnReviewOrder")));Thread.sleep(2000);
    driver.findElement(By.id("btnReviewOrder")).click();
    Thread.sleep(2000);
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("btnEditOrder")));	
    wait.until(ExpectedConditions.elementToBeClickable(By.id("btnEditOrder")));Thread.sleep(2000);
    driver.findElement(By.id("btnEditOrder")).click();
    Thread.sleep(2000);
    driver.findElement(By.id("select2-jobsDropDown-container")).click();
    Thread.sleep(2000);
    driver.findElement(By.id("select2-vaultDropDown-container")).click();
    Thread.sleep(2000);
    driver.findElement(By.xpath("//span[contains(text(),\'Review Order\')]")).click();
    Thread.sleep(2000);
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[contains(text(),\'Complete Order\')]")));	
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[contains(text(),\'Complete Order\')]")));Thread.sleep(2000);
    driver.findElement(By.xpath("//span[contains(text(),\'Complete Order\')]")).click();
    Thread.sleep(2000);
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[contains(text(),\'Okay\')]")));	
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[contains(text(),\'Okay\')]")));Thread.sleep(2000);
    driver.findElement(By.xpath("//span[contains(text(),\'Okay\')]")).click();
    Thread.sleep(2000);
    driver.navigate().refresh();
    Thread.sleep(2000);
    
    /* Change plan to Annual from Monthly subscription */
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[normalize-space()='Menu']")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()='Menu']")));Thread.sleep(2000);
    driver.findElement(By.xpath("//span[normalize-space()='Menu']")).click();
    Thread.sleep(2000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[normalize-space()='Payments']")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[normalize-space()='Payments']")));Thread.sleep(2000);
    driver.findElement(By.xpath("//a[normalize-space()='Payments']")).click();
    Thread.sleep(2000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@title='Redo Automation']")));	// Business Hub Logo Bavigation
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@title='Redo Automation']")));Thread.sleep(2000);
	driver.findElement(By.xpath("//div[@title='Redo Automation']")).click();
	Thread.sleep(2000);
    driver.navigate().refresh();
    Thread.sleep(2000);
    
    /* Upgrade to Prime Teams using 100% Coupons */ 
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[normalize-space()='Menu']")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()='Menu']")));Thread.sleep(2000);
    driver.findElement(By.xpath("//span[normalize-space()='Menu']")).click();
    Thread.sleep(2000); 
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[normalize-space()='Payments']")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[normalize-space()='Payments']")));Thread.sleep(2000);
    driver.findElement(By.xpath("//a[normalize-space()='Payments']")).click();
    Thread.sleep(2000);
    driver.navigate().refresh();
    Thread.sleep(2000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@title='Redo Automation']")));	// Business Hub Logo Bavigation
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@title='Redo Automation']")));Thread.sleep(2000);
	driver.findElement(By.xpath("//div[@title='Redo Automation']")).click();
	Thread.sleep(2000); 
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[normalize-space()='Menu']")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()='Menu']")));Thread.sleep(2000);
    driver.findElement(By.xpath("//span[normalize-space()='Menu']")).click();
    Thread.sleep(2000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[normalize-space()='Subscription']")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[normalize-space()='Subscription']")));Thread.sleep(2000);
    driver.findElement(By.xpath("//a[normalize-space()='Subscription']")).click();
    Thread.sleep(2000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("td > .biz-plans-head > form .btn-sm")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector("td > .biz-plans-head > form .btn-sm")));Thread.sleep(2000);
    driver.findElement(By.cssSelector("td > .biz-plans-head > form .btn-sm")).click(); // upgrade plan
    Thread.sleep(2000);
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@id=\'divCouponContainer\']/div/div/div/form/div/div/div[2]/div[2]/button")));	
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@id=\'divCouponContainer\']/div/div/div/form/div/div/div[2]/div[2]/button")));Thread.sleep(2000);
    driver.findElement(By.xpath("//div[@id=\'divCouponContainer\']/div/div/div/form/div/div/div[2]/div[2]/button")).click();
    Thread.sleep(2000);
    driver.findElement(By.id("CouponCode")).click();Thread.sleep(2000);
    driver.findElement(By.id("CouponCode")).sendKeys("v2mStQkgNB");Thread.sleep(2000);
    driver.findElement(By.xpath("//div[@id=\'divCouponContainer\']/div/div/div/form/div/div/div[2]/div[2]/button")).click();Thread.sleep(2000);
    driver.findElement(By.cssSelector("#btnBillingDetails > .fa")).click();
    Thread.sleep(2000);
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[contains(text(),\'Review Order\')]")));	
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[contains(text(),\'Review Order\')]")));Thread.sleep(2000);
    driver.findElement(By.xpath("//span[contains(text(),\'Review Order\')]")).click();
    Thread.sleep(2000);
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[contains(text(),\'Complete Order\')]")));	
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[contains(text(),\'Complete Order\')]")));Thread.sleep(2000);
    driver.findElement(By.id("btnEditOrder")).click();
    Thread.sleep(2000);
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[contains(text(),\'Review Order\')]")));	
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[contains(text(),\'Review Order\')]")));Thread.sleep(2000);
    driver.findElement(By.xpath("//span[contains(text(),\'Review Order\')]")).click();Thread.sleep(2000);
    Thread.sleep(2000);
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[contains(text(),\'Complete Order\')]")));
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[contains(text(),\'Complete Order\')]")));Thread.sleep(2000);
    driver.findElement(By.xpath("//span[contains(text(),\'Complete Order\')]")).click();Thread.sleep(2000);
    Thread.sleep(2000);
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[contains(text(),\'Okay\')]")));	
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[contains(text(),\'Okay\')]")));Thread.sleep(2000);
    driver.findElement(By.xpath("//span[contains(text(),\'Okay\')]")).click();
    
    /* Waiting for one minute just to avoid crashing of Subscription due to Payemnt Services */
    Thread.sleep(60000);
    driver.navigate().refresh();
    
    /* Cancel Prime Teams - Subscription  */
    Thread.sleep(2000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@title='Redo Automation']")));	// Business Hub Logo Bavigation
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@title='Redo Automation']")));Thread.sleep(2000);
	driver.findElement(By.xpath("//div[@title='Redo Automation']")).click();
	Thread.sleep(2000);
    driver.navigate().refresh();
    Thread.sleep(2000);   
    driver.navigate().refresh();
    Thread.sleep(2000); 
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[normalize-space()='Menu']")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()='Menu']")));Thread.sleep(2000);
    driver.findElement(By.xpath("//span[normalize-space()='Menu']")).click();
    Thread.sleep(2000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[normalize-space()='Subscription']")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[normalize-space()='Subscription']")));Thread.sleep(2000);
    driver.findElement(By.xpath("//a[normalize-space()='Subscription']")).click();
    Thread.sleep(2000);
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.linkText("Subscription & Orders")));	
    wait.until(ExpectedConditions.elementToBeClickable(By.linkText("Subscription & Orders")));Thread.sleep(2000);
    driver.findElement(By.linkText("Subscription & Orders")).click();
    Thread.sleep(2000);
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[normalize-space()=\'Cancel Subscription\']")));	
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()=\'Cancel Subscription\']")));Thread.sleep(2000);
    driver.findElement(By.xpath("//span[normalize-space()=\'Cancel Subscription\']")).click();
    Thread.sleep(2000);
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".btn-outline-maroon")));	
    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".btn-outline-maroon")));Thread.sleep(2000);
    driver.findElement(By.cssSelector(".btn-outline-maroon")).click();
    Thread.sleep(20000);
        
    /* Logout */
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'My Profile')]")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'My Profile')]")));Thread.sleep(2000);
	driver.findElement(By.xpath("//div[contains(text(),'My Profile')]")).click();  
	Thread.sleep(2000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//div[contains(text(),'Logout')])[1]")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//div[contains(text(),'Logout')])[1]")));Thread.sleep(2000);
	driver.findElement(By.xpath("(//div[contains(text(),'Logout')])[1]")).click(); 
    Thread.sleep(2000);
  }
}

