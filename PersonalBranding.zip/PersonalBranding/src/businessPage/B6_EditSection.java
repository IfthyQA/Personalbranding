package businessPage;

import java.io.IOException;
import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import screenshotOnFailure.FailScreenshot;

@Listeners(screenshotListners.EventList.class)
public class B6_EditSection extends FailScreenshot{
	
	@Test
	public void Biz_Add_Editsection() throws InterruptedException, IOException {
	
	/* Login to the Application - PBC */ 		
	driver.findElement(By.xpath("(//button[normalize-space()='Login'])[1]")).click();
	driver.findElement(By.xpath("//input[@id='Username']")).click();
	driver.findElement(By.xpath("//input[@id='Username']")).sendKeys("test.doe001");
	driver.findElement(By.xpath("//input[@id='password-field']")).click();
	driver.findElement(By.xpath("//input[@id='password-field']")).sendKeys("Rockon123");
	driver.findElement(By.xpath("//button[@id='loginButton']")).click();
	Thread.sleep(2000);
	WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(120));
    
    /* Navigate to the Business page */
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[normalize-space()='Repeat Automation']")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()='Repeat Automation']")));Thread.sleep(2000);
    driver.findElement(By.xpath("//span[normalize-space()='Repeat Automation']")).click();
    Thread.sleep(2000);
    
    /* Edit page */
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[normalize-space()='Menu']")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()='Menu']")));Thread.sleep(2000);
    driver.findElement(By.xpath("//span[normalize-space()='Menu']")).click();
    Thread.sleep(2000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[normalize-space()='Edit Business Page']")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[normalize-space()='Edit Business Page']")));Thread.sleep(2000);
    driver.findElement(By.xpath("//a[normalize-space()='Edit Business Page']")).click();
    Thread.sleep(2000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".btn-edit-content")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".btn-edit-content")));Thread.sleep(2000);
    driver.findElement(By.cssSelector(".btn-edit-content")).click();
    Thread.sleep(2000);
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.linkText("Custom Section")));
    wait.until(ExpectedConditions.elementToBeClickable(By.linkText("Custom Section")));
    driver.findElement(By.linkText("Custom Section")).click();
    Thread.sleep(2000);
    
    /* Add Video - Custom Section */
    driver.findElement(By.linkText("Add Custom Section")).click();Thread.sleep(2000);
    driver.findElement(By.xpath("(//input[@type=\'radio\'])[2]")).click();
    Thread.sleep(2000);   
    driver.findElement(By.id("Title")).click();
    driver.findElement(By.id("Title")).sendKeys("Sample Video Upload");
    Thread.sleep(2000);
    driver.findElement(By.cssSelector(".mce-i-bold")).click();
    Thread.sleep(2000);
    driver.findElement(By.cssSelector(".mce-i-bullist")).click();
    Thread.sleep(4000);
    driver.findElement(By.xpath("//img[@alt='Upload Files']")).click();
    Thread.sleep(2000);   
    Runtime.getRuntime().exec("C:\\Users\\dev\\Documents\\AutoScripts\\Upload1.exe"); 
    Thread.sleep(2000);
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@id=\'uploadvideo\']//span[@class=\'pb-remove-video\'][normalize-space()=\'Remove Video\']")));
	JavascriptExecutor jse = (JavascriptExecutor)driver;
 	WebElement Save = driver.findElement(By.cssSelector(".btnSaveCustomSection"));
    Thread.sleep(2000);
    jse.executeScript("arguments[0].scrollIntoView(true);",Save);
    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".btnSaveCustomSection")));
    driver.findElement(By.cssSelector(".btnSaveCustomSection")).click();
	wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".toast-message")));
	driver.findElement(By.cssSelector(".toast-message")).click();
    Thread.sleep(2000);
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[2]/div/div/div/div/div[2]/span/button[2]/span")));
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[2]/div/div/div/div/div[2]/span/button[2]/span")));
    driver.findElement(By.xpath("//div[2]/div/div/div/div/div[2]/span/button[2]/span")).click();Thread.sleep(2000);
    driver.findElement(By.id("btnYesConfirmYesNo")).click();
    Thread.sleep(2000);
	wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".toast-message")));
	driver.findElement(By.cssSelector(".toast-message")).click();
    
    /* Add Section After Deleting */
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("btnAddSection")));
    wait.until(ExpectedConditions.elementToBeClickable(By.id("btnAddSection")));
    driver.findElement(By.id("btnAddSection")).click();Thread.sleep(2000);
    driver.findElement(By.xpath("(//input[@type=\'radio\'])[2]")).click();Thread.sleep(2000);
    driver.findElement(By.cssSelector("#modalAddSectionContent .modal-header .fa")).click();Thread.sleep(2000);
    driver.findElement(By.id("btnYesConfirmYesNo")).click();Thread.sleep(2000);
    driver.findElement(By.cssSelector("#btnAddSection > span")).click();Thread.sleep(2000);
    driver.findElement(By.xpath("//input[@type=\'radio\']")).click();
    Thread.sleep(2000);   
    driver.findElement(By.id("Title")).click();Thread.sleep(2000);
    driver.findElement(By.id("Title")).sendKeys("qwertyuioplkjhgfdsazxcvbnmkjhgfddsaqwerttyuiooplkj");Thread.sleep(2000);
    driver.findElement(By.id("Title")).clear();
    driver.findElement(By.id("Title")).sendKeys("Image Upload a Dummy Section");Thread.sleep(2000);
    driver.findElement(By.cssSelector(".mce-i-bold")).click();Thread.sleep(2000);
    driver.findElement(By.cssSelector(".mce-i-bullist")).click();Thread.sleep(2000);
    Thread.sleep(2000);
    driver.findElement(By.xpath("//img[@alt='Upload Files']")).click();
    Thread.sleep(2000);   
    Runtime.getRuntime().exec("C:\\Users\\dev\\Documents\\AutoScripts\\Upload.exe");	  
    Thread.sleep(2000);
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@id=\'uploadvideo\']//span[@class=\'pb-remove-video\'][normalize-space()=\'Remove Image\']")));
 	WebElement Save1 = driver.findElement(By.cssSelector(".btnSaveCustomSection"));
    Thread.sleep(3000);
    jse.executeScript("arguments[0].scrollIntoView(true);",Save1);
    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".btnSaveCustomSection")));
    driver.findElement(By.cssSelector(".btnSaveCustomSection")).click();
	wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".toast-message")));
	driver.findElement(By.cssSelector(".toast-message")).click();
    Thread.sleep(2000);
    
    /* Testimonials */
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".btn-edit-content")));
    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".btn-edit-content")));
    driver.findElement(By.cssSelector(".btn-edit-content")).click();
    Thread.sleep(2000);
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.linkText("Testimonials")));
    wait.until(ExpectedConditions.elementToBeClickable(By.linkText("Testimonials")));
    driver.findElement(By.linkText("Testimonials")).click();
    Thread.sleep(2000);
    driver.findElement(By.xpath("//button[@id=\'btnRequestTestimonial\']/span")).click();Thread.sleep(2000);   
    driver.findElement(By.id("sendRequestRating")).click();
    driver.findElement(By.id("sendRequestRating")).sendKeys("Adam");
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//ul[@id='ui-id-1']/li")));
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//ul[@id='ui-id-1']/li")));
    driver.findElement(By.xpath("//ul[@id='ui-id-1']/li")).click();
    Thread.sleep(2000);
    driver.findElement(By.cssSelector(".fa-times-circle")).click();Thread.sleep(2000);
    driver.findElement(By.cssSelector(".sendReqRating")).click();Thread.sleep(2000);
    driver.findElement(By.id("sendRequestRating")).click();Thread.sleep(2000);
    driver.findElement(By.id("sendRequestRating")).sendKeys("adam");
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//ul[@id='ui-id-1']/li")));
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//ul[@id='ui-id-1']/li")));
    driver.findElement(By.xpath("//ul[@id='ui-id-1']/li")).click();
    Thread.sleep(2000);
    driver.findElement(By.cssSelector(".sendReqRating")).click();
	wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".toast-message")));
	driver.findElement(By.cssSelector(".toast-message")).click();Thread.sleep(2000);   
    
    /* Location Updating */
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".btn-edit-content")));
    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".btn-edit-content")));
    driver.findElement(By.cssSelector(".btn-edit-content")).click();
    Thread.sleep(2000);
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.linkText("Location")));
    wait.until(ExpectedConditions.elementToBeClickable(By.linkText("Location")));
    driver.findElement(By.linkText("Location")).click();
    Thread.sleep(2000);
    driver.findElement(By.id("modalbusinesseditlocation")).click();Thread.sleep(2000);
    driver.findElement(By.xpath("//div[@class='form-group has-float-label']//input[@id='pac-input']")).clear();
    driver.findElement(By.xpath("//div[@class='form-group has-float-label']//input[@id='pac-input']")).sendKeys("Chennai");Thread.sleep(2000);
    driver.findElement(By.xpath("//div[@class='form-group has-float-label']//input[@id='pac-input']")).sendKeys(Keys.ENTER);
    Thread.sleep(2000);
    wait.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath("//span[contains(text(),'Save')]")));Thread.sleep(2000);
    
    /* Contact Details */
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".btn-edit-content")));
    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".btn-edit-content")));
    driver.findElement(By.cssSelector(".btn-edit-content")).click();
    Thread.sleep(2000);
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.linkText("Contact Details")));
    wait.until(ExpectedConditions.elementToBeClickable(By.linkText("Contact Details")));
    driver.findElement(By.linkText("Contact Details")).click();
    Thread.sleep(2000);
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//b[@role='presentation']")));
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//b[@role='presentation']")));
    driver.findElement(By.xpath("//b[@role='presentation']")).click();
    Thread.sleep(2000);
    driver.findElement(By.cssSelector(".select2-search__field")).sendKeys("+64");Thread.sleep(2000);
    driver.findElement(By.cssSelector(".select2-search__field")).sendKeys(Keys.ENTER);
    Thread.sleep(2000);
    driver.findElement(By.id("Phone")).click();
    driver.findElement(By.id("Phone")).sendKeys("98867");Thread.sleep(2000);
    driver.findElement(By.id("Phone")).clear();Thread.sleep(2000);
    driver.findElement(By.id("Phone")).sendKeys("12345687");
    Thread.sleep(2000);   
    driver.findElement(By.id("WebsiteUrl")).click();Thread.sleep(2000);
    driver.findElement(By.id("WebsiteUrl")).clear();
    driver.findElement(By.id("WebsiteUrl")).sendKeys("www.tescra.com");
    Thread.sleep(2000);
    driver.findElement(By.xpath("//label[normalize-space()='Business Mail']")).click();Thread.sleep(2000);
    driver.findElement(By.xpath("//span[@class='has-float-label']//input[@id='Email']")).clear();
    driver.findElement(By.xpath("//span[@class='has-float-label']//input[@id='Email']")).sendKeys("test.automation@tescra.com");
    Thread.sleep(2000);
    driver.findElement(By.id("FacebookUrl")).click();
    driver.findElement(By.id("FacebookUrl")).sendKeys("fb.co/testcra");
    Thread.sleep(2000);
    driver.findElement(By.id("LinkedinUrl")).click();
    driver.findElement(By.id("LinkedinUrl")).sendKeys("lnkd.in/tescra");
    Thread.sleep(2000);
    driver.findElement(By.id("TwitterUrl")).click();
    driver.findElement(By.id("TwitterUrl")).sendKeys("twitter.com/tescra");
    Thread.sleep(2000);
    driver.findElement(By.id("GoogleUrl")).click();
    driver.findElement(By.id("GoogleUrl")).sendKeys("www.google.com/apple");
    Thread.sleep(2000);
    driver.findElement(By.xpath("//div[@id=\'modalEditContact\']/div/div/div[2]/div/div/form/div/div[2]/span/button")).click();
    Thread.sleep(2000);     
    
    /* Logout */
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'My Profile')]")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'My Profile')]")));Thread.sleep(2000);
	driver.findElement(By.xpath("//div[contains(text(),'My Profile')]")).click();  
	Thread.sleep(2000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//div[contains(text(),'Logout')])[1]")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//div[contains(text(),'Logout')])[1]")));Thread.sleep(2000);
	driver.findElement(By.xpath("(//div[contains(text(),'Logout')])[1]")).click(); 
    Thread.sleep(2000);
  }
}

