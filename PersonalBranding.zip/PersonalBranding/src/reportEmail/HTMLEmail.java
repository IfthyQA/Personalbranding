package reportEmail;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import org.apache.commons.mail.DefaultAuthenticator;
import org.apache.commons.mail.EmailException;
import org.apache.commons.mail.HtmlEmail;
import org.testng.annotations.Test;
import java.util.*;

public class HTMLEmail {
		
	@Test
	public void EmailReport() throws EmailException, InterruptedException, IOException {
		
		DateTimeFormatter date = DateTimeFormatter.ofPattern("yyyy/MM/dd"); 
		LocalDateTime now = LocalDateTime.now(); 
		   
		HtmlEmail email = new HtmlEmail();
		email.setDebug(true);
		email.setSmtpPort(587);
		email.setAuthenticator(new DefaultAuthenticator("support@personalbrandingcouncil.com", "Rockon$459"));
		email.setStartTLSRequired(true);
		email.setHostName("mail.personalbrandingcouncil.com");		
	
	/* Get the Path of the Overview.html from the test.reports Folders */
		Path dir = Paths.get("C:\\Users\\dev\\eclipse-workspace\\PersonalBranding\\test.reports\\");
		Thread.sleep(2000);  
		Path lastModified = dir;
		
    	if (Files.isDirectory(dir))
    	{
    		Optional<Path> opPath = Files.list(dir)
          .filter(p -> Files.isDirectory(p))
          .sorted((p1, p2)-> Long.valueOf(p2.toFile().lastModified())
            .compareTo(p1.toFile().lastModified()))
          .findFirst();
        Thread.sleep(2000);
        
        if (opPath.isPresent()){
             lastModified =  opPath.get();
        }
    	}
    	Thread.sleep(2000);  
        Path indexHtmlPath = Paths.get(lastModified.toString(), "html", "overview.html");
        String Folder = lastModified.getFileName().toString();
        Thread.sleep(2000);    
        
	/* Paste it on the Email Body */
        StringBuilder contentBuilder = new StringBuilder();
        try {
        BufferedReader in = new BufferedReader(new FileReader(indexHtmlPath.toString()));
        String str;
        while ((str = in.readLine()) != null) {
            contentBuilder.append(str);
        }
        in.close();
        } 
        catch (IOException e) {
        } 
        
        String content = contentBuilder.toString();    
        if(content == null || content.isEmpty())
        {	
    	content = lastModified.toAbsolutePath().toString();
    	}
        Thread.sleep(2000); 
    
    /* Parse the Data from HTML File */
    		String html = content;
    		Document doc = Jsoup.parse(html);Thread.sleep(2000); 
    		
    /* Get the Elements from HTML File */	
    		List<List<String>> outputTable = new ArrayList<>();
    		boolean titleEntered = false;
    		Elements Overview = doc.getElementsByClass("overviewTable");
    		for (Element OverviewTab : Overview) 
    		{
    			Elements Columns = OverviewTab.getElementsByClass("columnHeadings"); 
    			if(Columns.isEmpty())
    				continue;
    			String ColumnName = Columns.text();
    			String[] ColumnSplit = ColumnName.trim().split("\\s+");
    			
    			//Enters the Table Column Titles
    			if(titleEntered == false)
    			{
    				EnterTitle(ColumnSplit, outputTable);
    				titleEntered = true;
    			}  		
    			
    			Elements Rows2 = OverviewTab.getElementsByClass("test"); 
    			if(Rows2.isEmpty())
    				continue;
    			String RowsName = Rows2.text();  
    			String link = Rows2.get(0).getElementsByAttribute("href").attr("href");
    			String[] RowsSplit = RowsName.trim().split("\\s+");
    			RowsSplit[0] = "<a href=\""+link+"\">"+RowsSplit[0]+"</a>"; 
    			List<String> currRowElements = new ArrayList<String>();
    			
    			for(String currRow : RowsSplit)
    			{
    				currRowElements.add(currRow);
    				if(currRowElements.size()== outputTable.get(0).size())
    					break;
    			}
    			outputTable.add(currRowElements); 			
    		}
    		Thread.sleep(2000); 
    		String table = "<style>\r\n"
    				+ "table {\r\n"
    				+ "  font-family: arial, sans-serif;\r\n"
    				+ "  border-collapse: collapse;\r\n"
    				+ "  width: 100%;\r\n"
    				+ "}\r\n"
    				+ "\r\n"
    				+ "td, th {\r\n"
    				+ "  border: 1px solid #dddddd;\r\n"
    				+ "  text-align: left;\r\n"
    				+ "  padding: 8px;\r\n"
    				+ "}\r\n"
    				+ "\r\n"
    				+ "tr:nth-child(even) {\r\n"
    				+ "  background-color: #dddddd;\r\n"
    				+ "}\r\n"
    				+ "</style>";
    		table += "<br><h1><center> Regression Suite - Automation Test Report </center></h1><br>";
    		table += GetHTMLTable(outputTable);
    		doc = Jsoup.parse(table);Thread.sleep(2000); 
    		
//    /* Passed Test Case : CSS Design (Green and Red Color) for the HTML Report */
//    		Elements contents1 = doc.getElementsByClass("Passed");
//    		for (Element Color : contents1) 
//    		{
//    		  String percentage = Color.text();
//    		  if(percentage.contains("50"))
//    		  {
//    			  Color.attr("style","background-color:#009900; color: #ffffff;");
//    		  }
//    		  else
//    		  {
//    			  Color.attr("style","background-color:#FF0000; color: #ffffff;");
//    		  }
//    		}
//    		
    		
    /* Total Pass : CSS Design (Green and Red Color) for the HTML Report */
    		Elements contents = doc.getElementsByClass("Pass_Rate");
    		for (Element Color : contents) 
    		{
    		  String percentage = Color.text();
    		  if(percentage.contains("100"))
    		  {
    			  Color.attr("style","background-color:#009900; color: #ffffff;");
    		  }
    		  else
    		  {
    			  Color.attr("style","background-color:#FF0000; color: #ffffff;");
    		  }
    		}
    		
    /* Links to the Test Suite names */	
    		Elements contentLink = doc.getElementsByTag("a");
    		for (Element elem : contentLink)
    		{
    		elem.attr("href", "http://192.168.4.153/"+Folder+"/html/"+elem.attr("href"));
    		}   		  		
    		String htmlview = doc.toString();Thread.sleep(2000); 
    
    /* Email Subject and Body */
    		String emailContent = "Hello Team,<br>The Table below is the Regression suite test results for today, and for the detailed results please <a href=\"http://192.168.4.153/"+Folder+"/html/\">click here</a> and for the previous day's results <a href=\"http://192.168.4.153/\">click here</a>.<br>Thank you,<br>Iftikhar" +htmlview;           
    		email.setFrom("support@personalbrandingcouncil.com");
    		email.setSubject("PBC - Today's Automation Test Report "+date.format(now));
    		email.addTo("neeraj.chaudhary@tescra.com");
    		String[] emails = {"achnetteam@tescra.com"}; 	
    		email.addCc(emails );	
    		email.setHtmlMsg(emailContent);	
    		email.send();
}
	
	public static void EnterTitle(String[] ColumnSplit, List<List<String>> outputTable)
	{
		List<String> Titles = new ArrayList<String>();
		Titles.add("Suite_Name");
		for(String currTitle:ColumnSplit)
		{
			Titles.add(currTitle);
		}
		// Last two items in the column titles is Pass Rate which is a single title
		int lastIndex = Titles.size()-1;
		Titles.remove(lastIndex);
		Titles.set(lastIndex-1, "Pass_Rate");
		outputTable.add(Titles);
	}
	
	public static String GetHTMLTable(List<List<String>> outputTable)
	{
		if(outputTable.size() == 0)
		{
			return "";
		}
		String result = "<table style=\"width:100%\"> <tr>";
		for(String header:outputTable.get(0))
		{
			result += "<th>"+header+"</th>";
		}
		result += "</tr>";
		
		for(int i=1; i<outputTable.size();i++)
		{
			result += "<tr>";
			for(int j=0; j<outputTable.get(i).size();j++)
			{
				String currRow = outputTable.get(i).get(j);
				String currColumn = outputTable.get(0).get(j);
				result += "<td class=\""+currColumn+"\">"+currRow+"</td>";			
			}
			result += "</tr>";
		}
		result += "</table>";		
		return result;
	}
}
