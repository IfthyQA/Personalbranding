package powerConnect;

import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import screenshotOnFailure.FailScreenshot;

@Listeners(screenshotListners.EventList.class)
public class PC0_Remove_Connection extends FailScreenshot {

	@Test
	public void PowerConnect_Remove_SendConnection() throws InterruptedException {
		 
/* Login to the Application */ 			
	  	driver.findElement(By.xpath("(//button[normalize-space()='Login'])[1]")).click();
		driver.findElement(By.xpath("//input[@id='Username']")).click();
		driver.findElement(By.xpath("//input[@id='Username']")).sendKeys("john.doe004");
		driver.findElement(By.xpath("//input[@id='password-field']")).click();
		driver.findElement(By.xpath("//input[@id='password-field']")).sendKeys("Rockon123");
		driver.findElement(By.xpath("//button[@id='loginButton']")).click();
		Thread.sleep(2000);
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(120));
	     
/* Search People ->> Send Message */
	     wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'My Profile')]")));
		 wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'My Profile')]")));
		 Thread.sleep(2000);
		 driver.findElement(By.xpath("(//div[normalize-space()='Search'])[1]")).click();
		 Thread.sleep(2000);
		 driver.findElement(By.xpath("//input[@placeholder='Search']")).click();Thread.sleep(2000);
		 driver.findElement(By.xpath("//input[@placeholder='Search']")).clear();Thread.sleep(2000);
		 driver.findElement(By.xpath("//input[@placeholder='Search']")).sendKeys("CHIGUMBURA");
		 Thread.sleep(2000);
		 driver.findElement(By.xpath("//input[@placeholder='Search']")).sendKeys(Keys.ENTER);
		 Thread.sleep(2000);
	     wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[normalize-space()='Message']")));
		 wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()='Message']")));
	     driver.findElement(By.xpath("//span[normalize-space()='Message']")).click();
	     Thread.sleep(2000);	    
		 wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//textarea[@placeholder='Say something']")));	
		 wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//textarea[@placeholder='Say something']")));Thread.sleep(2000);	
	     driver.findElement(By.xpath("//textarea[@placeholder='Say something']")).click();
	     driver.findElement(By.xpath("//textarea[@placeholder='Say something']")).sendKeys("hello");
	     Thread.sleep(2000);
	     driver.findElement(By.xpath("//div[@class='send-button-text']")).click();Thread.sleep(2000);
	     Thread.sleep(2000);
	     
	     /* Delete Message */
	     wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@title='You: hello']")));
		 wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@title='You: hello']")));Thread.sleep(2000);
		    {
			     WebElement hover = driver.findElement(By.xpath("//div[@title='You: hello']"));
			     Actions builder = new Actions(driver);
			     builder.moveToElement(hover).perform();
			} 
		 Thread.sleep(2000); 
		 wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[2]/div[2]/div[2]/div[1]/div[1]/*[name()='svg'][1]")));
		 wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[2]/div[2]/div[2]/div[1]/div[1]/*[name()='svg'][1]")));Thread.sleep(2000);	
		 driver.findElement(By.xpath("//div[2]/div[2]/div[2]/div[1]/div[1]/*[name()='svg'][1]")).click();
		 Thread.sleep(2000);
		 wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//li[normalize-space()='Delete']")));
		 wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//li[normalize-space()='Delete']")));Thread.sleep(2000);	
		 driver.findElement(By.xpath("//li[normalize-space()='Delete']")).click();
		 Thread.sleep(2000);
		 wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[normalize-space()='Delete']")));
		 wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[normalize-space()='Delete']")));Thread.sleep(2000);	
		 driver.findElement(By.xpath("//button[normalize-space()='Delete']")).click();
		 Thread.sleep(2000);
	     		     
	     /* Navigate to Power Connect */
		 wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'My Profile')]")));
		 wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'My Profile')]")));Thread.sleep(2000);
	     {
		     WebElement menu = driver.findElement(By.xpath("//div[@id='desktopMenu']"));
		     Actions builder = new Actions(driver);
		     builder.moveToElement(menu).perform();
		 }
	     Thread.sleep(2000);
		 wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'Power Connect')]")));
		 wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'Power Connect')]")));Thread.sleep(2000);
		 driver.findElement(By.xpath("//div[contains(text(),'Power Connect')]")).click();
		 Thread.sleep(2000);
	     driver.findElement(By.xpath("//span[contains(text(),\'My Connections\')]")).click();
	     Thread.sleep(2000);
	     driver.findElement(By.cssSelector(".col-12:nth-child(4) .d-inline-block:nth-child(3) > .btn-sm")).click();
	     Thread.sleep(2000);
	     driver.findElement(By.id("btnNoConfirmYesNo")).click();
	     Thread.sleep(2000);
	     driver.findElement(By.cssSelector(".col-12:nth-child(4) .d-inline-block:nth-child(2) > .btn-sm")).click();
	     Thread.sleep(2000);
	     driver.findElement(By.id("btnNoConfirmYesNo")).click();
	     Thread.sleep(2000);
	     driver.findElement(By.cssSelector(".col-12:nth-child(4) .d-inline-block:nth-child(1) > .btn-sm")).click();
	     Thread.sleep(2000);
	     driver.findElement(By.cssSelector(".btn-blue")).click();
	     Thread.sleep(2000);
	     
	     /* Remove Connection - CHIGUMBURA */
	     wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".menu-list-active > .invisibleButton > span")));
		 wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".menu-list-active > .invisibleButton > span")));Thread.sleep(2000);
	     driver.findElement(By.cssSelector(".menu-list-active > .invisibleButton > span")).click();
	     Thread.sleep(2000);
	     driver.findElement(By.cssSelector(".col-12:nth-child(4) .d-inline-block:nth-child(3) > .btn-sm")).click();
	     Thread.sleep(2000);
	     driver.findElement(By.id("btnYesConfirmYesNo")).click();
		 wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".toast-message")));Thread.sleep(2000);
		 driver.findElement(By.cssSelector(".toast-message")).click();
	     Thread.sleep(2000);
	     
	     /* Try to Remove another Connection */	
	     wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".col-12:nth-child(4) .d-inline-block:nth-child(3) > .btn-sm")));
		 wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".col-12:nth-child(4) .d-inline-block:nth-child(3) > .btn-sm")));Thread.sleep(2000);
	     driver.findElement(By.cssSelector(".col-12:nth-child(4) .d-inline-block:nth-child(3) > .btn-sm")).click();
	     Thread.sleep(2000);
	     driver.findElement(By.id("btnNoConfirmYesNo")).click();
	     Thread.sleep(2000);	     
	     
	     /* Search "CHIGUMBURA" and Send Connection Request */
	     wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//div[normalize-space()='Search'])[1]")));
		 wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//div[normalize-space()='Search'])[1]")));Thread.sleep(2000);
		 driver.findElement(By.xpath("(//div[normalize-space()='Search'])[1]")).click();     
	     Thread.sleep(2000);
		 wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@placeholder='Type here...']")));
		 wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@placeholder='Type here...']")));
		 driver.findElement(By.xpath("//input[@placeholder='Type here...']")).click();Thread.sleep(2000);
		 driver.findElement(By.xpath("//input[@placeholder='Type here...']")).clear();Thread.sleep(2000);
		 driver.findElement(By.xpath("//input[@placeholder='Type here...']")).sendKeys("chigumbura");
		 Thread.sleep(2000);
		 driver.findElement(By.xpath("//input[@placeholder='Type here...']")).sendKeys(Keys.ENTER);
		 Thread.sleep(2000);
	     wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[normalize-space()='Connect']")));
		 wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()='Connect']")));Thread.sleep(2000);
	     driver.findElement(By.xpath("//span[normalize-space()='Connect']")).click();
	     Thread.sleep(2000);
	      
	     /* Logout */
		 wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'My Profile')]")));
		 wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'My Profile')]")));Thread.sleep(2000);
		 driver.findElement(By.xpath("//div[contains(text(),'My Profile')]")).click();
		 Thread.sleep(2000);
		 driver.findElement(By.xpath("//div[contains(text(),'Logout')]")).click();
		 Thread.sleep(2000);    
	}
}