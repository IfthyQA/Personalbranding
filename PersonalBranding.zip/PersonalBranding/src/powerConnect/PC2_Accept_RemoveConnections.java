package powerConnect;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import screenshotOnFailure.FailScreenshot;

@Listeners(screenshotListners.EventList.class)
public class PC2_Accept_RemoveConnections extends FailScreenshot {

	@Test
	public  void PowerConnect_AcceptRemove() throws InterruptedException {

		/* Login to the Application - PBC */ 		
	  	driver.findElement(By.xpath("(//button[normalize-space()='Login'])[1]")).click();
		driver.findElement(By.xpath("//input[@id='Username']")).click();
		driver.findElement(By.xpath("//input[@id='Username']")).sendKeys("john.doe001");
		driver.findElement(By.xpath("//input[@id='password-field']")).click();
		driver.findElement(By.xpath("//input[@id='password-field']")).sendKeys("Rockon123");
		driver.findElement(By.xpath("//button[@id='loginButton']")).click();
		Thread.sleep(2000);
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(120));
	    
	    /* Navigate to Settings to change the Name - which was changed from Builder Cover */
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'My Profile')]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'My Profile')]")));Thread.sleep(2000);
		driver.findElement(By.xpath("//div[contains(text(),'My Profile')]")).click();
		Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'Settings')]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'Settings')]")));Thread.sleep(2000);
		driver.findElement(By.xpath("//div[contains(text(),'Settings')]")).click();
		Thread.sleep(2000);
	    
	    /* Save without Last Name */	
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("FirstName")));
		wait.until(ExpectedConditions.elementToBeClickable(By.id("FirstName")));Thread.sleep(2000);
	    driver.findElement(By.id("FirstName")).click();
	    driver.findElement(By.id("FirstName")).clear();
	    Thread.sleep(2000);
	    driver.findElement(By.id("FirstName")).sendKeys("Ahmed");
	    Thread.sleep(2000);
	    driver.findElement(By.id("LastName")).clear();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".set-personal-savebtn")).click();
	    Thread.sleep(2000);
	    
	    /* Change first and Last name */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("FirstName")));
		wait.until(ExpectedConditions.elementToBeClickable(By.id("FirstName")));Thread.sleep(2000);
	    driver.findElement(By.id("FirstName")).click();
	    driver.findElement(By.id("FirstName")).clear();
	    Thread.sleep(2000);
	    driver.findElement(By.id("FirstName")).sendKeys("Ahmed");
	    Thread.sleep(2000);
	    driver.findElement(By.id("LastName")).click();
	    driver.findElement(By.id("LastName")).sendKeys("Tescra");
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".set-personal-savebtn")).click();
		wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".toast-message")));
	    driver.findElement(By.cssSelector(".toast-message")).click();
	    
/* From Here the Code is Dependency of B2_Send Request (Power Bio) */
	    /* Search Member from Menu */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//div[normalize-space()='Search'])[1]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//div[normalize-space()='Search'])[1]")));Thread.sleep(2000);
	    driver.findElement(By.xpath("(//div[normalize-space()='Search'])[1]")).click();
		Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@placeholder='Type here...']")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@placeholder='Type here...']")));
		driver.findElement(By.xpath("//input[@placeholder='Type here...']")).click();Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@placeholder='Type here...']")).clear();Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@placeholder='Type here...']")).sendKeys("John Tescra");
		Thread.sleep(2000);
		driver.findElement(By.xpath("//div[@class='search-input-icon-text']")).click();
		Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[normalize-space()='Accept']")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()='Accept']")));Thread.sleep(2000);
	    String winHandleBefore = driver.getWindowHandle();
	    driver.findElement(By.linkText("John Tescra")).click();
	    Thread.sleep(2000);
	    for(String winHandle : driver.getWindowHandles()){
		        driver.switchTo().window(winHandle); 
	    }
	    Thread.sleep(2000);
	    
	    /* Accept (John Tescra) Request from Public View */
	    driver.findElement(By.xpath("//span[normalize-space()='Accept']")).click();
	    Thread.sleep(2000);
	    
	    /* Remove Connection (John Tescra) from Public View */ 
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[normalize-space()='Remove Connection']")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()='Remove Connection']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//span[normalize-space()='Remove Connection']")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[@class='modal-btn btn-delete-fill']")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[@class='modal-btn btn-delete-fill']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//button[@class='modal-btn btn-delete-fill']")).click();
	    Thread.sleep(2000);
	    driver.close();	
	    Thread.sleep(2000);
	    driver.switchTo().window(winHandleBefore);
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("(//span[normalize-space()='Follow'])[2]")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("(//span[normalize-space()='Unfollow'])[1]")).click();
	    Thread.sleep(2000);	    
/* Till here the Code is Dependency of Bio Story */
	       
	    /* Logout */
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'My Profile')]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'My Profile')]")));Thread.sleep(2000);
		driver.findElement(By.xpath("//div[contains(text(),'My Profile')]")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//div[contains(text(),'Logout')]")).click();
		Thread.sleep(2000);
	  }
	}

