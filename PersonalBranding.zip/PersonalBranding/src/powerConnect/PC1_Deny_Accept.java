package powerConnect;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import screenshotOnFailure.FailScreenshot;

@Listeners(screenshotListners.EventList.class)
public class PC1_Deny_Accept extends FailScreenshot {

	@Test
	public  void PowerConnect_DenyAccept_Request() throws InterruptedException {

		/* Login to the Application */ 			
	  	driver.findElement(By.xpath("(//button[normalize-space()='Login'])[1]")).click();
		driver.findElement(By.xpath("//input[@id='Username']")).click();
		driver.findElement(By.xpath("//input[@id='Username']")).sendKeys("john.doe001");
		driver.findElement(By.xpath("//input[@id='password-field']")).click();
		driver.findElement(By.xpath("//input[@id='password-field']")).sendKeys("Rockon123");
		driver.findElement(By.xpath("//button[@id='loginButton']")).click();
		Thread.sleep(2000);
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(120));
	    
	 // Dependency of Msg_Remove Connections //
	    /* Search and Deny Connection Request (Ilhan Lolita) */   
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'My Profile')]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'My Profile')]")));
		Thread.sleep(2000);
	    driver.findElement(By.xpath("(//div[normalize-space()='Search'])[1]")).click();   
	    Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@placeholder='Search']")).click();Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@placeholder='Search']")).clear();Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@placeholder='Search']")).sendKeys("ilhan");
		Thread.sleep(2000);
		driver.findElement(By.xpath("//div[@class='see-result-text']")).click();
		Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[normalize-space()='Deny']")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()='Deny']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//span[normalize-space()='Deny']")).click();
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@role='alert']")));
	    driver.findElement(By.xpath("//div[@role='alert']")).click();
	    Thread.sleep(2000);
	    
	    /* Unblock (Ilhan Lolita) from Power Connect */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'My Profile')]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'My Profile')]")));
	    driver.get("https://www.personalbrandingcouncil.com/network/blocked");
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//button[normalize-space()='Unblock'])[2]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//button[normalize-space()='Unblock'])[2]")));Thread.sleep(2000);
	    driver.findElement(By.xpath("(//button[normalize-space()='Unblock'])[2]")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.id("btnYesConfirmYesNo")).click();
		wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".toast-message")));Thread.sleep(1000);
	    driver.findElement(By.cssSelector(".toast-message")).click();
	    wait.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath("(//button[normalize-space()='Unblock'])[2]"))); 
	    
	    /* Search (Ilhan Lolita) and Accept Request after unblocking and then send a message */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//div[normalize-space()='Search'])[1]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//div[normalize-space()='Search'])[1]")));Thread.sleep(2000);
	    driver.findElement(By.xpath("(//div[normalize-space()='Search'])[1]")).click();
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@placeholder='Type here...']")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@placeholder='Type here...']")));
		driver.findElement(By.xpath("//input[@placeholder='Type here...']")).click();Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@placeholder='Type here...']")).clear();Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@placeholder='Type here...']")).sendKeys("Ilhan");
		Thread.sleep(2000);
		driver.findElement(By.xpath("//div[@class='search-input-icon-text']")).click();
		Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[normalize-space()='Accept']")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()='Accept']")));
	    driver.findElement(By.xpath("//span[normalize-space()='Accept']")).click();
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@role='alert']")));
	    driver.findElement(By.xpath("//div[@role='alert']")).click();
	    Thread.sleep(2000);	 
	    driver.findElement(By.xpath("(//span[normalize-space()='Follow'])[1]")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("(//span[normalize-space()='Unfollow'])[1]")).click();
	    Thread.sleep(2000);
	    
	    /* Logout */
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'My Profile')]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'My Profile')]")));Thread.sleep(2000);
		driver.findElement(By.xpath("//div[contains(text(),'My Profile')]")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//div[contains(text(),'Logout')]")).click();
		Thread.sleep(2000);
	  }
	}

