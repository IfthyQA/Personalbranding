package powerConnect;

import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import screenshotOnFailure.FailScreenshot;

@Listeners(screenshotListners.EventList.class)
public class PC3_Connections extends FailScreenshot {

	@Test
	public  void PowerConnect_Connections() throws InterruptedException {

		/* Login to the Application */ 			
	  	driver.findElement(By.xpath("(//button[normalize-space()='Login'])[1]")).click();
		driver.findElement(By.xpath("//input[@id='Username']")).click();
		driver.findElement(By.xpath("//input[@id='Username']")).sendKeys("john.doe001");
		driver.findElement(By.xpath("//input[@id='password-field']")).click();
		driver.findElement(By.xpath("//input[@id='password-field']")).sendKeys("Rockon123");
		driver.findElement(By.xpath("//button[@id='loginButton']")).click();
		Thread.sleep(2000);
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(120));
	    
	    /* Navigate to Power Connect - Inite Friends */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'My Profile')]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'My Profile')]")));Thread.sleep(2000);
	    {
		     WebElement element = driver.findElement(By.xpath("//div[@class='menu-item menu-item-active']"));
		     Actions builder = new Actions(driver);
		     builder.moveToElement(element).perform();
		}
		Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'Power Connect')]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'Power Connect')]")));Thread.sleep(2000);
		driver.findElement(By.xpath("//div[contains(text(),'Power Connect')]")).click();
		Thread.sleep(2000);
	    driver.findElement(By.linkText("Invite Friends")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.id("EmailInviteSubmitBtn")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector("#lnkGmail span")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector("#lnkEmail span")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.id("EmailInviteSubmitBtn")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".ui-autocomplete-input")).click();
	    driver.findElement(By.cssSelector(".ui-autocomplete-input")).sendKeys("vignesh@tescra.com");Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".ui-autocomplete-input")).sendKeys(Keys.ENTER);
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".ui-autocomplete-input")).sendKeys("ifthy@tescra.com");Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".ui-autocomplete-input")).sendKeys(Keys.ENTER);
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("//body//div[@class='container header-mobile-menu']//div[@class='row']//div[@class='row']//li[2]//a[1]//span[1]")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".ui-autocomplete-input")).sendKeys("ifthy@tescra.com");Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".ui-autocomplete-input")).sendKeys(Keys.ENTER);
	    Thread.sleep(2000);
	    driver.findElement(By.id("EmailInviteSubmitBtn")).click();
	    Thread.sleep(2000);
	    
	    /* My Connections */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[contains(text(),\'My Connections\')]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[contains(text(),\'My Connections\')]")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//span[contains(text(),\'My Connections\')]")).click();	    
	    Thread.sleep(2000);
	    driver.findElement(By.id("searchStr")).click();
	    driver.findElement(By.id("searchStr")).sendKeys("Ilhan");
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector("#nw-center-searchbtn > .fa")).click();
	    Thread.sleep(2000);
	    
	    /* Public VIEW MESSAGE - Handle Windows - New Window */ 
    	String winHandleBefore2 = driver.getWindowHandle();
    	driver.findElement(By.linkText("Ilhan Lolita")).click();
    	Thread.sleep(2000);
    	for(String winHandle : driver.getWindowHandles()){
        driver.switchTo().window(winHandle);
    	}
    	Thread.sleep(2000);
    	driver.close();    	
    	driver.switchTo().window(winHandleBefore2);
    	Thread.sleep(2000);
    	
    	/* PENDING Menu - Try to Cancel Sidra Request */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[contains(text(),\'Pending\')]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[contains(text(),\'Pending\')]")));Thread.sleep(2000);
        driver.findElement(By.xpath("//span[contains(text(),\'Pending\')]")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".col-12:nth-child(3) .btn-sm")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.id("btnNoConfirmYesNo")).click();
	    Thread.sleep(2000);
	    
	    /* Cancel Request to Sidra */	    
	    driver.findElement(By.cssSelector(".col-12:nth-child(3) .btn-sm")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.id("btnYesConfirmYesNo")).click();
		wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".toast-message")));Thread.sleep(2000);
		driver.findElement(By.cssSelector(".toast-message")).click();   
		
		/* Send Connection Requests to Sidra */ 
		{
		     WebElement element = driver.findElement(By.xpath("//div[@id='desktopMenu']"));
		     Actions builder = new Actions(driver);
		     builder.moveToElement(element).perform();
		}
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//div[contains(text(),'Power Connect')])[2]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//div[contains(text(),'Power Connect')])[2]")));Thread.sleep(2000);
		driver.findElement(By.xpath("(//div[contains(text(),'Power Connect')])[2]")).click();
		Thread.sleep(2000);
	    driver.findElement(By.xpath("//span[contains(text(),\'My Connections\')]")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.id("searchStr")).click();
	    driver.findElement(By.id("searchStr")).sendKeys("Sidra");
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector("#nw-center-searchbtn > .fa")).click();
	    Thread.sleep(2000);	    
	    driver.findElement(By.cssSelector(".btn-blue")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".btn-grey")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.id("btnNoConfirmYesNo")).click();
	    Thread.sleep(2000);
	    
	    /* Set Permissions */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[contains(text(),\'My Connections\')]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[contains(text(),\'My Connections\')]")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//span[contains(text(),\'My Connections\')]")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".col-12:nth-child(1) .coach-footer .d-inline-block:nth-child(1) > .btn-sm")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.id("IsPostAllowing")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.id("IsPostSharing")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.id("IsSharing")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.id("IsPostAllowing")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.id("IsPostSharing")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.id("IsSharing")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".btn-blue")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("(//span[contains(text(),'Blocked')])[1]")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("//span[contains(text(),\'My Requests\')]")).click();
	    Thread.sleep(2000);
	    
	    /* Unblock the Member - BLOCKED Menu --  ADAM ISA */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[contains(text(),\'Blocked\')]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[contains(text(),\'Blocked\')]")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//span[contains(text(),\'Blocked\')]")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".col-12:nth-child(1) .coach-footer .btn-sm")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.id("btnNoConfirmYesNo")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".col-12:nth-child(1) .coach-footer .btn-sm")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.id("btnYesConfirmYesNo")).click();
		wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".toast-message")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".toast-message")).click();
	    Thread.sleep(2000);
	    
	    /* Block the Member from MY CONNECTIONS Menu -- ADAM ISA */
	    driver.findElement(By.xpath("//span[contains(text(),\'My Connections\')]")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".col-12:nth-child(1) .coach-footer .d-inline-block:nth-child(2) > .btn-sm")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.id("btnNoConfirmYesNo")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".col-12:nth-child(1) .coach-footer .d-inline-block:nth-child(2) > .btn-sm")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.id("btnYesConfirmYesNo")).click();
		wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".toast-message")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".toast-message")).click();
	    Thread.sleep(2000);
	    
	    /* Search Adam MUSA and Send Connection request  - SEARCH Menu */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//span[contains(text(),\'Search\')])[1]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//span[contains(text(),\'Search\')])[1]")));Thread.sleep(2000);
	    driver.findElement(By.xpath("(//span[contains(text(),\'Search\')])[1]")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.id("searchStr")).click();
	    driver.findElement(By.id("searchStr")).sendKeys("Ad");
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector("#nw-center-searchbtn > .fa")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.id("searchStr")).clear();
	    driver.findElement(By.id("searchStr")).sendKeys("Adam Musa");
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector("#nw-center-searchbtn > .fa")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".btn-blue")).click();
	    Thread.sleep(2000);
	    
	    /* Cancel Connection Request to ADAM MUSA - Handle Windows - New Window */ 
    	String winHandleBefore3 = driver.getWindowHandle();Thread.sleep(2000);
    	driver.findElement(By.linkText("Adam Musa")).click();
    	Thread.sleep(2000);
    	for(String winHandle : driver.getWindowHandles()){
        driver.switchTo().window(winHandle);	
    	}
	    driver.close();
    	driver.switchTo().window(winHandleBefore3);    	
    	Thread.sleep(2000);
    	
    	/* Back to main page - Cancel Connection request to MUSA */
    	driver.navigate().refresh();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".btn-grey")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.id("btnYesConfirmYesNo")).click();
		wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".toast-message")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".toast-message")).click();
	    
	    /* Logout */
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'My Profile')]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'My Profile')]")));Thread.sleep(2000);
		driver.findElement(By.xpath("//div[contains(text(),'My Profile')]")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("(//div[contains(text(),'Logout')])[2]")).click();
		Thread.sleep(2000);
	  }
	}

