package profileBuilder;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import screenshotOnFailure.FailScreenshot;

@Listeners(screenshotListners.EventList.class)
public class ViewProfiles extends FailScreenshot{

	@Test
	public void Member_PrivateProfiles() throws InterruptedException {
		
		/* Login to the Application - PBC */ 		
	  	driver.findElement(By.xpath("(//button[normalize-space()='Login'])[1]")).click();
		driver.findElement(By.xpath("//input[@id='Username']")).click();
		driver.findElement(By.xpath("//input[@id='Username']")).sendKeys("john.doe001");
		driver.findElement(By.xpath("//input[@id='password-field']")).click();
		driver.findElement(By.xpath("//input[@id='password-field']")).sendKeys("Rockon123");
		driver.findElement(By.xpath("//button[@id='loginButton']")).click();
		Thread.sleep(2000);
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(120));
		 
		/* Navigate to the Profile Builder */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'My Profile')]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'My Profile')]")));Thread.sleep(2000);
		{
		     WebElement element = driver.findElement(By.xpath("//div[@class='menu-item menu-item-active']"));
		     Actions builder = new Actions(driver);
		     builder.moveToElement(element).perform();
		}
		Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'Profile Builder')]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'Profile Builder')]")));Thread.sleep(2000);
		driver.findElement(By.xpath("//div[contains(text(),'Profile Builder')]")).click();
		Thread.sleep(2000);
	    
	    /* Restrict Public View ON */	    
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".active")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".active")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".active")).click();
		wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".toast-message")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".toast-message")).click();
	    
	    /* Create Private profile */
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".btn-blue:nth-child(1)")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".btn-blue:nth-child(1)")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".btn-blue:nth-child(1)")).click();    
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".btn-outline-grey")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".btn-outline-grey")).click();	    
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".btn-blue:nth-child(1)")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".btn-blue:nth-child(1)")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[normalize-space()='Back']")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()='Back']")));
	    Thread.sleep(2000);	    
	   
	    {
	      WebElement element = driver.findElement(By.cssSelector(".pb-Template2 > .template-thumbnail"));
	      Actions builder = new Actions(driver);
	      builder.moveToElement(element).perform();
	    }
	    driver.findElement(By.linkText("View")).click();	    
	    Thread.sleep(2000);
	    
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".btn-outline-grey")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".btn-outline-grey")));   
	    driver.findElement(By.cssSelector(".btn-outline-grey")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[normalize-space()='Back']")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()='Back']")));Thread.sleep(2000);	    
	    Thread.sleep(2000);
	   
	    {
	      WebElement element = driver.findElement(By.cssSelector(".pb-Template2 > .template-thumbnail"));
	      Actions builder = new Actions(driver);
	      builder.moveToElement(element).perform();
	    }
	    driver.findElement(By.linkText("View")).click();
	    Thread.sleep(2000);

	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".btn-burnt-sienna")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".btn-burnt-sienna"))); 
	    driver.findElement(By.cssSelector(".btn-burnt-sienna")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("ProfileName")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.id("ProfileName"))); 
	    driver.findElement(By.id("ProfileName")).click();
	    driver.findElement(By.id("ProfileName")).sendKeys("Ifthy");
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".btn-blue")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".btn-blue")).click();
	    
	    /* Rename the Created Private Profile */
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".saveprofile")));
		wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".saveprofile")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".saveprofile")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("ProfileName")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.id("ProfileName"))); 
	    driver.findElement(By.id("ProfileName")).click();
	    driver.findElement(By.id("ProfileName")).clear();
	    Thread.sleep(2000);
	    driver.findElement(By.id("ProfileName")).sendKeys("Ahmed");
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".float-right > .btn-sm")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".float-right > .btn-sm")).click();
	    Thread.sleep(2000);    
	    
	    /* Delete Private Profile */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".deleteprofile")));
		wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".deleteprofile")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".deleteprofile")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.id("btnYesConfirmYesNo")).click();
		wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".toast-message")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".toast-message")).click();
	    Thread.sleep(2000);
	    
	    /* Create Another Private Profile */
	    {
		     WebElement element = driver.findElement(By.xpath("//div[@id='desktopMenu']"));
		     Actions builder = new Actions(driver);
		     builder.moveToElement(element).perform();
		}
		Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//a[normalize-space()='Profile Builder'])[2]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//a[normalize-space()='Profile Builder'])[2]")));Thread.sleep(2000);
		driver.findElement(By.xpath("(//a[normalize-space()='Profile Builder'])[2]")).click();
		Thread.sleep(2000);
	    driver.findElement(By.cssSelector("form > .btn-blue")).click();
	    {
	      WebElement element = driver.findElement(By.cssSelector(".pb-Template2 > .template-thumbnail"));
	      Actions builder = new Actions(driver);
	      builder.moveToElement(element).perform();
	    }
	    Thread.sleep(2000);
	    driver.findElement(By.linkText("View")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".btn-burnt-sienna > span")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector("#modaleditgoalpopup > .modal-header .fa")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".btn-burnt-sienna")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".btn-burnt-sienna"))); 
	    driver.findElement(By.cssSelector(".btn-burnt-sienna")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("ProfileName")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.id("ProfileName"))); 
	    driver.findElement(By.id("ProfileName")).click();
	    driver.findElement(By.id("ProfileName")).sendKeys("Ifthy");
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".btn-blue")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".btn-blue")).click();
	    Thread.sleep(2000);
	    
	    /* Create another profile - Prime Subscription overlay */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".margin-top-5 > .btn-sm")));
	    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".margin-top-5 > .btn-sm")));Thread.sleep(2000);  
	    driver.findElement(By.cssSelector(".margin-top-5 > .btn-sm")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("btnPrimeFAQ")));
	    wait.until(ExpectedConditions.elementToBeClickable(By.id("btnPrimeFAQ")));Thread.sleep(2000);  
	    driver.findElement(By.id("btnPrimeFAQ")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[@id='modalPrimeFAQ']//i[@class='fa fa-times']")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector("td .btn:nth-child(2)")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector("td .btn:nth-child(1)")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[@id='modalSubscriptionPricing']/div/div/div/button/span/i")).click();
	    Thread.sleep(2000);
	    
	    /* Copy public profile Link */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".btn-blue-link-12 > span")));
	    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".btn-blue-link-12 > span")));Thread.sleep(2000);  
	    driver.findElement(By.cssSelector(".btn-blue-link-12 > span")).click();
	    Thread.sleep(2000);
	    
	    /* PRINT PDF - Handle Windows - New Window */ 
    	String winHandleBefore = driver.getWindowHandle();
    	driver.findElement(By.linkText("Print (PDF)")).click();
    	Thread.sleep(9000);
    	for(String winHandle : driver.getWindowHandles()){
        driver.switchTo().window(winHandle);
    	}
    	driver.close();
    	driver.switchTo().window(winHandleBefore);
    	Thread.sleep(2000);
    	
    	/* Switch back to original browser (first window) -- Promote Profiles */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".btn-promote")));
	    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".btn-promote")));Thread.sleep(2000); 
	    driver.findElement(By.cssSelector(".btn-promote")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.linkText("Post to Social Networks")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@title='Linkedin']//i[@class='fa fa-linkedin']")));
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@title='Linkedin']//i[@class='fa fa-linkedin']")));Thread.sleep(2000); 
	    driver.findElement(By.xpath("//div[@title='Linkedin']//i[@class='fa fa-linkedin']")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.id("btnNoConfirmYesNo")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".SPbtnshare")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".SPcontent > .modal-header .fa")).click();
	    Thread.sleep(2000);
	    
	    /* Cancel Subscription */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".margin-top-5 > .btn-sm")));
	    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".margin-top-5 > .btn-sm")));Thread.sleep(2000); 
	    driver.findElement(By.cssSelector(".margin-top-5 > .btn-sm")).click();Thread.sleep(2000);	    
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@id='divModalMain']/div[3]/div/form/button")));
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@id='divModalMain']/div[3]/div/form/button")));Thread.sleep(2000); 
	    driver.findElement(By.xpath("//div[@id='divModalMain']/div[3]/div/form/button")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".fa-plus-circle")));
	    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".fa-plus-circle")));Thread.sleep(2000); 
	    driver.findElement(By.cssSelector(".fa-plus-circle")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("//button[contains(.,'APPLY')]")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.id("btnAddCard")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.id("cardRadioBtn")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("paypalRadioBtn")));
		wait.until(ExpectedConditions.elementToBeClickable(By.id("paypalRadioBtn")));Thread.sleep(2000);
	    driver.findElement(By.id("paypalRadioBtn")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("btnReviewOrder")));
		wait.until(ExpectedConditions.elementToBeClickable(By.id("btnReviewOrder")));Thread.sleep(2000);
	    driver.findElement(By.id("btnReviewOrder")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[normalize-space()='Edit Order']")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()='Edit Order']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//span[normalize-space()='Edit Order']")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("btnReviewOrder")));
		wait.until(ExpectedConditions.elementToBeClickable(By.id("btnReviewOrder")));Thread.sleep(2000);
	    driver.findElement(By.id("btnReviewOrder")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@id='modalSubscriptionPricing']/div/div/div/button/span/i")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@id='modalSubscriptionPricing']/div/div/div/button/span/i")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[@id='modalSubscriptionPricing']/div/div/div/button/span/i")).click();
	    Thread.sleep(2000);
	    
	    /* Restrict Public View OFF */
	    Thread.sleep(2000);
	    driver.navigate().refresh();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".active")).click();
		wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".toast-message")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".toast-message")).click();
	    Thread.sleep(2000);
	    
	    /* Delete the Created Private Profile */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".deleteprofile")));
		wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".deleteprofile")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".deleteprofile")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.id("btnYesConfirmYesNo")).click();
		wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".toast-message")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".toast-message")).click();
	    Thread.sleep(2000);
	    
	    /* Logout */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'My Profile')]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'My Profile')]")));Thread.sleep(2000);
		driver.findElement(By.xpath("//div[contains(text(),'My Profile')]")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("(//div[contains(text(),'Logout')])[2]")).click();
		Thread.sleep(2000);
	  }
	}
