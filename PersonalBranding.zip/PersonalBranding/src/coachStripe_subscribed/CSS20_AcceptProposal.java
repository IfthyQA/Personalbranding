package coachStripe_subscribed;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import screenshotOnFailure.FailScreenshot;

@Listeners(screenshotListners.EventList.class)
public class CSS20_AcceptProposal extends FailScreenshot{

	@Test
	public void CSS_AcceptProposal() throws InterruptedException {

		/* Login to the Application - PBC */ 		
		driver.findElement(By.xpath("//button[normalize-space()='Login']")).click();
		driver.findElement(By.xpath("//input[@id='Username']")).click();
		driver.findElement(By.xpath("//input[@id='Username']")).sendKeys("test.doe001");
		driver.findElement(By.xpath("//input[@id='password-field']")).click();
		driver.findElement(By.xpath("//input[@id='password-field']")).sendKeys("Rockon123");
		driver.findElement(By.xpath("//button[@id='loginButton']")).click();
		Thread.sleep(2000);
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(120));
		
	    /* Navigate to Coaching Support */
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'My Profile')]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'My Profile')]")));
		Thread.sleep(2000);
		{
		     WebElement element = driver.findElement(By.xpath("//div[@class='menu-item menu-item-active']"));
		     Actions builder = new Actions(driver);
		     builder.moveToElement(element).perform();
		}
		Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'Coaching Support')]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'Coaching Support')]")));Thread.sleep(2000);
		driver.findElement(By.xpath("//div[contains(text(),'Coaching Support')]")).click();
	    Thread.sleep(2000);			
		
		/* Accept Proposal */
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[contains(.,\'Accept\')]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[contains(.,\'Accept\')]")));Thread.sleep(2000);
		driver.findElement(By.xpath("//button[contains(.,\'Accept\')]")).click();
		Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".credit-card-list > div")));
		wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".credit-card-list > div")));Thread.sleep(2000);
		driver.findElement(By.cssSelector(".credit-card-list > div")).click();
		Thread.sleep(2000);
		driver.findElement(By.cssSelector(".btn-blue:nth-child(3)")).click();
		Thread.sleep(2000);
		driver.findElement(By.id("btnNoConfirmYesNo")).click();
		Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".btn-blue:nth-child(3)")));
		wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".btn-blue:nth-child(3)")));Thread.sleep(2000);
		driver.findElement(By.cssSelector(".btn-blue:nth-child(3)")).click();
		Thread.sleep(2000);
		driver.findElement(By.id("btnYesConfirmYesNo")).click();
		Thread.sleep(2000);		
		
		/* Schedule and Create 2 Meetings */
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[normalize-space()='My Meeting']")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()='My Meeting']")));Thread.sleep(2000);
		driver.findElement(By.xpath("//span[normalize-space()='My Meeting']")).click();
		Thread.sleep(2000);
		driver.findElement(By.cssSelector("li > .btn-blue-link-12 > span")).click();
		Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("submitbtn")));
		wait.until(ExpectedConditions.elementToBeClickable(By.id("submitbtn")));
		Thread.sleep(2000);
		driver.findElement(By.id("MeetingName")).click();
		driver.findElement(By.id("MeetingName")).sendKeys("Client : Accepted Proposal");
		Thread.sleep(2000);
	    driver.findElement(By.xpath("//span[@class=\'input-group-append set-date set-date-birth\']//i[@class=\'fa fa-calendar set-date-icon\']")).click();Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[contains(@class, \'datetimepicker datetimepicker-\')][last()]/div[3]/table/tbody/tr/td[@class=\'day active\']")).click();Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[contains(@class, \'datetimepicker datetimepicker-\')][last()]/div[2]/table/tbody/tr/td/fieldset/span[contains(@class,\'hour active \')]")).click();Thread.sleep(2000);
	    
	    if(!driver.findElements(By.xpath("//div[contains(@class, 'datetimepicker datetimepicker-')][last()]/div[1]/table/tbody/tr/td/fieldset/span[10][contains(@class, 'minute disabled')]")).isEmpty())
		{	    		    
			Thread.sleep(2000);
			driver.findElement(By.xpath("//div[@class='datetimepicker-minutes']//th[@class='next']")).click();
		    Thread.sleep(2000);
		    driver.findElement(By.xpath("//div[contains(@class, \'datetimepicker datetimepicker-\')][last()]/div[1]/table/tbody/tr/td/fieldset/span[@class=\'minute\'][3]")).click();	    		    
		}		
		else {
			Thread.sleep(2000);
		    driver.findElement(By.xpath("//div[contains(@class, \'datetimepicker datetimepicker-\')][last()]/div[1]/table/tbody/tr/td/fieldset/span[@class=\'minute\'][3]")).click();
		} 
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.elementToBeClickable(By.id("submitbtn")));Thread.sleep(2000);
		driver.findElement(By.id("submitbtn")).click();
		
		/* Second Meeting in Accept Proposal */
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("li > .btn-blue-link-12 > span")));
		wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector("li > .btn-blue-link-12 > span")));Thread.sleep(2000);
		driver.findElement(By.cssSelector("li > .btn-blue-link-12 > span")).click();
		Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("submitbtn")));
		wait.until(ExpectedConditions.elementToBeClickable(By.id("submitbtn")));
		Thread.sleep(2000);
		driver.findElement(By.id("MeetingName")).click();
		driver.findElement(By.id("MeetingName")).sendKeys("Client : 2nd Meet after Accept Proposal");
		Thread.sleep(2000);
	    driver.findElement(By.xpath("//span[@class=\'input-group-append set-date set-date-birth\']//i[@class=\'fa fa-calendar set-date-icon\']")).click();Thread.sleep(2000);
	    driver.findElement(By.xpath("(//div[contains(@class, \'datetimepicker datetimepicker-\')][last()]/div[3]/table/tbody/tr/td[@class=\'day\'])[1]")).click();Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[contains(@class, \'datetimepicker datetimepicker-\')][last()]/div[2]/table/tbody/tr/td/fieldset/span[contains(@class,\'hour active \')]")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[contains(@class, \'datetimepicker datetimepicker-\')][last()]/div[1]/table/tbody/tr/td/fieldset/span[@class=\'minute\'][1]")).click();	
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.elementToBeClickable(By.id("submitbtn")));Thread.sleep(2000);
		driver.findElement(By.id("submitbtn")).click();
		Thread.sleep(2000);
		wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".biz-admin-overlay > .modal-header .fa")));Thread.sleep(2000);
		driver.findElement(By.cssSelector(".biz-admin-overlay > .modal-header .fa")).click();
		Thread.sleep(2000);	
		driver.navigate().refresh();
		Thread.sleep(2000);	
		
		/* Logout */
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'My Profile')]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'My Profile')]")));Thread.sleep(2000);
		driver.findElement(By.xpath("//div[contains(text(),'My Profile')]")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("(//div[contains(text(),'Logout')])[2]")).click();
		Thread.sleep(2000);
	}
}