package coachStripe_subscribed;

import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import screenshotOnFailure.FailScreenshot;

@Listeners(screenshotListners.EventList.class)
public class CSS11_SendProposal extends FailScreenshot{
	
	@Test
	public void CSS_SendProposal() throws InterruptedException {

	/* Login to the Application */  
	driver.findElement(By.xpath("(//button[normalize-space()='Login'])[1]")).click();
	driver.findElement(By.xpath("//input[@id='Username']")).click();
	driver.findElement(By.xpath("//input[@id='Username']")).sendKeys("john.doe007");
	driver.findElement(By.xpath("//input[@id='password-field']")).click();
	driver.findElement(By.xpath("//input[@id='password-field']")).sendKeys("Rockon123");
	driver.findElement(By.xpath("//button[@id='loginButton']")).click();
	Thread.sleep(2000);
	WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(120));    
    
	/* Navigate to the Coach Page */
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[2]/div[1]/div[1]/div[2]/div[1]/div[1]/a[1]/span[1]")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[2]/div[1]/div[1]/div[2]/div[1]/div[1]/a[1]/span[1]")));Thread.sleep(2000);
    driver.findElement(By.xpath("//div[2]/div[1]/div[1]/div[2]/div[1]/div[1]/a[1]/span[1]")).click();
    Thread.sleep(2000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[normalize-space()='Menu']")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()='Menu']")));Thread.sleep(2000);
    driver.findElement(By.xpath("//span[normalize-space()='Menu']")).click();
    Thread.sleep(2000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[normalize-space()='Coaching Services']")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[normalize-space()='Coaching Services']")));Thread.sleep(2000);
    driver.findElement(By.xpath("//a[normalize-space()='Coaching Services']")).click();
    Thread.sleep(2000);
    
    /* Schedule Meeting */
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[normalize-space()=\'Subscribed Coach Request\']")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()=\'Subscribed Coach Request\']")));Thread.sleep(2000);   
    driver.findElement(By.xpath("//span[normalize-space()=\'Subscribed Coach Request\']")).click();
    Thread.sleep(2000); 
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[3]/div[1]/span/span")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[3]/div[1]/span/span")));Thread.sleep(2000);
    driver.findElement(By.xpath("//div[3]/div[1]/span/span")).click();
    Thread.sleep(2000);
	wait.until(ExpectedConditions.elementToBeClickable(By.id("submitbtn")));Thread.sleep(2000);
    driver.findElement(By.id("submitbtn")).click();
    Thread.sleep(2000);
    driver.findElement(By.id("MeetingName")).click();
    driver.findElement(By.id("MeetingName")).sendKeys("Coach : Proposal MEET on your Request");
    Thread.sleep(2000);
	wait.until(ExpectedConditions.elementToBeClickable(By.id("submitbtn")));Thread.sleep(2000);
    driver.findElement(By.id("submitbtn")).click();
    Thread.sleep(2000);
    driver.findElement(By.xpath("//span[@class=\'input-group-append set-date set-date-birth\']//i[@class=\'fa fa-calendar set-date-icon\']")).click();Thread.sleep(2000);
    driver.findElement(By.xpath("//div[contains(@class, \'datetimepicker datetimepicker-\')][last()]/div[3]/table/tbody/tr/td[@class=\'day active\']")).click();Thread.sleep(2000);
    driver.findElement(By.xpath("//div[contains(@class, \'datetimepicker datetimepicker-\')][last()]/div[2]/table/tbody/tr/td/fieldset/span[contains(@class,\'hour active \')]")).click();Thread.sleep(2000);

    if(!driver.findElements(By.xpath("//div[contains(@class, 'datetimepicker datetimepicker-')][last()]/div[1]/table/tbody/tr/td/fieldset/span[11][contains(@class, 'minute disabled')]")).isEmpty())
	{	    		    
		Thread.sleep(2000);
		driver.findElement(By.xpath("//div[@class='datetimepicker-minutes']//th[@class='next']")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[contains(@class, \'datetimepicker datetimepicker-\')][last()]/div[1]/table/tbody/tr/td/fieldset/span[@class=\'minute\'][2]")).click();	    		    
	}	
	else {
		Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[contains(@class, \'datetimepicker datetimepicker-\')][last()]/div[1]/table/tbody/tr/td/fieldset/span[@class=\'minute\'][2]")).click();
	}
	Thread.sleep(2000);
	driver.findElement(By.xpath("//form[@id=\'myForm\']/div[2]/div[2]/div/div[2]/div/span/span/span")).click();Thread.sleep(2000);
    driver.findElement(By.cssSelector(".select2-search__field")).click();Thread.sleep(2000);
    driver.findElement(By.cssSelector(".select2-search__field")).sendKeys("50");
    driver.findElement(By.cssSelector(".select2-search__field")).sendKeys(Keys.ENTER);  
    Thread.sleep(2000);
	wait.until(ExpectedConditions.elementToBeClickable(By.id("submitbtn")));Thread.sleep(2000);
    driver.findElement(By.id("submitbtn")).click();
    wait.until(ExpectedConditions.invisibilityOfElementLocated(By.id("submitbtn")));
    Thread.sleep(2000);
    driver.findElement(By.cssSelector(".biz-admin-overlay > .modal-header .fa")).click();
    Thread.sleep(2000);
    
    /* Create Proposal - Draft */
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[contains(.,\'Create Proposal\')]")));Thread.sleep(2000);  
    driver.findElement(By.xpath("//button[contains(.,\'Create Proposal\')]")).click();
    Thread.sleep(2000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("TermsAndCondition")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.id("TermsAndCondition")));Thread.sleep(2000); 
    driver.findElement(By.id("TermsAndCondition")).click();
    Thread.sleep(2000);
    driver.findElement(By.cssSelector(".btn-lg")).click();
    Thread.sleep(2000);
    driver.findElement(By.cssSelector(".float-right > .btn-sm")).click();
    Thread.sleep(2000);
    driver.findElement(By.id("ProposalTitle")).click();
    driver.findElement(By.id("ProposalTitle")).sendKeys("Proposal for Subscribed Coach Request");
    Thread.sleep(2000);
    driver.findElement(By.id("HourlyRate")).click();
    driver.findElement(By.id("HourlyRate")).sendKeys("15");
    Thread.sleep(2000);
    JavascriptExecutor js = (JavascriptExecutor) driver;
    js.executeScript("document.querySelector(\'textarea.proposalHourlyDescription\').value=\"hi\";");

//    /* Select Business Team */
//    driver.findElement(By.id("select2-GroupSoid-container")).click();
//    Thread.sleep(2000);
//    driver.findElement(By.cssSelector(".select2-search__field")).click(); Thread.sleep(2000);
//    driver.findElement(By.cssSelector(".select2-search__field")).sendKeys("h");
//    driver.findElement(By.cssSelector(".select2-search__field")).sendKeys(Keys.ENTER);
    Thread.sleep(2000);
    WebElement element = driver.findElement(By.cssSelector(".col-9 > .btn-outline-blue")); /* Scroll till Draft button */
    Actions builder = new Actions(driver);
    builder.moveToElement(element).perform();
    Thread.sleep(2000);
    driver.findElement(By.xpath("//div[@id=\'addblanktask\']/div/div/input")).click();
    driver.findElement(By.xpath("//div[@id=\'addblanktask\']/div/div/input")).sendKeys("Milestone for Subscribed Coach Request");
    driver.findElement(By.xpath("//div[@id=\'addblanktask\']/div/div/input")).click();
    Thread.sleep(2000);
    js.executeScript("document.querySelector(\'textarea.proposalFixedTaskDescription\').value=\"hi\";");
    js.executeScript("document.querySelector(\'textarea.proposalFixedTaskDescription\').value");
    Thread.sleep(2000);
    driver.findElement(By.cssSelector(".divStartDatePicker .fa")).click();
    Thread.sleep(2000);
    driver.findElement(By.xpath("//span[@class='year new']")).click();
    Thread.sleep(2000);
    driver.findElement(By.xpath("(//span[normalize-space()='Jan'])[2]")).click();
    Thread.sleep(2000);
    driver.findElement(By.xpath("(//td[@class='new day'])[1]")).click();
    Thread.sleep(2000);
    driver.findElement(By.xpath("//div[@id=\'addblanktask\']/div/div[2]/div[2]/div/div[4]/div/label")).click();
    driver.findElement(By.xpath("//div[@id=\'addblanktask\']/div/div[2]/div[2]/div/div[4]/div/input")).sendKeys("24");
    Thread.sleep(2000);
    driver.findElement(By.xpath("//div[@id=\'addblanktask\']/div/div/input")).click();
    Thread.sleep(2000);
    driver.findElement(By.cssSelector(".col-9 > .btn-outline-blue")).click();
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@class='toast-message']")));
    driver.findElement(By.xpath("//div[@class='toast-message']")).click(); 
    Thread.sleep(2000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("menuitemdraft")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.id("menuitemdraft")));Thread.sleep(2000);
    driver.findElement(By.id("menuitemdraft")).click();
    Thread.sleep(2000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".form-inline > .btn-maroon")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".form-inline > .btn-maroon")));Thread.sleep(2000);
    driver.findElement(By.cssSelector(".form-inline > .btn-maroon")).click();
    Thread.sleep(2000);
    driver.findElement(By.id("btnYesConfirmYesNo")).click();
    Thread.sleep(2000);
    
    /* Logout */
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'My Profile')]")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'My Profile')]")));Thread.sleep(2000);
	driver.findElement(By.xpath("//div[contains(text(),'My Profile')]")).click();  
	Thread.sleep(2000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//div[contains(text(),'Logout')])[1]")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//div[contains(text(),'Logout')])[1]")));Thread.sleep(2000);
	driver.findElement(By.xpath("(//div[contains(text(),'Logout')])[1]")).click();  
	Thread.sleep(2000);
  }
}

