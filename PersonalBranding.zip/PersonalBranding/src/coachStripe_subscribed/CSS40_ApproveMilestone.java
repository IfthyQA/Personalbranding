package coachStripe_subscribed;

import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import screenshotOnFailure.FailScreenshot;

@Listeners(screenshotListners.EventList.class)
public class CSS40_ApproveMilestone extends FailScreenshot{
	
	@Test
	public void CSS_Milestone_Approve() throws InterruptedException {
		
		/* Login to the Application - PBC */ 		
	  	driver.findElement(By.xpath("(//button[normalize-space()='Login'])[1]")).click();
		driver.findElement(By.xpath("//input[@id='Username']")).click();
		driver.findElement(By.xpath("//input[@id='Username']")).sendKeys("test.doe001");
		driver.findElement(By.xpath("//input[@id='password-field']")).click();
		driver.findElement(By.xpath("//input[@id='password-field']")).sendKeys("Rockon123");
		driver.findElement(By.xpath("//button[@id='loginButton']")).click();
		Thread.sleep(2000);
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(120));		
		
		/* Navigate to Coaching Support */
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'My Profile')]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'My Profile')]")));
		Thread.sleep(2000);
		{
		     WebElement element = driver.findElement(By.xpath("//div[@class='menu-item menu-item-active']"));
		     Actions builder = new Actions(driver);
		     builder.moveToElement(element).perform();
		}
		Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'Coaching Support')]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'Coaching Support')]")));Thread.sleep(2000);
		driver.findElement(By.xpath("//div[contains(text(),'Coaching Support')]")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@id=\'divLeftMenu\']/div[4]/a")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@id=\'divLeftMenu\']/div[4]/a")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[@id=\'divLeftMenu\']/div[4]/a")).click();
	    
	    /* Create Meeting */
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[4]/div[2]/div[2]/div[2]/div[2]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[3]/div[4]/span[1]/span[1]/span[1]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[4]/div[2]/div[2]/div[2]/div[2]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[3]/div[4]/span[1]/span[1]/span[1]")));Thread.sleep(2000);
		driver.findElement(By.xpath("//div[4]/div[2]/div[2]/div[2]/div[2]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[3]/div[4]/span[1]/span[1]/span[1]")).click();
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("li > .btn-blue-link-12 > span")));
		wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector("li > .btn-blue-link-12 > span")));Thread.sleep(2000);
		driver.findElement(By.cssSelector("li > .btn-blue-link-12 > span")).click();
		Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("submitbtn")));
		wait.until(ExpectedConditions.elementToBeClickable(By.id("submitbtn")));
		Thread.sleep(2000);
		driver.findElement(By.id("MeetingName")).click();
		driver.findElement(By.id("MeetingName")).sendKeys("Client : 1st Approving Milestone");
		Thread.sleep(2000);
	    driver.findElement(By.xpath("//span[@class=\'input-group-append set-date set-date-birth\']//i[@class=\'fa fa-calendar set-date-icon\']")).click();Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[contains(@class, \'datetimepicker datetimepicker-\')][last()]/div[3]/table/tbody/tr/td[@class=\'day active\']")).click();Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[contains(@class, \'datetimepicker datetimepicker-\')][last()]/div[2]/table/tbody/tr/td/fieldset/span[contains(@class,\'hour active \')]")).click();Thread.sleep(2000);
	    
	    if(!driver.findElements(By.xpath("//div[contains(@class, 'datetimepicker datetimepicker-')][last()]/div[1]/table/tbody/tr/td/fieldset/span[12][contains(@class, 'minute disabled')]")).isEmpty())
		{	    		    
			Thread.sleep(2000);
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='datetimepicker-minutes']//th[@class='next']")));
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@class='datetimepicker-minutes']//th[@class='next']")));Thread.sleep(2000);
			driver.findElement(By.xpath("//div[@class='datetimepicker-minutes']//th[@class='next']")).click();
		    Thread.sleep(2000);
		    driver.findElement(By.xpath("//div[contains(@class, \'datetimepicker datetimepicker-\')][last()]/div[1]/table/tbody/tr/td/fieldset/span[@class=\'minute\'][1]")).click();	    		    
		}		
		else {
			Thread.sleep(2000);
		    driver.findElement(By.xpath("//div[contains(@class, \'datetimepicker datetimepicker-\')][last()]/div[1]/table/tbody/tr/td/fieldset/span[@class=\'minute\'][1]")).click();
		} 
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.elementToBeClickable(By.id("submitbtn")));Thread.sleep(2000);
		driver.findElement(By.id("submitbtn")).click();
		
		/* Second Meeting in Approving Milestone  */
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("li > .btn-blue-link-12 > span")));
		wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector("li > .btn-blue-link-12 > span")));Thread.sleep(2000);
		driver.findElement(By.cssSelector("li > .btn-blue-link-12 > span")).click();
		Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("submitbtn")));
		wait.until(ExpectedConditions.elementToBeClickable(By.id("submitbtn")));
		Thread.sleep(2000);
		driver.findElement(By.id("MeetingName")).click();
		driver.findElement(By.id("MeetingName")).sendKeys("Client : 2nd Meet on Approving Milestone");
		Thread.sleep(2000);
	    driver.findElement(By.xpath("//span[@class='input-group-append set-date set-date-birth']//i[@class='fa fa-calendar set-date-icon']")).click();Thread.sleep(2000);
	    driver.findElement(By.xpath("(//div[contains(@class, \'datetimepicker datetimepicker-\')][last()]/div[3]/table/tbody/tr/td[@class=\'day\'])[1]")).click();Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[contains(@class, \'datetimepicker datetimepicker-\')][last()]/div[2]/table/tbody/tr/td/fieldset/span[contains(@class,\'hour active \')]")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[contains(@class, \'datetimepicker datetimepicker-\')][last()]/div[1]/table/tbody/tr/td/fieldset/span[@class=\'minute\'][2]")).click();		  
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.elementToBeClickable(By.id("submitbtn")));Thread.sleep(2000);
		driver.findElement(By.id("submitbtn")).click();
		Thread.sleep(2000);
		
		/* Delete All Meetings */
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//i[@class='deletemeeting-icon'])[1]")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//i[@class='deletemeeting-icon'])[1]")));Thread.sleep(2000);
		driver.findElement(By.xpath("(//i[@class='deletemeeting-icon'])[1]")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//button[@id='btnYesConfirmYesNo']")).click();
		Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//i[@class='deletemeeting-icon'])[1]")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//i[@class='deletemeeting-icon'])[1]")));Thread.sleep(2000);
		driver.findElement(By.xpath("(//i[@class='deletemeeting-icon'])[1]")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//button[@id='btnYesConfirmYesNo']")).click();
		Thread.sleep(2000);
		wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".biz-admin-overlay > .modal-header .fa")));Thread.sleep(2000);
		driver.findElement(By.cssSelector(".biz-admin-overlay > .modal-header .fa")).click();
		Thread.sleep(2000);		
	    
	    /* Complete Milestone */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[contains(.,\'Complete Milestone\')]")));
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[contains(.,\'Complete Milestone\')]")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//button[contains(.,\'Complete Milestone\')]")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@id='divWorkInProgressModal']/div/div/div[2]/div/div[5]/form/button")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@id='divWorkInProgressModal']/div/div/div[2]/div/div[5]/form/button")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[@id='divWorkInProgressModal']/div/div/div[2]/div/div[5]/form/button")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[contains(text(),'Milestone completed - Paid')]")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[contains(text(),'Milestone completed - Paid')]")));
	    
	    /* Archived Work */
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".d-none:nth-child(5) > a")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".d-none:nth-child(5) > a")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".d-none:nth-child(5) > a")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[4]/span/span")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[4]/span/span")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[4]/span/span")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".biz-admin-overlay > .modal-header .fa")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".biz-admin-overlay > .modal-header .fa")).click();
	    Thread.sleep(2000);	   
		driver.navigate().refresh();
		Thread.sleep(2000);	 	    
	    
	    /* Logout */
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'My Profile')]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'My Profile')]")));
		driver.findElement(By.xpath("//div[contains(text(),'My Profile')]")).click();
		Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//div[contains(text(),'Logout')])[2]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//div[contains(text(),'Logout')])[2]")));
		driver.findElement(By.xpath("(//div[contains(text(),'Logout')])[2]")).click();
		Thread.sleep(2000);
	  }
	}



