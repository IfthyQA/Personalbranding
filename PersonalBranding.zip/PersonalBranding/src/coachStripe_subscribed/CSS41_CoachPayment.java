package coachStripe_subscribed;

import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import screenshotOnFailure.FailScreenshot;

@Listeners(screenshotListners.EventList.class)
public class CSS41_CoachPayment extends FailScreenshot{

	@Test
	public void CSS_CoachPayment() throws InterruptedException {

		/* Login to the Application */ 
	  	driver.findElement(By.xpath("(//button[normalize-space()='Login'])[1]")).click();
		driver.findElement(By.xpath("//input[@id='Username']")).click();
		driver.findElement(By.xpath("//input[@id='Username']")).sendKeys("john.doe007");
		driver.findElement(By.xpath("//input[@id='password-field']")).click();
		driver.findElement(By.xpath("//input[@id='password-field']")).sendKeys("Rockon123");
		driver.findElement(By.xpath("//button[@id='loginButton']")).click();
		Thread.sleep(2000);
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(120));	    
	    
		/* Navigate to the Coach Page */
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[2]/div[1]/div[1]/div[2]/div[1]/div[1]/a[1]/span[1]")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[2]/div[1]/div[1]/div[2]/div[1]/div[1]/a[1]/span[1]")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[2]/div[1]/div[1]/div[2]/div[1]/div[1]/a[1]/span[1]")).click();
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[normalize-space()='Menu']")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()='Menu']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//span[normalize-space()='Menu']")).click();
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[normalize-space()='Payments']")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[normalize-space()='Payments']")));Thread.sleep(2000);
		driver.findElement(By.xpath("//a[normalize-space()='Payments']")).click();
		Thread.sleep(2000);
	    
	    /* Manage Payments & Orders */
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.linkText("RECEIVING BANK")));
	    wait.until(ExpectedConditions.elementToBeClickable(By.linkText("RECEIVING BANK")));Thread.sleep(2000);
	    driver.findElement(By.linkText("RECEIVING BANK")).click();
	    Thread.sleep(2000);	    
	    wait.until(ExpectedConditions.elementToBeClickable(driver.findElement(By.cssSelector(".btn-blue-link-12 > span"))));	  
	    Thread.sleep(2000);	
	    driver.findElement(By.cssSelector(".btn-blue-link-12 > span")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".coach-receiving-payment .fa")));
	    driver.findElement(By.cssSelector(".coach-receiving-payment .fa")).click();
	    Thread.sleep(2000);
	    
	    /* Transfer - Cancel*/
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".col-centered:nth-child(5) .btn-sm")));
	    wait.until(ExpectedConditions.elementToBeClickable(driver.findElement(By.cssSelector(".col-centered:nth-child(5) .btn-sm"))));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".col-centered:nth-child(5) .btn-sm")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("//button[contains(.,\'Next \')]")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".modal-lg .modal-header .fa")).click();
	    Thread.sleep(2000);
	    
	    /* Transactions Reciepts */
	    driver.findElement(By.xpath("//div[2]/div/div/div/span/form/button/i")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("(//span[contains(text(), 'Coaching')])[1]")).click();
	    Thread.sleep(2000);			
	    	String winHandleBefore = driver.getWindowHandle();
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.linkText("Proposal for Subscribed Coach Request")));
		    wait.until(ExpectedConditions.elementToBeClickable(driver.findElement(By.linkText("Proposal for Subscribed Coach Request"))));Thread.sleep(2000);
		    driver.findElement(By.linkText("Proposal for Subscribed Coach Request")).click();
		    Thread.sleep(2000);	    	// Navigate to New window
	    	for(String winHandle : driver.getWindowHandles()){
	        driver.switchTo().window(winHandle);
	    	}
	    	Thread.sleep(2000);
	    	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[2]/form/button")));
		    driver.findElement(By.xpath("//div[2]/form/button")).click();
		    Thread.sleep(2000);
		    driver.findElement(By.cssSelector(".fa-arrow-circle-o-left")).click();
		    Thread.sleep(2000);
		    driver.close();
		    driver.switchTo().window(winHandleBefore);	    
	    driver.findElement(By.cssSelector("#modalsettingtaskdetailpopup .fa")).click();
	    driver.findElement(By.cssSelector(".fa-minus-circle")).click();	    
	    
	    /* Transfer Payment */	    
	    wait.until(ExpectedConditions.elementToBeClickable(driver.findElement(By.cssSelector(".btn-blue-link-12 > span"))));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".col-centered:nth-child(5) .btn-sm")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("//button[contains(.,\'Next \')]")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.id("TransferAmount")).click();
	    driver.findElement(By.id("TransferAmount")).sendKeys("10");
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("//button[contains(.,\'Next \')]")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.id("reviewEditTransfer")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("TransferAmount")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.id("TransferAmount")));	
	    Thread.sleep(2000);
	    driver.findElement(By.id("TransferAmount")).click();
	    driver.findElement(By.id("TransferAmount")).sendKeys("1");
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[contains(.,\'Next \')]")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//button[contains(.,\'Next \')]")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".btn-blue:nth-child(2)")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".btn-blue:nth-child(2)")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".btn-blue:nth-child(2)")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".btn-blue-link-12 > span")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".btn-blue-link-12 > span")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".btn-blue-link-12 > span")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".coach-receiving-payment .fa")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".coach-receiving-payment .fa")).click();	    	    
	    
	    /* Logout */
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'My Profile')]")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'My Profile')]")));Thread.sleep(2000);
		driver.findElement(By.xpath("//div[contains(text(),'My Profile')]")).click();  
		Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//div[contains(text(),'Logout')])[1]")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//div[contains(text(),'Logout')])[1]")));Thread.sleep(2000);
		driver.findElement(By.xpath("(//div[contains(text(),'Logout')])[1]")).click();  
		Thread.sleep(2000);
	  }
	}
