package coachStripe_subscribed;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import screenshotOnFailure.FailScreenshot;

@Listeners(screenshotListners.EventList.class)
public class CSS31_CompleteMilestone extends FailScreenshot{
	
	@Test
	public void CSS_Milestone_Complete() throws InterruptedException {
		
		/* Login to the Application */ 
	  	driver.findElement(By.xpath("(//button[normalize-space()='Login'])[1]")).click();
		driver.findElement(By.xpath("//input[@id='Username']")).click();
		driver.findElement(By.xpath("//input[@id='Username']")).sendKeys("john.doe007");
		driver.findElement(By.xpath("//input[@id='password-field']")).click();
		driver.findElement(By.xpath("//input[@id='password-field']")).sendKeys("Rockon123");
		driver.findElement(By.xpath("//button[@id='loginButton']")).click();
		Thread.sleep(2000);
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(120));	    
	    
		/* Navigate to the Coach Page */
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[2]/div[1]/div[1]/div[2]/div[1]/div[1]/a[1]/span[1]")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[2]/div[1]/div[1]/div[2]/div[1]/div[1]/a[1]/span[1]")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[2]/div[1]/div[1]/div[2]/div[1]/div[1]/a[1]/span[1]")).click();
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[normalize-space()='Menu']")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()='Menu']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//span[normalize-space()='Menu']")).click();
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[normalize-space()='Coaching Services']")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[normalize-space()='Coaching Services']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//a[normalize-space()='Coaching Services']")).click();
	    Thread.sleep(2000);
	    
	    /* Delete and Create New Meeting */
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("menuiteminprogress")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.id("menuiteminprogress")));Thread.sleep(2000);
	    driver.findElement(By.id("menuiteminprogress")).click();
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".float-md-right > .btn-blue-link-12:nth-child(1)")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".float-md-right > .btn-blue-link-12:nth-child(1)")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".float-md-right > .btn-blue-link-12:nth-child(1)")).click();
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".deletemeeting-icon")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".deletemeeting-icon")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".deletemeeting-icon")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.id("btnYesConfirmYesNo")).click();Thread.sleep(2000);
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("li > .btn-blue-link-12 > span")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector("li > .btn-blue-link-12 > span")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector("li > .btn-blue-link-12 > span")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.id("MeetingName")).click();
	    driver.findElement(By.id("MeetingName")).sendKeys("Coach : Complete Milestone");
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("//span[@class=\'input-group-append set-date set-date-birth\']//i[@class=\'fa fa-calendar set-date-icon\']")).click();Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[contains(@class, \'datetimepicker datetimepicker-\')][last()]/div[3]/table/tbody/tr/td[@class=\'day active\']")).click();Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[contains(@class, \'datetimepicker datetimepicker-\')][last()]/div[2]/table/tbody/tr/td/fieldset/span[contains(@class,\'hour active \')]")).click();Thread.sleep(2000);
	   
	    if(!driver.findElements(By.xpath("//div[contains(@class, 'datetimepicker datetimepicker-')][last()]/div[1]/table/tbody/tr/td/fieldset/span[12][contains(@class, 'minute disabled')]")).isEmpty())
		{	    		    
			Thread.sleep(2000);
			driver.findElement(By.xpath("//div[@class='datetimepicker-minutes']//th[@class='next']")).click();
		    Thread.sleep(2000);
		    driver.findElement(By.xpath("//div[contains(@class, \'datetimepicker datetimepicker-\')][last()]/div[1]/table/tbody/tr/td/fieldset/span[@class=\'minute\'][1]")).click();	    		    
		}		
		else {
			Thread.sleep(2000);
		    driver.findElement(By.xpath("//div[contains(@class, \'datetimepicker datetimepicker-\')][last()]/div[1]/table/tbody/tr/td/fieldset/span[@class=\'minute\'][1]")).click();
		}  
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.elementToBeClickable(By.id("submitbtn")));Thread.sleep(2000);
	    driver.findElement(By.id("submitbtn")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".biz-admin-overlay > .modal-header .fa")).click();
	    Thread.sleep(2000);
	   	    	    
	    /* Complete Milestone */
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[2]/div/form/button")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[2]/div/form/button")));Thread.sleep(2000);	
	    driver.findElement(By.xpath("//div[2]/div/form/button")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[normalize-space()='Confirm']")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()='Confirm']")));Thread.sleep(2000);	
	    driver.findElement(By.xpath("//span[normalize-space()='Confirm']")).click();
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@class='toast-message']")));
	    driver.findElement(By.xpath("//div[@class='toast-message']")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath("//span[normalize-space()='Confirm']")));	    	    
	    
	    /* Delete Meeting from Meeting Dashboard */
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@title='Stripe Test Automation']")));	// Business Hub Logo Bavigation
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@title='Stripe Test Automation']")));Thread.sleep(2000);
		driver.findElement(By.xpath("//div[@title='Stripe Test Automation']")).click();
		Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[normalize-space()='Menu']")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()='Menu']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//span[normalize-space()='Menu']")).click();
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[normalize-space()='Meetings']")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[normalize-space()='Meetings']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//a[normalize-space()='Meetings']")).click();
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".deletemeeting-icon")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".deletemeeting-icon")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".deletemeeting-icon")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.id("btnYesConfirmYesNo")).click();
	    wait.until(ExpectedConditions.invisibilityOfElementLocated(By.id("btnYesConfirmYesNo")));
	    Thread.sleep(2000);
	    
	    /* Logout */
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'My Profile')]")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'My Profile')]")));Thread.sleep(2000);
		driver.findElement(By.xpath("//div[contains(text(),'My Profile')]")).click();  
		Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//div[contains(text(),'Logout')])[1]")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//div[contains(text(),'Logout')])[1]")));Thread.sleep(2000);
		driver.findElement(By.xpath("(//div[contains(text(),'Logout')])[1]")).click();  
		Thread.sleep(2000);
	  }
	}


