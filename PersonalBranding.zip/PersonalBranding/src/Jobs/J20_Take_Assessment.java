package Jobs;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import screenshotOnFailure.FailScreenshot;

@Listeners(screenshotListners.EventList.class)
public class J20_Take_Assessment extends FailScreenshot{
	
	@Test
	public void Jobs_Take_Assessment() throws InterruptedException {

		/* Login to the Application - PBC */ 		
	  	driver.findElement(By.xpath("(//button[normalize-space()='Login'])[1]")).click();
		driver.findElement(By.xpath("//input[@id='Username']")).click();
		driver.findElement(By.xpath("//input[@id='Username']")).sendKeys("john.doe002");
		driver.findElement(By.xpath("//input[@id='password-field']")).click();
		driver.findElement(By.xpath("//input[@id='password-field']")).sendKeys("Rockon123");
		driver.findElement(By.xpath("//button[@id='loginButton']")).click();
		Thread.sleep(2000);
		 WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(120));
		 
		/* Navigate to the Assessment */
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'My Profile')]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'My Profile')]")));
		Thread.sleep(2000);
		{
		     WebElement element = driver.findElement(By.xpath("//div[@class='menu-item menu-item-active']"));
		     Actions builder = new Actions(driver);
		     builder.moveToElement(element).perform();
		}
		Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='menu-label ml-1'][normalize-space()='Personality Assessment']")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@class='menu-label ml-1'][normalize-space()='Personality Assessment']")));Thread.sleep(2000);
		driver.findElement(By.xpath("//div[@class='menu-label ml-1'][normalize-space()='Personality Assessment']")).click();
		Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//section[2]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[2]/a[1]")));
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//section[2]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[2]/a[1]")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//section[2]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[2]/a[1]")).click();Thread.sleep(2000); 
	    
	    /* Click Buisness Page on Request Card */
	    String winHandleBefore = driver.getWindowHandle();Thread.sleep(2000);
	    driver.findElement(By.xpath("(//span[@class='request-name'][normalize-space()='Business Automation'])[2]")).click();
	    Thread.sleep(2000);
	    for(String winHandle : driver.getWindowHandles()){
	        driver.switchTo().window(winHandle);Thread.sleep(2000);
	    	}
		    driver.close();Thread.sleep(2000);
		    driver.switchTo().window(winHandleBefore);Thread.sleep(2000);
	    
	    /* Click Job ID on Request Card */
	    driver.findElement(By.xpath("//section[2]/div[2]/div[1]/div[2]/div[1]/div[1]/div[2]/div[2]/div[1]/div[2]/div[1]/div[1]/div[2]/span[1]/strong[1]")).click();Thread.sleep(2000);
	    String winHandleBefore1 = driver.getWindowHandle();Thread.sleep(2000);
	    driver.findElement(By.xpath("//span[@class=\'bizName\']")).click();Thread.sleep(2000);
	    	for(String winHandle : driver.getWindowHandles()){
	        driver.switchTo().window(winHandle);Thread.sleep(2000);
	    	}
		    driver.close();Thread.sleep(2000);
		    driver.switchTo().window(winHandleBefore1);Thread.sleep(2000);    
	    driver.findElement(By.xpath("//div[@id=\'coachingcancelpopup\']//i[@class=\'fa fa-times\']")).click();Thread.sleep(2000); 
	    
	    /* Take MBTI (16 Personlity) Assessment */
	    driver.findElement(By.xpath("//div[4]/div[1]/div[1]/section[2]/div[2]/div[1]/div[2]/div[2]/div[1]/div[3]/div/span")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("(//input[@id=\'Answers_0__ScoreData\'])[1]")).click();Thread.sleep(2000);
	    driver.findElement(By.xpath("(//input[@id=\'Answers_1__ScoreData\'])[2]")).click();Thread.sleep(2000);
	    driver.findElement(By.xpath("(//input[@id=\'Answers_2__ScoreData\'])[3]")).click();Thread.sleep(2000);
	    driver.findElement(By.xpath("(//input[@id=\"Answers_3__ScoreData\"])[4]")).click();Thread.sleep(2000);
	    driver.findElement(By.xpath("(//input[@id=\"Answers_4__ScoreData\"])[5]")).click();Thread.sleep(2000);
	    driver.findElement(By.xpath("(//input[@id=\"Answers_5__ScoreData\"])[4]")).click();Thread.sleep(2000);
	    driver.findElement(By.xpath("(//input[@id=\"Answers_6__ScoreData\"])[3]")).click();Thread.sleep(2000);
	    driver.findElement(By.xpath("(//input[@id=\'Answers_7__ScoreData\'])[2]")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".btn-outline-grey")).click();Thread.sleep(2000);
	    driver.findElement(By.id("btnNoConfirmYesNo")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".fa-angle-right")).click();Thread.sleep(2000);
	    driver.findElement(By.xpath("(//input[@id=\"Answers_8__ScoreData\"])[2]")).click();Thread.sleep(2000);
	    driver.findElement(By.xpath("(//input[@id=\"Answers_9__ScoreData\"])[3]")).click();Thread.sleep(2000);
	    driver.findElement(By.xpath("(//input[@id=\"Answers_10__ScoreData\"])[4]")).click();Thread.sleep(2000);
	    driver.findElement(By.xpath("(//input[@id=\'Answers_11__ScoreData\'])[5]")).click();Thread.sleep(2000);
	    driver.findElement(By.xpath("(//input[@id=\'Answers_12__ScoreData\'])[1]")).click();Thread.sleep(2000);
	    driver.findElement(By.xpath("(//input[@id=\'Answers_13__ScoreData\'])[2]")).click();Thread.sleep(2000);
	    driver.findElement(By.xpath("(//input[@id=\'Answers_14__ScoreData\'])[3]")).click();Thread.sleep(2000);
	    driver.findElement(By.xpath("(//input[@id=\'Answers_15__ScoreData\'])[4]")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".fa-angle-right")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("(//input[@id=\"Answers_16__ScoreData\"])[2]")).click();Thread.sleep(2000);
	    driver.findElement(By.xpath("(//input[@id=\"Answers_17__ScoreData\"])[3]")).click();Thread.sleep(2000);
	    driver.findElement(By.xpath("(//input[@id=\"Answers_18__ScoreData\"])[4]")).click();Thread.sleep(2000);
	    driver.findElement(By.xpath("(//input[@id=\'Answers_19__ScoreData\'])[5]")).click();Thread.sleep(2000);
	    driver.findElement(By.xpath("(//input[@id=\'Answers_20__ScoreData\'])[1]")).click();Thread.sleep(2000);
	    driver.findElement(By.xpath("(//input[@id=\'Answers_21__ScoreData\'])[2]")).click();Thread.sleep(2000);
	    driver.findElement(By.xpath("(//input[@id=\'Answers_22__ScoreData\'])[3]")).click();Thread.sleep(2000);
	    driver.findElement(By.xpath("(//input[@id=\'Answers_23__ScoreData\'])[4]")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".fa-angle-right")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("(//input[@id=\"Answers_24__ScoreData\"])[1]")).click();Thread.sleep(2000);
	    driver.findElement(By.xpath("(//input[@id=\"Answers_25__ScoreData\"])[3]")).click();Thread.sleep(2000);
	    driver.findElement(By.xpath("(//input[@id=\"Answers_26__ScoreData\"])[1]")).click();Thread.sleep(2000);
	    driver.findElement(By.xpath("(//input[@id=\'Answers_27__ScoreData\'])[5]")).click();Thread.sleep(2000);
	    driver.findElement(By.xpath("(//input[@id=\'Answers_28__ScoreData\'])[2]")).click();Thread.sleep(2000);
	    driver.findElement(By.xpath("(//input[@id=\'Answers_29__ScoreData\'])[3]")).click();Thread.sleep(2000);
	    driver.findElement(By.xpath("(//input[@id=\'Answers_30__ScoreData\'])[2]")).click();Thread.sleep(2000);
	    driver.findElement(By.xpath("(//input[@id=\'Answers_31__ScoreData\'])[5]")).click();
	    Thread.sleep(2000);
	   
	    /* Submit the Assessment */
	    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".btn-blue")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".btn-blue")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".fa-arrow-left")).click();	    
	    
	    /* Logout */
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'My Profile')]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'My Profile')]")));Thread.sleep(2000);
		driver.findElement(By.xpath("//div[contains(text(),'My Profile')]")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("(//div[contains(text(),'Logout')])[2]")).click();
		Thread.sleep(2000);
	  }
	}
		
