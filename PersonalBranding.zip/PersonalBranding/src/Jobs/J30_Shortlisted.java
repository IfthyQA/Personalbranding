package Jobs;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import screenshotOnFailure.FailScreenshot;

@Listeners(screenshotListners.EventList.class)
public class J30_Shortlisted extends FailScreenshot{
	
	@Test
	public void Jobs_Shortlist() throws InterruptedException {

		/* Login to the Application - PBC */ 		
	  	driver.findElement(By.xpath("(//button[normalize-space()='Login'])[1]")).click();
		driver.findElement(By.xpath("//input[@id='Username']")).click();
		driver.findElement(By.xpath("//input[@id='Username']")).sendKeys("john.doe002");
		driver.findElement(By.xpath("//input[@id='password-field']")).click();
		driver.findElement(By.xpath("//input[@id='password-field']")).sendKeys("Rockon123");
		driver.findElement(By.xpath("//button[@id='loginButton']")).click();
		Thread.sleep(2000);
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(120));
		 
		/* Navigate to the Job Opportunity Page */
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'My Profile')]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'My Profile')]")));
		Thread.sleep(2000);
		{
		     WebElement element = driver.findElement(By.xpath("//div[@class='menu-item menu-item-active']"));
		     Actions builder = new Actions(driver);
		     builder.moveToElement(element).perform();
		}
		Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='menu-label ml-1'][normalize-space()='Jobs']")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@class='menu-label ml-1'][normalize-space()='Jobs']")));Thread.sleep(2000);
		driver.findElement(By.xpath("//div[@class='menu-label ml-1'][normalize-space()='Jobs']")).click();
		Thread.sleep(2000);	
	    
	    /* Shortlisted Jobs */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='menu-list']//div[4]")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@class='menu-list']//div[4]")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[@class='menu-list']//div[4]")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[@class='biz-discussion-link invisibleButton margin-bottom-0']")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[@class='biz-discussion-link invisibleButton margin-bottom-0']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//button[@class='biz-discussion-link invisibleButton margin-bottom-0']")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//i[@class='fa fa-arrow-circle-o-left margin-right-5']")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//i[@class='fa fa-arrow-circle-o-left margin-right-5']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//i[@class='fa fa-arrow-circle-o-left margin-right-5']")).click();
	    Thread.sleep(2000);	    
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[2]/div[2]/div[2]")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[2]/div[2]/div[2]")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[2]/div[2]/div[2]")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".biz-discussion-link")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".biz-discussion-link")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".biz-discussion-link")).click();	    
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".btnCancelDiscussion")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".btnCancelDiscussion")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".btnCancelDiscussion")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".biz-discussion-link")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".biz-discussion-link")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".biz-discussion-link")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".bp-back-link")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".bp-back-link")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//a[@class='invisibleButton bp-back-link bp-back-link-list']")).click();Thread.sleep(2000);
	    
	    /* Discussions */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".biz-discussion-link")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".biz-discussion-link")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".biz-discussion-link")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("Message")));
	  	wait.until(ExpectedConditions.elementToBeClickable(By.id("Message")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//button[contains(.,\'Send\')]")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("Message")));
	  	wait.until(ExpectedConditions.elementToBeClickable(By.id("Message")));Thread.sleep(2000);
	    driver.findElement(By.id("Message")).click();Thread.sleep(2000);
	    driver.findElement(By.id("Message")).sendKeys("Sure Sir. thank you");Thread.sleep(2000);
	    
	    /* Add Attachment */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[@class=\'titleAttach\']")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[@class=\'titleAttach\']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//span[@class=\'titleAttach\']")).click();Thread.sleep(2000);	 
	    driver.findElement(By.xpath("//button[@type=\'button\']//span[contains(text(),\'Power Share\')]")).click();Thread.sleep(2000);
	    driver.findElement(By.xpath("//span[contains(.,\'ADD FILES\')]")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".aspect-ratio-16-9 > img")).click();Thread.sleep(2000);
	    driver.findElement(By.xpath("//span[contains(.,\'ADD FILES\')]")).click();Thread.sleep(2000);
	    driver.findElement(By.xpath("//button[contains(.,\'Send\')]")).click();Thread.sleep(2000);
	    
	    /* Reply to the Above message With Attachment */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[@class=\'titleAttach\']")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[@class=\'titleAttach\']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//span[@class=\'titleAttach\']")).click();Thread.sleep(2000);	 
	    driver.findElement(By.xpath("//button[@type=\'button\']//span[contains(text(),\'Power Share\')]")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".aspect-ratio-16-9 > img")).click();Thread.sleep(2000);
	    driver.findElement(By.xpath("//span[contains(.,\'ADD FILES\')]")).click();Thread.sleep(2000);
	    
	    /* Remove Attachments */
	    driver.findElement(By.xpath("//div[@id=\'outfineuploader\']/div/span/i[2]")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[@class=\'titleAttach\']")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[@class=\'titleAttach\']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//span[@class=\'titleAttach\']")).click();Thread.sleep(2000);	 
	    driver.findElement(By.xpath("//button[@type=\'button\']//span[contains(text(),\'Power Share\')]")).click();Thread.sleep(2000);
	    driver.findElement(By.xpath("//span[contains(.,\'ADD FILES\')]")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".modal-social > .modal-header .fa")).click();Thread.sleep(2000);	    
	    
	    /* Reply to Discussion */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("Message")));
	  	wait.until(ExpectedConditions.elementToBeClickable(By.id("Message")));Thread.sleep(2000);
	    driver.findElement(By.id("Message")).click();Thread.sleep(2000);
	    driver.findElement(By.xpath("//button[contains(.,\'Send\')]")).click();Thread.sleep(2000);
	    driver.findElement(By.id("Message")).sendKeys("Okay");Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".biz-discussion-link")).click();Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("Message")));
	  	wait.until(ExpectedConditions.elementToBeClickable(By.id("Message")));Thread.sleep(2000);
	    driver.findElement(By.id("Message")).click();Thread.sleep(2000);
	    driver.findElement(By.id("Message")).sendKeys("Thanks for the Shortlisted!");Thread.sleep(2000);
	    driver.findElement(By.xpath("//button[contains(.,\'Send\')]")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".btnCancelDiscussion")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".bp-back-link")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".bp-back-link")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//a[@class='invisibleButton bp-back-link bp-back-link-list']")).click();Thread.sleep(2000);
	    
	    /* Share the Job */
	    driver.findElement(By.cssSelector(".title-controls .btn-sm")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".SPbtnshare")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".txtMemberInvite")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".txtMemberInvite")).sendKeys("Adam");
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[2]/div/ul/li/div")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[2]/div/ul/li/div")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[2]/div/ul/li/div")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".SPbtnshare")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".SPbtnshare")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".bp-back-link")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".bp-back-link")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//a[@class='invisibleButton bp-back-link bp-back-link-list']")).click();
	    Thread.sleep(2000);
	    
	    /* Logout */
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'My Profile')]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'My Profile')]")));Thread.sleep(2000);
		driver.findElement(By.xpath("//div[contains(text(),'My Profile')]")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("(//div[contains(text(),'Logout')])[2]")).click();
		Thread.sleep(2000);
	  }
	}

