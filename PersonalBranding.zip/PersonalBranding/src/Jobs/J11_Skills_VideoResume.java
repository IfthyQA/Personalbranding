package Jobs;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import screenshotOnFailure.FailScreenshot;

@Listeners(screenshotListners.EventList.class)
public class J11_Skills_VideoResume extends FailScreenshot{

	@Test
	public void Jobs_Skills_Resume() throws InterruptedException {

  		/* Login to the Application - PBC */ 		
	  	driver.findElement(By.xpath("(//button[normalize-space()='Login'])[1]")).click();
  		driver.findElement(By.xpath("//input[@id='Username']")).click();
  		driver.findElement(By.xpath("//input[@id='Username']")).sendKeys("john.doe005");
  		driver.findElement(By.xpath("//input[@id='password-field']")).click();
  		driver.findElement(By.xpath("//input[@id='password-field']")).sendKeys("Rockon123");
  		driver.findElement(By.xpath("//button[@id='loginButton']")).click();
  		Thread.sleep(2000);
  		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(120));
	    
	    /* Naviagte to the Business Page */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[normalize-space()='Business Automati...']")));
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()='Business Automati...']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//span[normalize-space()='Business Automati...']")).click();
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[normalize-space()='Menu']")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()='Menu']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//span[normalize-space()='Menu']")).click();
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//a[normalize-space()='Talent Management'])[1]")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//a[normalize-space()='Talent Management'])[1]")));Thread.sleep(2000);
	    driver.findElement(By.xpath("(//a[normalize-space()='Talent Management'])[1]")).click();
	    Thread.sleep(2000);   
	    
	    /*Applicant Public Views */
	    	String winHandleBefore = driver.getWindowHandle();Thread.sleep(3000);
		    driver.findElement(By.linkText("John Tescra")).click();Thread.sleep(3000);  /* PROFILE NAME - Public View */	  	
	    	for(String winHandle : driver.getWindowHandles()){
	        driver.switchTo().window(winHandle);Thread.sleep(3000);
	    	}
		    driver.close();Thread.sleep(3000);
		    driver.switchTo().window(winHandleBefore);Thread.sleep(3000);
	    	
	    	String winHandleBefore1 = driver.getWindowHandle();Thread.sleep(3000);
		    driver.findElement(By.cssSelector(".image50 img")).click();Thread.sleep(3000); /* PROFILE Image - Public View */	 
	    	for(String winHandle : driver.getWindowHandles()){
	        driver.switchTo().window(winHandle);Thread.sleep(3000);
	    	}
		    driver.close();Thread.sleep(3000);
		    driver.switchTo().window(winHandleBefore1);Thread.sleep(3000);
		    
		    String winHandleBefore2 = driver.getWindowHandle();Thread.sleep(3000);
		    driver.findElement(By.xpath("//span[@class='pb-pointer']")).click(); /* COMMENDATION Link - Public View */
		    for(String winHandle : driver.getWindowHandles()){
		    driver.switchTo().window(winHandle);Thread.sleep(3000);
		    }
			driver.close();Thread.sleep(3000);
			driver.switchTo().window(winHandleBefore2);Thread.sleep(3000);
	
		/* Mouse Over on Skills, Phone Icon */
			  {
		        WebElement element = driver.findElement(By.cssSelector(".link-tip > .fa")); /* Skills */
		        Actions builder = new Actions(driver);
		        builder.moveToElement(element).perform();
		      }
		      Thread.sleep(3000);   
		      {
		    	WebElement element = driver.findElement(By.xpath("//div[@class=\'testShareContainer\']//div[@class=\'btn-sm btn-outline-blue personalityTestBtn\']")); /* Assessment Button */
		        Actions builder = new Actions(driver);
		        builder.moveToElement(element).perform();
		      }
		      Thread.sleep(3000);		     		     
		      {
		      	WebElement element = driver.findElement(By.xpath("//div[@class=\'testShareContainer\']//div[@class=\'btn-sm btn-outline-blue personalityTestBtn\']")); /* Assessment Button */
		        Actions builder = new Actions(driver);
		        builder.moveToElement(element).perform();
		      }
		        Thread.sleep(3000);
		      {
		      	WebElement element = driver.findElement(By.xpath("//div[@class=\'contactDetailsIcon\']")); /* Phone Mail Icon */
		        Actions builder = new Actions(driver);
		        builder.moveToElement(element).perform();
		      }
		      
	    /* Calendar Icon */
		Thread.sleep(3000);
		driver.findElement(By.xpath("//span[normalize-space()=\'Interview Schedule\']")).click();
		Thread.sleep(3000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".defaultSubmit")));
		wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".defaultSubmit")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".defaultSubmit")).click();
	    Thread.sleep(3000);
	    driver.findElement(By.cssSelector(".btnCancelDecision .fa")).click();Thread.sleep(2000);
	    
	    /* Logout */
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'My Profile')]")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'My Profile')]")));Thread.sleep(2000);
		driver.findElement(By.xpath("//div[contains(text(),'My Profile')]")).click();  
		Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//div[contains(text(),'Logout')])[1]")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//div[contains(text(),'Logout')])[1]")));Thread.sleep(2000);
		driver.findElement(By.xpath("(//div[contains(text(),'Logout')])[1]")).click();  
		Thread.sleep(2000);
	  }
	}

