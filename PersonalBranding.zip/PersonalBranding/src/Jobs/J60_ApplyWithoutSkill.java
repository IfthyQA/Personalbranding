package Jobs;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import screenshotOnFailure.FailScreenshot;

@Listeners(screenshotListners.EventList.class)
public class J60_ApplyWithoutSkill extends FailScreenshot{
	
	@Test
	public void Jobs_ApplyWithoutskill() throws InterruptedException {

		/* Login to the Application - PBC */ 		
	  	driver.findElement(By.xpath("(//button[normalize-space()='Login'])[1]")).click();
		driver.findElement(By.xpath("//input[@id='Username']")).click();
		driver.findElement(By.xpath("//input[@id='Username']")).sendKeys("john.doe002");
		driver.findElement(By.xpath("//input[@id='password-field']")).click();
		driver.findElement(By.xpath("//input[@id='password-field']")).sendKeys("Rockon123");
		driver.findElement(By.xpath("//button[@id='loginButton']")).click();
		Thread.sleep(2000);
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(120));
		 
		/* Navigate to the Job Opportunity Page */
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'My Profile')]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'My Profile')]")));
		Thread.sleep(2000);
		{
		     WebElement element = driver.findElement(By.xpath("//div[@class='menu-item menu-item-active']"));
		     Actions builder = new Actions(driver);
		     builder.moveToElement(element).perform();
		}
		Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='menu-label ml-1'][normalize-space()='Jobs']")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@class='menu-label ml-1'][normalize-space()='Jobs']")));Thread.sleep(2000);
		driver.findElement(By.xpath("//div[@class='menu-label ml-1'][normalize-space()='Jobs']")).click();
		Thread.sleep(2000);
	    driver.findElement(By.id("btnWorkPreference")).click();Thread.sleep(2000);
	    driver.findElement(By.name("CurrentlyLooking")).click();Thread.sleep(2000);
	    driver.findElement(By.xpath("//*[@id=\"preferenceModal\"]/div/div/div[2]/form/div[2]/div[2]/div/div[2]/label/input")).click();Thread.sleep(2000);
	    driver.findElement(By.name("CurrentlyLooking")).click();Thread.sleep(2000);
	    driver.findElement(By.id("WillingToRelocate")).click();Thread.sleep(2000);
	    driver.findElement(By.id("WillingToTravel")).click();Thread.sleep(2000);
	    driver.findElement(By.id("Remote")).click();Thread.sleep(2000);
	    driver.findElement(By.id("NoticePeriod")).click();Thread.sleep(2000);
	    driver.findElement(By.id("NoticePeriod")).sendKeys("3");Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".jo-blue-btn")).click();Thread.sleep(2000);
	    
	    /* Apply Job without Skill */
	    driver.findElement(By.cssSelector(".tagit-choice:nth-child(1) .text-icon")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".ui-autocomplete-input")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".ui-autocomplete-input")).sendKeys("Artificial Intelligence");Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".ui-autocomplete-input")).sendKeys(Keys.ENTER);Thread.sleep(2000);
	    driver.findElement(By.id("updateResults")).click();Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[2]/div[2]/div/div/div/div[2]/div/div/div/div[2]/div/div")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.linkText("Back to List")).click();Thread.sleep(2000);
	    driver.findElement(By.xpath("//button[@type=\'submit\']")).click();Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[5]/div/div/form/button")).click();Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[2]/div/div[2]/button/i")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".SPbtnshare")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".SPcontent > .modal-header .fa")).click();
	    Thread.sleep(2000);
	    
	    /* Saved Menu*/
	    driver.findElement(By.xpath("//div[4]/div[1]/div[2]/div[2]/div[1]/div[1]/div[1]/div[1]/div[6]/a[1]")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".btn-blue-link-14 > .fa")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".SPbtnshare")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".txtMemberInvite")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".txtMemberInvite")).sendKeys("adam@tescra.com");Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".txtMemberInvite")).sendKeys(Keys.ENTER);
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".SPbtnshare")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".SPbtnshare")).click();
	    wait.until(ExpectedConditions.invisibilityOfElementLocated(By.cssSelector(".SPbtnshare")));
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("form:nth-child(2) > .btn-sm")));
		wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector("form:nth-child(2) > .btn-sm")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector("form:nth-child(2) > .btn-sm")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.id("btnNoConfirmYesNo")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".biz-job-title")).click();
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".title-controls form:nth-child(2) > .btn-sm")));
		wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".title-controls form:nth-child(2) > .btn-sm")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".title-controls form:nth-child(2) > .btn-sm")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.id("btnYesConfirmYesNo")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".title-controls .btnApplyJob")).click();Thread.sleep(2000);
	    driver.findElement(By.linkText("Back to List")).click();
	    Thread.sleep(2000);
	    
	    /* Delete From Power Share*/
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'My Profile')]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'My Profile')]")));Thread.sleep(2000);
		{
		     WebElement element = driver.findElement(By.xpath("//div[@id='desktopMenu']"));
		     Actions builder = new Actions(driver);
		     builder.moveToElement(element).perform();
		}
		Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//div[contains(text(),'Power Share')])[2]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//div[contains(text(),'Power Share')])[2]")));Thread.sleep(2000);
		driver.findElement(By.xpath("(//div[contains(text(),'Power Share')])[2]")).click();
		Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[normalize-space()='ArtUpload.jpg']")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()='ArtUpload.jpg']")));Thread.sleep(2000);
		driver.findElement(By.xpath("//div[2]/div[1]/div[1]/div[6]/div[1]/div[2]")).click();		
		Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("li .btnDeleteFile")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector("li .btnDeleteFile")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector("li .btnDeleteFile")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("btnYesConfirmYesNo")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.id("btnYesConfirmYesNo")));Thread.sleep(2000);	
	    driver.findElement(By.id("btnYesConfirmYesNo")).click();
		wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".toast-message")));
	    driver.findElement(By.cssSelector(".toast-message")).click();
	    Thread.sleep(2000);		
	    
	    /* Logout from the Power Share page */ 
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'My Profile')]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'My Profile')]")));Thread.sleep(2000);
		driver.findElement(By.xpath("//div[contains(text(),'My Profile')]")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("(//div[contains(text(),'Logout')])[2]")).click();
		Thread.sleep(2000);  
	    	  
	  }
	}
