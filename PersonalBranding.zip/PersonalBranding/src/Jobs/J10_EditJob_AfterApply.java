package Jobs;

import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import screenshotOnFailure.FailScreenshot;

@Listeners(screenshotListners.EventList.class)
public class J10_EditJob_AfterApply extends FailScreenshot{

	@Test
	public void Jobs_EditAfter_Appply() throws InterruptedException {

  		/* Login to the Application - PBC */ 		
	  	driver.findElement(By.xpath("(//button[normalize-space()='Login'])[1]")).click();
  		driver.findElement(By.xpath("//input[@id='Username']")).click();
  		driver.findElement(By.xpath("//input[@id='Username']")).sendKeys("john.doe005");
  		driver.findElement(By.xpath("//input[@id='password-field']")).click();
  		driver.findElement(By.xpath("//input[@id='password-field']")).sendKeys("Rockon123");
  		driver.findElement(By.xpath("//button[@id='loginButton']")).click();
  		Thread.sleep(2000);
  		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(120));
	    
	    /* Naviagte to the Business Page */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[normalize-space()='Business Automati...']")));
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()='Business Automati...']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//span[normalize-space()='Business Automati...']")).click();
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[normalize-space()='Menu']")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()='Menu']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//span[normalize-space()='Menu']")).click();
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//a[normalize-space()='Talent Management'])[1]")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//a[normalize-space()='Talent Management'])[1]")));Thread.sleep(2000);
	    driver.findElement(By.xpath("(//a[normalize-space()='Talent Management'])[1]")).click();
	    Thread.sleep(2000);     
	    
	    /* Public view of Hiring Manager*/
    	String winHandleBefore = driver.getWindowHandle();
	    driver.findElement(By.xpath("(//a[@class='ManagerFullName'][normalize-space()='Inara Cinderella'])[1]")).click();Thread.sleep(2000);
	    for(String winHandle : driver.getWindowHandles()){
	        driver.switchTo().window(winHandle);
	    }
	    Thread.sleep(2000);
    	driver.close();	
    	Thread.sleep(2000);    	
    	driver.switchTo().window(winHandleBefore);
    	Thread.sleep(2000);	    
	    
	    /* Edit and Remove Hiring Manager */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".editJob > span")));
		wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".editJob > span")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".editJob > span")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".btn-blue-link-12:nth-child(10) > span")));
		wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".btn-blue-link-12:nth-child(10) > span")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".btn-blue-link-12:nth-child(10) > span")).click();
	    Thread.sleep(2000);	      
	    driver.findElement(By.id("cross5d10622707b76a57106f7290")).click();Thread.sleep(2000);   
	    driver.findElement(By.cssSelector(".float-right > .btn-sm")).click();Thread.sleep(2000);
	    	   
	    /* Edit Requirements */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@id=\'divReviewRequirements\']/div/form/button")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@id=\'divReviewRequirements\']/div/form/button")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[@id=\'divReviewRequirements\']/div/form/button")).click();Thread.sleep(2000);
	    driver.findElement(By.xpath("//input[@name=\'MustHaveSkills\']")).click();
	    driver.findElement(By.xpath("//input[@name=\'MustHaveSkills\']")).sendKeys("Machine Learning");Thread.sleep(2000);
	    driver.findElement(By.xpath("//input[@name=\'MustHaveSkills\']")).sendKeys(Keys.ENTER);Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".optionalSkillTags #cross-\\ SQL\\ AND\\ C\\+\\+")).click();Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[@id='divReviewEditModal']/div/div/div[2]/div/div/form/div/div[7]/span/button")).click();
	    wait.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath("//div[@id='divReviewEditModal']/div/div/div[2]/div/div/form/div/div[7]/span/button")));Thread.sleep(2000);
	    	   
	    /* Edit Preferences */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@id='divReviewPreference']/div/form/button")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@id='divReviewPreference']/div/form/button")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[@id='divReviewPreference']/div/form/button")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".has-float-label > #Openings")).click();
	    driver.findElement(By.cssSelector(".has-float-label > #Openings")).sendKeys("5");Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".ui-autocomplete-input")).click();
	    driver.findElement(By.cssSelector(".ui-autocomplete-input")).sendKeys("Leadership");Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".ui-autocomplete-input")).sendKeys(Keys.ENTER);Thread.sleep(2000);
	    driver.findElement(By.cssSelector("label > #IsRated")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".float-right > .btn-sm")).click();Thread.sleep(2000);
	    
	    /* Delete Job in Detail View */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".btn-outline-grey")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".btn-outline-grey")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".btn-outline-grey")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.id("btnNoConfirmYesNo")).click();Thread.sleep(2000);
	    
	    /*Share Job */
	    driver.findElement(By.cssSelector(".btn-outline-blue")).click();Thread.sleep(2000);
	    driver.findElement(By.id("ToFollowers")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".SPbtnshare")).click();
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@class='toast-message']")));
	    driver.findElement(By.xpath("//div[@class='toast-message']")).click();
	    Thread.sleep(2000);
	    
	    /* Navigate to the Main View */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".btn > .pb-pointer")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".btn > .pb-pointer")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".btn > .pb-pointer")).click();
	    Thread.sleep(2000);
	    
	    /* Close Job in Main View - No */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[@class='btn-sm btn-outline-grey']//span[contains(text(),'Close')]")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[@class='btn-sm btn-outline-grey']//span[contains(text(),'Close')]")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//button[@class='btn-sm btn-outline-grey']//span[contains(text(),'Close')]")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("btnNoConfirmYesNo")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.id("btnNoConfirmYesNo")));Thread.sleep(2000);
	    driver.findElement(By.id("btnNoConfirmYesNo")).click();Thread.sleep(2000);	    	    
	    	    	    
	    /* Logout */
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'My Profile')]")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'My Profile')]")));Thread.sleep(2000);
		driver.findElement(By.xpath("//div[contains(text(),'My Profile')]")).click();  
		Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//div[contains(text(),'Logout')])[1]")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//div[contains(text(),'Logout')])[1]")));Thread.sleep(2000);
		driver.findElement(By.xpath("(//div[contains(text(),'Logout')])[1]")).click();  
		Thread.sleep(2000);
	  }
	}

