package Jobs;

import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import screenshotOnFailure.FailScreenshot;

@Listeners(screenshotListners.EventList.class)
public class J31_InterviewerMeeting extends FailScreenshot{
	
	@Test
	public void Jobs_Interviewer_Meet() throws InterruptedException {

	/* Login to the Application - PBC */ 		
	driver.findElement(By.xpath("(//button[normalize-space()='Login'])[1]")).click();
	driver.findElement(By.xpath("//input[@id='Username']")).click();
	driver.findElement(By.xpath("//input[@id='Username']")).sendKeys("john.doe004");
	driver.findElement(By.xpath("//input[@id='password-field']")).click();
	driver.findElement(By.xpath("//input[@id='password-field']")).sendKeys("Rockon123");
	driver.findElement(By.xpath("//button[@id='loginButton']")).click();
	Thread.sleep(2000);
	WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(120));
    
    /* Naviagte to the Business Page */
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[normalize-space()='Business Automati...']")));
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()='Business Automati...']")));Thread.sleep(2000);
    driver.findElement(By.xpath("//span[normalize-space()='Business Automati...']")).click();
    Thread.sleep(2000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[normalize-space()='Menu']")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()='Menu']")));Thread.sleep(2000);
    driver.findElement(By.xpath("//span[normalize-space()='Menu']")).click();
    Thread.sleep(2000);
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[normalize-space()='Interview Dashboard']")));
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[normalize-space()='Interview Dashboard']")));Thread.sleep(2000);
    driver.findElement(By.xpath("//a[normalize-space()='Interview Dashboard']")).click();
    Thread.sleep(2000);   
    
    /* View Assessment Report from Applicant Card */
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//b[normalize-space()='(INTJ)']")));	
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//b[normalize-space()='(INTJ)']")));Thread.sleep(2000);
	String winHandleBefore3 = driver.getWindowHandle();Thread.sleep(2000);
    driver.findElement(By.xpath("//b[normalize-space()='(INTJ)']")).click();Thread.sleep(2000);
    for(String winHandle : driver.getWindowHandles()){
    driver.switchTo().window(winHandle);Thread.sleep(2000);
   	}
    	String winHandleBefore31 = driver.getWindowHandle();Thread.sleep(2000);
    	driver.findElement(By.xpath("//span[@title=\'Print Assessment\']")).click();Thread.sleep(2000);
    	for(String winHandle : driver.getWindowHandles()){
        driver.switchTo().window(winHandle);Thread.sleep(2000);
    	}
    	driver.close();Thread.sleep(2000);	    	
    	driver.switchTo().window(winHandleBefore31); 
    	Thread.sleep(2000);
    driver.close();Thread.sleep(2000);	    	
    driver.switchTo().window(winHandleBefore3); 	
    
    /* Click the Job Title Before update */
    String winHandleBefore = driver.getWindowHandle();Thread.sleep(2000);	    
    driver.findElement(By.xpath("(//a[contains(text(),'Penetration Tester')])[1]")).click();Thread.sleep(2000);
    Thread.sleep(2000);
	for(String winHandle : driver.getWindowHandles()){
    driver.switchTo().window(winHandle);Thread.sleep(2000);
	}
	driver.close();Thread.sleep(2000);
	driver.switchTo().window(winHandleBefore);
	Thread.sleep(2000);
	
	 /* Scroll Up the page */
    JavascriptExecutor jse = (JavascriptExecutor)driver;
    jse.executeScript("scroll(0, -250);");	    	    
    Thread.sleep(2000);  
    
    /* Discuss with the HR (schedular) */
    driver.findElement(By.xpath("//span[normalize-space()=\'Discussions\']")).click();
    Thread.sleep(2000);
    driver.findElement(By.id("Message")).click();
    driver.findElement(By.id("Message")).sendKeys("Sure, i will take the Interview on Scheduled time");
    Thread.sleep(2000);
    driver.findElement(By.cssSelector(".titleAttach")).click();Thread.sleep(2000);
    driver.findElement(By.cssSelector(".btnVaultShare > span")).click();
    Thread.sleep(2000);
    driver.findElement(By.cssSelector(".modal-social > .modal-header .fa")).click();
    Thread.sleep(2000);
    driver.findElement(By.xpath("//span[normalize-space()=\'Send\']")).click();
    Thread.sleep(2000);
    driver.findElement(By.xpath("//div[@id=\'getjobdiscussion\']/div/div/div/button/span/i")).click();
    Thread.sleep(2000);
    
    /* Scroll Up the page */
    jse.executeScript("scroll(0, -250);");	    	    
    Thread.sleep(2000);  
    
    /* Notes */
    driver.findElement(By.xpath("//span[normalize-space()=\'Notes\']")).click();
    Thread.sleep(2000);
    driver.findElement(By.id("Message")).click();
    driver.findElement(By.id("Message")).sendKeys("Sure Ahmed, Will go with F2F Interview");
    Thread.sleep(2000);
    driver.findElement(By.cssSelector(".titleAttach")).click();Thread.sleep(2000);
    driver.findElement(By.cssSelector(".btnVaultShare > span")).click();
    Thread.sleep(2000);
    driver.findElement(By.cssSelector(".aspect-ratio-16-9 > img")).click();
    Thread.sleep(2000);
    driver.findElement(By.xpath("//span[normalize-space()=\'ADD FILES\']")).click();
    Thread.sleep(2000);
    driver.findElement(By.xpath("//span[normalize-space()=\'Add Note\']")).click();
    Thread.sleep(2000);
    driver.findElement(By.cssSelector(".registeradmin > .modal-header .fa")).click();
    Thread.sleep(2000);
    
    /* Scroll Up the page */
    jse.executeScript("scroll(0, -250);");	    	    
    Thread.sleep(2000);  
    
    /* All Interviews */
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[normalize-space()='Interview Schedule']")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()='Interview Schedule']")));Thread.sleep(2000);
    driver.findElement(By.xpath("//span[normalize-space()='Interview Schedule']")).click();
    Thread.sleep(2000);
    driver.findElement(By.id("btnAddInterviewer")).click();
    Thread.sleep(2000);
    driver.findElement(By.xpath("//div[4]/div[2]/div/div[5]/span/button/i")).click();
    Thread.sleep(2000);
    driver.findElement(By.cssSelector(".titleAttach")).click();
    Thread.sleep(2000);
    driver.findElement(By.cssSelector(".btnVaultShare > span")).click();
    Thread.sleep(2000);
    driver.findElement(By.cssSelector(".modal-social > .modal-header .fa")).click();
    Thread.sleep(2000);
    driver.findElement(By.xpath("//span[normalize-space()=\'Submit\']")).click();
    Thread.sleep(2000);
    
    /* Scroll Up the page */
    jse.executeScript("scroll(0, -250);");	    	    
    Thread.sleep(2000);  
    
    /* Check the Buttons and links */
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[contains(text(),'ADD FEEDBACK')]")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[contains(text(),'ADD FEEDBACK')]")));Thread.sleep(2000);
    driver.findElement(By.xpath("//span[contains(text(),'ADD FEEDBACK')]")).click();
    Thread.sleep(2000);
    driver.findElement(By.xpath("//span[normalize-space()='Update']")).click();
    Thread.sleep(2000);
    driver.findElement(By.cssSelector(".btnCancelDecision .fa")).click();
    Thread.sleep(2000);
    
    /* Click the Job Title after updation */
    String winHandleBefore1 = driver.getWindowHandle();Thread.sleep(2000);	    
    driver.findElement(By.xpath("(//a[contains(text(),'Penetration Tester')])[1]")).click();Thread.sleep(2000);
    Thread.sleep(2000);
	for(String winHandle : driver.getWindowHandles()){
    driver.switchTo().window(winHandle);Thread.sleep(2000);
	}
	driver.close();Thread.sleep(2000);
	driver.switchTo().window(winHandleBefore1);
	Thread.sleep(2000);
	
	 /* Scroll Up the page */
    jse.executeScript("scroll(0, -250);");	    	    
    Thread.sleep(2000);  
	
	/* Resend DISC Assessment */
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='testShareContainer']//span[contains(text(),'Personality')]")));	
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@class='testShareContainer']//span[contains(text(),'Personality')]")));Thread.sleep(2000);
    driver.findElement(By.xpath("//div[@class='testShareContainer']//span[contains(text(),'Personality')]")).click();
    Thread.sleep(2000);
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("div:nth-child(2) > .d-flex > .fa")));	
    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector("div:nth-child(2) > .d-flex > .fa")));Thread.sleep(2000);
    driver.findElement(By.cssSelector("div:nth-child(2) > .d-flex > .fa")).click();
    Thread.sleep(2000);
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("div:nth-child(2) .resendPersonalityTestBtn")));	
    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector("div:nth-child(2) .resendPersonalityTestBtn")));Thread.sleep(2000);
    driver.findElement(By.cssSelector("div:nth-child(2) .resendPersonalityTestBtn")).click();
    Thread.sleep(2000);
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("div:nth-child(2) > .d-flex > .fa")));	
    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector("div:nth-child(2) > .d-flex > .fa")));Thread.sleep(2000);
    driver.findElement(By.cssSelector("div:nth-child(2) > .d-flex > .fa")).click();
    Thread.sleep(2000);
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".discShowDescription .fa")));	
    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".discShowDescription .fa")));Thread.sleep(2000);
    driver.findElement(By.cssSelector(".discShowDescription .fa")).click();
    Thread.sleep(2000);
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[normalize-space()='Send']")));	
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[normalize-space()='Send']")));Thread.sleep(2000);
    driver.findElement(By.xpath("//button[normalize-space()='Send']")).click();
    Thread.sleep(2000);	   

    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='testShareContainer']//div[@class=\'btn-sm btn-outline-blue technicalTestBtn\']")));	
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@class='testShareContainer']//div[@class=\'btn-sm btn-outline-blue technicalTestBtn\']")));Thread.sleep(2000);
	
    /* Mouse Over on Skills, Phone Icon and Video Resume */
	  {
      WebElement element = driver.findElement(By.cssSelector(".link-tip > .fa"));Thread.sleep(2000); /* Skills */
      Actions builder = new Actions(driver);
      builder.moveToElement(element).perform();
      }
	  Thread.sleep(2000);   
	  {
	  WebElement element = driver.findElement(By.xpath("//div[@class=\'testShareContainer\']//div[@class=\'btn-sm btn-outline-blue personalityTestBtn\']"));Thread.sleep(2000); /* Assessment Button */
      Actions builder = new Actions(driver);
      builder.moveToElement(element).perform();
	  }
	  Thread.sleep(2000);		     	   
	  {
      WebElement element = driver.findElement(By.xpath("//div[@class=\'testShareContainer\']//div[@class=\'btn-sm btn-outline-blue personalityTestBtn\']"));Thread.sleep(2000); /* Assessment Button */
      Actions builder = new Actions(driver);
      builder.moveToElement(element).perform();
	  }
      Thread.sleep(2000);
      {
      WebElement element = driver.findElement(By.xpath("//div[@class=\'contactDetailsIcon\']"));Thread.sleep(2000); /* Phone Mail Icon */
      Actions builder = new Actions(driver);
      builder.moveToElement(element).perform();
      }
      Thread.sleep(2000);  
      
      /* Scroll Up the page */
      jse.executeScript("scroll(0, -250);");	    	    
      Thread.sleep(2000);  
      
      /* Request Technical Assessment */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='testShareContainer']//div[@class='btn-sm btn-outline-blue technicalTestBtn']")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@class='testShareContainer']//div[@class='btn-sm btn-outline-blue technicalTestBtn']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[@class='testShareContainer']//div[@class='btn-sm btn-outline-blue technicalTestBtn']")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".float-right > .btn-outline-grey")));
	    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".float-right > .btn-outline-grey")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".float-right > .btn-outline-grey")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[@class='testShareContainer']//div[@class='btn-sm btn-outline-blue technicalTestBtn']")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".registeradmin > .modal-header .fa")));
	    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".registeradmin > .modal-header .fa")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".registeradmin > .modal-header .fa")).click()
	    ;Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[@class='testShareContainer']//div[@class='btn-sm btn-outline-blue technicalTestBtn']")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".btnCreateAssesment")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".btnCreateAssesment")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".btnCreateAssesment")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//button[normalize-space()='Create New Assessment'])[1]")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//button[normalize-space()='Create New Assessment'])[1]")));Thread.sleep(2000);
	    driver.findElement(By.xpath("(//button[normalize-space()='Create New Assessment'])[1]")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='technical-assessment row']//div[@class='close-img']")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@class='technical-assessment row']//div[@class='close-img']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[@class='technical-assessment row']//div[@class='close-img']")).click();Thread.sleep(2000);
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[normalize-space()='Yes, Cancel']")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[normalize-space()='Yes, Cancel']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//button[normalize-space()='Yes, Cancel']")).click();
	    Thread.sleep(2000);
	    
	    /* Navigate to Manage Interviews from Technical Assessment Page */
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@title='Business Automation']")));	// Business Hub Bavigation
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@title='Business Automation']")));Thread.sleep(2000);
		driver.findElement(By.xpath("//div[@title='Business Automation']")).click();
		Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[normalize-space()='Menu']")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()='Menu']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//span[normalize-space()='Menu']")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[normalize-space()='Interview Dashboard']")));
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[normalize-space()='Interview Dashboard']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//a[normalize-space()='Interview Dashboard']")).click();
	    Thread.sleep(2000);  
	    
	    /* Scroll Up the page */
	    jse.executeScript("scroll(0, -250);");	    	    
	    Thread.sleep(2000);  
	    
    /* Start Meeting and Leave */
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[normalize-space()='Start Meeting']")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[normalize-space()='Start Meeting']")));Thread.sleep(2000);
    driver.findElement(By.xpath("//a[normalize-space()='Start Meeting']")).click();
    Thread.sleep(2000);
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[3]/div/div/div/div/header/button/span[1]/i")));	
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[3]/div/div/div/div/header/button/span[1]/i")));Thread.sleep(2000);
    driver.findElement(By.xpath("//div[3]/div/div/div/div/header/button/span[1]/i")).click();
    Thread.sleep(2000);
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div/div/header/div[1]/div[3]/div[2]/button/span[1]/i")));	
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div/div/header/div[1]/div[3]/div[2]/button/span[1]/i")));Thread.sleep(2000);
    driver.findElement(By.xpath("//div/div/header/div[1]/div[3]/div[2]/button/span[1]/i")).click();
    Thread.sleep(2000);
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[normalize-space()='Leave meeting']")));	
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[normalize-space()='Leave meeting']")));Thread.sleep(2000);
    driver.findElement(By.xpath("//div[normalize-space()='Leave meeting']")).click();
    Thread.sleep(2000);
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[1]/div[1]/div[1]/div[1]/div[1]/button[1]/span[1]")));	
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[1]/div[1]/div[1]/div[1]/div[1]/button[1]/span[1]")));Thread.sleep(2000);
    driver.findElement(By.xpath("//div[1]/div[1]/div[1]/div[1]/div[1]/button[1]/span[1]")).click();
    Thread.sleep(2000);
    
    /* Close the Feedback Modal, which Auto Populated */
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[normalize-space()='Update']")));
  	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()='Update']")));Thread.sleep(2000);
    driver.findElement(By.xpath("//span[normalize-space()='Update']")).click();
    Thread.sleep(2000);
    driver.findElement(By.xpath("//button[@class='close btnCancelDecision']//i[@class='fa fa-times']")).click();
    
    /* Join Meeting and End Meeting */
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[normalize-space()='Join Meeting']")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[normalize-space()='Join Meeting']")));Thread.sleep(2000);
    driver.findElement(By.xpath("//a[normalize-space()='Join Meeting']")).click();
    Thread.sleep(2000);
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[3]/div/div/div/div/header/button/span[1]/i")));	
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[3]/div/div/div/div/header/button/span[1]/i")));Thread.sleep(2000);
    driver.findElement(By.xpath("//div[3]/div/div/div/div/header/button/span[1]/i")).click();
    Thread.sleep(2000);
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div/div/header/div[1]/div[3]/div[2]/button/span[1]/i")));	
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div/div/header/div[1]/div[3]/div[2]/button/span[1]/i")));Thread.sleep(2000);
    driver.findElement(By.xpath("//div/div/header/div[1]/div[3]/div[2]/button/span[1]/i")).click();
    Thread.sleep(2000);
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[normalize-space()='End meeting']")));	
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[normalize-space()='End meeting']")));Thread.sleep(2000);
    driver.findElement(By.xpath("//div[normalize-space()='End meeting']")).click();
    Thread.sleep(2000);
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[normalize-space()='End session for all users']")));	
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[normalize-space()='End session for all users']")));Thread.sleep(2000);
    driver.findElement(By.xpath("//button[normalize-space()='End session for all users']")).click();
    Thread.sleep(2000);
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[normalize-space()='OK']")));	
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()='OK']")));Thread.sleep(2000);
    driver.findElement(By.xpath("//span[normalize-space()='OK']")).click();
    Thread.sleep(2000);  
    
    /* Close the Feedback Modal, which Auto Populated */
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[normalize-space()='Update']")));
  	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()='Update']")));Thread.sleep(2000);
    driver.findElement(By.xpath("//span[normalize-space()='Update']")).click();
    Thread.sleep(2000);
    driver.findElement(By.xpath("//button[@class='close btnCancelDecision']//i[@class='fa fa-times']")).click();
    
    /* Logout */
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'My Profile')]")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'My Profile')]")));Thread.sleep(2000);
	driver.findElement(By.xpath("//div[contains(text(),'My Profile')]")).click();  
	Thread.sleep(2000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//div[contains(text(),'Logout')])[1]")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//div[contains(text(),'Logout')])[1]")));Thread.sleep(2000);
	driver.findElement(By.xpath("(//div[contains(text(),'Logout')])[1]")).click();  
	Thread.sleep(2000);
  }
}

