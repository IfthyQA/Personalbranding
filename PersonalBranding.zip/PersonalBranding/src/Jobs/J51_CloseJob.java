package Jobs;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import screenshotOnFailure.FailScreenshot;

@Listeners(screenshotListners.EventList.class)
public class J51_CloseJob extends FailScreenshot{

	@Test
	public void Jobs_CloseActiveJob() throws InterruptedException {

		/* Login to the Application - PBC */ 		
	  	driver.findElement(By.xpath("(//button[normalize-space()='Login'])[1]")).click();
  		driver.findElement(By.xpath("//input[@id='Username']")).click();
  		driver.findElement(By.xpath("//input[@id='Username']")).sendKeys("john.doe005");
  		driver.findElement(By.xpath("//input[@id='password-field']")).click();
  		driver.findElement(By.xpath("//input[@id='password-field']")).sendKeys("Rockon123");
  		driver.findElement(By.xpath("//button[@id='loginButton']")).click();
  		Thread.sleep(2000);
  		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(120));
	    
	    /* Naviagte to the Business Page */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[normalize-space()='Business Automati...']")));
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()='Business Automati...']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//span[normalize-space()='Business Automati...']")).click();
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[normalize-space()='Menu']")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()='Menu']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//span[normalize-space()='Menu']")).click();
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//a[normalize-space()='Talent Management'])[1]")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//a[normalize-space()='Talent Management'])[1]")));Thread.sleep(2000);
	    driver.findElement(By.xpath("(//a[normalize-space()='Talent Management'])[1]")).click();
	    Thread.sleep(2000);   
	    
	    /* Share and then Close the Jobs */ 
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".btn-outline-grey")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".btn-outline-grey")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".btn-outline-grey")).click();Thread.sleep(2000);
	    driver.findElement(By.id("btnNoConfirmYesNo")).click();Thread.sleep(2000);
	    
	    driver.findElement(By.cssSelector(".col-12 > .btn-sm")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".SPbtnshare")).click();Thread.sleep(2000);
	    driver.findElement(By.id("ToFollowers")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".txtMemberInvite")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".txtMemberInvite")).sendKeys("John Tes");
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='autocompleteSugLoc']")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@class='autocompleteSugLoc']")));
	    driver.findElement(By.xpath("//div[@class='autocompleteSugLoc']")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".SPbtnshare")).click();Thread.sleep(2000);
	    wait.until(ExpectedConditions.invisibilityOfElementLocated(By.cssSelector(".SPbtnshare")));
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".btn-outline-grey")));
	    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".btn-outline-grey")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".btn-outline-grey")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.id("btnYesConfirmYesNo")).click();
		wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".toast-message")));Thread.sleep(2000);
		driver.findElement(By.cssSelector(".toast-message")).click();
		Thread.sleep(2000);
	    
	    /* Re-open the Job and Navigate to Livejobs */
	    {
	        WebElement element = driver.findElement(By.xpath("//div[@id=\'divLeftMenu\']//div[@id=\'closedJobLink\']"));
	        Actions builder = new Actions(driver);
	        builder.doubleClick(element).perform();
	    }
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//span[contains(text(),'Edit')])[1]")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//span[contains(text(),'Edit')])[1]")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector("form > .btn-outline-blue")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@id=\'divReviewEditModal\']/div/div/div[2]/div/div/form/div/div[8]/span/button")));
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@id=\'divReviewEditModal\']/div/div/div[2]/div/div/form/div/div[8]/span/button")));Thread.sleep(2000);	
	    driver.findElement(By.xpath("//div[@id=\'divReviewEditModal\']/div/div/div[2]/div/div/form/div/div[8]/span/button")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".float-right > .btn-outline-blue")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".float-right > .btn-outline-blue")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".float-right > .btn-outline-blue")).click();
		wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".toast-message")));
		driver.findElement(By.cssSelector(".toast-message")).click();
	    Thread.sleep(2000);
	    
	    /* Click Post Another Job from Modal */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//button[normalize-space()='Post Another Job'])[2]")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//button[normalize-space()='Post Another Job'])[2]")));Thread.sleep(2000);
	    driver.findElement(By.xpath("(//button[normalize-space()='Post Another Job'])[2]")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".back-btn")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".back-btn")));
	    driver.findElement(By.cssSelector(".back-btn")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.id("btnYesConfirmYesNo")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".float-right > .btn-outline-blue")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".float-right > .btn-outline-blue")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".float-right > .btn-outline-blue")).click();
		wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".toast-message")));Thread.sleep(2000);
		driver.findElement(By.cssSelector(".toast-message")).click();
		Thread.sleep(2000);
	    
	    /* Again Close the JOB */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//button[normalize-space()='Manage Careers'])[2]")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//button[normalize-space()='Manage Careers'])[2]")));
	    driver.findElement(By.xpath("(//button[normalize-space()='Manage Careers'])[2]")).click();
		Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".btn-blue-link-12")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector("form:nth-child(1) > .btn-lg")).click();Thread.sleep(2000);
	    driver.findElement(By.id("btnYesConfirmYesNo")).click();
		wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".toast-message")));
		driver.findElement(By.cssSelector(".toast-message")).click();
	    Thread.sleep(2000);	    
	    
	    /* Delete the Job -from Closed Job Menu */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//span[contains(text(),'Edit')])[1]")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//span[contains(text(),'Edit')])[1]")));Thread.sleep(2000);
	    {
	        WebElement element = driver.findElement(By.xpath("//div[@id=\'divLeftMenu\']//div[@id=\'closedJobLink\']"));
	        Actions builder = new Actions(driver);
	        builder.doubleClick(element).perform();
	    }
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//span[contains(text(),'Edit')])[1]")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//span[contains(text(),'Edit')])[1]")));Thread.sleep(2000);
	    driver.findElement(By.xpath("(//span[contains(text(),'Edit')])[1]")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".btn-outline-grey")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".btn-outline-grey")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".btn-outline-grey")).click();Thread.sleep(2000);
	    driver.findElement(By.id("btnYesConfirmYesNo")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[contains(.,\'OK\')]")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[contains(.,\'OK\')]")));Thread.sleep(2000);	    
	    driver.findElement(By.xpath("//button[contains(.,\'OK\')]")).click();Thread.sleep(2000);
	    
	    /* Sign Out */
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'My Profile')]")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'My Profile')]")));Thread.sleep(2000);
		driver.findElement(By.xpath("//div[contains(text(),'My Profile')]")).click();  
		Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//div[contains(text(),'Logout')])[1]")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//div[contains(text(),'Logout')])[1]")));Thread.sleep(2000);
		driver.findElement(By.xpath("(//div[contains(text(),'Logout')])[1]")).click();  
		Thread.sleep(2000);
	  }
	}
