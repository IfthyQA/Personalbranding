package Jobs;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import screenshotOnFailure.FailScreenshot;

@Listeners(screenshotListners.EventList.class)
public class J41_SelectCandidate extends FailScreenshot{
	
	@Test
	public void Jobs_Candidate_Selection() throws InterruptedException {

		/* Login to the Application - PBC */ 		
	  	driver.findElement(By.xpath("(//button[normalize-space()='Login'])[1]")).click();
  		driver.findElement(By.xpath("//input[@id='Username']")).click();
  		driver.findElement(By.xpath("//input[@id='Username']")).sendKeys("john.doe005");
  		driver.findElement(By.xpath("//input[@id='password-field']")).click();
  		driver.findElement(By.xpath("//input[@id='password-field']")).sendKeys("Rockon123");
  		driver.findElement(By.xpath("//button[@id='loginButton']")).click();
  		Thread.sleep(2000);
  		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(120));
	    
	    /* Naviagte to the Business Page */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[normalize-space()='Business Automati...']")));
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()='Business Automati...']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//span[normalize-space()='Business Automati...']")).click();
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[normalize-space()='Menu']")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()='Menu']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//span[normalize-space()='Menu']")).click();
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//a[normalize-space()='Talent Management'])[1]")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//a[normalize-space()='Talent Management'])[1]")));Thread.sleep(2000);
	    driver.findElement(By.xpath("(//a[normalize-space()='Talent Management'])[1]")).click();
	    Thread.sleep(2000);   
	    
	    /* Discussions in Manage Careers */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[normalize-space()=\'Discussions\']")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()=\'Discussions\']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//span[normalize-space()=\'Discussions\']")).click();Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("Message")));
	  	wait.until(ExpectedConditions.elementToBeClickable(By.id("Message")));Thread.sleep(2000);
	    driver.findElement(By.id("Message")).click();Thread.sleep(2000);
	    driver.findElement(By.id("Message")).sendKeys("You have cleared all Rounds. lets me check the results and Ping you for final Call.");Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".titleAttach")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".btnVaultShare > span")).click();Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[normalize-space()=\'ADD FILES\']")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()=\'ADD FILES\']")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".aspect-ratio-16-9 > img")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".btn")).click();
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".defaultSubmit")));
		wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".defaultSubmit")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".defaultSubmit")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".modal-lg .text-center .fa")).click();Thread.sleep(2000);
	    	   
	    /* Notes & History */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[normalize-space()=\'Notes\']")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()=\'Notes\']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//span[normalize-space()=\'Notes\']")).click();Thread.sleep(2000);
	    driver.findElement(By.id("Message")).click();Thread.sleep(2000);
	    driver.findElement(By.id("Message")).sendKeys("Thank you Automation for the time you spent for the Interview and Thanks for the your Feedback about the Candidate.");Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".titleAttach")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".btnVaultShare > span")).click();Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[normalize-space()=\'ADD FILES\']")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()=\'ADD FILES\']")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".aspect-ratio-16-9 > img")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".btn")).click();Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".defaultSubmit")));
		wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".defaultSubmit")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".defaultSubmit")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".registeradmin > .modal-header .fa")).click();Thread.sleep(2000);	    	  
	    
	    /* View Feedback of Interviewer from Schedule Interview Modal */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[normalize-space()=\'Interview Schedule\']")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()=\'Interview Schedule\']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//span[normalize-space()=\'Interview Schedule\']")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".btnCancelDecision .fa")).click();Thread.sleep(2000);
	    driver.findElement(By.xpath("//span[normalize-space()=\'Interview Schedule\']")).click();Thread.sleep(2000);
	    driver.findElement(By.xpath("//i[@title=\'View Feedback\']")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".biz-admin-overlay .fa")).click();Thread.sleep(2000);
	    driver.findElement(By.xpath("//span[normalize-space()=\'Submit\']")).click();Thread.sleep(2000);
	    
	    /* All Interviews Completed - LINK */
	    driver.findElement(By.xpath("//span[normalize-space()=\'All interviews completed\']")).click();Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[@class=\'modal-content\']//div[@class=\'modal-header text-center\']//i[@class=\'fa fa-times\']")).click();Thread.sleep(2000);
	    driver.findElement(By.xpath("//span[normalize-space()=\'All interviews completed\']")).click();Thread.sleep(2000);
	    driver.findElement(By.xpath("//span[@class=\'d-none d-md-inline-block\']")).click();Thread.sleep(2000);
	    
	    driver.findElement(By.cssSelector(".biz-admin-overlay .fa")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".btnOK")).click();Thread.sleep(2000);	    
	    
	    /* Assessment DISC Pending - Links*/
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//b[normalize-space()='DISC']")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//b[normalize-space()='DISC']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//b[normalize-space()='DISC']")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[@class='resendPersonalityTestBtn margin-left-10']")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[@class='resendPersonalityTestBtn margin-left-10']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//span[@class='resendPersonalityTestBtn margin-left-10']")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[normalize-space()='Send']")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[normalize-space()='Send']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//button[normalize-space()='Send']")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//b[normalize-space()=\'DISC\']")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//b[normalize-space()=\'DISC\']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//b[normalize-space()=\'DISC\']")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".modal-sm .modal-header .fa")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".modal-sm .modal-header .fa")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".modal-sm .modal-header .fa")).click();Thread.sleep(2000);
	    
	    /* Hold the Candidate from the Dropdown */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//button[contains(.,'Scheduled for Interview')])[1]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//button[contains(.,'Scheduled for Interview')])[1]")));Thread.sleep(2000);
	    driver.findElement(By.xpath("(//button[contains(.,'Scheduled for Interview')])[1]")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("//button[contains(.,'On Hold')]")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".defaultSubmit")));
		wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".defaultSubmit")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".defaultSubmit")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".titleAttach")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".btnVaultShare > span")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[normalize-space()=\'ADD FILES\']")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()=\'ADD FILES\']")));
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".aspect-ratio-16-9 > img")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".btn")).click();Thread.sleep(2000);
	    driver.findElement(By.id("Message")).click();Thread.sleep(2000);
	    driver.findElement(By.id("Message")).sendKeys("Hey Congrats, We are Processing your Application, will update the Result in next 24 Hrs.");
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".defaultSubmit")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".defaultSubmit")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".defaultSubmit")).click();
	    Thread.sleep(2000);
	    
	    /* Select the Candidate from the HOLD Dropdown */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//button[contains(.,'On Hold')])[1]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//button[contains(.,'On Hold')])[1]")));Thread.sleep(2000);
	    driver.findElement(By.xpath("(//button[contains(.,'On Hold')])[1]")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("//button[contains(.,'Selected')]")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("Message")));
	  	wait.until(ExpectedConditions.elementToBeClickable(By.id("Message")));Thread.sleep(2000);
	    driver.findElement(By.id("Message")).click();Thread.sleep(2000);
	    driver.findElement(By.id("Message")).sendKeys("Hey Congrats, you have cleared Interview.");
	    driver.findElement(By.cssSelector(".titleAttach")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".btnVaultShare > span")).click();Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[normalize-space()=\'ADD FILES\']")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()=\'ADD FILES\']")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".btn")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".aspect-ratio-16-9 > img")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".btn")).click();Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[contains(text(),'Confirm Select')]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[contains(text(),'Confirm Select')]")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//span[contains(text(),'Confirm Select')]")).click();Thread.sleep(2000);
	    wait.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath("//span[contains(text(),'Confirm Select')]")));
	    
	    /* Logout */
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'My Profile')]")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'My Profile')]")));Thread.sleep(2000);
		driver.findElement(By.xpath("//div[contains(text(),'My Profile')]")).click();  
		Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//div[contains(text(),'Logout')])[1]")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//div[contains(text(),'Logout')])[1]")));Thread.sleep(2000);
		driver.findElement(By.xpath("(//div[contains(text(),'Logout')])[1]")).click();  
		Thread.sleep(2000);
	  }
	}