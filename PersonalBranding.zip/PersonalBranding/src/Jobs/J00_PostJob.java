package Jobs;

import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import screenshotOnFailure.FailScreenshot;

@Listeners(screenshotListners.EventList.class)
public class J00_PostJob extends FailScreenshot{
	
	@Test
	public void Jobs_Post() throws InterruptedException {

  		/* Login to the Application - PBC */ 		
	  	driver.findElement(By.xpath("(//button[normalize-space()='Login'])[1]")).click();
  		driver.findElement(By.xpath("//input[@id='Username']")).click();
  		driver.findElement(By.xpath("//input[@id='Username']")).sendKeys("john.doe005");
  		driver.findElement(By.xpath("//input[@id='password-field']")).click();
  		driver.findElement(By.xpath("//input[@id='password-field']")).sendKeys("Rockon123");
  		driver.findElement(By.xpath("//button[@id='loginButton']")).click();
  		Thread.sleep(2000);
  		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(120));
	    
	    /* Naviagte to the Business Page */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[normalize-space()='Business Automati...']")));
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()='Business Automati...']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//span[normalize-space()='Business Automati...']")).click();
	    Thread.sleep(2000);   
	    
	    /* Post Job from Hub */ 
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[normalize-space()='Menu']")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()='Menu']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//span[normalize-space()='Menu']")).click();
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//a[normalize-space()='Talent Management'])[1]")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//a[normalize-space()='Talent Management'])[1]")));Thread.sleep(2000);
	    driver.findElement(By.xpath("(//a[normalize-space()='Talent Management'])[1]")).click();
	    Thread.sleep(2000);   
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("form > .btn-sm")));
	    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector("form > .btn-sm")));Thread.sleep(2000);	 
	    driver.findElement(By.cssSelector("form > .btn-sm")).click();
	    Thread.sleep(2000);	    
	    
	    /* Select Team */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("select2-GroupSoidModal-container")));
	    wait.until(ExpectedConditions.elementToBeClickable(By.id("select2-GroupSoidModal-container")));Thread.sleep(2000);
	    driver.findElement(By.id("select2-GroupSoidModal-container")).click();Thread.sleep(2000);	 
	    driver.findElement(By.cssSelector(".select2-search__field")).sendKeys("recruit");
	    driver.findElement(By.cssSelector(".select2-search__field")).sendKeys(Keys.ENTER);Thread.sleep(2000);	 
	    
	    /* Select - Remove - Add Hiring Manager   */
	    driver.findElement(By.cssSelector("label:nth-child(2)")).click();Thread.sleep(2000);	
	    driver.findElement(By.xpath("//*[@id=\"fullcontainer\"]/div/div[3]/form/div/div[3]/div[2]/div/input")).sendKeys("inara");Thread.sleep(2000);	
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".autocompleteSugLoc:nth-child(3)")));
	    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".autocompleteSugLoc:nth-child(3)")));Thread.sleep(2000);	
	    driver.findElement(By.cssSelector(".autocompleteSugLoc:nth-child(3)")).click();Thread.sleep(2000);
	    driver.findElement(By.id("cross5e95372a92e0f8d76ce99e84")).click();Thread.sleep(2000);	
	    driver.findElement(By.cssSelector(".back-btn")).click();Thread.sleep(2000);	
	    driver.findElement(By.id("btnNoConfirmYesNo")).click();Thread.sleep(2000);	
	    driver.findElement(By.cssSelector("label:nth-child(2)")).click();Thread.sleep(2000);	
	    driver.findElement(By.xpath("//*[@id=\"fullcontainer\"]/div/div[3]/form/div/div[3]/div[2]/div/input")).sendKeys("inara");
	    Thread.sleep(2000);	
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".autocompleteSugLoc:nth-child(3)")));
	    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".autocompleteSugLoc:nth-child(3)")));Thread.sleep(2000);	
	    driver.findElement(By.cssSelector(".autocompleteSugLoc:nth-child(3)")).click();Thread.sleep(2000);	
	    driver.findElement(By.cssSelector(".next-btn")).click();
	    Thread.sleep(2000);	
	    
	    /* Job Title and Basic Details*/
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("Title")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.id("Title")));Thread.sleep(2000);
	    driver.findElement(By.id("Title")).click();Thread.sleep(2000);
	    driver.findElement(By.id("Title")).sendKeys(Keys.ENTER);Thread.sleep(2000);
	    driver.findElement(By.id("Title")).click();Thread.sleep(2000);
	    driver.findElement(By.id("Title")).sendKeys("123456789abcdefghijklmnopqrstuvwxyz12345678ABCDEFGI");
	    Thread.sleep(2000);
	    driver.findElement(By.id("Title")).clear();
	    driver.findElement(By.id("Title")).sendKeys("!@#$%^&*()_+/*-+?><:;Thread.sleep(2000);\'{}[]|\\");
	    Thread.sleep(2000);
	    driver.findElement(By.id("Title")).clear();
	    driver.findElement(By.id("Title")).sendKeys("Penetration");Thread.sleep(2000);	
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//form/div/div/div/ul/li/div")));
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//form/div/div/div/ul/li/div")));Thread.sleep(2000);	
	    driver.findElement(By.xpath("//form/div/div/div/ul/li/div")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.id("select2-WorkTypeJob-container")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".select2-search__field")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".select2-search__field")).sendKeys("full");Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".select2-search__field")).sendKeys(Keys.ENTER);
	    Thread.sleep(2000);
	    driver.findElement(By.id("Salary")).click();Thread.sleep(2000);
	    driver.findElement(By.id("Salary")).sendKeys("Seven Lacs per annum and best in IT Industry. Okays...");
	    Thread.sleep(2000);
	    driver.findElement(By.id("Salary")).clear();
	    driver.findElement(By.id("Salary")).sendKeys("1234567890123456789012345678901234567890123456789012345678901");Thread.sleep(2000);
	    driver.findElement(By.id("Salary")).clear();
	    driver.findElement(By.id("Salary")).sendKeys("700000 PA");Thread.sleep(2000);
	    driver.findElement(By.id("Salary")).clear();
	    driver.findElement(By.id("Salary")).sendKeys("700000.00/- PA");Thread.sleep(2000);
	      {
	        WebElement element = driver.findElement(By.cssSelector(".next-btn"));
	        Actions builder = new Actions(driver);
	        builder.doubleClick(element).perform();
	      }	      
	    
	    /* Job Descriptions */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".mce-i-numlist")));
	    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".mce-i-numlist")));Thread.sleep(2000);	
	    driver.findElement(By.cssSelector(".mce-i-numlist")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".mce-i-bold")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".next-btn")).click();
	    Thread.sleep(2000);
	    
	    /* Add Skills */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@name=\'MustHaveSkills\']")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@name=\'MustHaveSkills\']")));Thread.sleep(2000);	
	    
	    driver.findElement(By.cssSelector(".next-btn")).click();Thread.sleep(2000);
	    driver.findElement(By.xpath("//input[@name=\'MustHaveSkills\']")).click();Thread.sleep(2000);
	    driver.findElement(By.xpath("//input[@name=\'MustHaveSkills\']")).sendKeys("Coded UI");
	    driver.findElement(By.xpath("//input[@name=\'MustHaveSkills\']")).sendKeys(Keys.ENTER);Thread.sleep(2000);
	    driver.findElement(By.id("MinExperience")).click();Thread.sleep(2000);
	    driver.findElement(By.xpath("//label[normalize-space()=\'Good-To-Have Skills\']")).click();Thread.sleep(2000);
	    driver.findElement(By.xpath("(//input[@name=\'OptionalSkills\'])[2]")).sendKeys("Security Frameworks");Thread.sleep(2000);
	    driver.findElement(By.xpath("(//input[@name=\'OptionalSkills\'])[2]")).sendKeys(Keys.ENTER);Thread.sleep(2000);
	    driver.findElement(By.xpath("(//input[@name=\'OptionalSkills\'])[2]")).sendKeys("Linux and Unix");Thread.sleep(2000);
	    driver.findElement(By.xpath("(//input[@name=\'OptionalSkills\'])[2]")).sendKeys(Keys.ENTER);Thread.sleep(2000);
	    driver.findElement(By.xpath("(//input[@name=\'OptionalSkills\'])[2]")).sendKeys("Ruby and Python");Thread.sleep(2000);
	    driver.findElement(By.xpath("(//input[@name=\'OptionalSkills\'])[2]")).sendKeys(Keys.ENTER);Thread.sleep(2000);
	    driver.findElement(By.xpath("(//input[@name=\'OptionalSkills\'])[2]")).sendKeys("SQL and C++");Thread.sleep(2000);
	    driver.findElement(By.xpath("(//input[@name=\'OptionalSkills\'])[2]")).sendKeys(Keys.ENTER);Thread.sleep(2000);
	    driver.findElement(By.id("MinExperience")).click();Thread.sleep(2000);
	    driver.findElement(By.id("MinExperience")).sendKeys("99");Thread.sleep(2000);
	    driver.findElement(By.id("MinExperience")).clear();
	    driver.findElement(By.id("MinExperience")).sendKeys("2");Thread.sleep(2000);
	    driver.findElement(By.id("MaxExperience")).click();Thread.sleep(2000);
	    driver.findElement(By.id("MaxExperience")).sendKeys("88");Thread.sleep(2000);
	    driver.findElement(By.id("MaxExperience")).clear();
	    driver.findElement(By.id("MaxExperience")).sendKeys("4");Thread.sleep(2000);
	    driver.findElement(By.id("select2-Education-container")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".select2-search__field")).sendKeys("bach");Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".select2-search__field")).sendKeys(Keys.ENTER);
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".next-btn")));
	    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".next-btn")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".next-btn")).click();
	    Thread.sleep(2000);	    
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".back-btn")));
	    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".back-btn")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".back-btn")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".next-btn")));
	    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".next-btn")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".next-btn")).click();	
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".next-btn")));
	    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".next-btn")));Thread.sleep(2000);	
	    driver.findElement(By.cssSelector(".next-btn")).click();	    
	    
	    /* Change Team and Hiring Manager */
	    /* Change from Recruit to PAGE ADMIN Team */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".col-md-6 .form-inline span")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".col-md-6 .form-inline span")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".col-md-6 .form-inline span")).click();
	    Thread.sleep(2000);	 
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("select2-GroupSoidModal-container")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.id("select2-GroupSoidModal-container")));Thread.sleep(2000);
	    driver.findElement(By.id("select2-GroupSoidModal-container")).click();Thread.sleep(2000);	 
	    driver.findElement(By.cssSelector(".select2-search__field")).sendKeys("admin");Thread.sleep(2000);	 
	    driver.findElement(By.cssSelector(".select2-search__field")).sendKeys(Keys.ENTER);
	    Thread.sleep(2000);	 
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".btn-outline-maroon")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".btn-outline-maroon")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".btn-outline-maroon")).click();
	    Thread.sleep(2000);	 
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.name("Hiring Manager")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.name("Hiring Manager")));Thread.sleep(2000);
	    driver.findElement(By.name("Hiring Manager")).click();Thread.sleep(2000);	 
	    driver.findElement(By.name("Hiring Manager")).sendKeys("inara");
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".autocompleteSugLoc:nth-child(3)")));
	    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".autocompleteSugLoc:nth-child(3)")));Thread.sleep(2000);	
	    driver.findElement(By.cssSelector(".autocompleteSugLoc:nth-child(3)")).click();
	    Thread.sleep(2000);	 
	    driver.findElement(By.name("Hiring Manager")).sendKeys("ilhan");
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".autocompleteSugLoc:nth-child(3)")));
	    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".autocompleteSugLoc:nth-child(3)")));Thread.sleep(3000);	 
	    driver.findElement(By.cssSelector(".autocompleteSugLoc:nth-child(3)")).click();
	    Thread.sleep(2000);	 
	    driver.findElement(By.cssSelector(".float-right > .btn-sm")).click();
	    Thread.sleep(2000);		    
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".float-right:nth-child(2) > .btn-outline-blue")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".float-right:nth-child(2) > .btn-outline-blue")));Thread.sleep(2000);
	    WebElement ele = driver.findElement(By.cssSelector(".float-right:nth-child(2) > .btn-outline-blue"));
	    JavascriptExecutor jse = (JavascriptExecutor)driver;
		jse.executeScript("arguments[0].click()", ele);	
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".d-none .btn-blue")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".d-none .btn-blue")));Thread.sleep(2000); 
	    WebElement ele1 =  driver.findElement(By.cssSelector(".d-none .btn-blue"));
		jse.executeScript("arguments[0].click()", ele1);
	    Thread.sleep(2000);	
	    
	    /* Logout */
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'My Profile')]")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'My Profile')]")));Thread.sleep(2000);
		driver.findElement(By.xpath("//div[contains(text(),'My Profile')]")).click();  
		Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//div[contains(text(),'Logout')])[1]")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//div[contains(text(),'Logout')])[1]")));Thread.sleep(2000);
		driver.findElement(By.xpath("(//div[contains(text(),'Logout')])[1]")).click();  
		Thread.sleep(2000);
	  }
	}

