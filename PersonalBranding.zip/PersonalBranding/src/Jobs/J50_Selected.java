package Jobs;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import screenshotOnFailure.FailScreenshot;

@Listeners(screenshotListners.EventList.class)
public class J50_Selected extends FailScreenshot{
	
	@Test
	public void Jobs_SelectedMenu() throws InterruptedException {

		/* Login to the Application - PBC */ 		
	  	driver.findElement(By.xpath("(//button[normalize-space()='Login'])[1]")).click();
		driver.findElement(By.xpath("//input[@id='Username']")).click();
		driver.findElement(By.xpath("//input[@id='Username']")).sendKeys("john.doe002");
		driver.findElement(By.xpath("//input[@id='password-field']")).click();
		driver.findElement(By.xpath("//input[@id='password-field']")).sendKeys("Rockon123");
		driver.findElement(By.xpath("//button[@id='loginButton']")).click();
		Thread.sleep(2000);
		 WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(120));
		 
		/* Navigate to the Job Opportunity Page */
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'My Profile')]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'My Profile')]")));
		Thread.sleep(2000);
		{
		     WebElement element = driver.findElement(By.xpath("//div[@class='menu-item menu-item-active']"));
		     Actions builder = new Actions(driver);
		     builder.moveToElement(element).perform();
		}
		Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='menu-label ml-1'][normalize-space()='Jobs']")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@class='menu-label ml-1'][normalize-space()='Jobs']")));Thread.sleep(2000);
		driver.findElement(By.xpath("//div[@class='menu-label ml-1'][normalize-space()='Jobs']")).click();
		Thread.sleep(2000);	 
		
	    /* Share the Job from Selected menu */
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='menu-list']//div[5]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@class='menu-list']//div[5]")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[@class='menu-list']//div[5]")).click();
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".btn-blue-link-14 > .fa")));
		wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".btn-blue-link-14 > .fa")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".btn-blue-link-14 > .fa")).click();
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".SPbtnshare")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".SPbtnshare")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".form-group > label")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".txtMemberInvite")).sendKeys("sudhir@tescraa.com");Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".txtMemberInvite")).sendKeys(Keys.ENTER);Thread.sleep(2000);
		wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".SPbtnshare")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".SPbtnshare")).click();
	    wait.until(ExpectedConditions.invisibilityOfElementLocated(By.cssSelector(".SPbtnshare")));Thread.sleep(2000);
	    
	    /* Discussions from Selected Menu */
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".biz-discussion-link")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".biz-discussion-link")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".biz-discussion-link")).click();
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[contains(.,\'Send\')]")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[contains(.,\'Send\')]")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//button[contains(.,\'Send\')]")).click();
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".biz-discussion-link")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".biz-discussion-link")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".biz-discussion-link")).click();
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".btnCancelDiscussion")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".btnCancelDiscussion")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".btnCancelDiscussion")).click();
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".biz-discussion-link")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".biz-discussion-link")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".biz-discussion-link")).click();
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".bp-back-link")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".bp-back-link")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".bp-back-link")).click();
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".biz-discussion-link")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".biz-discussion-link")));Thread.sleep(2000);	    
	    driver.findElement(By.cssSelector(".biz-discussion-link")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.id("Message")).click();Thread.sleep(2000);
	    driver.findElement(By.id("Message")).sendKeys("Thanks for the Selection");Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".btnCancelDiscussion")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".biz-discussion-link")).click();Thread.sleep(2000);
	    
	    /* Click Job - Hyper Link from Discussion View */
	    	String winHandleBefore = driver.getWindowHandle();Thread.sleep(2000);
	    	driver.findElement(By.xpath("//div[3]/div[1]/div[3]/div[2]/div[1]/div[3]/a[2]/span[1]")).click();Thread.sleep(2000);
		    Thread.sleep(2000);// Navigate to New window
	    	for(String winHandle : driver.getWindowHandles()){
	        driver.switchTo().window(winHandle);Thread.sleep(2000);
	    	}
	    	Thread.sleep(2000);
		    driver.findElement(By.cssSelector(".title-controls .btn-sm")).click();Thread.sleep(2000);
		    
		    /* Share a Job From Public View */
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".SPbtnshare")));	
			wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".SPbtnshare")));	
		    driver.findElement(By.cssSelector(".SPbtnshare")).click();Thread.sleep(2000);
		    driver.findElement(By.cssSelector("label")).click();Thread.sleep(2000);
		    driver.findElement(By.xpath("//form[@id=\'formSelectedContacts\']/div/div[2]/div/input")).click();Thread.sleep(2000);
		    driver.findElement(By.xpath("//form[@id=\'formSelectedContacts\']/div/div[2]/div/input")).sendKeys("Ahmed");Thread.sleep(2000);
		    driver.findElement(By.cssSelector("#ui-id-2 .autocompleteSugLoc")).click();Thread.sleep(2000);
		    driver.findElement(By.id("ToFollowers")).click();Thread.sleep(2000);
			wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".SPbtnshare")));Thread.sleep(2000);
		    driver.findElement(By.cssSelector(".SPbtnshare")).click();Thread.sleep(2000);
		    
		    /* Click All the Buttons on the Public Views */
		    driver.findElement(By.linkText("Back to List")).click();Thread.sleep(2000);
		    driver.findElement(By.linkText("Penetration Tester")).click();Thread.sleep(2000);
		    driver.findElement(By.linkText("HOME")).click();Thread.sleep(2000);
		    driver.findElement(By.linkText("TEAM")).click();Thread.sleep(2000);
		    driver.findElement(By.linkText("CAREERS")).click();Thread.sleep(2000);
		    driver.close();Thread.sleep(2000);
		    driver.switchTo().window(winHandleBefore);Thread.sleep(2000);
		    
	    driver.findElement(By.id("Message")).click();Thread.sleep(2000);
	    driver.findElement(By.id("Message")).sendKeys("Thanks for selection, i was eagerly waiting for the Opportunity");Thread.sleep(2000);
	    driver.findElement(By.xpath("//button[contains(.,\'Send\')]")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".btnCancelDiscussion")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".bp-back-link")).click();Thread.sleep(2000);
	    
	    /* Selected Menu */
	    driver.findElement(By.xpath("//div[@class='menu-list']//div[5]")).click();Thread.sleep(2000);
	    driver.findElement(By.linkText("Penetration Tester")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".title-controls .btn-sm")).click();Thread.sleep(2000);
		wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".SPbtnshare")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".SPbtnshare")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".txtMemberInvite")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".txtMemberInvite")).sendKeys("priya@achnet.com");Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".txtMemberInvite")).sendKeys(Keys.ENTER);Thread.sleep(2000);
		wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".SPbtnshare")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".SPbtnshare")).click();Thread.sleep(2000);
	    wait.until(ExpectedConditions.stalenessOf(driver.findElement(By.xpath("//div[@class=\'toast-message\']"))));
	    driver.findElement(By.cssSelector(".btn-blue-link-14 > span")).click();Thread.sleep(2000);
	    
	    /* Discussion Again from Selected Menu */
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".biz-discussion-link")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".biz-discussion-link")));Thread.sleep(2000);	
	    driver.findElement(By.cssSelector(".biz-discussion-link")).click();
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.elementToBeClickable(By.id("Message")));
	    driver.findElement(By.id("Message")).click();Thread.sleep(2000);
	    driver.findElement(By.id("Message")).sendKeys("Thank You Sir.");
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".btnCancelDiscussion")));Thread.sleep(2000);	
	    driver.findElement(By.cssSelector(".btnCancelDiscussion")).click();
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".biz-discussion-link")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".biz-discussion-link")));
	    driver.findElement(By.cssSelector(".biz-discussion-link")).click();
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[@class=\'titleAttach\']")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[@class=\'titleAttach\']")));
	    driver.findElement(By.xpath("//span[@class=\'titleAttach\']")).click();
	    Thread.sleep(2000);	 
	    driver.findElement(By.xpath("//button[@type=\'button\']//span[contains(text(),\'Power Share\')]")).click();
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[contains(.,\'ADD FILES\')]")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[contains(.,\'ADD FILES\')]")));
	    driver.findElement(By.xpath("//span[contains(.,\'ADD FILES\')]")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".aspect-ratio-16-9 > img")).click();
	    Thread.sleep(2000);	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[contains(.,\'ADD FILES\')]")));
	    driver.findElement(By.xpath("//span[contains(.,\'ADD FILES\')]")).click();
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.elementToBeClickable(By.id("Message")));
	    driver.findElement(By.id("Message")).click();Thread.sleep(2000);
	    driver.findElement(By.id("Message")).sendKeys("Thank you so much for the Opportunity given to me, PFA of my Educational Docx");
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[contains(.,\'Send\')]")));
	    driver.findElement(By.xpath("//button[contains(.,\'Send\')]")).click();Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[@class='menu-list']//div[5]")).click();Thread.sleep(2000);	   	   
	    
	    /* Logout */
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'My Profile')]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'My Profile')]")));Thread.sleep(2000);
		driver.findElement(By.xpath("//div[contains(text(),'My Profile')]")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("(//div[contains(text(),'Logout')])[2]")).click();
		Thread.sleep(2000);
	  }
	}

