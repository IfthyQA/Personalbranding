package Jobs;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import screenshotOnFailure.FailScreenshot;

@Listeners(screenshotListners.EventList.class)
public class J52_PostLaterJob extends FailScreenshot{

	@Test
	public void Jobs_PostLater() throws InterruptedException {

		/* Login to the Application - PBC */ 		
	  	driver.findElement(By.xpath("(//button[normalize-space()='Login'])[1]")).click();
  		driver.findElement(By.xpath("//input[@id='Username']")).click();
  		driver.findElement(By.xpath("//input[@id='Username']")).sendKeys("john.doe005");
  		driver.findElement(By.xpath("//input[@id='password-field']")).click();
  		driver.findElement(By.xpath("//input[@id='password-field']")).sendKeys("Rockon123");
  		driver.findElement(By.xpath("//button[@id='loginButton']")).click();
  		Thread.sleep(2000);
  		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(120));
	    
	    /* Naviagte to the Business Page */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[normalize-space()='Business Automati...']")));
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()='Business Automati...']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//span[normalize-space()='Business Automati...']")).click();
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[normalize-space()='Menu']")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()='Menu']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//span[normalize-space()='Menu']")).click();
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//a[normalize-space()='Talent Management'])[1]")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//a[normalize-space()='Talent Management'])[1]")));Thread.sleep(2000);
	    driver.findElement(By.xpath("(//a[normalize-space()='Talent Management'])[1]")).click();
	    Thread.sleep(2000);   
	    	   	    
	    /* Post Later Job - Select Team and Manager */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[contains(text(),\'Post A Job\')]")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[contains(text(),\'Post A Job\')]")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//button[contains(text(),\'Post A Job\')]")).click();Thread.sleep(2000);
	    driver.findElement(By.id("select2-GroupSoidModal-container")).click();Thread.sleep(2000);	
	    driver.findElement(By.cssSelector(".select2-search__field")).sendKeys("001");Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".select2-search__field")).sendKeys(Keys.ENTER);Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".next-btn")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector("label:nth-child(2)")).click();
	    Thread.sleep(2000);	
	    driver.findElement(By.xpath("//*[@id=\"fullcontainer\"]/div/div[3]/form/div/div[3]/div[2]/div/input")).sendKeys("inara");
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".autocompleteSugLoc:nth-child(3)")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".autocompleteSugLoc:nth-child(3)")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".autocompleteSugLoc:nth-child(3)")).click();Thread.sleep(2000);	
	    driver.findElement(By.cssSelector(".next-btn")).click();
	    Thread.sleep(2000);
	    
	    /* Job Basic Details */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("Title")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.id("Title")));Thread.sleep(2000);
	    driver.findElement(By.id("Title")).click();Thread.sleep(2000);
	    driver.findElement(By.id("Title")).clear();Thread.sleep(2000);
	    driver.findElement(By.id("Title")).sendKeys("Automation Tester");Thread.sleep(2000);
	    driver.findElement(By.id("Salary")).click();Thread.sleep(2000);
	    driver.findElement(By.id("Salary")).sendKeys("600000");Thread.sleep(2000);
	    
	    /* Part Time Job */
	    driver.findElement(By.id("select2-WorkTypeJob-container")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".select2-search__field")).sendKeys("Par");Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".select2-search__field")).sendKeys(Keys.ENTER);Thread.sleep(2000);
	    
	    /* Start and End Date for Part Time Job */
	    driver.findElement(By.id("StartDate")).click();Thread.sleep(2000); 
	    driver.findElement(By.xpath("(//span[@class='year'])[3]")).click();Thread.sleep(2000); // Choose next year
	    driver.findElement(By.cssSelector(".month:nth-child(3)")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector("tr:nth-child(2) > .day:nth-child(3)")).click();Thread.sleep(2000);
	    driver.findElement(By.id("EndDate")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("(//span[@class='year'])[2]")).click();Thread.sleep(2000); // Choose next year
	    driver.findElement(By.cssSelector(".month:nth-child(11)")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector("tr:nth-child(2) > .day:nth-child(5)")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".next-btn")).click();Thread.sleep(2000);
	    
	    /* Job Descriptions */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".mce-i-numlist")));
	    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".mce-i-numlist")));Thread.sleep(2000);	
	    driver.findElement(By.cssSelector(".mce-i-numlist")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".mce-i-bold")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".next-btn")).click();
	    Thread.sleep(2000);
	    Thread.sleep(2000);
	    
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@name=\'MustHaveSkills\']")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@name=\'MustHaveSkills\']")));
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("//input[@name=\'MustHaveSkills\']")).click();Thread.sleep(2000);
	    driver.findElement(By.xpath("//input[@name=\'MustHaveSkills\']")).sendKeys("Artificial Intelligence");
	    driver.findElement(By.xpath("//input[@name=\'MustHaveSkills\']")).sendKeys(Keys.ENTER);Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".col-6:nth-child(1) label")).click();Thread.sleep(2000);
	    driver.findElement(By.id("MinExperience")).sendKeys("2");Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".col-6:nth-child(2) label")).click();Thread.sleep(2000);
	    driver.findElement(By.id("MaxExperience")).sendKeys("4");
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("//b[@role='presentation']")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".select2-search__field")).sendKeys("mas");Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".select2-search__field")).sendKeys(Keys.ENTER);Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".next-btn")).click();
	    Thread.sleep(2000);
	    
	    /* Post Later Date */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("chkPostDate")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.id("chkPostDate")));Thread.sleep(2000);
	    driver.findElement(By.id("chkPostDate")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector("#divLiveDate label")).click();Thread.sleep(2000);
	    driver.findElement(By.xpath("//span[@class='year']")).click();Thread.sleep(2000); // Always select next year
	    driver.findElement(By.cssSelector(".month:nth-child(3)")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector("tr:nth-child(3) > .day:nth-child(3)")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".ui-autocomplete-input")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".ui-autocomplete-input")).sendKeys("Numpy");Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".ui-autocomplete-input")).sendKeys(Keys.ENTER);Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".next-btn")).click();Thread.sleep(2000);
	    
	    /* Expiry Date */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("#divExpireDate .fa")));
	  	wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector("#divExpireDate .fa")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector("#divExpireDate .fa")).click();Thread.sleep(2000);
	    driver.findElement(By.xpath("(//span[@class='year'])[1]")).click();Thread.sleep(2000); // Always select next year
	    driver.findElement(By.cssSelector(".month:nth-child(10)")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector("tr:nth-child(2) > .day:nth-child(5)")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".next-btn")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".float-right > .btn-outline-blue")));
	  	wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".float-right > .btn-outline-blue")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".float-right > .btn-outline-blue")).click();
		wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".toast-message")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".toast-message")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".d-none .btn-blue")));
	  	wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".d-none .btn-blue")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".d-none .btn-blue")).click();Thread.sleep(2000);
	    
	    /* Post the Job from Post Later Menu */
	    {
	        WebElement element = driver.findElement(By.cssSelector("#postlaterJobLink > span"));
	        Actions builder = new Actions(driver);
	        builder.doubleClick(element).perform();
	    }
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("form > .btn-outline-blue")));
	  	wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector("form > .btn-outline-blue")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector("form > .btn-outline-blue")).click();Thread.sleep(2000);
	    driver.findElement(By.id("btnYesConfirmYesNo")).click();
	    Thread.sleep(2000);
	    
	    /* Sign Out */
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'My Profile')]")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'My Profile')]")));Thread.sleep(2000);
		driver.findElement(By.xpath("//div[contains(text(),'My Profile')]")).click();  
		Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//div[contains(text(),'Logout')])[1]")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//div[contains(text(),'Logout')])[1]")));Thread.sleep(2000);
		driver.findElement(By.xpath("(//div[contains(text(),'Logout')])[1]")).click();  
		Thread.sleep(2000);
	  }
	}
