package Jobs;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import screenshotOnFailure.FailScreenshot;

@Listeners(screenshotListners.EventList.class)
public class J61_DeleteJob extends FailScreenshot{
	
	@Test
	public void Jobs_Delete() throws InterruptedException {

		/* Login to the Application - PBC */ 		
	  	driver.findElement(By.xpath("(//button[normalize-space()='Login'])[1]")).click();
  		driver.findElement(By.xpath("//input[@id='Username']")).click();
  		driver.findElement(By.xpath("//input[@id='Username']")).sendKeys("john.doe005");
  		driver.findElement(By.xpath("//input[@id='password-field']")).click();
  		driver.findElement(By.xpath("//input[@id='password-field']")).sendKeys("Rockon123");
  		driver.findElement(By.xpath("//button[@id='loginButton']")).click();
  		Thread.sleep(2000);
  		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(120));
	    
	    /* Naviagte to the Business Page */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[normalize-space()='Business Automati...']")));
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()='Business Automati...']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//span[normalize-space()='Business Automati...']")).click();
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[normalize-space()='Menu']")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()='Menu']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//span[normalize-space()='Menu']")).click();
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//a[normalize-space()='Talent Management'])[1]")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//a[normalize-space()='Talent Management'])[1]")));Thread.sleep(2000);
	    driver.findElement(By.xpath("(//a[normalize-space()='Talent Management'])[1]")).click();
	    Thread.sleep(2000);   
	  	wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("form > .btn-sm")));
	  	wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector("form > .btn-sm")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector("form > .btn-sm")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".back-btn")));
	  	wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".back-btn")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".back-btn")).click();Thread.sleep(2000);
	    driver.findElement(By.id("btnYesConfirmYesNo")).click();Thread.sleep(2000);
	    
	    /* Sort the Team */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("select2-GroupSoid-container")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.id("select2-GroupSoid-container")));Thread.sleep(2000);
	    driver.findElement(By.id("select2-GroupSoid-container")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".select2-search__field")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".select2-search__field")).sendKeys("001");
	    driver.findElement(By.cssSelector(".select2-search__field")).sendKeys(Keys.ENTER);
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".btn-outline-grey")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".btn-outline-grey")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".btn-outline-grey")).click();Thread.sleep(2000);
	    driver.findElement(By.id("btnNoConfirmYesNo")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".col-12 > .btn-sm")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".SPbtnshare")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".SPcontent > .modal-header .fa")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".btn-outline-grey")).click();Thread.sleep(2000);
	    driver.findElement(By.id("btnNoConfirmYesNo")).click();Thread.sleep(2000);
	    
	    /* DELETE Job in Edit View - No */
	    driver.findElement(By.cssSelector(".btn-blue-link-12")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector("form:nth-child(1) > .btn-lg")).click();Thread.sleep(2000);
	    driver.findElement(By.id("btnNoConfirmYesNo")).click();Thread.sleep(2000);
	    
	    /* CLOSE Job in Main View - YES */
	    driver.findElement(By.cssSelector(".btn > .pb-pointer")).click();
	    Thread.sleep(4000);	    	    
	  	wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".btn-outline-grey")));
	  	wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".btn-outline-grey")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".btn-outline-grey")).click();
	    Thread.sleep(4000);
	    driver.findElement(By.id("btnYesConfirmYesNo")).click();
	    Thread.sleep(2000);	    	  
	    
	    /* From Business Hub */
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@title='Business Automation']")));	// Business Hub Bavigation
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@title='Business Automation']")));Thread.sleep(2000);
		driver.findElement(By.xpath("//div[@title='Business Automation']")).click();
		Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[normalize-space()='Menu']")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()='Menu']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//span[normalize-space()='Menu']")).click();
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//a[normalize-space()='Talent Management'])[1]")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//a[normalize-space()='Talent Management'])[1]")));Thread.sleep(2000);
	    driver.findElement(By.xpath("(//a[normalize-space()='Talent Management'])[1]")).click();
	    Thread.sleep(2000); 
	  	wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("select2-GroupSoid-container")));
	  	wait.until(ExpectedConditions.elementToBeClickable(By.id("select2-GroupSoid-container")));Thread.sleep(2000);
	    driver.findElement(By.id("select2-GroupSoid-container")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".select2-search__field")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".select2-search__field")).sendKeys("001");
	    driver.findElement(By.cssSelector(".select2-search__field")).sendKeys(Keys.ENTER);
	    Thread.sleep(2000);
	    
	    /* Delete the Closed Job */
	  	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@id='divLeftMenu']//div[@id='closedJobLink']")));
	  	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@id='divLeftMenu']//div[@id='closedJobLink']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[@id='divLeftMenu']//div[@id='closedJobLink']")).click();
	    Thread.sleep(2000);
	  	wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".btn-blue-link-12")));
	  	wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".btn-blue-link-12")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".btn-blue-link-12")).click();
	    Thread.sleep(2000);
	  	wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".btn-outline-grey")));
	  	wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".btn-outline-grey")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".btn-outline-grey")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.id("btnYesConfirmYesNo")).click();Thread.sleep(2000);
	    
	    /* Try Post Another Job */
	  	wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("form > .btn-sm")));
	  	wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector("form > .btn-sm")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector("form > .btn-sm")).click();
	    Thread.sleep(2000);
	  	wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".next-btn")));
	  	wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".next-btn")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".next-btn")).click();
	    Thread.sleep(2000);
	  	wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".back-btn")));
	  	wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".back-btn")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".back-btn")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.id("btnYesConfirmYesNo")).click();
	    Thread.sleep(2000);
	    
	    /* Sign out */
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'My Profile')]")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'My Profile')]")));Thread.sleep(2000);
		driver.findElement(By.xpath("//div[contains(text(),'My Profile')]")).click();  
		Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//div[contains(text(),'Logout')])[1]")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//div[contains(text(),'Logout')])[1]")));Thread.sleep(2000);
		driver.findElement(By.xpath("(//div[contains(text(),'Logout')])[1]")).click();  
		Thread.sleep(2000);
	  }
	}