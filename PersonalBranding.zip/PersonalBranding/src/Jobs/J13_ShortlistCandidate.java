package Jobs;

import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import screenshotOnFailure.FailScreenshot;

@Listeners(screenshotListners.EventList.class)
public class J13_ShortlistCandidate extends FailScreenshot{

	@Test
	public void Jobs_ShortlistCandidate() throws InterruptedException {

		/* Login to the Application - PBC */ 		
  		driver.findElement(By.xpath("//button[normalize-space()='Login']")).click();
  		driver.findElement(By.xpath("//input[@id='Username']")).click();
  		driver.findElement(By.xpath("//input[@id='Username']")).sendKeys("john.doe005");
  		driver.findElement(By.xpath("//input[@id='password-field']")).click();
  		driver.findElement(By.xpath("//input[@id='password-field']")).sendKeys("Rockon123");
  		driver.findElement(By.xpath("//button[@id='loginButton']")).click();
  		Thread.sleep(2000);
  		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(180));
	    
	    /* Naviagte to the Business Page */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[normalize-space()='Business Automati...']")));
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()='Business Automati...']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//span[normalize-space()='Business Automati...']")).click();
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[normalize-space()='Menu']")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()='Menu']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//span[normalize-space()='Menu']")).click();
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//a[normalize-space()='Talent Management'])[1]")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//a[normalize-space()='Talent Management'])[1]")));Thread.sleep(2000);
	    driver.findElement(By.xpath("(//a[normalize-space()='Talent Management'])[1]")).click();
	    Thread.sleep(2000);     
	    
	    /* Pending Dropdown on Applicant Card */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[contains(.,\'Pending\')]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[contains(.,\'Pending\')]")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//button[contains(.,\'Pending\')]")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("//button[@value=\'1\']")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".defaultSubmit")));
		wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".defaultSubmit")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".defaultSubmit")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.id("Message")).click();Thread.sleep(2000);
	    driver.findElement(By.id("Message")).sendKeys("Hello John, you have been shortlisted. Our HR Team will call you for the Telephonic discussion");
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".defaultSubmit")));
		wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".defaultSubmit")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".defaultSubmit")).click();
	    wait.until(ExpectedConditions.invisibilityOfElementLocated(By.cssSelector(".defaultSubmit")));
	    
	    /* Notes - Check the updated notes on previous step */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[contains(.,\'Pending\')]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[contains(.,\'Pending\')]")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//span[normalize-space()=\'Notes\']")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".col-md-12 > .btn-sm")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".registeradmin > .modal-header .fa")).click();Thread.sleep(2000);
	    
	    /* Shortlist Candidate from PENDING dropdown */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[contains(.,\'Pending\')]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[contains(.,\'Pending\')]")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//button[contains(.,\'Pending\')]")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("//button[@value=\'2\']")).click();Thread.sleep(2000);
	    
	    /* Try to delete first Interviewer */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[2]/div[2]/div/div[5]/span/button/i")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[2]/div[2]/div/div[5]/span/button/i")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[2]/div[2]/div/div[5]/span/button/i")).click();
	    Thread.sleep(2000);
	    
	    /* Enter Interviewer Details */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//html//div[@id=\'divSchedules\']/div[@class=\'row eachInterviewSchedule\']//span[@class=\'has-float-label\']//input[contains(@class, \'txtMemberInvite\')]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//html//div[@id=\'divSchedules\']/div[@class=\'row eachInterviewSchedule\']//span[@class=\'has-float-label\']//input[contains(@class, \'txtMemberInvite\')]")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//html//div[@id=\'divSchedules\']/div[@class=\'row eachInterviewSchedule\']//span[@class=\'has-float-label\']//input[contains(@class, \'txtMemberInvite\')]")).click();
	    driver.findElement(By.xpath("//html//div[@id=\'divSchedules\']/div[@class=\'row eachInterviewSchedule\']//span[@class=\'has-float-label\']//input[contains(@class, \'txtMemberInvite\')]")).sendKeys("ilhan");
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".autocompleteSugLoc")));
		wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".autocompleteSugLoc")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".autocompleteSugLoc")).click();
	    Thread.sleep(2000);	    
	    driver.findElement(By.xpath("//form[1]/div[1]/div[1]/div[2]/div[1]/div[2]/div[2]/div[2]/div[2]/div[1]/div[1]/div[1]/span[1]/label[1]")).click();Thread.sleep(2000);
	    
	    /* Meeting Checkbox */	    
	    			
	    	// need to automate //	    	    
	    	    
	    /* Select Date */
	    {
	        WebElement element = driver.findElement(By.xpath("//html//div[@id=\'divSchedules\']/div[@class=\'row eachInterviewSchedule\']//span[@class=\'has-float-label\']//input[contains(@class, \'DateTimePicker\')]"));
	        Actions builder = new Actions(driver);
	        builder.doubleClick(element).perform();
	    }	    	    
	    Thread.sleep(2000); 
	    driver.findElement(By.xpath("//div[contains(@class, \'datetimepicker datetimepicker-\')][last()]/div[3]/table/tbody/tr/td[@class=\'day active\']")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[contains(@class, \'datetimepicker datetimepicker-\')][last()]/div[2]/table/tbody/tr/td/fieldset/span[contains(@class,\'hour active \')]")).click();    
	    Thread.sleep(2000);
	    JavascriptExecutor jse = (JavascriptExecutor)driver;
	    jse.executeScript("scroll(0, 200);");
	    Thread.sleep(2000);
	    if(!driver.findElements(By.xpath("//div[contains(@class, 'datetimepicker datetimepicker-')][last()]/div[1]/table/tbody/tr/td/fieldset/span[12][contains(@class, 'minute disabled')]")).isEmpty())
		{	    		    
			Thread.sleep(2000);
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='datetimepicker-minutes']//th[@class='next']")));	
		    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@class='datetimepicker-minutes']//th[@class='next']")));Thread.sleep(2000);
			driver.findElement(By.xpath("//div[@class='datetimepicker-minutes']//th[@class='next']")).click();
		    Thread.sleep(2000);
		    driver.findElement(By.xpath("//div[contains(@class, \'datetimepicker datetimepicker-\')][last()]/div[1]/table/tbody/tr/td/fieldset/span[@class=\'minute\'][1]")).click();	    		    
		}		
		else 
		{
			Thread.sleep(2000);
		    driver.findElement(By.xpath("//div[contains(@class, \'datetimepicker datetimepicker-\')][last()]/div[1]/table/tbody/tr/td/fieldset/span[@class=\'minute\'][1]")).click();
		}  
		Thread.sleep(2000);
		
	    /* Duration */
	    			
    		// need to automate //	    	    	        	    
	    
	    /* Notes while scheduling interview */
	    driver.findElement(By.xpath("//div[@id='errortextarea']/div/div/div/label")).click();Thread.sleep(2000);
	    driver.findElement(By.id("NoteViewModel_Message")).sendKeys("Hey, You have been shortlisted for this job, will meet on interview day");Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".titleAttach")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".btnVaultShare > span")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".btn > span")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".btn > span")));
		Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".aspect-ratio-16-9 > img")).click();
	    Thread.sleep(2000);	
		wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".btn > span")));
	    driver.findElement(By.cssSelector(".btn > span")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.id("btnAddInterviewer")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".defaultSubmit")));
		wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".defaultSubmit")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".defaultSubmit")).click();
	    wait.until(ExpectedConditions.invisibilityOfElementLocated(By.cssSelector(".defaultSubmit")));	
	    Thread.sleep(2000);    
	    
	    /* Delete First Interviewer */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[normalize-space()=\'Interview Schedule\']")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()=\'Interview Schedule\']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//span[normalize-space()=\'Interview Schedule\']")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.id("btnAddInterviewer")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[2]/div[2]/div/div[5]/span/button/i")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.id("btnYesConfirmYesNo")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".defaultSubmit")));
		wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".defaultSubmit")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".defaultSubmit")).click();
	    Thread.sleep(2000);
	    
	    /* SHORTLIST - Reschedule the Interviewer not the Date / Time */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//html//div[@id=\'divSchedules\']/div[@class=\'row eachInterviewSchedule\']//span[@class=\'has-float-label\']//input[contains(@class, \'txtMemberInvite\')]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//html//div[@id=\'divSchedules\']/div[@class=\'row eachInterviewSchedule\']//span[@class=\'has-float-label\']//input[contains(@class, \'txtMemberInvite\')]")));Thread.sleep(2000);	   
	    driver.findElement(By.xpath("//html//div[@id=\'divSchedules\']/div[@class=\'row eachInterviewSchedule\']//span[@class=\'has-float-label\']//input[contains(@class, \'txtMemberInvite\')]")).click();
	    driver.findElement(By.xpath("//html//div[@id=\'divSchedules\']/div[@class=\'row eachInterviewSchedule\']//span[@class=\'has-float-label\']//input[contains(@class, \'txtMemberInvite\')]")).sendKeys("ilhan");
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".autocompleteSugLoc")));
		wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".autocompleteSugLoc")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".autocompleteSugLoc")).click();
	    Thread.sleep(2000);
	    
	    /* Remove the attachment and ADD Again */
	    driver.findElement(By.xpath("//div[@id=\'outfineuploader\']/div/span/i[2]")).click();Thread.sleep(2000); 
	    driver.findElement(By.xpath("//div[@id=\'errortextarea\']/div/div/div/label")).click();
	    driver.findElement(By.id("NoteViewModel_Message")).clear();Thread.sleep(2000);
	    driver.findElement(By.id("NoteViewModel_Message")).sendKeys("Hey, You have been shortlisted for this job, will Schedule the Date & Time soon - Rescheduling ");Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".titleAttach")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".btnVaultShare > span")).click();Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".btn > span")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".btn > span")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".aspect-ratio-16-9 > img")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".btn > span")).click();Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".defaultSubmit")));
		wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".defaultSubmit")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".defaultSubmit")).click();
	    wait.until(ExpectedConditions.invisibilityOfElementLocated(By.cssSelector(".defaultSubmit")));
	    Thread.sleep(2000);	    	  
	     
	    /* Logout */
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'My Profile')]")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'My Profile')]")));Thread.sleep(2000);
		driver.findElement(By.xpath("//div[contains(text(),'My Profile')]")).click();  
		Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//div[contains(text(),'Logout')])[1]")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//div[contains(text(),'Logout')])[1]")));Thread.sleep(2000);
		driver.findElement(By.xpath("(//div[contains(text(),'Logout')])[1]")).click();  
		Thread.sleep(2000);
	  }
	}

