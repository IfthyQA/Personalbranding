package Jobs;

import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import screenshotOnFailure.FailScreenshot;

@Listeners(screenshotListners.EventList.class)
public class J21_ViewAssessments extends FailScreenshot{

	@Test
	public void Jobs_View_Assessment() throws InterruptedException {

		/* Login to the Application - PBC */ 		
	  	driver.findElement(By.xpath("(//button[normalize-space()='Login'])[1]")).click();
  		driver.findElement(By.xpath("//input[@id='Username']")).click();
  		driver.findElement(By.xpath("//input[@id='Username']")).sendKeys("john.doe005");
  		driver.findElement(By.xpath("//input[@id='password-field']")).click();
  		driver.findElement(By.xpath("//input[@id='password-field']")).sendKeys("Rockon123");
  		driver.findElement(By.xpath("//button[@id='loginButton']")).click();
  		Thread.sleep(2000);
  		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(120));
	    
	    /* Naviagte to the Business Page */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[normalize-space()='Business Automati...']")));
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()='Business Automati...']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//span[normalize-space()='Business Automati...']")).click();
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[normalize-space()='Menu']")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()='Menu']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//span[normalize-space()='Menu']")).click();
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//a[normalize-space()='Talent Management'])[1]")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//a[normalize-space()='Talent Management'])[1]")));Thread.sleep(2000);
	    driver.findElement(By.xpath("(//a[normalize-space()='Talent Management'])[1]")).click();
	    Thread.sleep(2000);   
	    
		/* Mouse Over on Skills, Phone Icon and Video Resume */
			  {
		        WebElement element = driver.findElement(By.cssSelector(".link-tip > .fa")); /* Skills */
		        Actions builder = new Actions(driver);
		        builder.moveToElement(element).perform();
		      }
		      Thread.sleep(2000);   
		      {
		    	WebElement element = driver.findElement(By.xpath("//div[@class=\'testShareContainer\']//div[@class=\'btn-sm btn-outline-blue personalityTestBtn\']"));Thread.sleep(2000); /* Assessment Button */
		        Actions builder = new Actions(driver);
		        builder.moveToElement(element).perform();
		      }
		      Thread.sleep(2000);		     		       
		      {
		      	WebElement element = driver.findElement(By.xpath("//div[@class=\'testShareContainer\']//div[@class=\'btn-sm btn-outline-blue personalityTestBtn\']"));Thread.sleep(2000); /* Assessment Button */
		        Actions builder = new Actions(driver);
		        builder.moveToElement(element).perform();
		      }
		        Thread.sleep(2000);
		      {
		      	WebElement element = driver.findElement(By.xpath("//div[@class=\'contactDetailsIcon\']"));Thread.sleep(2000); /* Phone Mail Icon */
		        Actions builder = new Actions(driver);
		        builder.moveToElement(element).perform();
		      }
		        Thread.sleep(2000);  
		      
	    /* View Assessment Report from Applicant Card */
		{
			 WebElement element = driver.findElement(By.xpath("//b[normalize-space()='(INTJ)']"));Thread.sleep(2000); /* Assessment Report*/
			 Actions builder = new Actions(driver);
			 builder.moveToElement(element).perform();
	    }
		Thread.sleep(2000); 
		String winHandleBefore = driver.getWindowHandle();Thread.sleep(2000);
	    driver.findElement(By.xpath("//b[normalize-space()='(INTJ)']")).click();Thread.sleep(2000);
	    for(String winHandle : driver.getWindowHandles()){
	    driver.switchTo().window(winHandle);Thread.sleep(2000);
	   	}
	    	String winHandleBefore1 = driver.getWindowHandle();Thread.sleep(2000);
	    	driver.findElement(By.xpath("//span[@title='Print Assessment']")).click();Thread.sleep(2000);
	    	for(String winHandle : driver.getWindowHandles()){
	        driver.switchTo().window(winHandle);Thread.sleep(2000);
	    	}
	    	driver.close();Thread.sleep(2000);	    	
	    	driver.switchTo().window(winHandleBefore1); 
	    	Thread.sleep(2000);
	    driver.close();Thread.sleep(2000);	    	
	    driver.switchTo().window(winHandleBefore); 	
		        
	    /* View Assessment from Modal */
		driver.findElement(By.xpath("//div[@class='testShareContainer']//span[contains(text(),'Personality')]")).click();Thread.sleep(2000);
			String winHandleBefore2 = driver.getWindowHandle();Thread.sleep(2000);
			driver.findElement(By.xpath("//a[normalize-space()='(INTJ)']")).click();Thread.sleep(2000);
			for(String winHandle : driver.getWindowHandles()){
		    driver.switchTo().window(winHandle);Thread.sleep(2000);
		   	}
				String winHandleBefore21 = driver.getWindowHandle();Thread.sleep(2000);
		    	driver.findElement(By.xpath("//span[@title=\'Print Assessment\']")).click();Thread.sleep(2000);
		    	for(String winHandle : driver.getWindowHandles()){
		        driver.switchTo().window(winHandle);Thread.sleep(2000);
		    	}
		    	driver.close();Thread.sleep(2000);	    	
		    	driver.switchTo().window(winHandleBefore21); 
		    	Thread.sleep(2000);
	    driver.close();Thread.sleep(2000);	    	
	    driver.switchTo().window(winHandleBefore2);Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[@class=\'modal-content\']//div[@class=\'modal-header text-center\']//i[@class=\'fa fa-times\']")).click();Thread.sleep(2000);
	    
	    /* Attachments */
	    driver.findElement(By.cssSelector(".fa-paperclip")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".fa-paperclip")).click();Thread.sleep(2000);	    
	    
	    /* Discussions */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[normalize-space()='Discussions']")));
	  	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()='Discussions']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//span[normalize-space()='Discussions']")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("Message")));
	  	wait.until(ExpectedConditions.elementToBeClickable(By.id("Message")));Thread.sleep(2000);
	    driver.findElement(By.id("Message")).click();Thread.sleep(2000);
	    driver.findElement(By.id("Message")).sendKeys("Be there on Scheduled time at the Venue and please do carry your latest Resume");Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".titleAttach")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".btnVaultShare > span")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".btn")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector("#modalPowerShare .modal-header .fa")).click();Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".defaultSubmit")));
		wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".defaultSubmit")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".defaultSubmit")).click();Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[@id='getjobdiscussion']/div/div/div/button/span/i")).click();Thread.sleep(2000);
	    
	    /* Notes by Job Creator */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[normalize-space()='Notes']")));
	  	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()='Notes']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//span[normalize-space()='Notes']")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("Message")));
	  	wait.until(ExpectedConditions.elementToBeClickable(By.id("Message")));Thread.sleep(2000);
	    driver.findElement(By.id("Message")).click();Thread.sleep(2000);
	    driver.findElement(By.id("Message")).clear();
	    driver.findElement(By.id("Message")).sendKeys("His profile is good at Technical. Please take the Interview with writing Test Cases. and share the results");Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".titleAttach")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".btnVaultShare > span")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".aspect-ratio-16-9 > img")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".btn")).click();Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[@id=\'outfineuploader\']/div/span/i[2]")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".titleAttach")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".btnVaultShare > span")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".aspect-ratio-16-9 > img")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".btn")).click();Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".defaultSubmit")));
		wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".defaultSubmit")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".defaultSubmit")).click();Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".defaultSubmit")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".defaultSubmit")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".defaultSubmit")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".registeradmin > .modal-header .fa")).click();Thread.sleep(2000);
	    	   
	    /* Logout */
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'My Profile')]")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'My Profile')]")));Thread.sleep(2000);
		driver.findElement(By.xpath("//div[contains(text(),'My Profile')]")).click();  
		Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//div[contains(text(),'Logout')])[1]")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//div[contains(text(),'Logout')])[1]")));Thread.sleep(2000);
		driver.findElement(By.xpath("(//div[contains(text(),'Logout')])[1]")).click();  
		Thread.sleep(2000);
	  }
	}

