package Jobs;

import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import screenshotOnFailure.FailScreenshot;

@Listeners(screenshotListners.EventList.class)
public class J40_InterviewerFeedback extends FailScreenshot{
	
	@Test
	public void Jobs_Interviewer_Feedback() throws InterruptedException {

	/* Login to the Application - PBC */ 		
	driver.findElement(By.xpath("(//button[normalize-space()='Login'])[1]")).click();
	driver.findElement(By.xpath("//input[@id='Username']")).click();
	driver.findElement(By.xpath("//input[@id='Username']")).sendKeys("john.doe004");
	driver.findElement(By.xpath("//input[@id='password-field']")).click();
	driver.findElement(By.xpath("//input[@id='password-field']")).sendKeys("Rockon123");
	driver.findElement(By.xpath("//button[@id='loginButton']")).click();
	Thread.sleep(2000);
	WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(120));
    
    /* Naviagte to the Business Page */
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[normalize-space()='Business Automati...']")));
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()='Business Automati...']")));Thread.sleep(2000);
    driver.findElement(By.xpath("//span[normalize-space()='Business Automati...']")).click();
    Thread.sleep(2000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[normalize-space()='Menu']")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()='Menu']")));Thread.sleep(2000);
    driver.findElement(By.xpath("//span[normalize-space()='Menu']")).click();
    Thread.sleep(2000);
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[normalize-space()='Interview Dashboard']")));
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[normalize-space()='Interview Dashboard']")));Thread.sleep(2000);
    driver.findElement(By.xpath("//a[normalize-space()='Interview Dashboard']")).click();
    Thread.sleep(2000);   
    
    /* Click the Job Title Before update */
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//b[normalize-space()='(INTJ)']")));	
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//b[normalize-space()='(INTJ)']")));Thread.sleep(2000); 
    String winHandleBefore = driver.getWindowHandle();Thread.sleep(2000);	    
    driver.findElement(By.xpath("//b[normalize-space()='(INTJ)']")).click();Thread.sleep(2000);
    Thread.sleep(2000);	// Navigate to New window
	for(String winHandle : driver.getWindowHandles()){
    driver.switchTo().window(winHandle);Thread.sleep(2000);
	}
	driver.close();Thread.sleep(2000);
	driver.switchTo().window(winHandleBefore);
	Thread.sleep(2000);
	
	 /* Scroll Up the page */
    JavascriptExecutor jse = (JavascriptExecutor)driver;
    jse.executeScript("scroll(0, -250);");	    	    
    Thread.sleep(2000);  
    
    /* Discuss with the HR (schedular) */
    driver.findElement(By.xpath("//span[normalize-space()=\'Discussions\']")).click();
    Thread.sleep(2000);
    driver.findElement(By.id("Message")).click();
    driver.findElement(By.id("Message")).sendKeys("Sure, i will take the Interview on Scheduled time");
    Thread.sleep(2000);
    driver.findElement(By.cssSelector(".titleAttach")).click();Thread.sleep(2000);
    driver.findElement(By.cssSelector(".btnVaultShare > span")).click();
    Thread.sleep(2000);
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[normalize-space()=\'ADD FILES\']")));	
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()=\'ADD FILES\']")));Thread.sleep(2000);
    driver.findElement(By.cssSelector(".aspect-ratio-16-9 > img")).click();
    Thread.sleep(2000);
    driver.findElement(By.xpath("//span[normalize-space()=\'ADD FILES\']")).click();
    Thread.sleep(2000);
    driver.findElement(By.xpath("//span[normalize-space()=\'Send\']")).click();
    Thread.sleep(2000);
    driver.findElement(By.xpath("//div[@id=\'getjobdiscussion\']/div/div/div/button/span/i")).click();
    Thread.sleep(2000);
    
    /* Scroll Up the page */
    jse.executeScript("scroll(0, -250);");	    	    
    Thread.sleep(2000);  
    
    /* Notes */    
    driver.findElement(By.xpath("//span[normalize-space()=\'Notes\']")).click();
    Thread.sleep(2000);
    driver.findElement(By.id("Message")).click();
    driver.findElement(By.id("Message")).sendKeys("Sure Ahmed, Will go with F2F Interview");
    Thread.sleep(2000);
    driver.findElement(By.xpath("//span[normalize-space()=\'Add Note\']")).click();
    Thread.sleep(2000);
    driver.findElement(By.cssSelector(".registeradmin > .modal-header .fa")).click();
    Thread.sleep(2000);    
    
    /* Scroll Up the page */
    jse.executeScript("scroll(0, -250);");	    	    
    Thread.sleep(2000);  
    
    /* All Interviews */
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[normalize-space()=\'Interview Schedule\']")));	
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()=\'Interview Schedule\']")));Thread.sleep(2000);
    driver.findElement(By.xpath("//span[normalize-space()=\'Interview Schedule\']")).click();
    Thread.sleep(2000);
    driver.findElement(By.id("btnAddInterviewer")).click();
    Thread.sleep(2000);
    driver.findElement(By.xpath("//div[4]/div[2]/div/div[5]/span/button/i")).click();
    Thread.sleep(2000);
    driver.findElement(By.cssSelector(".titleAttach")).click();
    Thread.sleep(2000);
    driver.findElement(By.cssSelector(".btnVaultShare > span")).click();
    Thread.sleep(2000);
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[normalize-space()=\'ADD FILES\']")));	
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()=\'ADD FILES\']")));Thread.sleep(2000);
    driver.findElement(By.cssSelector(".modal-social > .modal-header .fa")).click();
    Thread.sleep(2000);
    driver.findElement(By.xpath("//span[normalize-space()=\'Submit\']")).click();
    Thread.sleep(2000);
    
    /* Scroll Up the page */
    jse.executeScript("scroll(0, -250);");	    	    
    Thread.sleep(2000);  
    
    /* Check the Buttons and links */
    driver.findElement(By.xpath("//span[contains(text(),\'ADD FEEDBACK\')]")).click();
    Thread.sleep(2000);
    driver.findElement(By.xpath("//span[normalize-space()=\'Update\']")).click();
    Thread.sleep(2000);
    driver.findElement(By.cssSelector(".btnCancelDecision .fa")).click();
    Thread.sleep(2000);
    driver.findElement(By.cssSelector(".fa-paperclip")).click();Thread.sleep(2000);
    driver.findElement(By.cssSelector(".fa-paperclip")).click();
    Thread.sleep(2000);
    driver.findElement(By.xpath("//span[normalize-space()=\'Discussions\']")).click();
    Thread.sleep(2000);
    driver.findElement(By.xpath("//div[@id=\'getjobdiscussion\']/div/div/div/button/span/i")).click();
    Thread.sleep(2000);
    driver.findElement(By.cssSelector(".fa-paperclip")).click();
    Thread.sleep(2000);
    driver.findElement(By.cssSelector(".fa-paperclip")).click();
    Thread.sleep(2000);
    
    /* Scroll Up the page */
    jse.executeScript("scroll(0, -250);");	    	    
    Thread.sleep(2000);  
    
    /* ADD Feedback  */
    driver.findElement(By.xpath("//span[contains(text(),\'ADD FEEDBACK\')]")).click();
    Thread.sleep(2000);
    driver.findElement(By.id("NoteViewModel_Message")).click();
    driver.findElement(By.id("NoteViewModel_Message")).clear();
    driver.findElement(By.id("NoteViewModel_Message")).sendKeys("Done with Test and Interview, His technical skills are strong. he can learn new things.");
    Thread.sleep(2000);
    
    /* Skill and Traights */
    driver.findElement(By.xpath("//div[@class='margin-bottom-10']//div[1]//div[2]//div[1]//span[2]//span[1]//span[1]//img[5]")).click();
    Thread.sleep(2000);
    driver.findElement(By.xpath("//div[@class='col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12']//div[2]//div[2]//div[1]//span[2]//span[1]//span[1]//img[5]")).click();
    Thread.sleep(2000);
    driver.findElement(By.xpath("//div[@id=\'modalGetInterviewerFeedback\']/form/div/div/div[2]/div/div[2]/div/div[2]/section/div[2]/div[3]/div[2]/div/span/span/span/span")).click();
    Thread.sleep(2000);
    driver.findElement(By.cssSelector(".select2-search__field")).click();
    Thread.sleep(2000);
    driver.findElement(By.cssSelector(".select2-search__field")).sendKeys("On");
    driver.findElement(By.cssSelector(".select2-search__field")).sendKeys(Keys.ENTER);
    Thread.sleep(2000);
    driver.findElement(By.xpath("//span[normalize-space()=\'Update\']")).click();
    wait.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath("//span[normalize-space()=\'Update\']")));
    Thread.sleep(2000);
    
    /* Discussion after - Feedback */
   	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[normalize-space()=\'Discussions\']")));	
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()=\'Discussions\']"))); 
    driver.findElement(By.xpath("//span[normalize-space()=\'Discussions\']")).click();
    Thread.sleep(2000);
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("Message")));
  	wait.until(ExpectedConditions.elementToBeClickable(By.id("Message")));Thread.sleep(2000);
    driver.findElement(By.id("Message")).click();
    driver.findElement(By.id("Message")).clear();
    driver.findElement(By.id("Message")).sendKeys("You've cleared first round, next is Technical round");
    Thread.sleep(2000);
    driver.findElement(By.cssSelector(".titleAttach")).click();Thread.sleep(2000);
    driver.findElement(By.cssSelector(".btnVaultShare > span")).click();
    Thread.sleep(2000);
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[normalize-space()=\'ADD FILES\']")));	
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()=\'ADD FILES\']")));Thread.sleep(2000);
    driver.findElement(By.xpath("//span[normalize-space()=\'ADD FILES\']")).click();
    Thread.sleep(2000);
    driver.findElement(By.cssSelector(".aspect-ratio-16-9 > img")).click();
    Thread.sleep(2000);
    driver.findElement(By.xpath("//span[normalize-space()=\'ADD FILES\']")).click();
    Thread.sleep(2000);
    driver.findElement(By.xpath("//span[normalize-space()=\'Send\']")).click();
    Thread.sleep(2000);
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("Message")));
  	wait.until(ExpectedConditions.elementToBeClickable(By.id("Message")));Thread.sleep(2000);
    driver.findElement(By.id("Message")).click();
    driver.findElement(By.id("Message")).sendKeys("Final Round");
    Thread.sleep(2000);
    driver.findElement(By.xpath("//span[normalize-space()=\'Send\']")).click();
    Thread.sleep(2000);
    driver.findElement(By.xpath("//div[@id=\'getjobdiscussion\']/div/div/div/button/span/i")).click();
    Thread.sleep(2000);
    
    /* Scroll Up the page */
    jse.executeScript("scroll(0, -250);");	    	    
    Thread.sleep(2000);  
    
    /* Edit My Feedback */
   	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[contains(text(),\'EDIT MY FEEDBACK\')]")));	
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[contains(text(),\'EDIT MY FEEDBACK\')]")));       
    Thread.sleep(2000);
    driver.findElement(By.xpath("//span[contains(text(),\'EDIT MY FEEDBACK\')]")).click();
    Thread.sleep(2000);
    driver.findElement(By.id("NoteViewModel_Message")).click();
    driver.findElement(By.id("NoteViewModel_Message")).sendKeys("Hey, The Candidate is great. he has good technical skills.");
    Thread.sleep(2000);
    driver.findElement(By.cssSelector(".titleAttach")).click();Thread.sleep(2000);
    driver.findElement(By.cssSelector(".btnVaultShare > span")).click();
    Thread.sleep(2000);
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[normalize-space()=\'ADD FILES\']")));	
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()=\'ADD FILES\']")));Thread.sleep(2000);
    driver.findElement(By.cssSelector(".aspect-ratio-16-9 > img")).click();
    Thread.sleep(2000);
    driver.findElement(By.xpath("//span[normalize-space()=\'ADD FILES\']")).click();
    Thread.sleep(2000);
    driver.findElement(By.xpath("//div[@id=\'modalGetInterviewerFeedback\']/form/div/div/div[2]/div/div[2]/div/div[2]/section/div[2]/div[3]/div[2]/div/span/span/span/span")).click();
    Thread.sleep(2000);
    driver.findElement(By.cssSelector(".select2-search__field")).click();
    driver.findElement(By.cssSelector(".select2-search__field")).sendKeys("Sele");
    driver.findElement(By.cssSelector(".select2-search__field")).sendKeys(Keys.ENTER);
    Thread.sleep(2000);
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()=\'Update\']")));
    driver.findElement(By.xpath("//span[normalize-space()=\'Update\']")).click();
    wait.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath("//span[normalize-space()=\'Update\']")));
    Thread.sleep(2000);
   	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[contains(text(),\'EDIT MY FEEDBACK\')]")));	
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[contains(text(),\'EDIT MY FEEDBACK\')]"))); 
    driver.findElement(By.xpath("//span[contains(text(),\'EDIT MY FEEDBACK\')]")).click();
    Thread.sleep(2000);
    driver.findElement(By.id("NoteViewModel_Message")).click();
    driver.findElement(By.id("NoteViewModel_Message")).clear();
    driver.findElement(By.id("NoteViewModel_Message")).sendKeys("Interview done. You can start Selection Process.. Thanks");
    Thread.sleep(2000);
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()=\'Update\']")));
    driver.findElement(By.xpath("//span[normalize-space()=\'Update\']")).click();
    wait.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath("//span[normalize-space()=\'Update\']")));
    Thread.sleep(2000);
    
    /* Scroll Up the page */
    jse.executeScript("scroll(0, -250);");	    	    
    Thread.sleep(2000);  
    
    /* View Feedback from All Interviews */
    driver.findElement(By.xpath("//span[normalize-space()=\'Interview Schedule\']")).click();
    Thread.sleep(2000);
    driver.findElement(By.cssSelector(".delete > .btn-blue-link-12 > .fa")).click();
    Thread.sleep(2000);
    driver.findElement(By.cssSelector(".col-12 > .dropdown .fa")).click();
    Thread.sleep(2000);
    
    	String winHandleBefore2 = driver.getWindowHandle();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".interviewed-Text span")).click();
	    for(String winHandle : driver.getWindowHandles()){
	        driver.switchTo().window(winHandle);Thread.sleep(2000);
	    	}
		    Thread.sleep(2000);
	    driver.close();Thread.sleep(2000);
	    driver.switchTo().window(winHandleBefore2);Thread.sleep(2000);
	    
    driver.findElement(By.cssSelector(".biz-admin-overlay > .modal-header .fa")).click();
    Thread.sleep(2000);
    driver.findElement(By.xpath("//div[@id=\'outfineuploader\']/div/span/i[2]")).click();
    Thread.sleep(2000);
    driver.findElement(By.xpath("//span[normalize-space()=\'Submit\']")).click();
	wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".toast-message")));
    driver.findElement(By.cssSelector(".toast-message")).click();
    Thread.sleep(2000);
    
    /* Logout */
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'My Profile')]")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'My Profile')]")));Thread.sleep(2000);
	driver.findElement(By.xpath("//div[contains(text(),'My Profile')]")).click();  
	Thread.sleep(2000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//div[contains(text(),'Logout')])[1]")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//div[contains(text(),'Logout')])[1]")));Thread.sleep(2000);
	driver.findElement(By.xpath("(//div[contains(text(),'Logout')])[1]")).click();  
	Thread.sleep(2000);
  }
}

