package Jobs;

import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import screenshotOnFailure.FailScreenshot;

@Listeners(screenshotListners.EventList.class)
public class J12_Request_Assessment extends FailScreenshot{

	@Test
	public void Jobs_AssessmentRequest() throws InterruptedException {

  		/* Login to the Application - PBC */ 		
	  	driver.findElement(By.xpath("(//button[normalize-space()='Login'])[1]")).click();
  		driver.findElement(By.xpath("//input[@id='Username']")).click();
  		driver.findElement(By.xpath("//input[@id='Username']")).sendKeys("john.doe005");
  		driver.findElement(By.xpath("//input[@id='password-field']")).click();
  		driver.findElement(By.xpath("//input[@id='password-field']")).sendKeys("Rockon123");
  		driver.findElement(By.xpath("//button[@id='loginButton']")).click();
  		Thread.sleep(2000);
  		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(120));
	    
	    /* Naviagte to the Business Page */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[normalize-space()='Business Automati...']")));
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()='Business Automati...']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//span[normalize-space()='Business Automati...']")).click();
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[normalize-space()='Menu']")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()='Menu']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//span[normalize-space()='Menu']")).click();
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//a[normalize-space()='Talent Management'])[1]")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//a[normalize-space()='Talent Management'])[1]")));Thread.sleep(2000);
	    driver.findElement(By.xpath("(//a[normalize-space()='Talent Management'])[1]")).click();
	    Thread.sleep(2000);   
	    
	    /* Request Personality Assessment */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class=\'testShareContainer\']//span[contains(text(),\'Personality\')]")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@class=\'testShareContainer\']//span[contains(text(),\'Personality\')]")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[@class=\'testShareContainer\']//span[contains(text(),\'Personality\')]")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".personalityShareBtn > .btn-sm")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".personalityShareBtn > .btn-sm")));Thread.sleep(2000);	    
	    driver.findElement(By.cssSelector(".personalityShareBtn > .btn-sm")).click();Thread.sleep(2000);
	    
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class=\'testShareContainer\']//span[contains(text(),\'Personality\')]")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@class=\'testShareContainer\']//span[contains(text(),\'Personality\')]")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[@class=\'testShareContainer\']//span[contains(text(),\'Personality\')]")).click();Thread.sleep(2000);
	    driver.findElement(By.id("IsMbti")).click();Thread.sleep(2000);
	    driver.findElement(By.id("MbtiDescription")).click();
	    driver.findElement(By.id("MbtiDescription")).sendKeys("Hi, can you please share your 16 Personality Report");
	    Thread.sleep(2000);	 
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[@type='submit']//span[contains(text(),'Send')]")));Thread.sleep(2000);   
	    driver.findElement(By.xpath("//button[@type='submit']//span[contains(text(),'Send')]")).click();
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@class='toast-message']")));
	    driver.findElement(By.xpath("//div[@class='toast-message']")).click(); 
	    Thread.sleep(2000);
	    
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class=\'testShareContainer\']//span[contains(text(),\'Personality\')]")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@class=\'testShareContainer\']//span[contains(text(),\'Personality\')]")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[@class=\'testShareContainer\']//span[contains(text(),\'Personality\')]")).click();Thread.sleep(2000);
	    driver.findElement(By.id("IsDisc")).click();Thread.sleep(2000);
	    driver.findElement(By.id("DiscDescription")).click();
	    driver.findElement(By.id("DiscDescription")).sendKeys("Hello, can you please share your DISC Report");
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[@type='submit']//span[contains(text(),'Send')]")));Thread.sleep(2000); 
	    driver.findElement(By.xpath("//button[@type='submit']//span[contains(text(),'Send')]")).click();
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@class='toast-message']")));
	    driver.findElement(By.xpath("//div[@class='toast-message']")).click(); 
	    Thread.sleep(2000);
	    
	    /* Resend Personality Assessment */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class=\'testShareContainer\']//span[contains(text(),\'Personality\')]")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@class=\'testShareContainer\']//span[contains(text(),\'Personality\')]")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[@class=\'testShareContainer\']//span[contains(text(),\'Personality\')]")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".margin-right-10 > .fa")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".mbtiShowDescription .fa")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".margin-right-35")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".margin-right-10 > .fa")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector("div:nth-child(2) > .d-flex > .fa")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector("div:nth-child(2) .resendPersonalityTestBtn")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector("div:nth-child(2) > .d-flex > .fa")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".discShowDescription .fa")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[@type='submit']//span[contains(text(),'Send')]")));Thread.sleep(2000); 
	    driver.findElement(By.xpath("//button[@type='submit']//span[contains(text(),'Send')]")).click();
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@class='toast-message']")));
	    driver.findElement(By.xpath("//div[@class='toast-message']")).click(); 
	    Thread.sleep(2000);
	    
	    /* Request Technical Assessment */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class=\'testShareContainer\']//div[@class=\'btn-sm btn-outline-blue technicalTestBtn\']")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@class=\'testShareContainer\']//div[@class=\'btn-sm btn-outline-blue technicalTestBtn\']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[@class=\'testShareContainer\']//div[@class=\'btn-sm btn-outline-blue technicalTestBtn\']")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".float-right > .btn-outline-grey")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".float-right > .btn-outline-grey")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".float-right > .btn-outline-grey")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class=\'testShareContainer\']//div[@class=\'btn-sm btn-outline-blue technicalTestBtn\']")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@class=\'testShareContainer\']//div[@class=\'btn-sm btn-outline-blue technicalTestBtn\']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[@class=\'testShareContainer\']//div[@class=\'btn-sm btn-outline-blue technicalTestBtn\']")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".float-right > .btn-outline-grey")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".registeradmin > .modal-header .fa")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".registeradmin > .modal-header .fa")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class=\'testShareContainer\']//div[@class=\'btn-sm btn-outline-blue technicalTestBtn\']")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@class=\'testShareContainer\']//div[@class=\'btn-sm btn-outline-blue technicalTestBtn\']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[@class=\'testShareContainer\']//div[@class=\'btn-sm btn-outline-blue technicalTestBtn\']")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".btnCreateAssesment")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".btnCreateAssesment")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".btnCreateAssesment")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//button[normalize-space()='Create New Assessment'])[1]")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//button[normalize-space()='Create New Assessment'])[1]")));Thread.sleep(2000);
	    driver.findElement(By.xpath("(//button[normalize-space()='Create New Assessment'])[1]")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='technical-assessment row']//div[@class='close-img']")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@class='technical-assessment row']//div[@class='close-img']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[@class='technical-assessment row']//div[@class='close-img']")).click();Thread.sleep(2000);
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[normalize-space()='Yes, Cancel']")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[normalize-space()='Yes, Cancel']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//button[normalize-space()='Yes, Cancel']")).click();
	    Thread.sleep(2000);
	    
	    /* Navigate to Manage Careers from Technical Assessment Page */
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@title='Business Automation']")));	// Business Hub Bavigation
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@title='Business Automation']")));Thread.sleep(2000);
		driver.findElement(By.xpath("//div[@title='Business Automation']")).click();
		Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[normalize-space()='Menu']")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()='Menu']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//span[normalize-space()='Menu']")).click();
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//a[normalize-space()='Talent Management'])[1]")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//a[normalize-space()='Talent Management'])[1]")));Thread.sleep(2000);
	    driver.findElement(By.xpath("(//a[normalize-space()='Talent Management'])[1]")).click();
	    Thread.sleep(2000);   
	    	    	    
	    /* Logout */
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'My Profile')]")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'My Profile')]")));Thread.sleep(2000);
		driver.findElement(By.xpath("//div[contains(text(),'My Profile')]")).click();  
		Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//div[contains(text(),'Logout')])[1]")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//div[contains(text(),'Logout')])[1]")));Thread.sleep(2000);
		driver.findElement(By.xpath("(//div[contains(text(),'Logout')])[1]")).click();  
		Thread.sleep(2000);
	  }
	}

