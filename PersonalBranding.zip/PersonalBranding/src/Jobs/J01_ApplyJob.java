package Jobs;

import java.io.IOException;
import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import screenshotOnFailure.FailScreenshot;

@Listeners(screenshotListners.EventList.class)
public class J01_ApplyJob extends FailScreenshot{
	
	@Test
	public void Jobs_Apply() throws InterruptedException, IOException {

		/* Login to the Application - PBC */ 		
	  	driver.findElement(By.xpath("(//button[normalize-space()='Login'])[1]")).click();
		driver.findElement(By.xpath("//input[@id='Username']")).click();
		driver.findElement(By.xpath("//input[@id='Username']")).sendKeys("john.doe002");
		driver.findElement(By.xpath("//input[@id='password-field']")).click();
		driver.findElement(By.xpath("//input[@id='password-field']")).sendKeys("Rockon123");
		driver.findElement(By.xpath("//button[@id='loginButton']")).click();
		Thread.sleep(2000);
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(120));
		 
		/* Navigate to the Job Opportunity Page */
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'My Profile')]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'My Profile')]")));
		Thread.sleep(2000);
		{
		     WebElement element = driver.findElement(By.xpath("//div[@class='menu-item menu-item-active']"));
		     Actions builder = new Actions(driver);
		     builder.moveToElement(element).perform();
		}
		Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='menu-label ml-1'][normalize-space()='Jobs']")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@class='menu-label ml-1'][normalize-space()='Jobs']")));Thread.sleep(2000);
		driver.findElement(By.xpath("//div[@class='menu-label ml-1'][normalize-space()='Jobs']")).click();
		Thread.sleep(2000);	    
	    
	    /* Search Job from List */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".ui-autocomplete-input")));
	    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".ui-autocomplete-input")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".tagit-choice:nth-child(1) .text-icon")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".ui-autocomplete-input")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".ui-autocomplete-input")).sendKeys("coded ui");Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".ui-autocomplete-input")).sendKeys(Keys.ENTER);
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.elementToBeClickable(By.id("updateResults")));Thread.sleep(2000);
	    driver.findElement(By.id("updateResults")).click();Thread.sleep(2000);	
	    
	    /* Save Job */
	    driver.findElement(By.xpath("//a[normalize-space()=\'Penetration Tester\']")).click();
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[normalize-space()='Save']")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()='Save']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//span[normalize-space()='Save']")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.linkText("Back to List")).click();
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[@title='Unsave']")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[@title='Unsave']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//button[@title='Unsave']")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.id("btnNoConfirmYesNo")).click();
	    Thread.sleep(2000);
	    
	    /* Upload from Power Share */
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[@title='Apply']")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[@title='Apply']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//button[@title='Apply']")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[@class='titleAttach']")));
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[@class='titleAttach']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//span[@class='titleAttach']")).click();
	    Thread.sleep(2000);	 
	    driver.findElement(By.xpath("//button[@type='button']//span[contains(text(),\'Power Share\')]")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".aspect-ratio-16-9 > img")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("//span[contains(.,\'ADD FILES\')]")).click();
	    Thread.sleep(2000);
	    
	    /* Cancel Job in Apply Modal */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("select2-AreaCode-container")));
	    wait.until(ExpectedConditions.elementToBeClickable(By.id("select2-AreaCode-container")));Thread.sleep(2000);
	    driver.findElement(By.id("select2-AreaCode-container")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".select2-search__field")).sendKeys("+91");Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".select2-search__field")).sendKeys(Keys.ENTER);
	    Thread.sleep(2000);
	    driver.findElement(By.id("PhoneNo")).click();
	    driver.findElement(By.id("PhoneNo")).clear();Thread.sleep(2000);
	    driver.findElement(By.id("PhoneNo")).sendKeys("9738230960");
	    Thread.sleep(2000);
	    driver.findElement(By.id("NoticePeriod")).click();Thread.sleep(2000);
	    driver.findElement(By.id("NoticePeriod")).sendKeys("2");
	    Thread.sleep(2000);
	    driver.findElement(By.id("select2-ProfileName-container")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".select2-search__field")).sendKeys("prof");Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".select2-search__field")).sendKeys(Keys.ENTER);Thread.sleep(2000);	    
	    driver.findElement(By.cssSelector(".jo-application-modal > .modal-header .fa")).click();Thread.sleep(2000);
	    
	    /* Apply job From Saved Jobs */
	    driver.findElement(By.xpath("//div[2]/div[2]/div[1]/div[1]/div[1]/div[1]/div[6]/a[1]")).click();
	    Thread.sleep(2000); 
	    driver.findElement(By.cssSelector(".btnApplyJobText")).click();Thread.sleep(2000);
	    
	    /* Upload from Local Device and Remove Attachment */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[@class=\'titleAttach\']")));
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[@class=\'titleAttach\']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//span[@class=\'titleAttach\']")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".btn-upload")).click();
	    Thread.sleep(2000);
	    Runtime.getRuntime().exec("C:\\Users\\dev\\Documents\\AutoScripts\\Upload.exe");	  
	    Thread.sleep(2000); // just because its uploading 
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id=\"outfineuploader\"]/div")));
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@id=\"outfineuploader\"]/div")));Thread.sleep(2000);
	    {
	      WebElement element = driver.findElement(By.xpath("//*[@id=\"outfineuploader\"]/div")); Thread.sleep(2000);
	      Actions builder = new Actions(driver);
	      builder.moveToElement(element).perform();
	    }
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[@id='outfineuploader']/div/span/i[2]")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".btn-blue")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".btn-blue")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".d-none .btn-blue")).click();Thread.sleep(2000);
	    
	    /* Edit Application */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[2]/div[2]/div[1]/div[1]/div[1]/div[1]/div[3]/a[1]")));
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[2]/div[2]/div[1]/div[1]/div[1]/div[1]/div[3]/a[1]")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[2]/div[2]/div[1]/div[1]/div[1]/div[1]/div[3]/a[1]")).click();
	    Thread.sleep(2000); 	    
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div/form/button")));
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div/form/button")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//div/form/button")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.id("NoticePeriod")).click();Thread.sleep(2000);
	    driver.findElement(By.id("NoticePeriod")).sendKeys("6");
	    Thread.sleep(2000);	 
	    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".btn-blue")));Thread.sleep(2000);   
	    driver.findElement(By.cssSelector(".btn-blue")).click();
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(@class,'toast-message')]")));   
	    driver.findElement(By.xpath("//div[contains(@class,'toast-message')]")).click();
	    Thread.sleep(2000); 
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//a[@class='btn-sm btn-outline-blue'])[2]")));
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//a[@class='btn-sm btn-outline-blue'])[2]")));Thread.sleep(2000);
	    driver.findElement(By.xpath("(//a[@class='btn-sm btn-outline-blue'])[2]")).click();
	    Thread.sleep(2000);
	    
	    /* Logout */
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'My Profile')]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'My Profile')]")));Thread.sleep(2000);
		driver.findElement(By.xpath("//div[contains(text(),'My Profile')]")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//div[contains(text(),'Logout')]")).click();
		Thread.sleep(2000);
	  }
	}
