package meetingBusiness;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import screenshotOnFailure.FailScreenshot;

@Listeners(screenshotListners.EventList.class)
public class B1_Scheduled_Meeting extends FailScreenshot{
	
	@Test
	public void Business_Scheduled_Meet() throws InterruptedException {

		/* Login to the Application */ 		
	  	driver.findElement(By.xpath("(//button[normalize-space()='Login'])[1]")).click();
		driver.findElement(By.xpath("//input[@id='Username']")).click();
		driver.findElement(By.xpath("//input[@id='Username']")).sendKeys("john.doe006");
		driver.findElement(By.xpath("//input[@id='password-field']")).click();
		driver.findElement(By.xpath("//input[@id='password-field']")).sendKeys("Rockon123");
		driver.findElement(By.xpath("//button[@id='loginButton']")).click();
		Thread.sleep(2000);
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(120));
	    
	    /* Navigate to the Meeting Dashboard */
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[normalize-space()='Coach Assessment']")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()='Coach Assessment']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//span[normalize-space()='Coach Assessment']")).click();
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[normalize-space()='Menu']")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()='Menu']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//span[normalize-space()='Menu']")).click();
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[normalize-space()='Meetings']")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[normalize-space()='Meetings']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//a[normalize-space()='Meetings']")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("btnCreateMeetingBusiness")));
	    wait.until(ExpectedConditions.elementToBeClickable(By.id("btnCreateMeetingBusiness")));
	    Thread.sleep(2000);
	    driver.findElement(By.linkText("Meeting History")).click();Thread.sleep(2000);
	    driver.findElement(By.linkText("My Meetings")).click();Thread.sleep(2000);	    
	    
	    /* Create Scheduled Meeting */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("btnCreateMeetingBusiness")));
	    wait.until(ExpectedConditions.elementToBeClickable(By.id("btnCreateMeetingBusiness")));Thread.sleep(2000);
	    driver.findElement(By.id("btnCreateMeetingBusiness")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("MeetingName")));
	    wait.until(ExpectedConditions.elementToBeClickable(By.id("MeetingName")));Thread.sleep(2000);
	    driver.findElement(By.id("MeetingName")).click();
	    driver.findElement(By.id("MeetingName")).sendKeys("Business Scheduled Meeting");Thread.sleep(2000);
	    
	    /* Calendar */
	    driver.findElement(By.xpath("//span[@class=\'input-group-append set-date set-date-birth\']//i[@class=\'fa fa-calendar set-date-icon\']")).click();Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[contains(@class, \'datetimepicker datetimepicker-\')][last()]/div[3]/table/tbody/tr/td[@class=\'day active\']")).click();Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[contains(@class, \'datetimepicker datetimepicker-\')][last()]/div[2]/table/tbody/tr/td/fieldset/span[contains(@class,\'hour active \')]")).click();Thread.sleep(2000);	    

	    if(!driver.findElements(By.xpath("//div[contains(@class, 'datetimepicker datetimepicker-')][last()]/div[1]/table/tbody/tr/td/fieldset/span[10][contains(@class, 'minute disabled')]")).isEmpty())
		{	    		    
			Thread.sleep(2000);
			driver.findElement(By.xpath("//div[@class='datetimepicker-minutes']//th[@class='next']")).click();
		    Thread.sleep(2000);
		    driver.findElement(By.xpath("//div[contains(@class, \'datetimepicker datetimepicker-\')][last()]/div[1]/table/tbody/tr/td/fieldset/span[@class=\'minute\'][3]")).click();	    		    
		}		
		else {
			Thread.sleep(2000);
		    driver.findElement(By.xpath("//div[contains(@class, \'datetimepicker datetimepicker-\')][last()]/div[1]/table/tbody/tr/td/fieldset/span[@class=\'minute\'][3]")).click();
		}

	    /* Participants */
	    Thread.sleep(2000);
	    {
	        WebElement element = driver.findElement(By.cssSelector(".col-md-9 label"));
	        Actions builder = new Actions(driver);
	        builder.doubleClick(element).perform();
	      }
	    driver.findElement(By.cssSelector(".txtMemberInvite")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".txtMemberInvite")).sendKeys("Ahmed");
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".autocompleteSugLoc")));
	    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".autocompleteSugLoc")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".autocompleteSugLoc")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".SPconnectname > span:nth-child(1)")).click();Thread.sleep(2000);
	    driver.findElement(By.xpath("//span[@class=\'SPConnectModerator margin-left-5 margin-right-5\']")).click();Thread.sleep(2000);
	    driver.findElement(By.id("contactsbtn")).click();Thread.sleep(2000);
	    driver.findElement(By.id("Attendees_1__Selected")).click();Thread.sleep(2000);
	    driver.findElement(By.id("Attendees_1__Selected")).click();Thread.sleep(2000);
	    driver.findElement(By.id("selectAll")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".margin-top-15 > .btn-sm")).click();Thread.sleep(2000);
	    driver.findElement(By.xpath("//form[@id=\'myForm\']//div[@class=\'SPdetailsshare\']/i")).click();Thread.sleep(2000);
	    driver.findElement(By.xpath("//button[@id='submitbtn']")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.invisibilityOfElementLocated(By.id("submitUpdatebtn"))); // Meeting Created
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//i[@class='editmeeting-icon']")));	  
	    Thread.sleep(2000);
	    
	    /* Remove and Add users -in  Add Participants Modal*/
	    driver.findElement(By.cssSelector(".addParticipant-icon")).click();Thread.sleep(2000);
	    Thread.sleep(2000);	
	    driver.findElement(By.xpath("//form[@id=\'myForm\']//div[@class=\'SPdetailsshare\']/i")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".txtMemberInvite")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".txtMemberInvite")).sendKeys("Ahmed");
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".autocompleteSugLoc")));
	    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".autocompleteSugLoc")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".autocompleteSugLoc")).click();Thread.sleep(2000);
	    driver.findElement(By.xpath("//form[@id=\'myForm\']//div[@class=\'SPdetailsshare\']/i")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".txtMemberInvite")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".txtMemberInvite")).sendKeys("Ahmed");
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".autocompleteSugLoc")));
	    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".autocompleteSugLoc")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".autocompleteSugLoc")).click();Thread.sleep(2000);
	    
	    /* Make Participants MODERATOR */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".SPconnectname > span:nth-child(1)")));
	    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".SPconnectname > span:nth-child(1)")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".SPconnectname > span:nth-child(1)")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("//span[@class=\'SPConnectModerator margin-left-5 margin-right-5\']")).click();Thread.sleep(2000);
	    driver.findElement(By.id("btnAddAttendee")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.invisibilityOfElementLocated(By.id("btnAddAttendee")));
	    
	    /* Edit Meeting and Cancel */
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//i[@class='editmeeting-icon']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//i[@class='editmeeting-icon']")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("submitUpdatebtn")));
	    wait.until(ExpectedConditions.elementToBeClickable(By.id("submitUpdatebtn")));Thread.sleep(2000);
	    driver.findElement(By.id("submitUpdatebtn")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.invisibilityOfElementLocated(By.id("submitUpdatebtn")));
	    
	    /* Edit Meeting */
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//i[@class='editmeeting-icon']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//i[@class='editmeeting-icon']")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("MeetingName")));
	    wait.until(ExpectedConditions.elementToBeClickable(By.id("MeetingName")));Thread.sleep(2000);
	    driver.findElement(By.id("MeetingName")).click();Thread.sleep(2000);
	    driver.findElement(By.id("MeetingName")).clear();Thread.sleep(2000);
	    driver.findElement(By.id("MeetingName")).sendKeys("Meeting For Schedule");Thread.sleep(2000);
	    driver.findElement(By.xpath("//span[@class=\'SPConnectModerator margin-left-5 margin-right-5\']")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("submitUpdatebtn")));
	    wait.until(ExpectedConditions.elementToBeClickable(By.id("submitUpdatebtn")));Thread.sleep(2000);
	    driver.findElement(By.id("submitUpdatebtn")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.invisibilityOfElementLocated(By.id("submitUpdatebtn")));
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//i[@class='editmeeting-icon']")));	  
	    Thread.sleep(2000);
	    
	    /* View Participant and Public view */
		wait.until(ExpectedConditions.elementToBeClickable(By.linkText("My Meetings")));Thread.sleep(2000);
	    driver.findElement(By.linkText("My Meetings")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".pb-pointer > span")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".meetingParticipants-icon")).click();Thread.sleep(2000);
	    
			    String winHandleBefore = driver.getWindowHandle();Thread.sleep(2000);
			    driver.findElement(By.xpath("//div[11]/div[2]/div/div/div/a")).click(); // Click the Particiapnt
			    Thread.sleep(2000); // Navigate to New window
		    	for(String winHandle : driver.getWindowHandles()){
		        driver.switchTo().window(winHandle);Thread.sleep(2000);
		    	}
		    	driver.close();Thread.sleep(2000);
		    	driver.switchTo().window(winHandleBefore);
		    	Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".meetingParticipants-icon")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".addParticipant-icon")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".biz-admin-overlay > .modal-header .fa")).click();
	    Thread.sleep(2000);
	    
	    /* Delete Meeting */
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//i[@class='editmeeting-icon']")));	  
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".deletemeeting-icon")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.id("btnYesConfirmYesNo")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.linkText("My Meetings")).click();
	    Thread.sleep(2000);
	    
	    /* Logout from Meeting */
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'My Profile')]")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'My Profile')]")));Thread.sleep(2000);
		driver.findElement(By.xpath("//div[contains(text(),'My Profile')]")).click();  
		Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//div[contains(text(),'Logout')])[1]")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//div[contains(text(),'Logout')])[1]")));Thread.sleep(2000);
		driver.findElement(By.xpath("(//div[contains(text(),'Logout')])[1]")).click();  
		Thread.sleep(2000);
	  }
	}

