package meetingBusiness;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import screenshotOnFailure.FailScreenshot;

@Listeners(screenshotListners.EventList.class)
public class B2_Recurrence_Meeting extends FailScreenshot{
	
	@Test
	public void Business_Recurrence_Meet() throws InterruptedException {

		/* Login to the Application */ 		
	  	driver.findElement(By.xpath("(//button[normalize-space()='Login'])[1]")).click();
		driver.findElement(By.xpath("//input[@id='Username']")).click();
		driver.findElement(By.xpath("//input[@id='Username']")).sendKeys("john.doe006");
		driver.findElement(By.xpath("//input[@id='password-field']")).click();
		driver.findElement(By.xpath("//input[@id='password-field']")).sendKeys("Rockon123");
		driver.findElement(By.xpath("//button[@id='loginButton']")).click();
		Thread.sleep(2000);
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(120));
	    
	    /* Navigate to the Meeting Dashboard */
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[normalize-space()='Coach Assessment']")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()='Coach Assessment']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//span[normalize-space()='Coach Assessment']")).click();
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[normalize-space()='Menu']")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()='Menu']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//span[normalize-space()='Menu']")).click();
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[normalize-space()='Meetings']")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[normalize-space()='Meetings']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//a[normalize-space()='Meetings']")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("btnCreateMeetingBusiness")));
	    wait.until(ExpectedConditions.elementToBeClickable(By.id("btnCreateMeetingBusiness")));
	    Thread.sleep(2000);
	    driver.findElement(By.linkText("Meeting History")).click();Thread.sleep(2000);
	    driver.findElement(By.linkText("My Meetings")).click();Thread.sleep(2000);
	    
	    /* Meeting and Cancel */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("btnCreateMeetingBusiness")));
	    wait.until(ExpectedConditions.elementToBeClickable(By.id("btnCreateMeetingBusiness")));Thread.sleep(2000);
	    driver.findElement(By.id("btnCreateMeetingBusiness")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("submitbtn")));
	    wait.until(ExpectedConditions.elementToBeClickable(By.id("submitbtn")));
	    driver.findElement(By.id("submitbtn")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".biz-admin-overlay > .modal-header .fa")).click();Thread.sleep(2000);
	    
	    /* Delete Prevous Day's Recurrence Meeting */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".deletemeeting-icon")));
	    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".deletemeeting-icon")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".deletemeeting-icon")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.id("btnYesConfirmYesNo")).click();Thread.sleep(2000);
	    
	    /* Create Meeting */
	    JavascriptExecutor jse = (JavascriptExecutor)driver;
	    jse.executeScript("scroll(0, -250);");
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("btnCreateMeetingBusiness")));
	    wait.until(ExpectedConditions.elementToBeClickable(By.id("btnCreateMeetingBusiness")));Thread.sleep(2000);
	    driver.findElement(By.id("btnCreateMeetingBusiness")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("MeetingName")));
	    wait.until(ExpectedConditions.elementToBeClickable(By.id("MeetingName")));Thread.sleep(2000);
	    driver.findElement(By.id("MeetingName")).click();Thread.sleep(2000);
	    driver.findElement(By.id("MeetingName")).sendKeys("Business Recurrence Meeting");Thread.sleep(2000);
	    
	    /* Current date and Time */
	    driver.findElement(By.xpath("//span[@class=\'input-group-append set-date set-date-birth\']//i[@class=\'fa fa-calendar set-date-icon\']")).click();Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[contains(@class, \'datetimepicker datetimepicker-\')][last()]/div[3]/table/tbody/tr/td[@class=\'day active\']")).click();Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[contains(@class, \'datetimepicker datetimepicker-\')][last()]/div[2]/table/tbody/tr/td/fieldset/span[contains(@class,\'hour active \')]")).click();Thread.sleep(2000);	    

	    if(!driver.findElements(By.xpath("//div[contains(@class, 'datetimepicker datetimepicker-')][last()]/div[1]/table/tbody/tr/td/fieldset/span[12][contains(@class, 'minute disabled')]")).isEmpty())
		{	    		    
			Thread.sleep(2000);
			driver.findElement(By.xpath("//div[@class='datetimepicker-minutes']//th[@class='next']")).click();
		    Thread.sleep(2000);
		    driver.findElement(By.xpath("//div[contains(@class, \'datetimepicker datetimepicker-\')][last()]/div[1]/table/tbody/tr/td/fieldset/span[@class=\'minute\'][1]")).click();	    		    
		}
		
		else {
			Thread.sleep(2000);
		    driver.findElement(By.xpath("//div[contains(@class, \'datetimepicker datetimepicker-\')][last()]/div[1]/table/tbody/tr/td/fieldset/span[@class=\'minute\'][1]")).click();
		}	    
	    
	    /* Add Attendees and Contacts */
	    Thread.sleep(2000);
	    {
	        WebElement element = driver.findElement(By.cssSelector(".col-md-9 label"));
	        Actions builder = new Actions(driver);
	        builder.doubleClick(element).perform();
	      }
	    driver.findElement(By.cssSelector(".txtMemberInvite")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".txtMemberInvite")).sendKeys("Ahmed");
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".autocompleteSugLoc")));
	    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".autocompleteSugLoc")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".autocompleteSugLoc")).click();Thread.sleep(2000);
  	    driver.findElement(By.cssSelector(".SPconnectname > span:nth-child(1)")).click();Thread.sleep(2000);
	    driver.findElement(By.xpath("//span[@class=\'SPConnectModerator margin-left-5 margin-right-5\']")).click();Thread.sleep(2000);
	    driver.findElement(By.id("contactsbtn")).click();Thread.sleep(2000);
	    driver.findElement(By.id("Attendees_1__Selected")).click();Thread.sleep(2000);
	    driver.findElement(By.id("Attendees_1__Selected")).click();Thread.sleep(2000);
	    driver.findElement(By.id("selectAll")).click();Thread.sleep(2000);	 
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[@id=\'submitContacts\']")));Thread.sleep(2000);   
	    driver.findElement(By.xpath("//button[@id=\'submitContacts\']")).click();Thread.sleep(2000);
	    driver.findElement(By.xpath("//form[@id=\'myForm\']//div[@class=\'SPdetailsshare\']/i")).click();Thread.sleep(2000);
	    
	    /*Recurrence Option - DAILY WEEKDAY */
	    driver.findElement(By.id("select2-PlannedSchedule_StartSchedule_TypeOfSchedule-container")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".select2-search__field")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".select2-search__field")).sendKeys("dail");Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".select2-search__field")).sendKeys(Keys.ENTER);Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".dailySchedule div:nth-child(3) > input")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".endInputs > div:nth-child(3) > input")).click();Thread.sleep(2000);
	    driver.findElement(By.id("dailyCount")).click();Thread.sleep(2000);
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[@id='submitbtn']")));
	    driver.findElement(By.xpath("//button[@id='submitbtn']")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.invisibilityOfElementLocated(By.id("submitUpdatebtn")));    
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//i[@class='editmeeting-icon']")));
	    
	    /* Add - Remove - Add Participants */
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".addParticipant-icon")).click();Thread.sleep(2000);
	    driver.findElement(By.xpath("//form[@id=\'myForm\']//div[@class=\'SPdetailsshare\']/i")).click();Thread.sleep(2000);	    
	    driver.findElement(By.cssSelector(".txtMemberInvite")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".txtMemberInvite")).sendKeys("Ahmed");
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".autocompleteSugLoc")));
	    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".autocompleteSugLoc")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".autocompleteSugLoc")).click();Thread.sleep(2000);
	    driver.findElement(By.xpath("//form[@id=\'myForm\']//div[@class=\'SPdetailsshare\']/i")).click();Thread.sleep(2000);    
	    driver.findElement(By.cssSelector(".txtMemberInvite")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".txtMemberInvite")).sendKeys("Ahmed");
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".autocompleteSugLoc")));
	    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".autocompleteSugLoc")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".autocompleteSugLoc")).click();Thread.sleep(2000);
	    
	    /* Make Participants MODERATOR */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".SPconnectname > span:nth-child(1)")));
	    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".SPconnectname > span:nth-child(1)")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".SPconnectname > span:nth-child(1)")).click();Thread.sleep(2000);
	    driver.findElement(By.xpath("//span[@class=\'SPConnectModerator margin-left-5 margin-right-5\']")).click();Thread.sleep(2000);
	    driver.findElement(By.id("btnAddAttendee")).click();
	    wait.until(ExpectedConditions.invisibilityOfElementLocated(By.id("btnAddAttendee")));
	    Thread.sleep(2000);
	    
	    /* Edit Meeting and Cancel */
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//i[@class='editmeeting-icon']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//i[@class='editmeeting-icon']")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.elementToBeClickable(By.id("submitUpdatebtn")));Thread.sleep(2000);
	    driver.findElement(By.id("submitUpdatebtn")).click();
	    wait.until(ExpectedConditions.invisibilityOfElementLocated(By.id("submitUpdatebtn")));
	    driver.navigate().refresh();
	    Thread.sleep(2000);
	    
	    /* Edit Meeting */
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//i[@class='editmeeting-icon']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//i[@class='editmeeting-icon']")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("MeetingName")));
	    wait.until(ExpectedConditions.elementToBeClickable(By.id("MeetingName")));Thread.sleep(2000);
	    driver.findElement(By.id("MeetingName")).click();Thread.sleep(2000);
	    driver.findElement(By.id("MeetingName")).clear();Thread.sleep(2000);
	    driver.findElement(By.id("MeetingName")).sendKeys("Edited Daily Recurrence Meeting");Thread.sleep(2000);
	    driver.findElement(By.xpath("//form[@id=\'myForm\']//div[@class=\'SPdetailsshare\']/i")).click();Thread.sleep(2000);
	    
	    /* Contacts on Edit Meeting */
	    driver.findElement(By.id("contactsbtn")).click();Thread.sleep(2000);
	    driver.findElement(By.id("selectAll")).click();Thread.sleep(2000);
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[@id=\'submitContacts\']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//button[@id=\'submitContacts\']")).click();Thread.sleep(2000);
	    
	    /* Moderators */
	    driver.findElement(By.cssSelector(".SPconnectname > span:nth-child(1)")).click();Thread.sleep(2000);
	    driver.findElement(By.xpath("//span[@class=\'SPConnectModerator margin-left-5 margin-right-5\']")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("//form[@id=\'myForm\']//div[@class=\'SPdetailsshare\']/i")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".SPconnectname > span:nth-child(1)")).click();Thread.sleep(2000);
	    driver.findElement(By.xpath("//span[@class=\'SPConnectModerator margin-left-5 margin-right-5\']")).click();Thread.sleep(2000);
	    driver.findElement(By.id("submitUpdatebtn")).click();
	    wait.until(ExpectedConditions.invisibilityOfElementLocated(By.id("submitUpdatebtn")));
	    Thread.sleep(2000);
	    
	    /* View Participant */	
		wait.until(ExpectedConditions.elementToBeClickable(By.linkText("My Meetings")));Thread.sleep(2000);
	    driver.findElement(By.linkText("My Meetings")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".pb-pointer > span")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".meetingParticipants-icon")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".meetingParticipants-icon")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".addParticipant-icon")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".biz-admin-overlay > .modal-header .fa")).click();
	    Thread.sleep(2000);
	    
	    /* Start Meeting - Leave Meeting  */
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[normalize-space()='Start Meeting']")));Thread.sleep(2000);
	    driver.findElement(By.linkText("Start Meeting")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[3]/div/div/div/div/header/button/span[1]/i")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[3]/div/div/div/div/header/button/span[1]/i")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[3]/div/div/div/div/header/button/span[1]/i")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div/div/header/div[1]/div[3]/div[2]/button/span[1]/i")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div/div/header/div[1]/div[3]/div[2]/button/span[1]/i")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//div/div/header/div[1]/div[3]/div[2]/button/span[1]/i")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[normalize-space()='Leave meeting']")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[normalize-space()='Leave meeting']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[normalize-space()='Leave meeting']")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[1]/div[1]/div[1]/div[1]/div[1]/button[1]/span[1]")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[1]/div[1]/div[1]/div[1]/div[1]/button[1]/span[1]")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[1]/div[1]/div[1]/div[1]/div[1]/button[1]/span[1]")).click();
	    Thread.sleep(2000);
	    
	    /* Join Meeting - End Meeting */
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[normalize-space()='Join Meeting']")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[normalize-space()='Join Meeting']")));Thread.sleep(2000);
	    driver.findElement(By.linkText("Join Meeting")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[3]/div/div/div/div/header/button/span[1]/i")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[3]/div/div/div/div/header/button/span[1]/i")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[3]/div/div/div/div/header/button/span[1]/i")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div/div/header/div[1]/div[3]/div[2]/button/span[1]/i")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div/div/header/div[1]/div[3]/div[2]/button/span[1]/i")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//div/div/header/div[1]/div[3]/div[2]/button/span[1]/i")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[normalize-space()='End meeting']")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[normalize-space()='End meeting']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[normalize-space()='End meeting']")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[normalize-space()='End session for all users']")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[normalize-space()='End session for all users']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//button[normalize-space()='End session for all users']")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[normalize-space()='OK']")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()='OK']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//span[normalize-space()='OK']")).click();
	    Thread.sleep(2000);  
		wait.until(ExpectedConditions.elementToBeClickable(By.linkText("My Meetings")));Thread.sleep(2000);
	    driver.findElement(By.linkText("My Meetings")).click();Thread.sleep(2000);
	    
	    /* Logout from meeting */
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'My Profile')]")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'My Profile')]")));Thread.sleep(2000);
		driver.findElement(By.xpath("//div[contains(text(),'My Profile')]")).click();  
		Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//div[contains(text(),'Logout')])[1]")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//div[contains(text(),'Logout')])[1]")));Thread.sleep(2000);
		driver.findElement(By.xpath("(//div[contains(text(),'Logout')])[1]")).click();  
		Thread.sleep(2000);
	  }
	}

