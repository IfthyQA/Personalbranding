package resume;

import java.io.IOException;
import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import screenshotOnFailure.FailScreenshot;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

@Listeners(screenshotListners.EventList.class)
public class R91_InviteTestimonials extends FailScreenshot {
	
	@Test
	public void Resume_InviteTestimonials() throws InterruptedException, IOException {
		
		/* Login to the Application */ 			
	  	driver.findElement(By.xpath("(//button[normalize-space()='Login'])[1]")).click();
		driver.findElement(By.xpath("//input[@id='Username']")).click();
		driver.findElement(By.xpath("//input[@id='Username']")).sendKeys("john.doe001");
		driver.findElement(By.xpath("//input[@id='password-field']")).click();
		driver.findElement(By.xpath("//input[@id='password-field']")).sendKeys("Rockon123");
		driver.findElement(By.xpath("//button[@id='loginButton']")).click();
		Thread.sleep(2000);
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(120));
	    
	    /* Navigate to the Resume from Hub */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'My Profile')]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'My Profile')]")));Thread.sleep(2000);
	    {
		     WebElement element = driver.findElement(By.xpath("//div[@class='menu-item menu-item-active']"));
		     Actions builder = new Actions(driver);
		     builder.moveToElement(element).perform();
		}
		Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'Resume')]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'Resume')]")));Thread.sleep(2000);
		driver.findElement(By.xpath("//div[contains(text(),'Resume')]")).click();
		Thread.sleep(2000);	
		
		/* Scroll Down to the page */
    	JavascriptExecutor jse = (JavascriptExecutor)driver;
	    jse.executeScript("scroll(0, 250);");	    	    
	    Thread.sleep(2000);
	    
		/* CANCEL - Invites - Testimonial */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'Invite Skills Testimonial')]")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'Invite Skills Testimonial')]")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[contains(text(),'Invite Skills Testimonial')]")).click();	  
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[@class='close-img']")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("//button[@class='modal-btn btn-black-outlined btn-common']")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'Invite Skills Testimonial')]")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'Invite Skills Testimonial')]")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[contains(text(),'Invite Skills Testimonial')]")).click();		  
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[normalize-space()='Cancel']")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[normalize-space()='Cancel']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//button[normalize-space()='Cancel']")).click();
	    Thread.sleep(2000);	
	    driver.findElement(By.xpath("//button[normalize-space()='Go Back']")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("//input[@id='email']")).click();
	    driver.findElement(By.xpath("//input[@id='email']")).sendKeys("Akilesh");
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'Akilesh Sharma')]")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'Akilesh Sharma')]")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[contains(text(),'Akilesh Sharma')]")).click(); // select from the dropdown
	    Thread.sleep(2000);	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[normalize-space()='Cancel']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//button[normalize-space()='Cancel']")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("//button[normalize-space()='Yes, Cancel']")).click();
	    Thread.sleep(2000);	    
	   	    
	    /* Invites - Testimonial Request */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'Invite Skills Testimonial')]")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'Invite Skills Testimonial')]")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[contains(text(),'Invite Skills Testimonial')]")).click();	
	    Thread.sleep(2000);	 
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@id='email']")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@id='email']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//input[@id='email']")).click();
	    driver.findElement(By.xpath("//input[@id='email']")).sendKeys("Akilesh");
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'Akilesh Sharma')]")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'Akilesh Sharma')]")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[contains(text(),'Akilesh Sharma')]")).click(); // select from the dropdown
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[2]/div[1]/div[1]/div[1]/span[1]/button[1]")).click(); // Remove the tag
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("//input[@id='email']")).click();
	    driver.findElement(By.xpath("//input[@id='email']")).sendKeys("Akilesh");
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'Akilesh Sharma')]")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'Akilesh Sharma')]")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[contains(text(),'Akilesh Sharma')]")).click(); // select from the dropdown
	    Thread.sleep(2000);
	    driver.findElement(By.id("email")).click();
	    driver.findElement(By.id("email")).sendKeys("Ifthytest@gmail.com");
	    driver.findElement(By.id("email")).sendKeys(Keys.ENTER);
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("//span[2]//button[1]")).click(); // Remove Email
	    Thread.sleep(2000);
	    driver.findElement(By.id("email")).click();
	    driver.findElement(By.id("email")).sendKeys("Ifthytest@gmail.com");
	    driver.findElement(By.id("email")).sendKeys(Keys.ENTER);
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[normalize-space()='Invite']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//button[normalize-space()='Invite']")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("//button[normalize-space()='OK']")).click();
	    Thread.sleep(2000);  
	    
	    /* Invites - Video Testimonial Request */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'Invite Video Testimonial')]")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'Invite Video Testimonial')]")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[contains(text(),'Invite Video Testimonial')]")).click();
	    Thread.sleep(2000);	 
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("email")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.id("email")));Thread.sleep(2000);
	    driver.findElement(By.id("email")).click();
	    driver.findElement(By.id("email")).sendKeys("Akilesh Sh");
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'Akilesh Sharma')]")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'Akilesh Sharma')]")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[contains(text(),'Akilesh Sharma')]")).click(); // select from the dropdown
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[2]/div[1]/div[1]/div[1]/span[1]/button[1]")).click(); // Remove the tag
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("//input[@id='email']")).click();
	    driver.findElement(By.xpath("//input[@id='email']")).sendKeys("Akilesh sh");
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'Akilesh Sharma')]")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'Akilesh Sharma')]")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[contains(text(),'Akilesh Sharma')]")).click(); // select from the dropdown
	    Thread.sleep(2000);
	    driver.findElement(By.id("email")).click();
	    driver.findElement(By.id("email")).sendKeys("Ifthytest@gmail.com");
	    driver.findElement(By.id("email")).sendKeys(Keys.ENTER);
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("//span[2]//button[1]")).click(); // Remove Email
	    Thread.sleep(2000);
	    driver.findElement(By.id("email")).click();
	    driver.findElement(By.id("email")).sendKeys("Ifthytest@gmail.com");
	    driver.findElement(By.id("email")).sendKeys(Keys.ENTER);
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[normalize-space()='Invite']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//button[normalize-space()='Invite']")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[normalize-space()='OK']")));
	    driver.findElement(By.xpath("//button[normalize-space()='OK']")).click();
	    Thread.sleep(2000);
	    
	    /* Scroll Up the page */
	    jse.executeScript("scroll(0, -250);");	    	    
	    Thread.sleep(2000);
	    
	    /* Naviagate to Testimonials Page - Delete Invites - Testimonial */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'My Profile')]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'My Profile')]")));Thread.sleep(2000);
	    {
		     WebElement element = driver.findElement(By.xpath("//div[@class='menu-item menu-item-active']"));
		     Actions builder = new Actions(driver);
		     builder.moveToElement(element).perform();
		}
		Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'Power Ratings')]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'Power Ratings')]")));Thread.sleep(2000);
		driver.findElement(By.xpath("//div[contains(text(),'Power Ratings')]")).click();
		Thread.sleep(2000);
		
		/* Scroll Up the page */
	    jse.executeScript("scroll(0, -250);");	    	    
	    Thread.sleep(2000);
	    
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[normalize-space()='See Logs']")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[normalize-space()='See Logs']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//button[normalize-space()='See Logs']")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[normalize-space()='Invites Sent']")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[normalize-space()='Invites Sent']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[normalize-space()='Invites Sent']")).click();
	    Thread.sleep(2000);	
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[normalize-space()='Delete']")));	// Delete video testimonial Contact 
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[normalize-space()='Delete']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("(//button[normalize-space()='Delete'])[2]")).click();
	    Thread.sleep(2000);	
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[@class='modal-btn btn-delete-fill']")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[@class='modal-btn btn-delete-fill']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//button[@class='modal-btn btn-delete-fill']")).click();
	    Thread.sleep(2000);		
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[normalize-space()='Delete']")));	// Delete video testimonial Email 
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[normalize-space()='Delete']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("(//button[normalize-space()='Delete'])[3]")).click();
	    Thread.sleep(2000);	
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[@class='modal-btn btn-delete-fill']")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[@class='modal-btn btn-delete-fill']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//button[@class='modal-btn btn-delete-fill']")).click();
	    Thread.sleep(2000);	
	    
	    /* Logout */ 
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'My Profile')]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'My Profile')]")));Thread.sleep(2000);
		driver.findElement(By.xpath("//div[contains(text(),'My Profile')]")).click();
		Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[contains(text(),'Logout')]")).click();
		Thread.sleep(2000);
	  }
	}
