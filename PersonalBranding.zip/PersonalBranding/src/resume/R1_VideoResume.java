package resume;

	import java.io.IOException;
	import java.time.Duration;
	import org.openqa.selenium.By;
	import org.openqa.selenium.JavascriptExecutor;
	import org.openqa.selenium.WebElement;
	import org.openqa.selenium.interactions.Actions;
	import org.openqa.selenium.support.ui.ExpectedConditions;
	import org.openqa.selenium.support.ui.WebDriverWait;
	import org.testng.annotations.Listeners;
	import org.testng.annotations.Test;
	import screenshotOnFailure.FailScreenshot;

	@Listeners(screenshotListners.EventList.class)
	public class R1_VideoResume extends FailScreenshot {
		
		@Test
		public  void Resume_VideoResume() throws InterruptedException, IOException {				

		/* Login to the Application */ 			
		driver.findElement(By.xpath("(//button[normalize-space()='Login'])[1]")).click();
		driver.findElement(By.xpath("//input[@id='Username']")).click();
		driver.findElement(By.xpath("//input[@id='Username']")).sendKeys("john.doe005");
		driver.findElement(By.xpath("//input[@id='password-field']")).click();
		driver.findElement(By.xpath("//input[@id='password-field']")).sendKeys("Rockon123");
		driver.findElement(By.xpath("//button[@id='loginButton']")).click();
		Thread.sleep(2000);
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(120));
	    
	    /* Navigate to the Resume from Hub */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'My Profile')]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'My Profile')]")));Thread.sleep(2000);
	    {
		     WebElement element = driver.findElement(By.xpath("//div[@class='menu-item menu-item-active']"));
		     Actions builder = new Actions(driver);
		     builder.moveToElement(element).perform();
		}
		Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'Resume')]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'Resume')]")));Thread.sleep(2000);
		driver.findElement(By.xpath("//div[contains(text(),'Resume')]")).click();
		Thread.sleep(2000);
		
		/* Play and Pause the Existing Video Resume */
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[5]/div[1]/div[1]/div[1]/div[1]/video[1]")));
		{
		     WebElement element = driver.findElement(By.xpath("//div[5]/div[1]/div[1]/div[1]/div[1]/video[1]"));
		     Actions builder = new Actions(driver);
		     builder.moveToElement(element).perform();		
		}	
		WebElement ele = driver.findElement(By.xpath("//div[5]/div/div/div/div/button"));
		JavascriptExecutor jse = (JavascriptExecutor)driver;
		jse.executeScript("arguments[0].scrollIntoView(true);",ele);
		jse.executeScript("arguments[0].click()", ele);	
		Thread.sleep(1000);
	    driver.findElement(By.xpath("//button[@title='Pause']")).click(); // Pause Button
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("//main[1]/div[1]/div[1]/div[6]/div[1]/div[1]")).click(); // click random place to make new hover for the video resume
	    Thread.sleep(2000);
	    
	    /* Scroll Up the page */
	    jse.executeScript("scroll(0, -250);");	    	    
	    Thread.sleep(2000);
	    	  	    
		/* Delete Video Resume */
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[5]/div[1]/div[1]/div[1]/div[1]/video[1]")));
	    {
		     WebElement element = driver.findElement(By.xpath("//div[5]/div[1]/div[1]/div[1]/div[1]/video[1]"));
		     Actions builder = new Actions(driver);
		     builder.moveToElement(element).perform();
		}
	    driver.findElement(By.xpath("//div[@class='red-danger-text']")).click(); // Hover Delete Button
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[normalize-space()='Delete']")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[normalize-space()='Delete']")));
	    driver.findElement(By.xpath("//button[normalize-space()='Delete']")).click(); // Delete Video
	    Thread.sleep(2000);
	    
		/* Add Video Resume */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[contains(text(),'Add Video Resume')]")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[contains(text(),'Add Video Resume')]")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//span[contains(text(),'Add Video Resume')]")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[@type='button']")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[@type='button']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//button[@type='button']")).click();
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[normalize-space()='Yes, Cancel']")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[normalize-space()='Yes, Cancel']")));
	    driver.findElement(By.xpath("//button[normalize-space()='Yes, Cancel']")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[contains(text(),'Add Video Resume')]")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[contains(text(),'Add Video Resume')]")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//span[contains(text(),'Add Video Resume')]")).click();
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='close-img']")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@class='close-img']")));
	    driver.findElement(By.xpath("//div[@class='close-img']")).click();
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[normalize-space()='Go Back']")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[normalize-space()='Go Back']")));
	    driver.findElement(By.xpath("//button[normalize-space()='Go Back']")).click();
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='close-img']")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@class='close-img']")));
	    driver.findElement(By.xpath("//div[@class='close-img']")).click();
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[normalize-space()='Yes, Cancel']")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[normalize-space()='Yes, Cancel']")));
	    driver.findElement(By.xpath("//button[normalize-space()='Yes, Cancel']")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[contains(text(),'Add Video Resume')]")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[contains(text(),'Add Video Resume')]")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//span[contains(text(),'Add Video Resume')]")).click();
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[normalize-space()='Record Video Resume']")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()='Record Video Resume']")));
	    driver.findElement(By.xpath("//span[normalize-space()='Record Video Resume']")).click();
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[normalize-space()='Okay!']")));	// Click okay for not having Camera warning modal in VM
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[normalize-space()='Okay!']")));
	    driver.findElement(By.xpath("//button[normalize-space()='Okay!']")).click();
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[normalize-space()='Upload Video Resume']")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()='Upload Video Resume']")));
	    driver.findElement(By.xpath("//span[normalize-space()='Upload Video Resume']")).click();
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='browse-blue']")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@class='browse-blue']")));
	    driver.findElement(By.xpath("//div[@class='browse-blue']")).click();
	    Thread.sleep(2000);
		Runtime.getRuntime().exec("C:\\Users\\dev\\Documents\\AutoScripts\\Upload1.exe");
		Thread.sleep(2000);
		
		/* Edit / Re-Upload Video Resume */
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[@class='modal-btn video-cancel-button']")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[@class='modal-btn video-cancel-button']")));
	    driver.findElement(By.xpath("//button[@class='modal-btn video-cancel-button']")).click();
	    Thread.sleep(2000); 
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[normalize-space()='Go Back']")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[normalize-space()='Go Back']")));
	    driver.findElement(By.xpath("//button[normalize-space()='Go Back']")).click();
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[@class='modal-btn video-cancel-button']")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[@class='modal-btn video-cancel-button']")));
	    driver.findElement(By.xpath("//button[@class='modal-btn video-cancel-button']")).click();
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[normalize-space()='Yes, Cancel']")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[normalize-space()='Yes, Cancel']")));
	    driver.findElement(By.xpath("//button[normalize-space()='Yes, Cancel']")).click();
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[normalize-space()='Upload Video Resume']")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()='Upload Video Resume']")));
	    driver.findElement(By.xpath("//span[normalize-space()='Upload Video Resume']")).click();
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='browse-blue']")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@class='browse-blue']")));
	    driver.findElement(By.xpath("//div[@class='browse-blue']")).click();
	    Thread.sleep(2000);
		Runtime.getRuntime().exec("C:\\Users\\dev\\Documents\\AutoScripts\\Upload1.exe");
		Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[normalize-space()='Re-Upload']")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[normalize-space()='Re-Upload']")));
	    driver.findElement(By.xpath("//button[normalize-space()='Re-Upload']")).click();
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='browse-blue']")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@class='browse-blue']")));
	    driver.findElement(By.xpath("//div[@class='browse-blue']")).click();
	    Thread.sleep(2000);
		Runtime.getRuntime().exec("C:\\Users\\dev\\Documents\\AutoScripts\\Upload1.exe");
		Thread.sleep(2000); 
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='video-modal-container']//div[@class='processing-container']")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[2]/div[2]/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/video[1]")));
		Thread.sleep(2000); 
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[2]/div[2]/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/button[1]")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[2]/div[2]/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/button[1]")));Thread.sleep(2000);
		driver.findElement(By.xpath("//div[2]/div[2]/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/button[1]")).click();
		Thread.sleep(2000); 
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[normalize-space()='Upload']")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[normalize-space()='Upload']")));
	    driver.findElement(By.xpath("//button[normalize-space()='Upload']")).click();
	    Thread.sleep(2000);
	    
	    /* Delete From Power Share*/
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'My Profile')]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'My Profile')]")));Thread.sleep(2000);
		{
		     WebElement element = driver.findElement(By.xpath("//div[@id='desktopMenu']"));
		     Actions builder = new Actions(driver);
		     builder.moveToElement(element).perform();
		}
		Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'Power Share')]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'Power Share')]")));Thread.sleep(2000);
		driver.findElement(By.xpath("//div[contains(text(),'Power Share')]")).click();
		Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[2]/div[1]/div[1]/div[1]/div[1]/div[2]/div[1]/div[1]")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[2]/div[1]/div[1]/div[1]/div[1]/div[2]/div[1]/div[1]")));Thread.sleep(2000);
		driver.findElement(By.xpath("//div[2]/div[1]/div[1]/div[1]/div[1]/div[2]/div[1]/div[1]")).click();		
		Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("li .btnDeleteFile")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector("li .btnDeleteFile")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector("li .btnDeleteFile")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("btnYesConfirmYesNo")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.id("btnYesConfirmYesNo")));Thread.sleep(2000);	
	    driver.findElement(By.id("btnYesConfirmYesNo")).click();
		wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".toast-message")));
	    driver.findElement(By.cssSelector(".toast-message")).click();
	    Thread.sleep(2000);	    

		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[2]/div[1]/div[1]/div[1]/div[1]/div[2]/div[1]/div[1]")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[2]/div[1]/div[1]/div[1]/div[1]/div[2]/div[1]/div[1]")));Thread.sleep(2000);
		driver.findElement(By.xpath("//div[2]/div[1]/div[1]/div[1]/div[1]/div[2]/div[1]/div[1]")).click();		
		Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("li .btnDeleteFile")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector("li .btnDeleteFile")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector("li .btnDeleteFile")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("btnYesConfirmYesNo")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.id("btnYesConfirmYesNo")));Thread.sleep(2000);	
	    driver.findElement(By.id("btnYesConfirmYesNo")).click();
		wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".toast-message")));
	    driver.findElement(By.cssSelector(".toast-message")).click();
	    Thread.sleep(2000);
	    
	    /* Logout from the Power Share page */ 
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'My Profile')]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'My Profile')]")));Thread.sleep(2000);
		driver.findElement(By.xpath("//div[contains(text(),'My Profile')]")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("(//div[contains(text(),'Logout')])[2]")).click();
		Thread.sleep(2000);  

}
}