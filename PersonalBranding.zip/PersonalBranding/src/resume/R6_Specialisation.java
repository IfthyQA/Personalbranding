package resume;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import screenshotOnFailure.FailScreenshot;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

@Listeners(screenshotListners.EventList.class)
public class R6_Specialisation extends FailScreenshot {

	@Test
	public void Resume_Specilization() throws InterruptedException {

		/* Login to the Application */ 			
	  	driver.findElement(By.xpath("(//button[normalize-space()='Login'])[1]")).click();
		driver.findElement(By.xpath("//input[@id='Username']")).click();
		driver.findElement(By.xpath("//input[@id='Username']")).sendKeys("john.doe001");
		driver.findElement(By.xpath("//input[@id='password-field']")).click();
		driver.findElement(By.xpath("//input[@id='password-field']")).sendKeys("Rockon123");
		driver.findElement(By.xpath("//button[@id='loginButton']")).click();
		Thread.sleep(2000);
		 WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(120));
	    
	    /* Navigate to the Resume from Hub */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'My Profile')]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'My Profile')]")));Thread.sleep(2000);
	    {
		     WebElement element = driver.findElement(By.xpath("//div[@class='menu-item menu-item-active']"));
		     Actions builder = new Actions(driver);
		     builder.moveToElement(element).perform();
		}
		Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'Resume')]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'Resume')]")));Thread.sleep(2000);
		driver.findElement(By.xpath("//div[contains(text(),'Resume')]")).click();
		Thread.sleep(2000);	
		
		/* Navigating to Specializations and Cancel */
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//span[normalize-space()='Add Specializations'])[1]")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//span[normalize-space()='Add Specializations'])[1]")));Thread.sleep(2000);
		driver.findElement(By.xpath("(//span[normalize-space()='Add Specializations'])[1]")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//button[normalize-space()='Cancel']")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//button[contains(@class,'modal-btn btn-cancel')]")).click();
		Thread.sleep(2000);	    
		    
		/* Click and Add Specializations */
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//span[normalize-space()='Add Specializations'])[1]")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//span[normalize-space()='Add Specializations'])[1]")));Thread.sleep(2000);
		driver.findElement(By.xpath("(//span[normalize-space()='Add Specializations'])[1]")).click();
		Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("current-specialization")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.id("current-specialization")));Thread.sleep(2000);
		driver.findElement(By.id("current-specialization")).click();
		Thread.sleep(2000);
		driver.findElement(By.id("current-specialization")).sendKeys("Investment");
	    driver.findElement(By.id("current-specialization")).sendKeys(Keys.ENTER);
		Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[1]/div[2]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[2]/div/div[2]/div/div[1]/div/div[2]/div/div[1]")).click();
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[normalize-space()='Save']")));Thread.sleep(2000);
		driver.findElement(By.xpath("//button[normalize-space()='Save']")).click();
		Thread.sleep(2000);
		
		/* Scroll till the Specialisation Section */ 	
		JavascriptExecutor jse = (JavascriptExecutor)driver;
		WebElement element1 = driver.findElement(By.xpath("//div[normalize-space()='Tescra Software - www.tescra.com']"));
		Thread.sleep(2000);
		jse.executeScript("arguments[0].scrollIntoView(true);",element1);
		Thread.sleep(2000);
	        
	    /* Edit Specialization */ 
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[1]/div[1]/div[6]/div[1]/div[3]/div[1]/div[2]")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[1]/div[1]/div[6]/div[1]/div[3]/div[1]/div[2]")));Thread.sleep(2000);
		driver.findElement(By.xpath("//div[1]/div[1]/div[6]/div[1]/div[3]/div[1]/div[2]")).click();
		Thread.sleep(2000);
		 {
		     WebElement element = driver.findElement(By.xpath("//div[6]/div[1]/div[4]/div[1]/div[1]/div[2]/div[1]/div[1]/div[3]/div[1]"));
		     Actions builder = new Actions(driver);
		     builder.moveToElement(element).perform();
		 }
		 Thread.sleep(2000);
		 driver.findElement(By.xpath("//div[@class='edit-card-btn']")).click();
		 Thread.sleep(2000);
		 wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("current-specialization")));	
		 wait.until(ExpectedConditions.elementToBeClickable(By.id("current-specialization")));Thread.sleep(2000);
		 driver.findElement(By.id("current-specialization")).click();
		 Thread.sleep(2000);
		 driver.findElement(By.id("current-specialization")).sendKeys("Payment and Transaction");
	     driver.findElement(By.id("current-specialization")).sendKeys(Keys.ENTER);
	     Thread.sleep(2000);
		 driver.findElement(By.xpath("(//div[1]/div[2]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1])[2]")).click(); // Change the Category to Bank & Finance
		 Thread.sleep(2000);
		 driver.findElement(By.xpath("//div[2]/div/div[2]/div/div[1]/div/div[2]/div/div[2]")).click();
		 Thread.sleep(2000);
		 wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[normalize-space()='Save']")));Thread.sleep(2000);
		 driver.findElement(By.xpath("//button[normalize-space()='Save']")).click();
		 Thread.sleep(2000);
		 driver.findElement(By.xpath("//div[@class='close-img']")).click();
		 Thread.sleep(2000);
		 
		 /* Delete Single Specialisation from the Edit Modal */
		 wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(@title,'Investment')]//div[contains(@class,'close-icon-blue')]")));	
		 wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(@title,'Investment')]//div[contains(@class,'close-icon-blue')]")));Thread.sleep(2000);
		 driver.findElement(By.xpath("//div[contains(@title,'Investment')]//div[contains(@class,'close-icon-blue')]")).click();
		 Thread.sleep(2000);
		 driver.findElement(By.xpath("//button[normalize-space()='Cancel']")).click();
		 Thread.sleep(2000);
		 {
		     WebElement element = driver.findElement(By.xpath("//div[contains(@class,'resume-content-container')]/div[3]/div[2]/div[2]/div[1]"));
		     Actions builder = new Actions(driver);
		     builder.moveToElement(element).perform();
		 }
		 driver.findElement(By.xpath("//div[@class='edit-card-btn']")).click();
		 Thread.sleep(2000);
		 driver.findElement(By.xpath("(//div[contains(@title,'Investment')]//div[contains(@class,'close-icon-blue')])[2]")).click();
		 Thread.sleep(2000);
		 wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[normalize-space()='Save']")));Thread.sleep(2000);
		 driver.findElement(By.xpath("//button[normalize-space()='Save']")).click();
		 Thread.sleep(2000);
		 
		 /* Add New Specialisation */
		 wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//span[normalize-space()='Add Specializations'])[1]")));	
		 wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//span[normalize-space()='Add Specializations'])[1]")));Thread.sleep(2000);
		 driver.findElement(By.xpath("(//span[normalize-space()='Add Specializations'])[1]")).click();
		 Thread.sleep(2000);
		 wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("current-specialization")));	
		 wait.until(ExpectedConditions.elementToBeClickable(By.id("current-specialization")));Thread.sleep(2000);
		 driver.findElement(By.id("current-specialization")).click();
		 Thread.sleep(2000);
		 driver.findElement(By.id("current-specialization")).sendKeys("Investment");
	     driver.findElement(By.id("current-specialization")).sendKeys(Keys.ENTER);
		 Thread.sleep(2000);
	     driver.findElement(By.xpath("//div[1]/div[2]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]")).click();
	     Thread.sleep(2000);
	     driver.findElement(By.xpath("//div[2]/div/div[2]/div/div[1]/div/div[2]/div/div[1]")).click();
	     Thread.sleep(2000);
		 wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[normalize-space()='Save']")));Thread.sleep(2000);
		 driver.findElement(By.xpath("//button[normalize-space()='Save']")).click();
		 Thread.sleep(2000);
		
	     /* Delete Specialization from See All Modal */ 
		 driver.findElement(By.xpath("//div[1]/div[1]/div[6]/div[1]/div[3]/div[1]/div[2]")).click();
		 Thread.sleep(2000);
		 {
		     WebElement element = driver.findElement(By.xpath("//div[6]/div[1]/div[4]/div[1]/div[1]/div[2]/div[1]/div[1]/div[3]/div[1]"));
		     Actions builder = new Actions(driver);
		     builder.moveToElement(element).perform();
		 }
		 Thread.sleep(2000);
		 driver.findElement(By.xpath("//div[@class='edit-card-btn']")).click();
		 Thread.sleep(2000);
		 wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("current-specialization")));	
		 wait.until(ExpectedConditions.elementToBeClickable(By.id("current-specialization")));
		 Thread.sleep(2000);
		 driver.findElement(By.xpath("//button[normalize-space()='Save']")).click();
		 Thread.sleep(2000);
		 {
		     WebElement element = driver.findElement(By.xpath("//div[6]/div[1]/div[4]/div[1]/div[1]/div[2]/div[1]/div[1]/div[3]/div[1]"));
		     Actions builder = new Actions(driver);
		     builder.moveToElement(element).perform();
		 }
		 driver.findElement(By.xpath("//div[@class='delete-card-btn']")).click();
		 Thread.sleep(2000);	
		 driver.findElement(By.xpath("//button[normalize-space()='Cancel']")).click();
		 Thread.sleep(2000);
		 driver.findElement(By.xpath("//div[contains(@title,'Investment')]//div[contains(@class,'close-icon-blue')]")).click();
		 Thread.sleep(2000);
		 driver.findElement(By.xpath("//button[normalize-space()='Delete']")).click();
		 Thread.sleep(2000);
		 driver.findElement(By.xpath("//div[@class='close-img']")).click();
		 Thread.sleep(2000);
		 
		 /* Log Out */ 
	     wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'My Profile')]")));
	 	 wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'My Profile')]")));Thread.sleep(2000);
		 driver.findElement(By.xpath("//div[contains(text(),'My Profile')]")).click();
		 Thread.sleep(2000);
		 driver.findElement(By.xpath("//div[contains(text(),'Logout')]")).click();
		 Thread.sleep(2000);
	  }
	}

