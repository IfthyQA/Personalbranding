package resume;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import screenshotOnFailure.FailScreenshot;
import org.openqa.selenium.Keys;

@Listeners(screenshotListners.EventList.class)
public class R4_ResumeFile extends FailScreenshot{

	@Test
	public void Resume_AddEditCV() throws InterruptedException {
		
		/* Login to the Application */ 		
	  	driver.findElement(By.xpath("(//button[normalize-space()='Login'])[1]")).click();
	    driver.findElement(By.id("Username")).click();
	    driver.findElement(By.id("Username")).sendKeys("john.doe001");
	    driver.findElement(By.id("password-field")).click();
	    driver.findElement(By.id("password-field")).sendKeys("Rockon123");
	    driver.findElement(By.cssSelector(".btn-lg")).click();
	    Thread.sleep(2000);
		 WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(120));
	    
	    /* Navigate to the Builder */ 
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".fa-ellipsis-v")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".fa-ellipsis-v")));Thread.sleep(2000);	
		driver.findElement(By.xpath("//span[@class='menuitem-power-bio']")).click();
		Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[@class='btn-lg btn-brown']")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[@class='btn-lg btn-brown']")));Thread.sleep(2000);	
		driver.findElement(By.xpath("//a[@class='btn-lg btn-brown']")).click();
	    Thread.sleep(2000);
	    
	    /* Add Certificate milestone */
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[normalize-space()='Add Certificate']")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()='Add Certificate']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//span[normalize-space()='Add Certificate']")).click();
	    Thread.sleep(2000);	
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("#afterdataCertificate .btn-sm")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector("#afterdataCertificate .btn-sm")));Thread.sleep(2000);	
	    driver.findElement(By.cssSelector("#afterdataCertificate .btn-sm")).click();
	    Thread.sleep(2000);	
	    driver.findElement(By.id("btnNoConfirmYesNo")).click();
	    Thread.sleep(2000);	
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("College")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.id("College")));Thread.sleep(2000);		    
	    {
	      WebElement element = driver.findElement(By.id("College"));
	      Actions builder = new Actions(driver);
	      builder.doubleClick(element).perform();
	    }
	    Thread.sleep(2000);
	    driver.findElement(By.id("College")).sendKeys("123456789abcdefghijklmnopqrstuvwxyz12345678ABCDEFGI");
	    Thread.sleep(2000);
	    driver.findElement(By.id("College")).clear();Thread.sleep(2000);
	    driver.findElement(By.id("College")).sendKeys("Oxford");
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//form[1]/div[1]/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/ul[1]/li[2]/div[1]")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//form[1]/div[1]/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/ul[1]/li[2]/div[1]")));Thread.sleep(2000);	
	    driver.findElement(By.xpath("//form[1]/div[1]/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/ul[1]/li[2]/div[1]")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.id("DegreeCertification")).click();
	    driver.findElement(By.id("DegreeCertification")).sendKeys("123456789abcdefghijklmnopqrstuvwxyz12345678ABCDEFGI123456789abcdefghijklmnopqrstuv");
	    Thread.sleep(2000);
	    driver.findElement(By.id("DegreeCertification")).clear();Thread.sleep(2000);
	    driver.findElement(By.id("DegreeCertification")).sendKeys("Machine Learning");
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".btn-blue")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".divStartDatePicker .fa")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".datepicker-months .datepicker-switch")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".datepicker-years .prev")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".year:nth-child(8)")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".month:nth-child(7)")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.id("IsOnGoing")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.id("IsOnGoing")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.id("EndDate")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".datepicker-months .datepicker-switch")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".year:nth-child(1)")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".month:nth-child(8)")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.id("Major")).click();
	    driver.findElement(By.id("Major")).sendKeys("Electronic123456789abcdefghijklmnopqrstuvwxyz12345678ABCDEFGI123456789abcdefghijklmnopqrstuv");
	    Thread.sleep(2000);
	    driver.findElement(By.id("Major")).clear();Thread.sleep(2000);
	    driver.findElement(By.id("Major")).sendKeys("Communications");
	    Thread.sleep(2000);
	    driver.findElement(By.id("Aggregate")).click();
	    driver.findElement(By.id("Aggregate")).sendKeys("7.8");
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".chosen-search-input")).click();
	    driver.findElement(By.cssSelector(".chosen-search-input")).sendKeys("Prime");
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".chosen-search-input")).sendKeys(Keys.ENTER);
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".btn-blue")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".btn-blue")).click();
		wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".toast-message")));Thread.sleep(2000);
		driver.findElement(By.cssSelector(".toast-message")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//section[3]/div[1]/div[1]/div[4]/div[1]/div[2]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/form[1]/div[1]/div[2]/div[1]/div[1]/div[2]/button[1]/span[1]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//section[3]/div[1]/div[1]/div[4]/div[1]/div[2]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/form[1]/div[1]/div[2]/div[1]/div[1]/div[2]/button[1]/span[1]")));
		
	    /* Scroll & Naviagte to Edit Academic */
	    Thread.sleep(2000);
	    JavascriptExecutor jse = (JavascriptExecutor)driver;
	    Thread.sleep(2000);
	    driver.navigate().refresh();
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[normalize-space()='Add Academic']")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()='Add Academic']")));Thread.sleep(2000);
	    WebElement element = driver.findElement(By.xpath("//span[normalize-space()='Add Academic']"));
	    Thread.sleep(2000);
	    jse.executeScript("arguments[0].scrollIntoView(true);",element);

	    /* Edit Certificate */
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//section[3]/div[1]/div[1]/div[4]/div[1]/div[2]/div[1]/div[2]/div[1]/div[1]/form[1]/div[1]/div[2]/div[1]/div[1]/div[2]/button[1]/span[1]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//section[3]/div[1]/div[1]/div[4]/div[1]/div[2]/div[1]/div[2]/div[1]/div[1]/form[1]/div[1]/div[2]/div[1]/div[1]/div[2]/button[1]/span[1]")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//section[3]/div[1]/div[1]/div[4]/div[1]/div[2]/div[1]/div[2]/div[1]/div[1]/form[1]/div[1]/div[2]/div[1]/div[1]/div[2]/button[1]/span[1]")).click();	    
	    Thread.sleep(2000);
	    driver.findElement(By.id("DegreeCertification")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.id("DegreeCertification")).clear();Thread.sleep(2000);
	    driver.findElement(By.id("DegreeCertification")).sendKeys("Data Scientist");
	    Thread.sleep(2000);
	    driver.findElement(By.id("IsOnGoing")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".search-choice-close")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".chosen-search-input")).click();
	    driver.findElement(By.cssSelector(".chosen-search-input")).sendKeys("Automation");
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".chosen-search-input")).sendKeys(Keys.ENTER);
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".btn-blue")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".btn-blue")).click();
		wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".toast-message")));Thread.sleep(2000);
		driver.findElement(By.cssSelector(".toast-message")).click();
	    Thread.sleep(2000);    
	   
	    /* Naviagte to Edit Certificate */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//section[3]/div[1]/div[1]/div[4]/div[1]/div[2]/div[1]/div[2]/div[1]/div[1]/form[1]/div[1]/div[2]/div[1]/div[1]/div[2]/button[1]/span[1]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//section[3]/div[1]/div[1]/div[4]/div[1]/div[2]/div[1]/div[2]/div[1]/div[1]/form[1]/div[1]/div[2]/div[1]/div[1]/div[2]/button[1]/span[1]")));Thread.sleep(2000);
	    driver.navigate().refresh();
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[normalize-space()='Add Academic']")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()='Add Academic']")));Thread.sleep(2000);
	    WebElement element1 = driver.findElement(By.xpath("//span[normalize-space()='Add Academic']"));
	    Thread.sleep(2000);
	    jse.executeScript("arguments[0].scrollIntoView(true);",element1);
	    
	    /* Delete Certificate */
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//section[3]/div[1]/div[1]/div[4]/div[1]/div[2]/div[1]/div[2]/div[1]/div[1]/form[1]/div[1]/div[2]/div[1]/div[1]/div[2]/button[1]/span[1]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//section[3]/div[1]/div[1]/div[4]/div[1]/div[2]/div[1]/div[2]/div[1]/div[1]/form[1]/div[1]/div[2]/div[1]/div[1]/div[2]/button[1]/span[1]")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//section[3]/div[1]/div[1]/div[4]/div[1]/div[2]/div[1]/div[2]/div[1]/div[1]/form[1]/div[1]/div[2]/div[1]/div[1]/div[2]/button[1]/span[1]")).click();	    
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("form:nth-child(2) > .btn-sm")));
		wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector("form:nth-child(2) > .btn-sm")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector("form:nth-child(2) > .btn-sm")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.id("btnYesConfirmYesNo")).click();
		wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".toast-message")));Thread.sleep(2000);
		driver.findElement(By.cssSelector(".toast-message")).click();
	    Thread.sleep(2000);	    

	    /* Log Out */ 
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".fa-ellipsis-v")));
		wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".fa-ellipsis-v")));Thread.sleep(2000);		
		WebElement ele = driver.findElement(By.cssSelector(".fa-ellipsis-v"));
		jse.executeScript("arguments[0].click()", ele);	 
	    Thread.sleep(2000);
		driver.findElement(By.linkText("Log off")).click();
		Thread.sleep(2000);
	  }
	}
