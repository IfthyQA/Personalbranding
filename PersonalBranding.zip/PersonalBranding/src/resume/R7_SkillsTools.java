package resume;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import screenshotOnFailure.FailScreenshot;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

@Listeners(screenshotListners.EventList.class)
public class R7_SkillsTools extends FailScreenshot {
	
	@Test
	public void Resume_SkillTools() throws InterruptedException {
		
		/* Login to the Application */ 			
	  	driver.findElement(By.xpath("(//button[normalize-space()='Login'])[1]")).click();
		driver.findElement(By.xpath("//input[@id='Username']")).click();
		driver.findElement(By.xpath("//input[@id='Username']")).sendKeys("john.doe001");
		driver.findElement(By.xpath("//input[@id='password-field']")).click();
		driver.findElement(By.xpath("//input[@id='password-field']")).sendKeys("Rockon123");
		driver.findElement(By.xpath("//button[@id='loginButton']")).click();
		Thread.sleep(2000);
		 WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(120));
	    
	    /* Navigate to the Resume from Hub */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'My Profile')]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'My Profile')]")));Thread.sleep(2000);
	    {
		     WebElement element = driver.findElement(By.xpath("//div[@class='menu-item menu-item-active']"));
		     Actions builder = new Actions(driver);
		     builder.moveToElement(element).perform();
		}
		Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'Resume')]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'Resume')]")));Thread.sleep(2000);
		driver.findElement(By.xpath("//div[contains(text(),'Resume')]")).click();
		Thread.sleep(2000);	
		
		 /* Navigating to Experience and Cancel */
		 wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//span[normalize-space()='Add Skills/Tools'])[1]")));	
		 wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//span[normalize-space()='Add Skills/Tools'])[1]")));Thread.sleep(2000);
		 driver.findElement(By.xpath("(//span[normalize-space()='Add Skills/Tools'])[1]")).click();
		 Thread.sleep(2000);
		 driver.findElement(By.xpath("//button[normalize-space()='Cancel']")).click();
		 Thread.sleep(2000);
		 driver.findElement(By.xpath("//button[contains(@class,'modal-btn btn-cancel')]")).click();
		 Thread.sleep(2000);	    
		    
		 /* Click and Add - Remove - Add */
		 wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//span[normalize-space()='Add Skills/Tools'])[1]")));	
		 wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//span[normalize-space()='Add Skills/Tools'])[1]")));Thread.sleep(2000);
		 driver.findElement(By.xpath("(//span[normalize-space()='Add Skills/Tools'])[1]")).click();
		 Thread.sleep(2000);
		 wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//input[@id='autofill-inp'])[1]")));
		 driver.findElement(By.xpath("(//input[@id='autofill-inp'])[1]")).click();
		 driver.findElement(By.xpath("(//input[@id='autofill-inp'])[1]")).sendKeys("Regression");
		 driver.findElement(By.xpath("(//input[@id='autofill-inp'])[1]")).sendKeys(Keys.ENTER);
		 Thread.sleep(2000);
		 driver.findElement(By.xpath("//div[@title='Regression']//div[@class='close-icon-blue']")).click();
		 Thread.sleep(2000);
		 wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//input[@id='autofill-inp'])[1]")));
		 driver.findElement(By.xpath("(//input[@id='autofill-inp'])[1]")).click();
		 driver.findElement(By.xpath("(//input[@id='autofill-inp'])[1]")).sendKeys("Regression");
		 Thread.sleep(2000);
		 driver.findElement(By.xpath("//li[normalize-space()='REGRESSION TESTING']")).click();
		 Thread.sleep(2000);
		 driver.findElement(By.xpath("(//input[@id='autofill-inp'])[2]")).click();
		 driver.findElement(By.xpath("(//input[@id='autofill-inp'])[2]")).sendKeys("RestAssured");
		 driver.findElement(By.xpath("(//input[@id='autofill-inp'])[2]")).sendKeys(Keys.ENTER);
		 Thread.sleep(2000);
		 driver.findElement(By.xpath("//div[@title='RestAssured']//div[@class='close-icon-blue']")).click();
		 Thread.sleep(2000);
		 driver.findElement(By.xpath("(//input[@id='autofill-inp'])[2]")).click();
		 driver.findElement(By.xpath("(//input[@id='autofill-inp'])[2]")).sendKeys("RestAssured");	 
		 Thread.sleep(2000);
		 driver.findElement(By.xpath("//li[normalize-space()='RestAssured']")).click();
		 Thread.sleep(2000);
		 wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[normalize-space()='Save']")));Thread.sleep(2000);
		 driver.findElement(By.xpath("//button[normalize-space()='Save']")).click();
		 Thread.sleep(2000);
		 
		 /* Scroll till the Specialisation Section */ 	
		 JavascriptExecutor jse = (JavascriptExecutor)driver;
		 WebElement element1 = driver.findElement(By.xpath("(//div[normalize-space()='Business and Corporate Related'])[2]"));
		 Thread.sleep(2000);
		 jse.executeScript("arguments[0].scrollIntoView(true);",element1);
		 Thread.sleep(2000);
		 
		 /* Edit and Change Skill from See All Modal */
		 wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='section-container skills-section']//div[@class='see-all-btn'][normalize-space()='See all']")));	
		 wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@class='section-container skills-section']//div[@class='see-all-btn'][normalize-space()='See all']")));Thread.sleep(2000);
		 driver.findElement(By.xpath("//div[@class='section-container skills-section']//div[@class='see-all-btn'][normalize-space()='See all']")).click();
		 Thread.sleep(2000); 
		 {
		     WebElement element = driver.findElement(By.xpath("//div[@class='skills-tools-content']"));
		     Actions builder = new Actions(driver);
		     builder.moveToElement(element).perform();
		 }
		 Thread.sleep(2000);
		 driver.findElement(By.xpath("//div[@class='edit-card-btn']")).click();
		 Thread.sleep(2000);
		 wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[normalize-space()='Save']")));
		 Thread.sleep(2000);
		 driver.findElement(By.xpath("(//div[@title='REGRESSION TESTING']//div[@class='close-icon-blue'])[3]")).click();
		 Thread.sleep(2000); 
		 driver.findElement(By.xpath("(//input[@id='autofill-inp'])[1]")).click();
		 driver.findElement(By.xpath("(//input[@id='autofill-inp'])[1]")).sendKeys("Smoke Testing");
		 driver.findElement(By.xpath("(//input[@id='autofill-inp'])[1]")).sendKeys(Keys.ENTER);
		 Thread.sleep(2000);
		 wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[normalize-space()='Save']")));Thread.sleep(2000);
		 driver.findElement(By.xpath("//button[normalize-space()='Save']")).click();
		 Thread.sleep(2000);
		 driver.findElement(By.xpath("//div[@class='close-img']")).click();
		 Thread.sleep(2000);
		 
		 /* Scroll till the Specialisation Section */ 
		 jse.executeScript("arguments[0].scrollIntoView(true);",element1);
		 Thread.sleep(2000);
		 
		 /* Delete Skill from See All Modal */
		 wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='section-container skills-section']//div[@class='see-all-btn'][normalize-space()='See all']")));	
		 wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@class='section-container skills-section']//div[@class='see-all-btn'][normalize-space()='See all']")));Thread.sleep(2000);
		 driver.findElement(By.xpath("//div[@class='section-container skills-section']//div[@class='see-all-btn'][normalize-space()='See all']")).click();
		 Thread.sleep(2000);
		 driver.findElement(By.xpath("(//div[@title='Smoke Testing']//div[@class='close-icon-blue'])[2]")).click();
		 Thread.sleep(2000);  
		 driver.findElement(By.xpath("//button[normalize-space()='Delete']")).click();
		 Thread.sleep(2000); 
		 driver.findElement(By.xpath("//div[@class='close-img']")).click();
		 Thread.sleep(2000);
		 
		 /* Edit and Change Tool from See All Modal */
		 wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='section-container tools-section']//div[@class='see-all-btn'][normalize-space()='See all']")));	
		 wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@class='section-container tools-section']//div[@class='see-all-btn'][normalize-space()='See all']")));Thread.sleep(2000);
		 driver.findElement(By.xpath("//div[@class='section-container tools-section']//div[@class='see-all-btn'][normalize-space()='See all']")).click();
		 Thread.sleep(2000); 
		 {
		     WebElement element = driver.findElement(By.xpath("//div[@class='skills-tools-content']"));
		     Actions builder = new Actions(driver);
		     builder.moveToElement(element).perform();
		 }
		 Thread.sleep(2000);
		 driver.findElement(By.xpath("//div[@class='edit-card-btn']")).click();
		 Thread.sleep(2000);
		 wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[normalize-space()='Save']")));
		 Thread.sleep(2000);
		 driver.findElement(By.xpath("(//div[@title='RestAssured']//div[@class='close-icon-blue'])[3]")).click();
		 Thread.sleep(2000); 
		 driver.findElement(By.xpath("(//input[@id='autofill-inp'])[2]")).click();
		 driver.findElement(By.xpath("(//input[@id='autofill-inp'])[2]")).sendKeys("SoapUI");
		 driver.findElement(By.xpath("(//input[@id='autofill-inp'])[2]")).sendKeys(Keys.ENTER);
		 Thread.sleep(2000);
		 wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[normalize-space()='Save']")));Thread.sleep(2000);
		 driver.findElement(By.xpath("//button[normalize-space()='Save']")).click();
		 Thread.sleep(2000);
		 driver.findElement(By.xpath("//div[@class='close-img']")).click();
		 Thread.sleep(2000);
		 
		 /* Delete Tool from See All Modal */
		 wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='section-container tools-section']//div[@class='see-all-btn'][normalize-space()='See all']")));	
		 wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@class='section-container tools-section']//div[@class='see-all-btn'][normalize-space()='See all']")));Thread.sleep(2000);
		 driver.findElement(By.xpath("//div[@class='section-container tools-section']//div[@class='see-all-btn'][normalize-space()='See all']")).click();
		 Thread.sleep(2000);
		 driver.findElement(By.xpath("(//div[@title='SoapUI']//div[@class='close-icon-blue'])[2]")).click();
		 Thread.sleep(2000);  
		 driver.findElement(By.xpath("//button[normalize-space()='Delete']")).click();
		 Thread.sleep(2000);  
		 driver.findElement(By.xpath("//div[@class='close-img']")).click();
		 Thread.sleep(2000); 
		 
		 /* Log Out */ 
	     wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'My Profile')]")));
		 wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'My Profile')]")));Thread.sleep(2000);
		 driver.findElement(By.xpath("//div[contains(text(),'My Profile')]")).click();
		 Thread.sleep(2000);
		 driver.findElement(By.xpath("//div[contains(text(),'Logout')]")).click();
		 Thread.sleep(2000);
	  }
	}
