package resume;

import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import screenshotOnFailure.FailScreenshot;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

@Listeners(screenshotListners.EventList.class)
public class R90_Membership extends FailScreenshot {

	@Test
	public void Resume_Membership() throws InterruptedException {

		/* Login to the Application */ 			
	  	driver.findElement(By.xpath("(//button[normalize-space()='Login'])[1]")).click();
		driver.findElement(By.xpath("//input[@id='Username']")).click();
		driver.findElement(By.xpath("//input[@id='Username']")).sendKeys("john.doe001");
		driver.findElement(By.xpath("//input[@id='password-field']")).click();
		driver.findElement(By.xpath("//input[@id='password-field']")).sendKeys("Rockon123");
		driver.findElement(By.xpath("//button[@id='loginButton']")).click();
		Thread.sleep(2000);
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(120));
	    
	    /* Navigate to the Resume from Hub */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'My Profile')]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'My Profile')]")));Thread.sleep(2000);
	    {
		     WebElement element = driver.findElement(By.xpath("//div[@class='menu-item menu-item-active']"));
		     Actions builder = new Actions(driver);
		     builder.moveToElement(element).perform();
		}
		Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'Resume')]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'Resume')]")));Thread.sleep(2000);
		driver.findElement(By.xpath("//div[contains(text(),'Resume')]")).click();
		Thread.sleep(2000);	
		
		/* Navigating to Membership and Cancel */
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//span[normalize-space()='Add Membership'])[1]")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//span[normalize-space()='Add Membership'])[1]")));Thread.sleep(2000);
		driver.findElement(By.xpath("(//span[normalize-space()='Add Membership'])[1]")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//button[normalize-space()='Cancel']")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//button[contains(@class,'modal-btn btn-cancel')]")).click();
		Thread.sleep(2000);	    
		    
		/* Click and Add Membership */
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//span[normalize-space()='Add Membership'])[1]")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//span[normalize-space()='Add Membership'])[1]")));Thread.sleep(2000);
		driver.findElement(By.xpath("(//span[normalize-space()='Add Membership'])[1]")).click();
		Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("membership-name")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.id("membership-name")));Thread.sleep(2000);
		driver.findElement(By.id("membership-name")).click();
		driver.findElement(By.id("membership-name")).sendKeys("123456789abcdefghijklmnopqrstuvwxyz12345678ABCDEFG4665656544643641234567890122345");
		Thread.sleep(2000);	
		driver.findElement(By.id("membership-name")).clear();
		Thread.sleep(2000);
		driver.findElement(By.id("membership-name")).sendKeys("IEEE Resource Collector");
		Thread.sleep(2000);
		driver.findElement(By.id("achmt-company-name")).click();
		driver.findElement(By.id("achmt-company-name")).sendKeys("Tescra Software");
		Thread.sleep(2000);
		driver.findElement(By.xpath("//li[@role='menuitem']")).click();
		Thread.sleep(2000);	
		driver.findElement(By.xpath("//div[contains(@class,'calendar-icon-img-blur')]")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//button[contains(text(),'‹')]")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//button[normalize-space()='2011']")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//button[normalize-space()='Jan']")).click();
		Thread.sleep(2000);
	    driver.findElement(By.id("achmt-descr")).click();
	    driver.findElement(By.id("achmt-descr")).sendKeys("123456789abcdefghijklmnopqrstuvwxyz12345678ABCDEFGI123456789abcdefghijklmnopqrstuv");
	    Thread.sleep(2000);
	    driver.findElement(By.id("achmt-descr")).clear();
	    driver.findElement(By.id("achmt-descr")).sendKeys("3rd party Service API handles the user authentication, session selection, and user consent. The result is an authorization code, which the application can exchange for an access token and a refresh token");
	    Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@id='associated-to']")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//ul[1]/li[2]/ul[1]/li[1]/label[1]")).click();
		Thread.sleep(2000);
	    driver.findElement(By.id("membership-name")).click();
		Thread.sleep(2000);
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[normalize-space()='Save']")));Thread.sleep(2000);
		driver.findElement(By.xpath("//button[normalize-space()='Save']")).click();
		Thread.sleep(2000);	
		
		/* Scroll Down to the See All */
		WebElement element = driver.findElement(By.xpath("//div[@class='section-container projects-section']//div[@class='see-all-btn'][normalize-space()='See all']"));
	    ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", element);
	    Thread.sleep(2000);     

	    /* Edit Membership */
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[1]/div[1]/div[6]/div[1]/div[9]/div[1]/div[2]")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[1]/div[1]/div[6]/div[1]/div[9]/div[1]/div[2]")));Thread.sleep(2000);
		driver.findElement(By.xpath("//div[1]/div[1]/div[6]/div[1]/div[9]/div[1]/div[2]")).click();
		{
		     WebElement element1 = driver.findElement(By.xpath("//div[10]/div[1]/div[1]/div[2]/div[1]/div[1]/div[3]/div[1]"));
		     Actions builder = new Actions(driver);
		     builder.moveToElement(element1).perform();
		}
		driver.findElement(By.xpath("//div[@class='edit-card-btn']")).click();
		Thread.sleep(2000);			
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[normalize-space()='Delete']")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[normalize-space()='Delete']")));
		Thread.sleep(2000);
		driver.findElement(By.id("achmt-company-name")).clear();
		Thread.sleep(2000);
		driver.findElement(By.id("achmt-company-name")).click();
		driver.findElement(By.id("achmt-company-name")).sendKeys("Infosys");
		Thread.sleep(2000);
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[normalize-space()='Save']")));Thread.sleep(2000);
		driver.findElement(By.xpath("//button[normalize-space()='Save']")).click();
		Thread.sleep(2000);	
		driver.findElement(By.xpath("//div[@class='close-img']")).click();
		Thread.sleep(2000);
	
	    /* Delete the recently Added Membership */ 
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[1]/div[1]/div[6]/div[1]/div[9]/div[1]/div[2]")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[1]/div[1]/div[6]/div[1]/div[9]/div[1]/div[2]")));Thread.sleep(2000);
		driver.findElement(By.xpath("//div[1]/div[1]/div[6]/div[1]/div[9]/div[1]/div[2]")).click();
		{
		     WebElement element2 = driver.findElement(By.xpath("//div[10]/div[1]/div[1]/div[2]/div[1]/div[1]/div[3]/div[1]"));
		     Actions builder = new Actions(driver);
		     builder.moveToElement(element2).perform();
		}
		driver.findElement(By.xpath("//div[@class='delete-card-btn']")).click();
		Thread.sleep(2000);	
		driver.findElement(By.xpath("//button[normalize-space()='Delete']")).click();
		Thread.sleep(2000);	
		driver.findElement(By.xpath("//div[@class='close-img']")).click();
		Thread.sleep(2000);    

	    /* Logout */ 
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'My Profile')]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'My Profile')]")));Thread.sleep(2000);
		driver.findElement(By.xpath("//div[contains(text(),'My Profile')]")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//div[contains(text(),'Logout')]")).click();
		Thread.sleep(2000);
	  }
	}

