package powerBio;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import screenshotOnFailure.FailScreenshot;

@Listeners(screenshotListners.EventList.class)
public class B2_SendRequest extends FailScreenshot {

	@Test
	public void PublicView_SendConnection_Request() throws InterruptedException {

		/* Login to the Application */ 			
	  	driver.findElement(By.xpath("(//button[normalize-space()='Login'])[1]")).click();
		driver.findElement(By.xpath("//input[@id='Username']")).click();
		driver.findElement(By.xpath("//input[@id='Username']")).sendKeys("john.doe002");
		driver.findElement(By.xpath("//input[@id='password-field']")).click();
		driver.findElement(By.xpath("//input[@id='password-field']")).sendKeys("Rockon123");
		driver.findElement(By.xpath("//button[@id='loginButton']")).click();
		Thread.sleep(2000);
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(120));	 
	    
	    /* Search (AHMED TESCRA) from Headder */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'My Profile')]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'My Profile')]")));
		Thread.sleep(2000);
		driver.findElement(By.xpath("(//div[normalize-space()='Search'])[1]")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@placeholder='Search']")).click();Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@placeholder='Search']")).clear();Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@placeholder='Search']")).sendKeys("ahmed tescra");
		Thread.sleep(2000);
		driver.findElement(By.xpath("//div[@class='see-result-text']")).click();
		Thread.sleep(2000);
	    
	    /* Send Request from Public View (John Tescra -->> Ahmed Tescra) */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//a[normalize-space()='Ahmed Tescra'])[2]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//a[normalize-space()='Ahmed Tescra'])[2]")));Thread.sleep(2000);
	    String winHandleBefore1 = driver.getWindowHandle();
	    driver.findElement(By.xpath("(//a[normalize-space()='Ahmed Tescra'])[2]")).click();
	    Thread.sleep(2000);
	    for(String winHandle : driver.getWindowHandles()){
		     driver.switchTo().window(winHandle); 
	     }
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[normalize-space()='Connect']")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()='Connect']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//span[normalize-space()='Connect']")).click();
	    Thread.sleep(2000); 
	    
	    /* Promote Profiles */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[normalize-space()='Share Profile']")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()='Share Profile']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//span[normalize-space()='Share Profile']")).click();
	    Thread.sleep(2000); 
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[@class='copy-title']")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[@class='copy-title']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//span[@class='copy-title']")).click();
	    Thread.sleep(2000); 
	    driver.findElement(By.xpath("//div[@class='radio-button-parent']/div[3]/span[1]")).click();
	    Thread.sleep(2000); 
	    driver.findElement(By.xpath("//span[normalize-space()='Share via Email']")).click();
	    Thread.sleep(2000); 
	    driver.findElement(By.xpath("//span[normalize-space()='Post to Social Power']")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("(//div[normalize-space()='Custom Share'])[4]")).click();
	    Thread.sleep(2000); 
	    driver.findElement(By.xpath("//div[@class='sub-component-container']//input[@id='autofill-inp']")).click();	    
	    driver.findElement(By.xpath("//div[@class='sub-component-container']//input[@id='autofill-inp']")).sendKeys("adam");
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//li[normalize-space()='Adam Isa'])[2]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//li[normalize-space()='Adam Isa'])[2]")));Thread.sleep(2000);
	    driver.findElement(By.xpath("(//li[normalize-space()='Adam Isa'])[2]")).click();
	    Thread.sleep(2000); 
	    driver.findElement(By.xpath("//div[@class='sub-component-container']//div[@class='tag-close-icon']")).click();
	    Thread.sleep(2000); 
	    driver.findElement(By.xpath("//div[@class='sub-component-container']//input[@id='autofill-inp']")).click();	    
	    driver.findElement(By.xpath("//div[@class='sub-component-container']//input[@id='autofill-inp']")).sendKeys("adam");
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//li[normalize-space()='Adam Isa'])[2]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//li[normalize-space()='Adam Isa'])[2]")));Thread.sleep(2000);
	    driver.findElement(By.xpath("(//li[normalize-space()='Adam Isa'])[2]")).click();
	    Thread.sleep(2000); 
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[normalize-space()='Share Profile']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//button[normalize-space()='Share Profile']")).click();
	    Thread.sleep(2000); 
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[normalize-space()='Share Profile']")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()='Share Profile']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//span[normalize-space()='Share Profile']")).click();
	    Thread.sleep(2000); 
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[normalize-space()='Post on other Social Networks']")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()='Post on other Social Networks']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//span[normalize-space()='Post on other Social Networks']")).click();
	    Thread.sleep(2000); 
	    driver.findElement(By.xpath("//div[@class='linkdin-icon']")).click();
	    Thread.sleep(2000); 
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[normalize-space()='Share Profile']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//button[normalize-space()='Share Profile']")).click();
	    Thread.sleep(2000); 
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[normalize-space()='Share Profile']")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()='Share Profile']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//span[normalize-space()='Share Profile']")).click();
	    Thread.sleep(2000); 
	    driver.findElement(By.xpath("//span[normalize-space()='Share via Email']")).click();
	    Thread.sleep(2000); 
	    driver.findElement(By.xpath("//div[@class='sub-component-container']//input[@id='autofill-inp']")).click();
	    driver.findElement(By.xpath("//div[@class='sub-component-container']//input[@id='autofill-inp']")).sendKeys("test@test.com");
	    Thread.sleep(2000); 
	    driver.findElement(By.xpath("//div[@class='sub-component-container']//input[@id='autofill-inp']")).sendKeys(Keys.ENTER);
	    Thread.sleep(2000); 
	    driver.findElement(By.xpath("//div[@class='sub-component-container']//div[@class='tag-close-icon']")).click();
	    Thread.sleep(2000); 
	    driver.findElement(By.xpath("//div[@class='sub-component-container']//input[@id='autofill-inp']")).click();
	    driver.findElement(By.xpath("//div[@class='sub-component-container']//input[@id='autofill-inp']")).sendKeys("test@test.com");
	    Thread.sleep(2000); 
	    driver.findElement(By.xpath("//div[@class='sub-component-container']//input[@id='autofill-inp']")).sendKeys(Keys.ENTER);
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[normalize-space()='Share Profile']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//button[normalize-space()='Share Profile']")).click();
	    Thread.sleep(2000); 
	    driver.close();	
	    Thread.sleep(2000);
	    driver.switchTo().window(winHandleBefore1);
	    Thread.sleep(2000);    
	    
	    /* Logout */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'My Profile')]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'My Profile')]")));Thread.sleep(2000);
		driver.findElement(By.xpath("//div[contains(text(),'My Profile')]")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//div[contains(text(),'Logout')]")).click();
		Thread.sleep(2000);
	  }
	}

