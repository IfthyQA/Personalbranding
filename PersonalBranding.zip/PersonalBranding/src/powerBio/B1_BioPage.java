package powerBio;

import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import screenshotOnFailure.FailScreenshot;

@Listeners(screenshotListners.EventList.class)
public class B1_BioPage extends FailScreenshot {

	@Test
	public void Bio_StoryView() throws InterruptedException {

		/* Login to the Application */ 			
	  	driver.findElement(By.xpath("(//button[normalize-space()='Login'])[1]")).click();
		driver.findElement(By.xpath("//input[@id='Username']")).click();
		driver.findElement(By.xpath("//input[@id='Username']")).sendKeys("john.doe002");
		driver.findElement(By.xpath("//input[@id='password-field']")).click();
		driver.findElement(By.xpath("//input[@id='password-field']")).sendKeys("Rockon123");
		driver.findElement(By.xpath("//button[@id='loginButton']")).click();
		Thread.sleep(2000);
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(120));
	    JavascriptExecutor jse = (JavascriptExecutor)driver;
	    
	    /* Navigate to the Story view from Hub */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'My Profile')]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'My Profile')]")));Thread.sleep(2000);
	    {
		     WebElement element = driver.findElement(By.xpath("//div[@class='menu-item menu-item-active']"));
		     Actions builder = new Actions(driver);
		     builder.moveToElement(element).perform();
		}
		Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'Profile / PowerBio')]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'Profile / PowerBio')]")));Thread.sleep(2000);
		driver.findElement(By.xpath("//div[contains(text(),'Profile / PowerBio')]")).click();
		Thread.sleep(2000);
		WebElement Toggle = driver.findElement(By.cssSelector(".custom-control-label"));
		jse.executeScript("arguments[0].click()", Toggle);	  
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@role='alert']")));Thread.sleep(1000);
		driver.findElement(By.xpath("//div[@role='alert']")).click();
	    Thread.sleep(2000);
	    jse.executeScript("arguments[0].click()", Toggle);	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@role='alert']")));Thread.sleep(1000);
		driver.findElement(By.xpath("//div[@role='alert']")).click();
	    Thread.sleep(2000);
	    
	    /* VIEW PUBLIC PROFILE - Button - Handle Windows - New Window */ 
	    	String winHandleBefore = driver.getWindowHandle();
			WebElement PublicProfile = driver.findElement(By.xpath("//span[contains(text(),'View Public Profile')]"));
			jse.executeScript("arguments[0].click()", PublicProfile);
	    	Thread.sleep(2000);	    	
	    	for(String winHandle : driver.getWindowHandles()){
	        driver.switchTo().window(winHandle);
	    	}
	    	Thread.sleep(2000);
	    	driver.close();	
	    	Thread.sleep(2000);    	
	    	driver.switchTo().window(winHandleBefore);
	    	Thread.sleep(2000);
	    	
	    /* Public View Toggle - Cancel by X icon */  	
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='visibility-text']")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@class='visibility-text']")));Thread.sleep(2000);
		WebElement PublicView = driver.findElement(By.xpath("//div[@class='visibility-text']"));
		jse.executeScript("arguments[0].click()", PublicView);
		Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='close-img']")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@class='close-img']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[@class='close-img']")).click();
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[@class='modal-btn btn-cancel']")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[@class='modal-btn btn-cancel']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//button[@class='modal-btn btn-cancel']")).click();
	    Thread.sleep(2000);	
	    
	    /* Public View Toggle - Cancel by CANCEL Button */  	
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[name()='path' and @id='eye']")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[name()='path' and @id='eye']")));Thread.sleep(2000);
		driver.findElement(By.xpath("//*[name()='path' and @id='eye']")).click();
		Thread.sleep(2000);	
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[normalize-space()='Cancel']")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[normalize-space()='Cancel']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//button[normalize-space()='Cancel']")).click();
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[normalize-space()='Go Back']")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[normalize-space()='Go Back']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//button[normalize-space()='Go Back']")).click();
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[normalize-space()='Cancel']")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[normalize-space()='Cancel']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//button[normalize-space()='Cancel']")).click();
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[@class='modal-btn btn-cancel']")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[@class='modal-btn btn-cancel']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//button[@class='modal-btn btn-cancel']")).click();
	    Thread.sleep(2000);	
	    
	    /* Public View Toggle - All Radio button and Save */  
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[name()='path' and @id='eye']")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[name()='path' and @id='eye']")));Thread.sleep(2000);
		driver.findElement(By.xpath("//*[name()='path' and @id='eye']")).click();
		Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("Hidden")));
		wait.until(ExpectedConditions.elementToBeClickable(By.id("Hidden")));Thread.sleep(2000);
		driver.findElement(By.id("Hidden")).click();
		Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("Preview")));
		wait.until(ExpectedConditions.elementToBeClickable(By.id("Preview")));Thread.sleep(2000);
		driver.findElement(By.id("Preview")).click();
		Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("Standard")));
		wait.until(ExpectedConditions.elementToBeClickable(By.id("Standard")));Thread.sleep(2000);
		driver.findElement(By.id("Standard")).click();
		Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[normalize-space()='Cancel']")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[normalize-space()='Cancel']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//button[normalize-space()='Cancel']")).click();
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[normalize-space()='Go Back']")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[normalize-space()='Go Back']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//button[normalize-space()='Go Back']")).click();
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[normalize-space()='Confirm']")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[normalize-space()='Confirm']")));Thread.sleep(2000);
		driver.findElement(By.xpath("//button[normalize-space()='Confirm']")).click();
		Thread.sleep(2000);			
	
	    /* Achievement - Expand & Cancel */  
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='awards-honors-container']/div[1]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@class='awards-honors-container']/div[1]")));Thread.sleep(2000);
	    Thread.sleep(2000);	
	    {
		     WebElement element = driver.findElement(By.xpath("//div[@class='awards-honors-container']/div[1]"));
		     Actions builder = new Actions(driver);
		     builder.moveToElement(element).perform();		
		}	
		driver.findElement(By.xpath("//div[2]/div[1]/div[1]/button[1]/*[name()='svg'][1]")).click();
		Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='close-img']")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@class='close-img']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[@class='close-img']")).click();
	    Thread.sleep(2000);
	    
	    /* Awards - Expand & Cancel */  
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='awards-honors-container']/div[4]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@class='awards-honors-container']/div[4]")));Thread.sleep(2000);
	    Thread.sleep(2000);	
	    {
		     WebElement element = driver.findElement(By.xpath("//div[@class='awards-honors-container']/div[4]"));
		     Actions builder = new Actions(driver);
		     builder.moveToElement(element).perform();		
		}	
		driver.findElement(By.xpath("//div[2]/div[1]/div[4]/button[1]/*[name()='svg'][1]")).click();
		Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='close-img']")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@class='close-img']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[@class='close-img']")).click();
	    Thread.sleep(2000);
	    
	    /* Video Resume - Play - Pause and Back*/  
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='image-container-video']//div[@class='play-button']//*[name()='svg']")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@class='image-container-video']//div[@class='play-button']//*[name()='svg']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[@class='image-container-video']//div[@class='play-button']//*[name()='svg']")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[2]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/video[1]")));
		{
		     WebElement element = driver.findElement(By.xpath("//div[2]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/video[1]"));
		     Actions builder = new Actions(driver);
		     builder.moveToElement(element).perform();		
		}	
		WebElement ele = driver.findElement(By.xpath("//div[2]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/button"));
		jse.executeScript("arguments[0].scrollIntoView(true);",ele);
		jse.executeScript("arguments[0].click()", ele);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[@title='Pause']")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[@title='Pause']")));
		{
		     WebElement element = driver.findElement(By.xpath("//div[2]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/video[1]")); // Hover on Play container
		     Actions builder = new Actions(driver);
		     builder.moveToElement(element).perform();		
		}
	    driver.findElement(By.xpath("//button[@title='Pause']")).click(); // Pause Button
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[@class='close-container-text']")).click(); // Back Button
	    Thread.sleep(2000);
	    
	    /* Video Resume and Cancel */  
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='image-container-video']//div[@class='play-button']")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@class='image-container-video']//div[@class='play-button']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[@class='image-container-video']//div[@class='play-button']")).click();
	    Thread.sleep(2000); 
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='close-img-video']")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@class='close-img-video']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[@class='close-img-video']")).click();
	    Thread.sleep(2000);      
	 
	    /* Specialisation - See All & Cancel */  
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[@class='see-all']")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[@class='see-all']")));Thread.sleep(2000);
	    Thread.sleep(2000);	
	    {
		     WebElement element = driver.findElement(By.xpath("(//canvas[@role='img'])[1]")); // Hover on the specialisation ARC
		     Actions builder = new Actions(driver);
		     builder.moveToElement(element).perform();		
		}	
		WebElement Canvas = driver.findElement(By.xpath("//button[@class='see-all']"));
		jse.executeScript("arguments[0].click()", Canvas);	
		Thread.sleep(2000);
		{
		     WebElement element = driver.findElement(By.xpath("(//canvas[@role='img'])[2]")); // Hover on the specialisation ARC
		     Actions builder = new Actions(driver);
		     builder.moveToElement(element).perform();		
		}
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='close-img']")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@class='close-img']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[@class='close-img']")).click();
	    Thread.sleep(2000);	    
	    
	    /* Contents Scroll */
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='menu-title-inactive'][normalize-space()='Awards and Achievements']")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@class='menu-title-inactive'][normalize-space()='Awards and Achievements']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[@class='menu-title-inactive'][normalize-space()='Awards and Achievements']")).click();
	    Thread.sleep(2000);	
	    driver.findElement(By.xpath("//div[@class='menu-title-inactive'][normalize-space()='Specializations, Traits and Strengths']")).click();
	    Thread.sleep(2000);	
	    driver.findElement(By.xpath("//div[@class='menu-title-inactive'][normalize-space()='Skills and Capabilities']")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[@class='menu-title-inactive'][normalize-space()='My Projects']")).click();
	    Thread.sleep(2000);	
	    driver.findElement(By.xpath("//div[@class='menu-title-inactive'][normalize-space()='Academic History']")).click();
	    Thread.sleep(2000);	
	    driver.findElement(By.xpath("//div[@class='menu-title-inactive'][normalize-space()='Awards and Achievements']")).click();
	    Thread.sleep(2000);	
	    
	    /* Skills and Capabilities - Coins */ 
	    driver.findElement(By.xpath("//div[@class='menu-title-inactive'][normalize-space()='Skills and Capabilities']")).click();
	    Thread.sleep(2000);	
	    {
		     WebElement element = driver.findElement(By.xpath("//div[contains(@class,'mb-3 capability-card-container')]//div[contains(@class,'DraggableTags')]//div[1]//div[1]//div[1]//div[1]//*[name()='svg']")); // Hover on the specialisation ARC
		     Actions builder = new Actions(driver);
		     builder.moveToElement(element).perform();		
		}
	    driver.findElement(By.xpath("//div[@class='DraggableTags ']//div[1]//div[1]//div[1]//div[3]")).click();
	    Thread.sleep(2000);	
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='close-img']")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@class='close-img']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[@class='close-img']")).click();
	    Thread.sleep(2000);	
	    
        /* Skill Testimonials - View Detail */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='menu-title-inactive'][normalize-space()='Skill and Video Testimonials']")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@class='menu-title-inactive'][normalize-space()='Skill and Video Testimonials']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[@class='menu-title-inactive'][normalize-space()='Skill and Video Testimonials']")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//div[normalize-space()='View Full Testimonial >'])[1]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//div[normalize-space()='View Full Testimonial >'])[1]")));Thread.sleep(2000);
	    driver.findElement(By.xpath("(//div[normalize-space()='View Full Testimonial >'])[1]")).click();
	    Thread.sleep(2000); 
	    String winHandleBefore3 = driver.getWindowHandle();
    	driver.findElement(By.xpath("//a[contains(text(),'Shane Watson')]")).click();
    	Thread.sleep(2000);   	// Navigate to New window
    	for(String winHandle : driver.getWindowHandles()){
        driver.switchTo().window(winHandle);
    	}
    	driver.close();
    	Thread.sleep(2000);
    	driver.switchTo().window(winHandleBefore3);
    	Thread.sleep(2000);  
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='close-img']")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@class='close-img']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[@class='close-img']")).click();
	    Thread.sleep(2000);	 
	    
	    /* Skill Testimonial - Shane Watson - PUBLIC VIEW - on Bio Page */ 
    	String winHandleBefore4 = driver.getWindowHandle();
    	driver.findElement(By.xpath("//h3[@class='name-text mb-0'][normalize-space()='Shane Watson']")).click();
    	Thread.sleep(2000);   	// Navigate to New window
    	for(String winHandle : driver.getWindowHandles()){
        driver.switchTo().window(winHandle);
    	}
    	driver.close();
    	Thread.sleep(2000);
    	driver.switchTo().window(winHandleBefore4);
    	Thread.sleep(2000);   	   
	
	    /* Timeline Graph */	
	    driver.findElement(By.xpath("//div[@class='menu-title-inactive'][normalize-space()='Work History']")).click();
	    Thread.sleep(2000);	
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//div[normalize-space()='Expand'])[1]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//div[normalize-space()='Expand'])[1]")));Thread.sleep(2000);
	    driver.findElement(By.xpath("(//div[normalize-space()='Expand'])[1]")).click();
		Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[4]/div[1]/div[1]/div[1]/div[1]/div[2]/div[2]/div[1]/div[1]/div[1]")).click();
		Thread.sleep(2000); 
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='close-img']")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@class='close-img']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[@class='close-img']")).click();
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[normalize-space()='Collapse']")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[normalize-space()='Collapse']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[normalize-space()='Collapse']")).click();
		Thread.sleep(2000);	
    	
        /* Membership and Organisations */	     	   
	    driver.findElement(By.xpath("//div[@class='menu-title-inactive'][normalize-space()='Memberships and Organizations']")).click();
	    Thread.sleep(2000);	
	    driver.findElement(By.xpath("//div[@class='menu-title-inactive'][normalize-space()='Awards and Achievements']")).click();
	    Thread.sleep(2000);	
	    
	    /* Logout */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'My Profile')]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'My Profile')]")));Thread.sleep(2000);
		driver.findElement(By.xpath("//div[contains(text(),'My Profile')]")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//div[contains(text(),'Logout')]")).click();
		Thread.sleep(2000);
   }
}

