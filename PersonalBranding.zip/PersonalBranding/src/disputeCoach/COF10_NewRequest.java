package disputeCoach;

import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import screenshotOnFailure.FailScreenshot;

@Listeners(screenshotListners.EventList.class)
public class COF10_NewRequest extends FailScreenshot{
	
	@Test
	public void COF_CoachRequest() throws InterruptedException {
		
		/* Login to the Application - PBC */ 		
	  	driver.findElement(By.xpath("(//button[normalize-space()='Login'])[1]")).click();
		driver.findElement(By.xpath("//input[@id='Username']")).click();
		driver.findElement(By.xpath("//input[@id='Username']")).sendKeys("john.doe007");
		driver.findElement(By.xpath("//input[@id='password-field']")).click();
		driver.findElement(By.xpath("//input[@id='password-field']")).sendKeys("Rockon123");
		driver.findElement(By.xpath("//button[@id='loginButton']")).click();
		Thread.sleep(2000);
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(120));	
		
	    /* Navigate to Coaching Support Page */
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'My Profile')]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'My Profile')]")));
		Thread.sleep(2000);
		String winHandleBefore = driver.getWindowHandle();
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[normalize-space()='Coaching Request']")));
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[normalize-space()='Coaching Request']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//button[normalize-space()='Coaching Request']")).click();
	    Thread.sleep(2000);
	    for(String winHandle : driver.getWindowHandles()){
	        driver.switchTo().window(winHandle);
	    }
	    Thread.sleep(2000);
	    
	    /* Send Private Coach Request */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".ui-autocomplete-input")));
	    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".ui-autocomplete-input")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".ui-autocomplete-input")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".ui-autocomplete-input")).sendKeys("john tescra");Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".ui-autocomplete-input")).sendKeys(Keys.ENTER);Thread.sleep(2000);
	    driver.findElement(By.cssSelector("#\\35 ee2f8dab4d985c1a0ed9367 .d-none > .btn-maroon")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector("div:nth-child(3) > label > input")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".private")).click();Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("TermsAndCondition")));
	    wait.until(ExpectedConditions.elementToBeClickable(By.id("TermsAndCondition")));Thread.sleep(2000);
	    driver.findElement(By.id("TermsAndCondition")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".btn-lg")).click();
	    Thread.sleep(2000);
	    
	    /* Fill Coach Request Details */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("Title")));
	    wait.until(ExpectedConditions.elementToBeClickable(By.id("Title")));Thread.sleep(2000);
	    driver.findElement(By.id("Title")).click();Thread.sleep(2000);
	    driver.findElement(By.id("Title")).sendKeys("Power BI");
	    Thread.sleep(2000);
	    driver.findElement(By.id("RequestSpecialities")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector("li:nth-child(2) .text-muted")).click();Thread.sleep(2000);
	    driver.findElement(By.id("RequestSpecialities")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector("li:nth-child(3) .text-muted")).click();Thread.sleep(2000);
	    driver.findElement(By.id("RequestSpecialities")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector("#bs-select-1-14 .text-muted")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.id("crossPerformance")).click(); // Remove one speciality
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".mce-i-bold")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".mce-i-bullist")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".back-btn")).click();Thread.sleep(2000);
	    driver.findElement(By.id("btnNoConfirmYesNo")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".next-btn")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".next-btn")).click();Thread.sleep(2000);
	    
	    /* Requirements */
	    wait.until(ExpectedConditions.elementToBeClickable(By.id("Countries_All_")));Thread.sleep(2000);
	    driver.findElement(By.id("Countries_All_")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.elementToBeClickable(By.id("Countries_India_")));Thread.sleep(2000);
	    driver.findElement(By.id("Countries_India_")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".next-btn")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".next-btn")).click();Thread.sleep(2000);
	    
	    /* Coach Preferences */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".days:nth-child(1)")));
	    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".days:nth-child(1)")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".days:nth-child(1)")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".days:nth-child(7)")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".days:nth-child(7)")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.elementToBeClickable(By.id("Preference_Evening")));Thread.sleep(2000);
	    driver.findElement(By.id("Preference_Evening")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.elementToBeClickable(By.id("Preference_IsConnectPerson")));Thread.sleep(2000);
	    driver.findElement(By.id("Preference_IsConnectPerson")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".next-btn")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".next-btn")).click();Thread.sleep(2000);
	    
	    /* Draft and Send Reqquest */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".btn-outline-blue")));
	    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".btn-outline-blue")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".btn-outline-blue")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[@class=\'btn-sm btn-outline-blue margin-right-15\']")));
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[@class=\'btn-sm btn-outline-blue margin-right-15\']")));
	    Thread.sleep(2000);
	    driver.findElement(By.linkText("Edit")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".btn-lg > span")).click();Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[@class=\'btn-sm btn-outline-blue margin-right-15\']")));
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[@class=\'btn-sm btn-outline-blue margin-right-15\']")));
	    Thread.sleep(2000);	    
	    driver.findElement(By.linkText("Delete")).click();Thread.sleep(2000);
	    driver.findElement(By.id("btnNoConfirmYesNo")).click();
	    Thread.sleep(2000);	
    	driver.close();Thread.sleep(2000);
    	driver.switchTo().window(winHandleBefore);
    	Thread.sleep(2000);    
	    
	    /* Logout */
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'My Profile')]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'My Profile')]")));Thread.sleep(2000);
		driver.findElement(By.xpath("//div[contains(text(),'My Profile')]")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//div[contains(text(),'Logout')]")).click();
		Thread.sleep(2000);
	  }
	}



