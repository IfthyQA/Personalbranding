package disputeCoach;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import screenshotOnFailure.FailScreenshot;

@Listeners(screenshotListners.EventList.class)
public class COF30_ApprovePayment extends FailScreenshot{
	
	@Test
	public void COF_ApprovePayment() throws InterruptedException {

		/* Login to the Application - PBC */ 		
	  	driver.findElement(By.xpath("(//button[normalize-space()='Login'])[1]")).click();
		driver.findElement(By.xpath("//input[@id='Username']")).click();
		driver.findElement(By.xpath("//input[@id='Username']")).sendKeys("john.doe007");
		driver.findElement(By.xpath("//input[@id='password-field']")).click();
		driver.findElement(By.xpath("//input[@id='password-field']")).sendKeys("Rockon123");
		driver.findElement(By.xpath("//button[@id='loginButton']")).click();
		Thread.sleep(2000);
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(120));
		
	    /* Navigate to Coaching Support Page */
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'My Profile')]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'My Profile')]")));
		Thread.sleep(2000);
		{
		     WebElement element = driver.findElement(By.xpath("//div[@class='menu-item menu-item-active']"));
		     Actions builder = new Actions(driver);
		     builder.moveToElement(element).perform();
		}
		Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'Coaching Support')]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'Coaching Support')]")));Thread.sleep(2000);
		driver.findElement(By.xpath("//div[contains(text(),'Coaching Support')]")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@id=\'divLeftMenu\']/div[4]/a")));
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@id=\'divLeftMenu\']/div[4]/a")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[@id=\'divLeftMenu\']/div[4]/a")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".form-inline > .btn-blue")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".form-inline > .btn-blue")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".form-inline > .btn-blue")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@id=\'divWorkInProgressModal\']/div/div/div[2]/div/div[5]/div/div[2]/form/button")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@id=\'divWorkInProgressModal\']/div/div/div[2]/div/div[5]/div/div[2]/form/button")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[@id=\'divWorkInProgressModal\']/div/div/div[2]/div/div[5]/div/div[2]/form/button")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[contains(text(),'Work in progress - waiting for coach to complete milestone')]")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[contains(text(),'Work in progress - waiting for coach to complete milestone')]")));
	    Thread.sleep(2000);
		
	    /* Logout */
		 wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'My Profile')]")));
		 wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'My Profile')]")));Thread.sleep(2000);
		 driver.findElement(By.xpath("//div[contains(text(),'My Profile')]")).click();
		 Thread.sleep(2000);
		 driver.findElement(By.xpath("(//div[contains(text(),'Logout')])[2]")).click();
		 Thread.sleep(2000);
	  }
	}

