package disputeCoach;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import screenshotOnFailure.FailScreenshot;

@Listeners(screenshotListners.EventList.class)
public class COF40_RaiseDispute extends FailScreenshot {
	
	@Test
	public void COF_RaiseDispute() throws InterruptedException {

		/* Login to the Application - PBC */ 		
	  	driver.findElement(By.xpath("(//button[normalize-space()='Login'])[1]")).click();
		driver.findElement(By.xpath("//input[@id='Username']")).click();
		driver.findElement(By.xpath("//input[@id='Username']")).sendKeys("john.doe007");
		driver.findElement(By.xpath("//input[@id='password-field']")).click();
		driver.findElement(By.xpath("//input[@id='password-field']")).sendKeys("Rockon123");
		driver.findElement(By.xpath("//button[@id='loginButton']")).click();
		Thread.sleep(2000);
		 WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(120));
		
	    /* Navigate to Coaching Support Page */
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'My Profile')]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'My Profile')]")));Thread.sleep(2000);
		{
		     WebElement element = driver.findElement(By.xpath("//div[@class='menu-item menu-item-active']"));
		     Actions builder = new Actions(driver);
		     builder.moveToElement(element).perform();
		}
		Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'Coaching Support')]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'Coaching Support')]")));Thread.sleep(2000);
		driver.findElement(By.xpath("//div[contains(text(),'Coaching Support')]")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[@id=\'divLeftMenu\']/div[4]/a")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".form-inline .d-none")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".btn-blue-link-12")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("//span[2]/button")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".modal-lg .fa")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".btn-outline-grey")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.id("btnNoConfirmYesNo")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("//span[contains(.,\'View Details\')]")).click();
	    Thread.sleep(2000);
	    JavascriptExecutor jse = (JavascriptExecutor)driver;
	    jse.executeScript("scroll(0, -250);");
	    Thread.sleep(2000);
	    driver.findElement(By.linkText("Back to Work In Progress")).click();
	    Thread.sleep(2000);
	    
	    /* Raise Dispute */
	    driver.findElement(By.cssSelector(".btn-outline-grey")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.id("btnYesConfirmYesNo")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("DisputeDetails")));
	    wait.until(ExpectedConditions.elementToBeClickable(By.id("DisputeDetails")));Thread.sleep(2000);
	    driver.findElement(By.id("DisputeDetails")).click();
	    driver.findElement(By.id("DisputeDetails")).sendKeys("I am not happy with your coaching.");
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".btn-grey")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.id("btnNoConfirmYesNo")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".float-right > .btn-blue")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".menu-list-active .fa")).click();
	    Thread.sleep(2000);
	    
	    /* View Details after Dispute Raised */
	    driver.findElement(By.cssSelector("form > .btn-sm")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".coaching-selected-task-title .fa")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".coaching-selected-task-title .fa")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".coaching-selected-task-title .fa")).click();
	    Thread.sleep(2000);
	    
	    /* Edit Dispute */
	    driver.findElement(By.cssSelector(".btn-outline-blue > span")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("DisputeDetails")));
	    wait.until(ExpectedConditions.elementToBeClickable(By.id("DisputeDetails")));Thread.sleep(2000);
	    driver.findElement(By.id("DisputeDetails")).clear();
	    driver.findElement(By.id("DisputeDetails")).sendKeys("I am not happy with your coaching. Please Refund");
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".margin-top-15 .btn-sm")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("//button[contains(.,\'Send\')]")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".menu-list-active > a")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("//span[contains(.,\'View Details\')]")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".form-inline span:nth-child(2)")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".btn-blue-link-12 > span")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".float-md-right > .btn-blue-link-12 > .d-none")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".fa-user-plus")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.id("submitbtn")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".biz-admin-overlay > .modal-header .fa")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".fa-angle-down")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".fa-angle-up")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("//span[2]/button")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".modal-lg .fa")).click();
	    Thread.sleep(2000);
	    
	    /* Logout */
		 wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'My Profile')]")));
		 wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'My Profile')]")));Thread.sleep(2000);
		 driver.findElement(By.xpath("//div[contains(text(),'My Profile')]")).click();
		 Thread.sleep(2000);
		 driver.findElement(By.xpath("(//div[contains(text(),'Logout')])[2]")).click();
		 Thread.sleep(2000);
	  }
	}

