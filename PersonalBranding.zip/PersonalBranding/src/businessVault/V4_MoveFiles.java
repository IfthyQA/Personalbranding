package businessVault;

import java.io.IOException;
import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import screenshotOnFailure.FailScreenshot;

@Listeners(screenshotListners.EventList.class)
public class V4_MoveFiles extends FailScreenshot{
	
	@Test
	public void Vault_MoveFiles() throws InterruptedException, IOException{	
		 
	/* Login to the Application */ 		
	driver.findElement(By.xpath("(//button[normalize-space()='Login'])[1]")).click();
	driver.findElement(By.xpath("//input[@id='Username']")).click();
	driver.findElement(By.xpath("//input[@id='Username']")).sendKeys("john.doe006");
	driver.findElement(By.xpath("//input[@id='password-field']")).click();
	driver.findElement(By.xpath("//input[@id='password-field']")).sendKeys("Rockon123");
	driver.findElement(By.xpath("//button[@id='loginButton']")).click();
	Thread.sleep(2000);
	WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(120));
    
    /* Manage Business Page */
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[normalize-space()='Coach Assessment']")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()='Coach Assessment']")));Thread.sleep(2000);
    driver.findElement(By.xpath("//span[normalize-space()='Coach Assessment']")).click();
    Thread.sleep(2000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[normalize-space()='Menu']")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()='Menu']")));Thread.sleep(2000);
    driver.findElement(By.xpath("//span[normalize-space()='Menu']")).click();
    Thread.sleep(2000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[normalize-space()='Business Vault']")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[normalize-space()='Business Vault']")));Thread.sleep(2000);
    driver.findElement(By.xpath("//a[normalize-space()='Business Vault']")).click();
    Thread.sleep(2000);  
    
    /*  Move file to Page Administrative Folder */
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[6]/div/button/i")));	
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[6]/div/button/i")));Thread.sleep(2000);
    driver.findElement(By.xpath("//div[6]/div/button/i")).click();
    Thread.sleep(2000);
    driver.findElement(By.cssSelector(".show .btnMoveFile")).click();
    Thread.sleep(2000);
    driver.findElement(By.cssSelector(".select2-search__field")).sendKeys("admin");
    Thread.sleep(3000);
    driver.findElement(By.cssSelector(".select2-search__field")).sendKeys(Keys.ENTER);
    Thread.sleep(2000);
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[6]/div/button/i")));	
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[6]/div/button/i")));Thread.sleep(2000);
    driver.findElement(By.id("download5ef045e0765c70eb832c39cb")).click();
    Thread.sleep(2000);
    driver.findElement(By.xpath("//div[6]/div/button/i")).click();
    Thread.sleep(2000);
    driver.findElement(By.cssSelector(".show .btnShareFile")).click();
    Thread.sleep(2000);
    driver.findElement(By.cssSelector("span:nth-child(3) > #IsTeam")).click();
    Thread.sleep(2000);
    driver.findElement(By.id("IsTeam")).click();
    Thread.sleep(2000);
    driver.findElement(By.cssSelector(".autocompleteSugName")).click();
    Thread.sleep(2000);
    driver.findElement(By.cssSelector(".col-12:nth-child(1) > .btn-blue")).click();
	wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".toast-message")));
	driver.findElement(By.cssSelector(".toast-message")).click(); 
    Thread.sleep(2000);
    
    /* Move back to Main Folder */
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[6]/div/button/i")));	
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[6]/div/button/i")));Thread.sleep(2000);
    driver.findElement(By.xpath("//div[6]/div/button/i")).click();
    Thread.sleep(2000);
    driver.findElement(By.cssSelector(".show .btnMoveFile")).click();
    Thread.sleep(2000);
    driver.findElement(By.cssSelector(".select2-search__field")).sendKeys("vault");
    Thread.sleep(2000);
    driver.findElement(By.cssSelector(".select2-search__field")).sendKeys(Keys.ENTER);
    Thread.sleep(2000);
	wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".toast-message")));
	driver.findElement(By.cssSelector(".toast-message")).click(); 
	Thread.sleep(2000);
    driver.findElement(By.xpath("//span[normalize-space()='Business Vault']")).click();
    wait.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath("//span[normalize-space()='Business Vault']")));
    Thread.sleep(2000);  
    
    /* Logout from Coach Page */
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'My Profile')]")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'My Profile')]")));Thread.sleep(2000);
	driver.findElement(By.xpath("//div[contains(text(),'My Profile')]")).click();  
	Thread.sleep(2000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//div[contains(text(),'Logout')])[1]")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//div[contains(text(),'Logout')])[1]")));Thread.sleep(2000);
	driver.findElement(By.xpath("(//div[contains(text(),'Logout')])[1]")).click();  
	Thread.sleep(2000);
  }
}


