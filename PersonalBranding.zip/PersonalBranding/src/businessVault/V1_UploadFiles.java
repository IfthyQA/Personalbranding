package businessVault;

import java.io.IOException;
import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import screenshotOnFailure.FailScreenshot;

@Listeners(screenshotListners.EventList.class)
public class V1_UploadFiles extends FailScreenshot{
	
	@Test
	public void Vault_uploadFiles() throws InterruptedException, IOException{	
		 
	/* Login to the Application */ 		
	driver.findElement(By.xpath("(//button[normalize-space()='Login'])[1]")).click();
	driver.findElement(By.xpath("//input[@id='Username']")).click();
	driver.findElement(By.xpath("//input[@id='Username']")).sendKeys("john.doe006");
	driver.findElement(By.xpath("//input[@id='password-field']")).click();
	driver.findElement(By.xpath("//input[@id='password-field']")).sendKeys("Rockon123");
	driver.findElement(By.xpath("//button[@id='loginButton']")).click();
	Thread.sleep(2000);
	WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(120));
    
    /* Manage Business Page */
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[normalize-space()='Coach Assessment']")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()='Coach Assessment']")));Thread.sleep(2000);
    driver.findElement(By.xpath("//span[normalize-space()='Coach Assessment']")).click();
    Thread.sleep(2000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[normalize-space()='Menu']")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()='Menu']")));Thread.sleep(2000);
    driver.findElement(By.xpath("//span[normalize-space()='Menu']")).click();
    Thread.sleep(2000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[normalize-space()='Business Vault']")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[normalize-space()='Business Vault']")));Thread.sleep(2000);
    driver.findElement(By.xpath("//a[normalize-space()='Business Vault']")).click();
    Thread.sleep(2000);
    
    /* Upload File from Local */ 
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[normalize-space()='UPLOAD']")));	
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()='UPLOAD']")));Thread.sleep(2000);
    driver.findElement(By.xpath("//span[normalize-space()='UPLOAD']")).click();
    Thread.sleep(2000);   // Opens File Dialog on Machine
    Runtime.getRuntime().exec("C:\\Users\\dev\\Documents\\AutoScripts\\Upload.exe");
	wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".toast-message")));
	driver.findElement(By.cssSelector(".toast-message")).click();
    
    /* Rename the Uploaded File from Local */ 
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//div[6]/div/button/i)[1]")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//div[6]/div/button/i)[1]")));Thread.sleep(2000); 
    driver.findElement(By.xpath("(//div[6]/div/button/i)[1]")).click();
    Thread.sleep(2000);
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//ul[@class=\'dropdown-menu show\']//button[@class=\'invisibleButton btn-blue-link btnEditFile\'][normalize-space()=\'Edit\']")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//ul[@class=\'dropdown-menu show\']//button[@class=\'invisibleButton btn-blue-link btnEditFile\'][normalize-space()=\'Edit\']")));Thread.sleep(2000);
    driver.findElement(By.xpath("//ul[@class=\'dropdown-menu show\']//button[@class=\'invisibleButton btn-blue-link btnEditFile\'][normalize-space()=\'Edit\']")).click();    
    Thread.sleep(2000);
    driver.findElement(By.id("FileName")).click();
    driver.findElement(By.id("FileName")).clear();
    driver.findElement(By.id("FileName")).sendKeys("Local File");
    Thread.sleep(2000);
    driver.findElement(By.cssSelector(".ui-autocomplete-input")).click();
    driver.findElement(By.cssSelector(".ui-autocomplete-input")).sendKeys("Local");
    driver.findElement(By.cssSelector(".ui-autocomplete-input")).sendKeys(Keys.ENTER);
    Thread.sleep(2000);
	wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".btn-blue")));Thread.sleep(2000); 
    driver.findElement(By.cssSelector(".btn-blue")).click();
	wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".toast-message")));
	driver.findElement(By.cssSelector(".toast-message")).click();
    
    /* Delete Uploaded File */
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[6]/div/button/i")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[6]/div/button/i")));Thread.sleep(2000);
    driver.findElement(By.xpath("//div[6]/div/button/i")).click();
    Thread.sleep(2000);
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//ul[@class='dropdown-menu show']//button[@type='button'][normalize-space()='Trash']")));
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//ul[@class='dropdown-menu show']//button[@type='button'][normalize-space()='Trash']")));
    Thread.sleep(2000);
    driver.findElement(By.xpath("//ul[@class='dropdown-menu show']//button[@type='button'][normalize-space()='Trash']")).click();
    Thread.sleep(2000);
    driver.findElement(By.id("btnYesConfirmYesNo")).click(); 
	wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".toast-message")));
	driver.findElement(By.cssSelector(".toast-message")).click();    
    
    /* Trash to Permanent Delete */
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".float-left")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".float-left")));Thread.sleep(2000);
    driver.findElement(By.cssSelector(".float-left")).click();
    Thread.sleep(2000);
    driver.findElement(By.linkText("Trash")).click();
    Thread.sleep(2000);
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//i[@class='fa fa-ellipsis-v']")));	
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//i[@class='fa fa-ellipsis-v']")));
    Thread.sleep(2000);
    driver.findElement(By.xpath("//i[@class='fa fa-ellipsis-v']")).click();
    Thread.sleep(2000);
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[normalize-space()='Delete']")));
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[normalize-space()='Delete']")));Thread.sleep(2000);	
    driver.findElement(By.xpath("//button[normalize-space()='Delete']")).click();
    Thread.sleep(2000);
    driver.findElement(By.id("btnYesConfirmYesNo")).click();
	wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".toast-message")));
	driver.findElement(By.cssSelector(".toast-message")).click();    
    
	/* Logout from Coach Page */
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'My Profile')]")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'My Profile')]")));Thread.sleep(2000);
	driver.findElement(By.xpath("//div[contains(text(),'My Profile')]")).click();  
	Thread.sleep(2000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//div[contains(text(),'Logout')])[1]")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//div[contains(text(),'Logout')])[1]")));Thread.sleep(2000);
	driver.findElement(By.xpath("(//div[contains(text(),'Logout')])[1]")).click();  
	Thread.sleep(2000);
  }
}


