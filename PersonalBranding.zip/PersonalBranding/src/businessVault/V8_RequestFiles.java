package businessVault;

import java.io.IOException;
import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import screenshotOnFailure.FailScreenshot;

@Listeners(screenshotListners.EventList.class)
public class V8_RequestFiles extends FailScreenshot{
	
	@Test
	public void Vault_Request_Files() throws InterruptedException, IOException{	
		 
	/* Login to the Application */ 		
	driver.findElement(By.xpath("(//button[normalize-space()='Login'])[1]")).click();
	driver.findElement(By.xpath("//input[@id='Username']")).click();
	driver.findElement(By.xpath("//input[@id='Username']")).sendKeys("john.doe006");
	driver.findElement(By.xpath("//input[@id='password-field']")).click();
	driver.findElement(By.xpath("//input[@id='password-field']")).sendKeys("Rockon123");
	driver.findElement(By.xpath("//button[@id='loginButton']")).click();
	Thread.sleep(2000);
	WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(120));
    
    /* Manage Business Page */
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[normalize-space()='Coach Assessment']")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()='Coach Assessment']")));Thread.sleep(2000);
    driver.findElement(By.xpath("//span[normalize-space()='Coach Assessment']")).click();
    Thread.sleep(2000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[normalize-space()='Menu']")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()='Menu']")));Thread.sleep(2000);
    driver.findElement(By.xpath("//span[normalize-space()='Menu']")).click();
    Thread.sleep(2000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[normalize-space()='Business Vault']")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[normalize-space()='Business Vault']")));Thread.sleep(2000);
    driver.findElement(By.xpath("//a[normalize-space()='Business Vault']")).click();
    Thread.sleep(2000);
          
    /* Request Files */
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[contains(text(),\'Page Administrative Team\')]")));
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[contains(text(),\'Page Administrative Team\')]")));Thread.sleep(2000);
    driver.findElement(By.xpath("//a[contains(text(),\'Page Administrative Team\')]")).click();
    Thread.sleep(2000);
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[contains(text(),\'REQUEST FILES\')]")));
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[contains(text(),\'REQUEST FILES\')]")));Thread.sleep(2000);
    driver.findElement(By.xpath("//span[contains(text(),\'REQUEST FILES\')]")).click();
    Thread.sleep(2000);
    driver.findElement(By.xpath("//input[@id=\'NameorEmail\']")).click(); Thread.sleep(2000);
    driver.findElement(By.xpath("//input[@id=\'NameorEmail\']")).sendKeys("Adam Sula");
    Thread.sleep(2000);
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".autocompleteSugLoc")));	
    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".autocompleteSugLoc")));Thread.sleep(2000);
    driver.findElement(By.cssSelector(".autocompleteSugLoc")).click();
    Thread.sleep(2000);
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".input-group label")));	
    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".input-group label")));Thread.sleep(2000);   
    driver.findElement(By.cssSelector(".input-group label")).click();
    Thread.sleep(2000);
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".datepicker-days .next")));	
    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".datepicker-days .next")));Thread.sleep(2000);   
    driver.findElement(By.cssSelector(".datepicker-days .next")).click();
    Thread.sleep(2000);
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("tr:nth-child(2) > .day:nth-child(4)")));	
    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector("tr:nth-child(2) > .day:nth-child(4)")));Thread.sleep(2000);   
    driver.findElement(By.cssSelector("tr:nth-child(2) > .day:nth-child(4)")).click();
    Thread.sleep(2000);
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@id=\'FolderName\']")));	
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@id=\'FolderName\']")));Thread.sleep(2000);   
    driver.findElement(By.xpath("//input[@id=\'FolderName\']")).click();
    driver.findElement(By.xpath("//input[@id=\'FolderName\']")).sendKeys("Automation File Request");
    Thread.sleep(2000);
    driver.findElement(By.cssSelector(".mce-i-numlist")).click();Thread.sleep(2000);
    driver.findElement(By.cssSelector(".mce-i-bold")).click();Thread.sleep(2000);
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[@class=\'btn-sm btn-blue btnRequestFiles\']")));Thread.sleep(2000); 
    driver.findElement(By.xpath("//button[@class=\'btn-sm btn-blue btnRequestFiles\']")).click();
    Thread.sleep(2000);

    /* Revoke Request Files */
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[normalize-space()=\'FOLDER INFO\']")));	
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()=\'FOLDER INFO\']")));Thread.sleep(2000);
    driver.findElement(By.xpath("//span[normalize-space()=\'FOLDER INFO\']")).click();
    Thread.sleep(2000);
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@id='requestfilepopup']//i[@class='fa fa-times']")));	
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@id='requestfilepopup']//i[@class='fa fa-times']")));Thread.sleep(2000);
    driver.findElement(By.xpath("//div[@id='requestfilepopup']//i[@class='fa fa-times']")).click();
    Thread.sleep(2000);
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[normalize-space()=\'REVOKE ACCESS\']")));	
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()=\'REVOKE ACCESS\']")));Thread.sleep(2000);   
    driver.findElement(By.xpath("//span[normalize-space()=\'REVOKE ACCESS\']")).click();
    Thread.sleep(2000);
    wait.until(ExpectedConditions.elementToBeClickable(By.id("btnYesConfirmYesNo")));Thread.sleep(2000);
    driver.findElement(By.id("btnYesConfirmYesNo")).click(); Thread.sleep(2000);
    
    /* Delete Request File Folder */
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[contains(text(),\'Page Admin…\')]")));	
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[contains(text(),\'Page Admin…\')]")));Thread.sleep(2000);  
    driver.findElement(By.xpath("//span[contains(text(),\'Page Admin…\')]")).click();
    Thread.sleep(2000);
    driver.findElement(By.xpath("//div[6]/div/button/i")).click(); Thread.sleep(2000);
    driver.findElement(By.cssSelector("li:nth-child(3) > form > .invisibleButton")).click(); Thread.sleep(2000);
    driver.findElement(By.id("btnYesConfirmYesNo")).click(); Thread.sleep(2000);
    driver.findElement(By.cssSelector(".float-left")).click();
    Thread.sleep(2000);
    driver.findElement(By.linkText("Trash")).click();
    Thread.sleep(2000);
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//i[@class='fa fa-ellipsis-v']")));	
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//i[@class='fa fa-ellipsis-v']")));Thread.sleep(2000);
    driver.findElement(By.xpath("//i[@class='fa fa-ellipsis-v']")).click();
    Thread.sleep(2000);
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[normalize-space()='Delete']")));
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[normalize-space()='Delete']")));Thread.sleep(2000);	
    driver.findElement(By.xpath("//button[normalize-space()='Delete']")).click();
    Thread.sleep(2000);
    wait.until(ExpectedConditions.elementToBeClickable(By.id("btnYesConfirmYesNo")));Thread.sleep(2000);
    driver.findElement(By.id("btnYesConfirmYesNo")).click();
    Thread.sleep(2000);
    
    /* Logout from Coach Page */
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'My Profile')]")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'My Profile')]")));Thread.sleep(2000);
	driver.findElement(By.xpath("//div[contains(text(),'My Profile')]")).click();  
	Thread.sleep(2000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//div[contains(text(),'Logout')])[1]")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//div[contains(text(),'Logout')])[1]")));Thread.sleep(2000);
	driver.findElement(By.xpath("(//div[contains(text(),'Logout')])[1]")).click();  
	Thread.sleep(2000);
  }
}


