package businessVault;

import java.io.IOException;
import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import screenshotOnFailure.FailScreenshot;

@Listeners(screenshotListners.EventList.class)
public class V6_SearchDelete_Files extends FailScreenshot{
	
	@Test
	public void Vault_SearchFiles() throws InterruptedException, IOException{	
		 
	/* Login to the Application */ 		
	driver.findElement(By.xpath("(//button[normalize-space()='Login'])[1]")).click();
	driver.findElement(By.xpath("//input[@id='Username']")).click();
	driver.findElement(By.xpath("//input[@id='Username']")).sendKeys("john.doe006");
	driver.findElement(By.xpath("//input[@id='password-field']")).click();
	driver.findElement(By.xpath("//input[@id='password-field']")).sendKeys("Rockon123");
	driver.findElement(By.xpath("//button[@id='loginButton']")).click();
	Thread.sleep(2000);
	WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(120));
    
    /* Manage Business Page */
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[normalize-space()='Coach Assessment']")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()='Coach Assessment']")));Thread.sleep(2000);
    driver.findElement(By.xpath("//span[normalize-space()='Coach Assessment']")).click();
    Thread.sleep(2000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[normalize-space()='Menu']")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()='Menu']")));Thread.sleep(2000);
    driver.findElement(By.xpath("//span[normalize-space()='Menu']")).click();
    Thread.sleep(2000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[normalize-space()='Business Vault']")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[normalize-space()='Business Vault']")));Thread.sleep(2000);
    driver.findElement(By.xpath("//a[normalize-space()='Business Vault']")).click();
    Thread.sleep(2000);
    
    /* Search Files */
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("btnSearchFileFolder")));	
    wait.until(ExpectedConditions.elementToBeClickable(By.id("btnSearchFileFolder")));Thread.sleep(3000);
    driver.findElement(By.id("btnSearchFileFolder")).click();
    Thread.sleep(2000);
    driver.findElement(By.xpath("//div[@id='searchfilefolderpopup']/div[2]/form/div/div[2]/button")).click();
    Thread.sleep(2000);
    driver.findElement(By.id("Keyword")).click();
    Thread.sleep(2000);
    driver.findElement(By.id("Keyword")).sendKeys("Benelli");
    Thread.sleep(2000);
    driver.findElement(By.xpath("//span[normalize-space()='SEARCH']")).click();
    Thread.sleep(2000); 
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".btn-outline-grey")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".btn-outline-grey")));Thread.sleep(2000);
	
		    String winHandleBefore1 = driver.getWindowHandle();
		    driver.findElement(By.xpath("//a[contains(text(),'Benelli.jpg')]")).click();
		    Thread.sleep(2000);
			/* Navigate to New window */
			for(String winHandle : driver.getWindowHandles()){
		    driver.switchTo().window(winHandle);
			}
			Thread.sleep(2000);
		    driver.close();
		    driver.switchTo().window(winHandleBefore1);
		    Thread.sleep(2000);
		    
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".btn-outline-grey")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".btn-outline-grey")));Thread.sleep(2000);
	driver.findElement(By.cssSelector(".btn-outline-grey")).click();
    Thread.sleep(2000);
    
    /* Delete & Restore */
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[4]/div/div/div[6]/div/button/i")));	
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[4]/div/div/div[6]/div/button/i")));Thread.sleep(3000);
    driver.findElement(By.xpath("//div[4]/div/div/div[6]/div/button/i")).click();
    Thread.sleep(2000);
    driver.findElement(By.cssSelector(".show .btnEditFile")).click();
    Thread.sleep(2000);
    driver.findElement(By.cssSelector(".btn-outline-grey")).click();
    Thread.sleep(2000);
    driver.findElement(By.id("btnYesConfirmYesNo")).click();
    Thread.sleep(2000);
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@class='toast-message']")));
	driver.findElement(By.xpath("//button[@role='button']//*[name()='svg']")).click();
	Thread.sleep(2000);
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("btnSearchFileFolder")));	
    wait.until(ExpectedConditions.elementToBeClickable(By.id("btnSearchFileFolder")));
    driver.findElement(By.id("btnSearchFileFolder")).click();
    Thread.sleep(2000);
    {
      WebElement element = driver.findElement(By.id("Keyword"));
      Actions builder = new Actions(driver);
      builder.doubleClick(element).perform();
    }
    Thread.sleep(2000);
    driver.findElement(By.id("Keyword")).sendKeys("benelli");
    Thread.sleep(2000);
    driver.findElement(By.xpath("//div[@id='searchfilefolderpopup']/div[2]/form/div/div[2]/button")).click();
    Thread.sleep(2000);
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[@class='btn-sm btn-outline-grey']")));	
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[@class='btn-sm btn-outline-grey']")));
    Thread.sleep(2000);
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("btnSearchFileFolder")));	
    wait.until(ExpectedConditions.elementToBeClickable(By.id("btnSearchFileFolder")));Thread.sleep(2000);
    driver.findElement(By.id("btnSearchFileFolder")).click();
    Thread.sleep(2000);
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@id='searchfilefolderpopup']/div[2]/form/div/div[2]/button")));	
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@id='searchfilefolderpopup']/div[2]/form/div/div[2]/button")));
    driver.findElement(By.xpath("//div[@id='searchfilefolderpopup']/div[2]/form/div/div[2]/button")).click();
    Thread.sleep(2000);
    driver.findElement(By.cssSelector("#searchfilefolderpopup > .modal-header .fa")).click();
    Thread.sleep(2000);
    driver.findElement(By.cssSelector(".btn-outline-grey")).click();
    Thread.sleep(2000);
    
    /* Restore the Deleted Files */
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".float-left")));	
    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".float-left")));Thread.sleep(2000);
    driver.findElement(By.cssSelector(".float-left")).click();
    Thread.sleep(2000);
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.linkText("Trash")));	
    wait.until(ExpectedConditions.elementToBeClickable(By.linkText("Trash")));Thread.sleep(2000);
    driver.findElement(By.linkText("Trash")).click();
    Thread.sleep(2000);
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//i[@class='fa fa-ellipsis-v']")));	
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//i[@class='fa fa-ellipsis-v']")));Thread.sleep(2000);
    driver.findElement(By.xpath("//i[@class='fa fa-ellipsis-v']")).click();
    Thread.sleep(2000);
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("li:nth-child(1) .btn-blue-link")));	
    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector("li:nth-child(1) .btn-blue-link")));Thread.sleep(2000);
    driver.findElement(By.cssSelector("li:nth-child(1) .btn-blue-link")).click();
    Thread.sleep(2000);
    driver.findElement(By.cssSelector(".btn > .d-none")).click();
    Thread.sleep(2000);
     
    /* Logout from Coach Page */
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'My Profile')]")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'My Profile')]")));Thread.sleep(2000);
	driver.findElement(By.xpath("//div[contains(text(),'My Profile')]")).click();  
	Thread.sleep(2000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//div[contains(text(),'Logout')])[1]")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//div[contains(text(),'Logout')])[1]")));Thread.sleep(2000);
	driver.findElement(By.xpath("(//div[contains(text(),'Logout')])[1]")).click();  
	Thread.sleep(2000);
  }
}


