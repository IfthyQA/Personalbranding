package businessVault;

import java.io.IOException;
import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import screenshotOnFailure.FailScreenshot;

@Listeners(screenshotListners.EventList.class)
public class V2_CreateFolders extends FailScreenshot{
	
	@Test
	public void Vault_CreateFolders() throws InterruptedException, IOException{	
		 
	/* Login to the Application */ 		
	driver.findElement(By.xpath("(//button[normalize-space()='Login'])[1]")).click();
	driver.findElement(By.xpath("//input[@id='Username']")).click();
	driver.findElement(By.xpath("//input[@id='Username']")).sendKeys("john.doe006");
	driver.findElement(By.xpath("//input[@id='password-field']")).click();
	driver.findElement(By.xpath("//input[@id='password-field']")).sendKeys("Rockon123");
	driver.findElement(By.xpath("//button[@id='loginButton']")).click();
	Thread.sleep(2000);
	WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(120));
    
    /* Manage Business Page */
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[normalize-space()='Coach Assessment']")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()='Coach Assessment']")));Thread.sleep(2000);
    driver.findElement(By.xpath("//span[normalize-space()='Coach Assessment']")).click();
    Thread.sleep(2000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[normalize-space()='Menu']")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()='Menu']")));Thread.sleep(2000);
    driver.findElement(By.xpath("//span[normalize-space()='Menu']")).click();
    Thread.sleep(2000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[normalize-space()='Business Vault']")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[normalize-space()='Business Vault']")));Thread.sleep(2000);
    driver.findElement(By.xpath("//a[normalize-space()='Business Vault']")).click();
    Thread.sleep(2000); 
    
    /* Create Folder and Sub Folder */
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".businessvault-new-folder")));
	wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".businessvault-new-folder")));Thread.sleep(3000);
    driver.findElement(By.cssSelector(".businessvault-new-folder")).click();
    Thread.sleep(2000);
    driver.findElement(By.cssSelector("#createfolderpopup > .modal-header .fa")).click();
    Thread.sleep(2000);
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".businessvault-new-folder")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".businessvault-new-folder")));Thread.sleep(3000);
    driver.findElement(By.cssSelector(".businessvault-new-folder")).click();
    Thread.sleep(2000);
    driver.findElement(By.id("Name")).click();
    driver.findElement(By.id("Name")).clear();
    driver.findElement(By.id("Name")).sendKeys("!@#$%^.,3543");Thread.sleep(2000);
    driver.findElement(By.id("Name")).clear();
    driver.findElement(By.id("Name")).sendKeys("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxy");
	wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".toast-message")));
	driver.findElement(By.cssSelector(".toast-message")).click();
    driver.findElement(By.id("Name")).clear();
    driver.findElement(By.id("Name")).sendKeys("Automation");
    Thread.sleep(2000);
    driver.findElement(By.xpath("//div[@id=\'createfolderpopup\']/div[2]/div/form/div[2]/button")).click();
	wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".toast-message")));
	driver.findElement(By.cssSelector(".toast-message")).click();
    Thread.sleep(2000);
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".businessvault-new-folder")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".businessvault-new-folder")));Thread.sleep(3000);
    driver.findElement(By.cssSelector(".businessvault-new-folder")).click();
    Thread.sleep(2000);
    driver.findElement(By.id("Name")).click();
    driver.findElement(By.id("Name")).clear();
    driver.findElement(By.id("Name")).sendKeys("!@#$%^.,3543");Thread.sleep(2000);
    driver.findElement(By.id("Name")).clear();
    driver.findElement(By.id("Name")).sendKeys("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxy");
	wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".toast-message")));Thread.sleep(2000);
	driver.findElement(By.cssSelector(".toast-message")).click();
    driver.findElement(By.id("Name")).clear();
    driver.findElement(By.id("Name")).sendKeys("Sub Folder");
    Thread.sleep(2000);
    driver.findElement(By.xpath("//div[@id=\'createfolderpopup\']/div[2]/div/form/div[2]/button")).click();
	wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".toast-message")));Thread.sleep(2000);
	driver.findElement(By.cssSelector(".toast-message")).click(); 
    Thread.sleep(2000);
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".col-12 > .invisibleButton")));	
    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".col-12 > .invisibleButton")));Thread.sleep(3000);	
    driver.findElement(By.cssSelector(".col-12 > .invisibleButton")).click();
    Thread.sleep(3000);
    driver.findElement(By.cssSelector(".invisibleButton > .float-left")).click();
    Thread.sleep(3000);
    driver.findElement(By.cssSelector(".btn:nth-child(2) > .btn > span")).click();
    Thread.sleep(2000);
    driver.findElement(By.xpath("//span[normalize-space()='Business Vault']")).click();
    wait.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath("//span[normalize-space()='Business Vault']")));
    Thread.sleep(2000);
    
    /* Delete the created Folder */
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[6]/div/button/i")));	
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[6]/div/button/i")));Thread.sleep(2000);
    driver.findElement(By.xpath("//div[6]/div/button/i")).click();
    Thread.sleep(2000);
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//ul[@class='dropdown-menu show']//button[@type='button'][normalize-space()='Trash']")));	
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//ul[@class='dropdown-menu show']//button[@type='button'][normalize-space()='Trash']")));Thread.sleep(2000);
    driver.findElement(By.xpath("//ul[@class='dropdown-menu show']//button[@type='button'][normalize-space()='Trash']")).click();
    Thread.sleep(2000);
    driver.findElement(By.id("btnYesConfirmYesNo")).click();
	wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".toast-message")));
	driver.findElement(By.cssSelector(".toast-message")).click(); 
    Thread.sleep(2000);
    
    /* Trash to Permanent Delete */
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".float-left")));	
    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".float-left")));Thread.sleep(2000);
    driver.findElement(By.cssSelector(".float-left")).click();
    Thread.sleep(2000);
    driver.findElement(By.linkText("Trash")).click();
    Thread.sleep(2000);
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//i[@class='fa fa-ellipsis-v']")));	
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//i[@class='fa fa-ellipsis-v']")));Thread.sleep(3000);
    driver.findElement(By.xpath("//i[@class='fa fa-ellipsis-v']")).click();
    Thread.sleep(2000);
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[normalize-space()='Delete']")));
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[normalize-space()='Delete']")));Thread.sleep(2000);	
    driver.findElement(By.xpath("//button[normalize-space()='Delete']")).click();
    Thread.sleep(2000);
    driver.findElement(By.id("btnYesConfirmYesNo")).click();
	wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".toast-message")));
	driver.findElement(By.cssSelector(".toast-message")).click(); 
    
    /* Public View of Uploader */
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@id=\'divMain\']/div/div/div/div/div/form/button/span")));
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@id=\'divMain\']/div/div/div/div/div/form/button/span")));Thread.sleep(2000);
    driver.findElement(By.xpath("//div[@id=\'divMain\']/div/div/div/div/div/form/button/span")).click();Thread.sleep(2000);    
		    String winHandleBefore = driver.getWindowHandle();
		    driver.findElement(By.linkText("Benelli Sebastian")).click();
		    Thread.sleep(2000);			// Navigate to New window
			for(String winHandle : driver.getWindowHandles()){
		    driver.switchTo().window(winHandle);
			}
		    Thread.sleep(2000);
		    driver.close();
		    driver.switchTo().window(winHandleBefore);
	Thread.sleep(2000);
       
	/* Logout from Coach Page */
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'My Profile')]")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'My Profile')]")));Thread.sleep(2000);
	driver.findElement(By.xpath("//div[contains(text(),'My Profile')]")).click();  
	Thread.sleep(2000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//div[contains(text(),'Logout')])[1]")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//div[contains(text(),'Logout')])[1]")));Thread.sleep(2000);
	driver.findElement(By.xpath("(//div[contains(text(),'Logout')])[1]")).click();  
	Thread.sleep(2000);
  }
}


