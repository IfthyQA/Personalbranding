package businessVault;

import java.io.IOException;
import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import screenshotOnFailure.FailScreenshot;

@Listeners(screenshotListners.EventList.class)
public class V3_RenameFiles extends FailScreenshot{
	
	@Test
	public void Vault_Rename_Files() throws InterruptedException, IOException{	
		 
	/* Login to the Application */ 		
	driver.findElement(By.xpath("(//button[normalize-space()='Login'])[1]")).click();
	driver.findElement(By.xpath("//input[@id='Username']")).click();
	driver.findElement(By.xpath("//input[@id='Username']")).sendKeys("john.doe006");
	driver.findElement(By.xpath("//input[@id='password-field']")).click();
	driver.findElement(By.xpath("//input[@id='password-field']")).sendKeys("Rockon123");
	driver.findElement(By.xpath("//button[@id='loginButton']")).click();
	Thread.sleep(2000);
	WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(120));
    
    /* Manage Business Page */
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[normalize-space()='Coach Assessment']")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()='Coach Assessment']")));Thread.sleep(2000);
    driver.findElement(By.xpath("//span[normalize-space()='Coach Assessment']")).click();
    Thread.sleep(2000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[normalize-space()='Menu']")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()='Menu']")));Thread.sleep(2000);
    driver.findElement(By.xpath("//span[normalize-space()='Menu']")).click();
    Thread.sleep(2000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[normalize-space()='Business Vault']")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[normalize-space()='Business Vault']")));Thread.sleep(2000);
    driver.findElement(By.xpath("//a[normalize-space()='Business Vault']")).click();
    Thread.sleep(2000);
    
    /* Public View of Uploader */	
		    String winHandleBefore = driver.getWindowHandle();
		    driver.findElement(By.linkText("Benelli Sebastian")).click();
		    Thread.sleep(2000);			// Navigate to New window
			for(String winHandle : driver.getWindowHandles()){
		    driver.switchTo().window(winHandle);
			}
		    Thread.sleep(2000);
		    driver.close();
		    driver.switchTo().window(winHandleBefore);
		    Thread.sleep(2000);
	
	/* Rename File Names */
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//div[6]/div/button/i)[1]")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//div[6]/div/button/i)[1]")));Thread.sleep(2000);	    
    driver.findElement(By.xpath("(//div[6]/div/button/i)[1]")).click();
    Thread.sleep(2000);
    driver.findElement(By.xpath("//ul[@class=\'dropdown-menu show\']//button[@class=\'invisibleButton btn-blue-link btnEditFile\'][normalize-space()=\'Edit\']")).click();   
    Thread.sleep(2000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("FileName")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.id("FileName")));Thread.sleep(2000);	
    driver.findElement(By.id("FileName")).click();
    driver.findElement(By.id("FileName")).clear();
    Thread.sleep(2000);
    driver.findElement(By.id("FileName")).sendKeys("Active Presentation");
    Thread.sleep(2000);
    driver.findElement(By.cssSelector(".btn-outline-grey")).click();
    Thread.sleep(2000);
    driver.findElement(By.id("btnNoConfirmYesNo")).click();
    Thread.sleep(2000);
    driver.findElement(By.cssSelector(".btn-blue")).click();
	wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".toast-message")));Thread.sleep(2000);
	driver.findElement(By.cssSelector(".toast-message")).click(); 
    Thread.sleep(2000);
    
    /* Rename to Original Name */
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//div[6]/div/button/i)[1]")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//div[6]/div/button/i)[1]")));Thread.sleep(2000);	    
    driver.findElement(By.xpath("(//div[6]/div/button/i)[1]")).click();
    Thread.sleep(2000);
    driver.findElement(By.xpath("//ul[@class=\'dropdown-menu show\']//button[@class=\'invisibleButton btn-blue-link btnEditFile\'][normalize-space()=\'Edit\']")).click();       
    Thread.sleep(2000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("FileName")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.id("FileName")));Thread.sleep(2000);
    driver.findElement(By.id("FileName")).click();
    driver.findElement(By.id("FileName")).clear();
    Thread.sleep(3000);
    driver.findElement(By.id("FileName")).sendKeys("Achnet Session");
    Thread.sleep(2000);
    driver.findElement(By.cssSelector(".ui-autocomplete-input")).click();
    driver.findElement(By.cssSelector(".ui-autocomplete-input")).sendKeys("Files");
    driver.findElement(By.cssSelector(".ui-autocomplete-input")).sendKeys(Keys.ENTER);
    Thread.sleep(2000);
    driver.findElement(By.cssSelector(".btn-blue")).click();
	wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".toast-message")));
	driver.findElement(By.cssSelector(".toast-message")).click(); 
    
	/* Logout from Coach Page */
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'My Profile')]")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'My Profile')]")));Thread.sleep(2000);
	driver.findElement(By.xpath("//div[contains(text(),'My Profile')]")).click();  
	Thread.sleep(2000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//div[contains(text(),'Logout')])[1]")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//div[contains(text(),'Logout')])[1]")));Thread.sleep(2000);
	driver.findElement(By.xpath("(//div[contains(text(),'Logout')])[1]")).click();  
	Thread.sleep(2000);
  }
}


