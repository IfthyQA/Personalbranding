package disputeClient;

import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import screenshotOnFailure.FailScreenshot;

@Listeners(screenshotListners.EventList.class)
public class CLF11_CreateProposal extends FailScreenshot{
	
	@Test
	public void CLF_CreateProposal() throws InterruptedException {

	/* Login to the Application - PBC */ 		
	driver.findElement(By.xpath("(//button[normalize-space()='Login'])[1]")).click();
	driver.findElement(By.xpath("//input[@id='Username']")).click();
	driver.findElement(By.xpath("//input[@id='Username']")).sendKeys("john.doe002");
	driver.findElement(By.xpath("//input[@id='password-field']")).click();
	driver.findElement(By.xpath("//input[@id='password-field']")).sendKeys("Rockon123");
	driver.findElement(By.xpath("//button[@id='loginButton']")).click();
	Thread.sleep(2000);
	WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(120));    
    
	/* Navigate to the Coach Page */
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[2]/div[1]/div[1]/div[2]/div[1]/div[1]/a[1]/span[1]")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[2]/div[1]/div[1]/div[2]/div[1]/div[1]/a[1]/span[1]")));Thread.sleep(2000);
    driver.findElement(By.xpath("//div[2]/div[1]/div[1]/div[2]/div[1]/div[1]/a[1]/span[1]")).click();
    Thread.sleep(2000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[normalize-space()='Menu']")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()='Menu']")));Thread.sleep(2000);
    driver.findElement(By.xpath("//span[normalize-space()='Menu']")).click();
    Thread.sleep(2000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[normalize-space()='Coaching Services']")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[normalize-space()='Coaching Services']")));Thread.sleep(2000);
    driver.findElement(By.xpath("//a[normalize-space()='Coaching Services']")).click();
    Thread.sleep(2000);
    driver.navigate().refresh();
    Thread.sleep(2000);
    
    /* Sreach Request on Criteria */
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[@id=\'Career\']")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[@id=\'Career\']")));Thread.sleep(2000);
    driver.findElement(By.xpath("//span[@id=\'Career\']")).click();
    Thread.sleep(2000);
    driver.findElement(By.xpath("//span[@id=\'Education & Admissions\']")).click();Thread.sleep(2000);    
    
    /* Create Proposal */
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[3]/div/div[2]/span/span")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[3]/div/div[2]/span/span")));Thread.sleep(2000);
    driver.findElement(By.cssSelector(".btn-blue")).click();Thread.sleep(2000);
    driver.findElement(By.id("TermsAndCondition")).click();Thread.sleep(2000);
    driver.findElement(By.cssSelector(".btn-lg")).click();Thread.sleep(2000);
    driver.findElement(By.cssSelector(".float-right > .btn-sm")).click();Thread.sleep(2000);  
    driver.findElement(By.id("ProposalTitle")).click();Thread.sleep(2000);
    driver.findElement(By.id("ProposalTitle")).sendKeys("DM");Thread.sleep(2000);
    driver.findElement(By.id("ProposalTitle")).clear();
    driver.findElement(By.id("ProposalTitle")).sendKeys("abcdefghijklmnopqrstuvwxyz-abcdefghijklmnopqrstuvwxyz");Thread.sleep(2000);
    driver.findElement(By.id("ProposalTitle")).clear();
    driver.findElement(By.id("ProposalTitle")).sendKeys("Digital Marketing with SEO");Thread.sleep(2000);
    driver.findElement(By.id("HourlyRate")).click();Thread.sleep(2000);
    driver.findElement(By.id("HourlyRate")).sendKeys("10");
    Thread.sleep(2000);
    
    /* Proposal Description - TinyMCE */
    driver.findElement(By.cssSelector("#mceu_6 .mce-ico")).click();
    Thread.sleep(2000);
    driver.findElement(By.cssSelector("#mceu_3 > button")).click();
    Thread.sleep(2000);
    
    /* Milestone Title */
    driver.findElement(By.xpath("//div[@id=\'addblanktask\']/div/div/input")).click();Thread.sleep(2000);
    driver.findElement(By.xpath("//div[@id=\'addblanktask\']/div/div/input")).sendKeys("123456789abcdefghijklmnopqrstuvwxyz12345678ABCDEFGI");Thread.sleep(2000);
    driver.findElement(By.xpath("//div[@id=\'addblanktask\']/div/div/input")).clear();Thread.sleep(2000);
    driver.findElement(By.xpath("//div[@id=\'addblanktask\']/div/div/input")).sendKeys("Syllabus on Digital Marketing");Thread.sleep(2000);
    driver.findElement(By.xpath("//div[@id=\'addblanktask\']/div/div/input")).click();Thread.sleep(2000);
    
    /* Milestone Description - TinyMCE */
    JavascriptExecutor jse = (JavascriptExecutor)driver;
    jse.executeScript("window.scrollBy(0,250)");
    Thread.sleep(2000);
    driver.findElement(By.cssSelector("#mceu_27 .mce-ico")).click();
    Thread.sleep(2000);
    driver.findElement(By.cssSelector("#mceu_24 .mce-ico")).click();
    Thread.sleep(2000);
    driver.findElement(By.cssSelector(".divStartDatePicker .fa")).click();Thread.sleep(2000);
    driver.findElement(By.xpath("//div[3]/table/tbody/tr/td/span[12]")).click();Thread.sleep(2000);   
    driver.findElement(By.xpath("//div[2]/table/tbody/tr/td/span[9]")).click();Thread.sleep(2000);
    driver.findElement(By.cssSelector(".datepicker-days tr:nth-child(6) > .day:nth-child(2)")).click();Thread.sleep(2000);
    driver.findElement(By.xpath("//div[@id=\'addblanktask\']/div/div[2]/div[2]/div/div[4]/div/label")).click();Thread.sleep(2000);
    driver.findElement(By.xpath("//div[@id=\'addblanktask\']/div/div[2]/div[2]/div/div[4]/div/input")).sendKeys("24");Thread.sleep(2000);
    driver.findElement(By.xpath("//div[@id=\'addblanktask\']/div/div/input")).click();Thread.sleep(2000);
    driver.findElement(By.cssSelector(".col-9 > .btn-outline-blue")).click();
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@class='toast-message']")));
    driver.findElement(By.xpath("//div[@class='toast-message']")).click(); 
    Thread.sleep(2000);
    
    /* Edit - Send Proposal */
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("menuitemdraft")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.id("menuitemdraft")));Thread.sleep(2000);
    driver.findElement(By.id("menuitemdraft")).click();
    Thread.sleep(2000);
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.linkText("Edit")));
  	wait.until(ExpectedConditions.elementToBeClickable(By.linkText("Edit")));Thread.sleep(2000);
    driver.findElement(By.linkText("Edit")).click();Thread.sleep(2000);
    driver.findElement(By.id("ProposalTitle")).click();Thread.sleep(2000);
    driver.findElement(By.id("ProposalTitle")).clear();
    driver.findElement(By.id("ProposalTitle")).sendKeys("SEO with Digital Marketing");Thread.sleep(2000);
    driver.findElement(By.cssSelector(".btn-blue")).click();
	wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".toast-message")));
	driver.findElement(By.cssSelector(".toast-message")).click();
    Thread.sleep(2000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("menuitemreview")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.id("menuitemreview")));Thread.sleep(2000);
    driver.findElement(By.id("menuitemreview")).click();
    Thread.sleep(2000);
    
    /* Logout */
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'My Profile')]")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'My Profile')]")));Thread.sleep(2000);
	driver.findElement(By.xpath("//div[contains(text(),'My Profile')]")).click();  
	Thread.sleep(2000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//div[contains(text(),'Logout')])[1]")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//div[contains(text(),'Logout')])[1]")));Thread.sleep(2000);
	driver.findElement(By.xpath("(//div[contains(text(),'Logout')])[1]")).click();  
	Thread.sleep(2000);
  }
}

