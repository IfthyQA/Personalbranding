package disputeClient;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import screenshotOnFailure.FailScreenshot;

@Listeners(screenshotListners.EventList.class)
public class CLF50_ClientPayment extends FailScreenshot{

	@Test
	public void CLF_ClientPayment() throws InterruptedException {

		/* Login to the Application - PBC */ 		
	  	driver.findElement(By.xpath("(//button[normalize-space()='Login'])[1]")).click();
		driver.findElement(By.xpath("//input[@id='Username']")).click();
		driver.findElement(By.xpath("//input[@id='Username']")).sendKeys("john.doe005");
		driver.findElement(By.xpath("//input[@id='password-field']")).click();
		driver.findElement(By.xpath("//input[@id='password-field']")).sendKeys("Rockon123");
		driver.findElement(By.xpath("//button[@id='loginButton']")).click();
		Thread.sleep(2000);
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(120));
		
		 /* Subscription & Payment from Strategic Hub */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'My Profile')]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'My Profile')]")));Thread.sleep(2000);
		driver.findElement(By.xpath("//div[contains(text(),'My Profile')]")).click();
	    Thread.sleep(2000);	
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'Subscription and Orders')]")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'Subscription and Orders')]")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[contains(text(),'Subscription and Orders')]")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.id("btnPrimeMembership")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector("td .btn:nth-child(2)")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector("td .btn:nth-child(1)")).click();Thread.sleep(2000);
	    driver.findElement(By.id("btnPrimeFAQ")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector("#modalPrimeFAQ .fa")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".modal-dialog:nth-child(3) .modal-header .fa")).click();
	    Thread.sleep(2000);;
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".col-12 > .btnAddPaymentMethod")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".col-12 > .btnAddPaymentMethod")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".col-12 > .btnAddPaymentMethod")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("addBtn")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.id("addBtn")));Thread.sleep(2000);
	    driver.findElement(By.id("addBtn")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[@id=\'modalAddPaymentMethod\']/div/div/div/button/span/i")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.linkText("ORDERS")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.linkText("ORDERS")));Thread.sleep(2000);
	    driver.findElement(By.linkText("ORDERS")).click();
	    Thread.sleep(2000);	   
	    driver.findElement(By.xpath("//div[3]/div/div[2]/div/div/div[2]/span")).click();Thread.sleep(2000);
	    
	    	String winHandleBefore = driver.getWindowHandle();Thread.sleep(2000);
		    driver.findElement(By.linkText("SEO with Digital Marketing")).click();
	    	Thread.sleep(2000);
	    	// Navigate to New window
	    	for(String winHandle : driver.getWindowHandles()){
	        driver.switchTo().window(winHandle);Thread.sleep(2000);
	    	}
	    	Thread.sleep(2000);
	    	driver.close();Thread.sleep(2000);	    	
	    	driver.switchTo().window(winHandleBefore);Thread.sleep(2000);
	    
	    driver.findElement(By.cssSelector("#modalsettingtaskdetailpopup .fa")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector("#divAddPaymentMethod > .btnAddStripePaymentMethod")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".modal-prime .fa")).click();Thread.sleep(2000);
	    driver.findElement(By.xpath("//span/form/button/i")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".fa-minus-circle")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector("#divAddPaymentMethod > .btnAddStripePaymentMethod")).click();Thread.sleep(2000);
	    driver.findElement(By.id("addBtnStripe")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".modal-prime .fa")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".history-coaching-title")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector("#modalsettingtaskdetailpopup .fa")).click();
	    Thread.sleep(2000);
	    
	    /* Logout */
		 wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'My Profile')]")));
		 wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'My Profile')]")));Thread.sleep(2000);
		 driver.findElement(By.xpath("//div[contains(text(),'My Profile')]")).click();
		 Thread.sleep(2000);
		 driver.findElement(By.xpath("(//div[contains(text(),'Logout')])[2]")).click();
		 Thread.sleep(2000); 
	  }
	}

