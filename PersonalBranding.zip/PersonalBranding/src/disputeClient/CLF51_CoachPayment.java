package disputeClient;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import screenshotOnFailure.FailScreenshot;

@Listeners(screenshotListners.EventList.class)
public class CLF51_CoachPayment extends FailScreenshot{
	
	@Test
	public void CLF_CoachPayment() throws InterruptedException {

		/* Login to the Application - PBC */ 		
	  	driver.findElement(By.xpath("(//button[normalize-space()='Login'])[1]")).click();
		driver.findElement(By.xpath("//input[@id='Username']")).click();
		driver.findElement(By.xpath("//input[@id='Username']")).sendKeys("john.doe002");
		driver.findElement(By.xpath("//input[@id='password-field']")).click();
		driver.findElement(By.xpath("//input[@id='password-field']")).sendKeys("Rockon123");
		driver.findElement(By.xpath("//button[@id='loginButton']")).click();
		Thread.sleep(2000);
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(120));	    
	    
		/* Navigate to the Coach Page */
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[2]/div[1]/div[1]/div[2]/div[1]/div[1]/a[1]/span[1]")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[2]/div[1]/div[1]/div[2]/div[1]/div[1]/a[1]/span[1]")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[2]/div[1]/div[1]/div[2]/div[1]/div[1]/a[1]/span[1]")).click();
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[normalize-space()='Menu']")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()='Menu']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//span[normalize-space()='Menu']")).click();
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[normalize-space()='Payments']")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[normalize-space()='Payments']")));Thread.sleep(2000);
		driver.findElement(By.xpath("//a[normalize-space()='Payments']")).click();
		Thread.sleep(2000);
	    
	    /* Suubscription & Orders */
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.linkText("RECEIVING BANK")));
	    wait.until(ExpectedConditions.elementToBeClickable(By.linkText("RECEIVING BANK")));Thread.sleep(2000);
	    driver.findElement(By.linkText("RECEIVING BANK")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".btn-blue-link-12 > span")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".coach-receiving-payment .fa")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".col-centered:nth-child(5) .btn-sm")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".margin-bottom-30")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".modal-lg .modal-header .fa")).click();Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[2]/div/div/div/span/form/button/i")).click();Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[2]/span")).click();Thread.sleep(2000);
	    
	    	String winHandleBefore = driver.getWindowHandle();Thread.sleep(2000);
		    driver.findElement(By.linkText("SEO with Digital Marketing")).click();
	    	Thread.sleep(2000);
	    	// Navigate to New window
	    	for(String winHandle : driver.getWindowHandles()){
	        driver.switchTo().window(winHandle);Thread.sleep(2000);
	    	}
	    	Thread.sleep(2000);
		    driver.findElement(By.xpath("//div[2]/form/button")).click();Thread.sleep(2000);
		    driver.findElement(By.cssSelector(".fa-arrow-circle-o-left")).click();Thread.sleep(2000);
		    driver.findElement(By.xpath("//div/div/div/div/div/div/div/div/button")).click();Thread.sleep(2000);
		    driver.findElement(By.cssSelector(".modal-lg .modal-header .fa")).click();Thread.sleep(2000);
		    driver.findElement(By.xpath("//div[3]/span")).click();
		    Thread.sleep(2000);
		    driver.close();Thread.sleep(2000);	    	
	    	driver.switchTo().window(winHandleBefore);Thread.sleep(2000);
	    
	    driver.findElement(By.cssSelector("#modalsettingtaskdetailpopup .fa")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".fa-minus-circle")).click();Thread.sleep(2000);
	    driver.findElement(By.linkText("Edit")).click();
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.linkText("RECEIVING BANK")));
	    wait.until(ExpectedConditions.elementToBeClickable(driver.findElement(By.linkText("RECEIVING BANK"))));Thread.sleep(2000);
	    driver.findElement(By.linkText("RECEIVING BANK")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".col-centered:nth-child(5) .btn-sm")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".margin-bottom-30")).click();Thread.sleep(2000);
	    driver.findElement(By.id("TransferAmount")).click();Thread.sleep(2000);
	    driver.findElement(By.id("TransferAmount")).sendKeys("10");Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".margin-bottom-30")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".modal-lg .modal-header .fa")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".btn-blue-link-12 > span")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".coach-receiving-payment .fa")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".dropdown > .invisibleButton")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".dropdown-menu > li:nth-child(3)")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".invisibleButton > span")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".dropdown-menu > li:nth-child(2)")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".invisibleButton > span")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".dropdown-menu > li:nth-child(1)")).click();
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.linkText("SUBSCRIPTION")));
	    wait.until(ExpectedConditions.elementToBeClickable(driver.findElement(By.linkText("SUBSCRIPTION"))));Thread.sleep(2000);
	    driver.findElement(By.linkText("SUBSCRIPTION")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".btnUnassignSeat")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".modal-lg .modal-header .fa")).click();
	    Thread.sleep(2000);
	    
	    /* Logout */
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'My Profile')]")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'My Profile')]")));Thread.sleep(2000);
		driver.findElement(By.xpath("//div[contains(text(),'My Profile')]")).click();  
		Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//div[contains(text(),'Logout')])[1]")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//div[contains(text(),'Logout')])[1]")));Thread.sleep(2000);
		driver.findElement(By.xpath("(//div[contains(text(),'Logout')])[1]")).click();  
		Thread.sleep(2000);
	  }
	}

