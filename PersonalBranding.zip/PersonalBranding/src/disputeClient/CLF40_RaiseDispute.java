package disputeClient;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import screenshotOnFailure.FailScreenshot;

@Listeners(screenshotListners.EventList.class)
public class CLF40_RaiseDispute extends FailScreenshot{
	
	@Test
	public void CLF_RaiseDispute() throws InterruptedException {

		/* Login to the Application - PBC */ 		
	  	driver.findElement(By.xpath("(//button[normalize-space()='Login'])[1]")).click();
		driver.findElement(By.xpath("//input[@id='Username']")).click();
		driver.findElement(By.xpath("//input[@id='Username']")).sendKeys("john.doe005");
		driver.findElement(By.xpath("//input[@id='password-field']")).click();
		driver.findElement(By.xpath("//input[@id='password-field']")).sendKeys("Rockon123");
		driver.findElement(By.xpath("//button[@id='loginButton']")).click();
		Thread.sleep(2000);

		 WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(120));		
	    /* Navigate to Coaching Support */
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'My Profile')]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'My Profile')]")));
		Thread.sleep(2000);
		{
		     WebElement element = driver.findElement(By.xpath("//div[@class='menu-item menu-item-active']"));
		     Actions builder = new Actions(driver);
		     builder.moveToElement(element).perform();
		}
		Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'Coaching Support')]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'Coaching Support')]")));Thread.sleep(2000);
		driver.findElement(By.xpath("//div[contains(text(),'Coaching Support')]")).click();
	    Thread.sleep(2000);	
	    driver.findElement(By.xpath("//div[@id=\'divLeftMenu\']/div[4]/a")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".btn-outline-grey")).click();Thread.sleep(2000);
	    driver.findElement(By.id("btnNoConfirmYesNo")).click();Thread.sleep(2000);
	    driver.findElement(By.xpath("//span[contains(.,\'View Details\')]")).click();Thread.sleep(2000);
	    driver.findElement(By.linkText("Back to Work In Progress")).click();Thread.sleep(2000);
	    
	    /* Raise Dispute */
	    driver.findElement(By.cssSelector(".btn-outline-grey")).click();Thread.sleep(2000);
	    driver.findElement(By.id("btnYesConfirmYesNo")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".fa-plus-circle")).click();Thread.sleep(2000);
	    driver.findElement(By.id("select2-DisputeReason-container")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".select2-search__field")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".select2-search__field")).sendKeys("ove");Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".select2-search__field")).sendKeys(Keys.ENTER);Thread.sleep(2000);
	    driver.findElement(By.id("DisputeDetails")).click();Thread.sleep(2000);
	    driver.findElement(By.id("DisputeDetails")).sendKeys("I am not happy with your coaching.");Thread.sleep(2000);
	    driver.findElement(By.xpath("//span/button")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".menu-list-active .fa")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".col-md-9 > .btn-blue-link-12")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".menu-list-active .fa")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector("form > .btn-sm")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".col-12:nth-child(3) .btn-sm")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".fa-minus-circle")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".float-right > .pb-pointer")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".btn-outline-blue:nth-child(1)")).click();Thread.sleep(2000);
	    driver.findElement(By.id("select2-DisputeReason-container")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".select2-search__field")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".select2-search__field")).sendKeys("work");Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".select2-search__field")).sendKeys(Keys.ENTER);Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".margin-top-15 .btn-sm")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".coaching-selected-task-title .fa")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".btn-outline-grey > span")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".margin-bottom-20 .btn-sm")).click();Thread.sleep(2000);
	    driver.findElement(By.id("CancelDetails")).click();Thread.sleep(2000);
	    driver.findElement(By.id("CancelDetails")).sendKeys("Nothing");Thread.sleep(2000);
	    driver.findElement(By.cssSelector("#coachingcancelpopup > .modal-header .fa")).click();
	    Thread.sleep(2000);
	    
	    /* Logout */
		 wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'My Profile')]")));
		 wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'My Profile')]")));Thread.sleep(2000);
		 driver.findElement(By.xpath("//div[contains(text(),'My Profile')]")).click();
		 Thread.sleep(2000);
		 driver.findElement(By.xpath("(//div[contains(text(),'Logout')])[2]")).click();
		 Thread.sleep(2000);
	  }
	}

