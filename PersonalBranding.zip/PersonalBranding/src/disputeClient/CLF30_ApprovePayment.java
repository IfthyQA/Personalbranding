package disputeClient;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import screenshotOnFailure.FailScreenshot;

@Listeners(screenshotListners.EventList.class)
public class CLF30_ApprovePayment extends FailScreenshot{
	
	@Test
	public void CLF_ApprovePayment() throws InterruptedException {

		/* Login to the Application - PBC */ 		
	  	driver.findElement(By.xpath("(//button[normalize-space()='Login'])[1]")).click();
		driver.findElement(By.xpath("//input[@id='Username']")).click();
		driver.findElement(By.xpath("//input[@id='Username']")).sendKeys("john.doe005");
		driver.findElement(By.xpath("//input[@id='password-field']")).click();
		driver.findElement(By.xpath("//input[@id='password-field']")).sendKeys("Rockon123");
		driver.findElement(By.xpath("//button[@id='loginButton']")).click();
		Thread.sleep(2000);

		 WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(120));		
	    /* Navigate to Coaching Support */
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'My Profile')]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'My Profile')]")));
		Thread.sleep(2000);
		{
		     WebElement element = driver.findElement(By.xpath("//div[@class='menu-item menu-item-active']"));
		     Actions builder = new Actions(driver);
		     builder.moveToElement(element).perform();
		}
		Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'Coaching Support')]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'Coaching Support')]")));Thread.sleep(2000);
		driver.findElement(By.xpath("//div[contains(text(),'Coaching Support')]")).click();
	    Thread.sleep(2000);	
	    driver.findElement(By.xpath("//div[@id=\'divLeftMenu\']/div[4]/a")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".col-md-9 > .btn-blue-link-12")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".btn-outline-blue")).click();Thread.sleep(2000);
	    driver.findElement(By.xpath("(//i[@class='fa fa-trash-o'])[2]")).click();Thread.sleep(2000);
	    driver.findElement(By.id("btnYesConfirmYesNo")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector("#modalMyFiles .modal-header .fa")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".menu-list-active > a")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".margin-top-10 > .btn-blue-link-12")).click();Thread.sleep(2000);
	    
	    	String winHandleBefore = driver.getWindowHandle();Thread.sleep(2000);
		    driver.findElement(By.linkText("Inara Cinderella")).click();
		    Thread.sleep(2000);
	    	for(String winHandle : driver.getWindowHandles()){
	        driver.switchTo().window(winHandle);Thread.sleep(2000);
	    	}
	    	Thread.sleep(2000);
	    	driver.close();Thread.sleep(2000);	    	
	    	driver.switchTo().window(winHandleBefore);Thread.sleep(2000);
	    
	    driver.findElement(By.cssSelector("#coachingcancelpopup > .modal-header .fa")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//form[2]/button")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//form[2]/button")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//form[2]/button")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("btnNoConfirmYesNo")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.id("btnNoConfirmYesNo")));Thread.sleep(2000);
	    driver.findElement(By.id("btnNoConfirmYesNo")).click();Thread.sleep(2000);
	    
	    /* View Details */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[contains(.,\'View Details\')]")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[contains(.,\'View Details\')]")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//span[contains(.,\'View Details\')]")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".form-inline > .btn-outline-grey")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".form-inline > .btn-outline-grey")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".form-inline > .btn-outline-grey")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("btnNoConfirmYesNo")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.id("btnNoConfirmYesNo")));Thread.sleep(2000);
	    driver.findElement(By.id("btnNoConfirmYesNo")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".btn-blue")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".btn-blue")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".btn-blue")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("#divWorkInProgressModal .modal-header .fa")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector("#divWorkInProgressModal .modal-header .fa")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector("#divWorkInProgressModal .modal-header .fa")).click();Thread.sleep(2000);
	    
	    /* Back To Work in Progress view */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.linkText("Back to Work In Progress")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.linkText("Back to Work In Progress")));Thread.sleep(2000);
	    driver.findElement(By.linkText("Back to Work In Progress")).click();Thread.sleep(2000);
	    driver.navigate().refresh();
	    
	    /* Approve Payment */
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".form-inline > .btn-blue")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".form-inline > .btn-blue")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".form-inline > .btn-blue")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("btnConfirmApprovePayment")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.id("btnConfirmApprovePayment")));Thread.sleep(2000);
	    driver.findElement(By.id("btnConfirmApprovePayment")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.invisibilityOfElementLocated(By.id("btnConfirmApprovePayment")));
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[contains(text(),'Work in progress - waiting for coach to complete milestone')]")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[contains(text(),'Work in progress - waiting for coach to complete milestone')]")));
	    Thread.sleep(2000);
	    
	    /* Logout */
		 wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'My Profile')]")));
		 wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'My Profile')]")));Thread.sleep(2000);
		 driver.findElement(By.xpath("//div[contains(text(),'My Profile')]")).click();
		 Thread.sleep(2000);
		 driver.findElement(By.xpath("(//div[contains(text(),'Logout')])[2]")).click();
		 Thread.sleep(2000);
	  }
	}

