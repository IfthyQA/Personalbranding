package disputeClient;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import screenshotOnFailure.FailScreenshot;

@Listeners(screenshotListners.EventList.class)
public class CLF42_AdminAssistance extends FailScreenshot{
	
	@Test
	public void CLF_AdminAssistance() throws InterruptedException {

		/* Login to the Application - PBC */ 		
	  	driver.findElement(By.xpath("(//button[normalize-space()='Login'])[1]")).click();
		driver.findElement(By.xpath("//input[@id='Username']")).click();
		driver.findElement(By.xpath("//input[@id='Username']")).sendKeys("site.admin");
		driver.findElement(By.xpath("//input[@id='password-field']")).click();
		driver.findElement(By.xpath("//input[@id='password-field']")).sendKeys("Rockon123");
		driver.findElement(By.xpath("//button[@id='loginButton']")).click();
		Thread.sleep(2000);
		 WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(120));
		 
	    /* Naviage to Admin Dashboard */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'My Profile')]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'My Profile')]")));Thread.sleep(2000);
	    driver.get("https://www.personalbrandingcouncil.com/admin");
	    Thread.sleep(2000);
    	wait.until(ExpectedConditions.visibilityOfElementLocated(By.linkText("Approvals")));
		wait.until(ExpectedConditions.elementToBeClickable(By.linkText("Approvals")));Thread.sleep(2000);
	    driver.findElement(By.linkText("Approvals")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("//button[normalize-space()='Dispute Assistance']")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.id("Sorttype")).click();Thread.sleep(2000);	
	    {
	        WebElement dropdown = driver.findElement(By.id("Sorttype"));Thread.sleep(2000);
	        dropdown.findElement(By.xpath("//option[. = 'Recently Updated']")).click();Thread.sleep(2000);
	      }
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.textToBePresentInElementLocated(By.xpath("(//*[contains(text(),'ACHNET Assistance Required')])[1]"), "ACHNET Assistance Required"));
	    Thread.sleep(2000);	
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id=\"divDisputes\"]/div/div[1]/div/div/div/div[2]/div/div[1]/div/div[1]/form/button")));
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@id=\"divDisputes\"]/div/div[1]/div/div/div/div[2]/div/div[1]/div/div[1]/form/button")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//*[@id=\"divDisputes\"]/div/div[1]/div/div/div/div[2]/div/div[1]/div/div[1]/form/button")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".btn-blue")));
	    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".btn-blue")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".btn-blue")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@id=\'coachadapprovepopup\']/div[2]/div/form/div[2]/span/button")));
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@id=\'coachadapprovepopup\']/div[2]/div/form/div[2]/span/button")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[@id=\'coachadapprovepopup\']/div[2]/div/form/div[2]/span/button")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector("#coachadapprovepopup > .modal-header .fa")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".btn-maroon")));
	    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".btn-maroon")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".btn-maroon")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".btn-grey")));
	    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".btn-grey")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".btn-grey")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".margin-right-20")).click();Thread.sleep(2000);
	    driver.findElement(By.id("ApproveDetails")).click();Thread.sleep(2000);
	    driver.findElement(By.id("ApproveDetails")).sendKeys("Yeah missed few notes and topics as the client claimed. excuse me for the missing the notes");Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[@id=\'coachadapprovepopup\']/div[2]/div/form/div[2]/span/button")).click();Thread.sleep(2000);
	    driver.findElement(By.linkText("Back")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".btn-blue-link-12 > span")).click();Thread.sleep(2000);
	    driver.findElement(By.linkText("Admin Dashboard")).click();
	    Thread.sleep(2000);
	    
	    /* Logout */
		 wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'My Profile')]")));
		 wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'My Profile')]")));Thread.sleep(2000);
		 driver.findElement(By.xpath("//div[contains(text(),'My Profile')]")).click();
		 Thread.sleep(2000);
		 driver.findElement(By.xpath("//div[contains(text(),'Logout')]")).click();
		 Thread.sleep(2000);
	  }
	}

