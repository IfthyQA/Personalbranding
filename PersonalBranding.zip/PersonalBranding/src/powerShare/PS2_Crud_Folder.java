package powerShare;

import java.io.IOException;
import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import screenshotOnFailure.FailScreenshot;

@Listeners(screenshotListners.EventList.class)
public class PS2_Crud_Folder extends FailScreenshot {

	@Test
	public void PS_FolderCreate_Delete() throws InterruptedException, IOException {		
		
		/* Login to the Application - PBC */ 		
	  	driver.findElement(By.xpath("(//button[normalize-space()='Login'])[1]")).click();
		driver.findElement(By.xpath("//input[@id='Username']")).click();
		driver.findElement(By.xpath("//input[@id='Username']")).sendKeys("test.doe002");
		driver.findElement(By.xpath("//input[@id='password-field']")).click();
		driver.findElement(By.xpath("//input[@id='password-field']")).sendKeys("Rockon123");
		driver.findElement(By.xpath("//button[@id='loginButton']")).click();
		Thread.sleep(2000);
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(120));
		 
		/* Navigate to the Power Share */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'My Profile')]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'My Profile')]")));Thread.sleep(2000);
		{
		     WebElement element = driver.findElement(By.xpath("//div[@class='menu-item menu-item-active']"));
		     Actions builder = new Actions(driver);
		     builder.moveToElement(element).perform();
		}
		Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'Power Share')]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'Power Share')]")));Thread.sleep(2000);
		driver.findElement(By.xpath("//div[contains(text(),'Power Share')]")).click();	    	    	   
	    
	    /* Create NEW Folder */ 
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//span[contains(text(),'New Folder')])[1]")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//span[contains(text(),'New Folder')])[1]")));Thread.sleep(2000);
	    driver.findElement(By.xpath("(//span[contains(text(),'New Folder')])[1]")).click(); // New folder //
	    Thread.sleep(2000);	    
	    driver.findElement(By.id("FolderName")).click();
	    driver.findElement(By.id("FolderName")).clear();
	    driver.findElement(By.id("FolderName")).sendKeys("Quality Assurance Team");Thread.sleep(2000);	
	    driver.findElement(By.cssSelector(".powershare-blue-btn")).click(); // Save Button //
	    Thread.sleep(2000);	   
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//span[contains(text(),'New Folder')])[1]")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//span[contains(text(),'New Folder')])[1]")));Thread.sleep(2000); 	    
	    driver.findElement(By.xpath("(//span[contains(text(),'New Folder')])[1]")).click(); // Sub folder //
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".powershare-blue-btn")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[@data-ajax='true'][contains(text(),'Manage Files')]")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[@data-ajax='true'][contains(text(),'Manage Files')]")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//a[@data-ajax='true'][contains(text(),'Manage Files')]")).click();
	    Thread.sleep(2000);	   
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[6]/div/div/div/div/div[2]/div[2]/div")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[6]/div/div/div/div/div[2]/div[2]/div")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[6]/div/div/div/div/div[2]/div[2]/div")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector("li .btnDeleteFolder")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("btnYesConfirmYesNo")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.id("btnYesConfirmYesNo")));Thread.sleep(2000);	
	    driver.findElement(By.id("btnYesConfirmYesNo")).click();
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@class='toast-message']")));
	    driver.findElement(By.xpath("//div[@class='toast-message']")).click(); 
	    Thread.sleep(2000);
	    
	    /* Rename existing Folder */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[6]/div/div/div/div/div[2]/div[2]/div")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[6]/div/div/div/div/div[2]/div[2]/div")));Thread.sleep(2000);	 
	    driver.findElement(By.xpath("//div[6]/div/div/div/div/div[2]/div[2]/div")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector("li > .btnRenameFolder")).click();	    
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[@id=\'renamefolderpopup\']/div[2]/form/div/div/div/input")).click();
	    driver.findElement(By.xpath("//div[@id=\'renamefolderpopup\']/div[2]/form/div/div/div/input")).clear();
	    driver.findElement(By.xpath("//div[@id=\'renamefolderpopup\']/div[2]/form/div/div/div/input")).sendKeys("Hero Group");
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[contains(text(), 'Save')]")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//span[contains(text(), 'Save')]")).click();
		wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".toast-message")));Thread.sleep(1000);
	    driver.findElement(By.cssSelector(".toast-message")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[6]/div/div/div/div/div[2]/div[2]/div")));Thread.sleep(2000);	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[6]/div/div/div/div/div[2]/div[2]/div")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[6]/div/div/div/div/div[2]/div[2]/div")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector("li > .btnRenameFolder")).click();	    
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[@id=\'renamefolderpopup\']/div[2]/form/div/div/div/input")).click();
	    driver.findElement(By.xpath("//div[@id=\'renamefolderpopup\']/div[2]/form/div/div/div/input")).clear();
	    driver.findElement(By.xpath("//div[@id=\'renamefolderpopup\']/div[2]/form/div/div/div/input")).sendKeys("Admin Group");
	    Thread.sleep(2000);	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[contains(text(), 'Save')]")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//span[contains(text(), 'Save')]")).click();
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@class='toast-message']")));
	    driver.findElement(By.xpath("//div[@class='toast-message']")).click(); 
	    Thread.sleep(2000);
	    	        
    	/* Switch back to original Window (first window) and Logout */
    	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'My Profile')]")));
   	 	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'My Profile')]")));Thread.sleep(2000);
   	 	driver.findElement(By.xpath("//div[contains(text(),'My Profile')]")).click();
   	 	Thread.sleep(2000);
   	 	driver.findElement(By.xpath("(//div[contains(text(),'Logout')])[2]")).click();
   	 	Thread.sleep(2000);
	  }
	}

