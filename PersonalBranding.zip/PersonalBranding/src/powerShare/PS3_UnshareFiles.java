package powerShare;

import java.io.IOException;
import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import screenshotOnFailure.FailScreenshot;

@Listeners(screenshotListners.EventList.class)
public class PS3_UnshareFiles extends FailScreenshot {

	@Test
	public void PS_Files_Unshare() throws InterruptedException, IOException {		
		
		/* Login to the Application - PBC */ 		
	  	driver.findElement(By.xpath("(//button[normalize-space()='Login'])[1]")).click();
		driver.findElement(By.xpath("//input[@id='Username']")).click();
		driver.findElement(By.xpath("//input[@id='Username']")).sendKeys("test.doe002");
		driver.findElement(By.xpath("//input[@id='password-field']")).click();
		driver.findElement(By.xpath("//input[@id='password-field']")).sendKeys("Rockon123");
		driver.findElement(By.xpath("//button[@id='loginButton']")).click();
		Thread.sleep(2000);
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(120));
		 
		/* Navigate to the Power Share */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'My Profile')]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'My Profile')]")));Thread.sleep(2000);
		{
		     WebElement element = driver.findElement(By.xpath("//div[@class='menu-item menu-item-active']"));
		     Actions builder = new Actions(driver);
		     builder.moveToElement(element).perform();
		}
		Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'Power Share')]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'Power Share')]")));Thread.sleep(2000);
		driver.findElement(By.xpath("//div[contains(text(),'Power Share')]")).click();	    	    	  
		Thread.sleep(2000); 
	    
	    /* Shared By Me - Menu */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.linkText("Shared By Me")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.linkText("Shared By Me")));Thread.sleep(2000);
	    driver.findElement(By.linkText("Shared By Me")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[@class='float-right']//a[contains(text(),'Manage Files')]")));
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[@class='float-right']//a[contains(text(),'Manage Files')]")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//span[@class='float-right']//a[contains(text(),'Manage Files')]")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[6]/div/div/div/div/div[2]/div[2]/div")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector("li .btnDeleteFolder")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.id("btnNoConfirmYesNo")).click();
	    Thread.sleep(2000);
	    
	    /* Menu -Shared by Me - Public View */
	    driver.findElement(By.linkText("Shared By Me")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".powershare-shared-member > img")).click();
	    Thread.sleep(2000);
	    
	    /* Public view of Shared Person */
	    String winHandleBefore = driver.getWindowHandle();
	    driver.findElement(By.xpath("//span[normalize-space()=\'Adam M.\']")).click();
	    Thread.sleep(2000);
	     	for(String winHandle : driver.getWindowHandles())
	     	{
		    driver.switchTo().window(winHandle);  
		    }
	    Thread.sleep(2000);
	    driver.close();	
	    Thread.sleep(2000);
	    driver.switchTo().window(winHandleBefore);
	    Thread.sleep(2000);
	    
	    /* Unshare the Files - from 2 Users */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".fa-times-circle")));
	    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".fa-times-circle")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".fa-times-circle")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.id("btnYesConfirmYesNo")).click();
		wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".toast-message")));Thread.sleep(1000);
	    driver.findElement(By.cssSelector(".toast-message")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".fa-times-circle")));
	    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".fa-times-circle")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".fa-times-circle")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.id("btnYesConfirmYesNo")).click();
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@class='toast-message']")));
	    driver.findElement(By.xpath("//div[@class='toast-message']")).click(); 
	    Thread.sleep(2000);
	    	   
    	/* Logout */
    	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'My Profile')]")));
   	 	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'My Profile')]")));Thread.sleep(2000);
   	 	driver.findElement(By.xpath("//div[contains(text(),'My Profile')]")).click();
   	 	Thread.sleep(2000);
   	 	driver.findElement(By.xpath("(//div[contains(text(),'Logout')])[2]")).click();
   	 	Thread.sleep(2000);
	  }
	}

