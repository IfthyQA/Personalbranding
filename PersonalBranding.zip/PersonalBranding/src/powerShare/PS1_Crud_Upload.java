package powerShare;

import java.io.IOException;
import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import screenshotOnFailure.FailScreenshot;

@Listeners(screenshotListners.EventList.class)
public class PS1_Crud_Upload extends FailScreenshot {

	@Test
	public void PS_Upload_Delete() throws InterruptedException, IOException {		
		
		/* Login to the Application - PBC */ 		
	  	driver.findElement(By.xpath("(//button[normalize-space()='Login'])[1]")).click();
		driver.findElement(By.xpath("//input[@id='Username']")).click();
		driver.findElement(By.xpath("//input[@id='Username']")).sendKeys("test.doe002");
		driver.findElement(By.xpath("//input[@id='password-field']")).click();
		driver.findElement(By.xpath("//input[@id='password-field']")).sendKeys("Rockon123");
		driver.findElement(By.xpath("//button[@id='loginButton']")).click();
		Thread.sleep(2000);
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(120));
		 
		/* Navigate to the Power Share */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'My Profile')]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'My Profile')]")));Thread.sleep(2000);
		{
		     WebElement element = driver.findElement(By.xpath("//div[@class='menu-item menu-item-active']"));
		     Actions builder = new Actions(driver);
		     builder.moveToElement(element).perform();
		}
		Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'Power Share')]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'Power Share')]")));Thread.sleep(2000);
		driver.findElement(By.xpath("//div[contains(text(),'Power Share')]")).click();
	    	    
	    /* Upload File From Local */ 
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".btn-upload:nth-child(2)")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".btn-upload:nth-child(2)")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".btn-upload:nth-child(2)")).click();	
	    Thread.sleep(3000);
	    Runtime.getRuntime().exec("C:\\Users\\dev\\Documents\\AutoScripts\\Upload.exe");  
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@class='toast-message']")));
	    driver.findElement(By.xpath("//div[@class='toast-message']")).click();  	    
	    
	    /* View the uploaded File */ 
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[normalize-space()='ArtUpload.jpg']")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()='ArtUpload.jpg']")));Thread.sleep(2000);
	    String winHandleBefore1 = driver.getWindowHandle();
	    driver.findElement(By.xpath("//span[normalize-space()='ArtUpload.jpg']")).click();
	    Thread.sleep(2000);
     	for(String winHandle : driver.getWindowHandles()){
	    driver.switchTo().window(winHandle);  }
        Thread.sleep(2000);
	    driver.close();	
	    Thread.sleep(2000);
	    driver.switchTo().window(winHandleBefore1);Thread.sleep(2000);
	    
	    /* Delete the uploaded File */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("li .btnDeleteFile")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector("li .btnDeleteFile")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector("li .btnDeleteFile")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("btnYesConfirmYesNo")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.id("btnYesConfirmYesNo")));Thread.sleep(2000);	
	    driver.findElement(By.id("btnYesConfirmYesNo")).click();  
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@class='toast-message']")));
	    driver.findElement(By.xpath("//div[@class='toast-message']")).click(); 
	    Thread.sleep(2000);	    	
	    
    	/* Logout */
    	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'My Profile')]")));
   	 	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'My Profile')]")));Thread.sleep(2000);
   	 	driver.findElement(By.xpath("//div[contains(text(),'My Profile')]")).click();
   	 	Thread.sleep(2000);
   	 	driver.findElement(By.xpath("(//div[contains(text(),'Logout')])[2]")).click();
   	 	Thread.sleep(2000);
	  }
	}

