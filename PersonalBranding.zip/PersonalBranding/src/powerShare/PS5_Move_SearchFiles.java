package powerShare;

import java.io.IOException;
import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import screenshotOnFailure.FailScreenshot;
import org.openqa.selenium.Keys;

@Listeners(screenshotListners.EventList.class)
public class PS5_Move_SearchFiles extends FailScreenshot {

	@Test
	public void PS_Search_MoveFiles() throws InterruptedException, IOException {		
		
		/* Login to the Application - PBC */ 		
	  	driver.findElement(By.xpath("(//button[normalize-space()='Login'])[1]")).click();
		driver.findElement(By.xpath("//input[@id='Username']")).click();
		driver.findElement(By.xpath("//input[@id='Username']")).sendKeys("test.doe002");
		driver.findElement(By.xpath("//input[@id='password-field']")).click();
		driver.findElement(By.xpath("//input[@id='password-field']")).sendKeys("Rockon123");
		driver.findElement(By.xpath("//button[@id='loginButton']")).click();
		Thread.sleep(2000);
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(120));
		 
		/* Navigate to the Power Share */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'My Profile')]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'My Profile')]")));Thread.sleep(2000);
		{
		     WebElement element = driver.findElement(By.xpath("//div[@class='menu-item menu-item-active']"));
		     Actions builder = new Actions(driver);
		     builder.moveToElement(element).perform();
		}
		Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'Power Share')]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'Power Share')]")));Thread.sleep(2000);
		driver.findElement(By.xpath("//div[contains(text(),'Power Share')]")).click();	
	    Thread.sleep(2000);

		/* Move file from Manage Files to Admin Folder */ 
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[6]/div/div[2]/div/div/div/div/div[2]/div/div")));
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[6]/div/div[2]/div/div/div/div/div[2]/div/div")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[6]/div/div[2]/div/div/div/div/div[2]/div/div")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector("li > .btnMoveFile")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".select2-selection__placeholder")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".select2-search__field")).click();
	    driver.findElement(By.cssSelector(".select2-search__field")).sendKeys("adm");
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".select2-search__field")).sendKeys(Keys.ENTER);
	    Thread.sleep(2000);
	    
	    /* Move file from Admin Folder to Manage Files */ 
    	wait.until(ExpectedConditions.visibilityOfElementLocated(By.linkText("Admin Group")));
		wait.until(ExpectedConditions.elementToBeClickable(By.linkText("Admin Group")));Thread.sleep(2000);
	    driver.findElement(By.linkText("Admin Group")).click();	    
	    Thread.sleep(2000);
    	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@id='outfineuploader']/div")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@id='outfineuploader']/div")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[@id='outfineuploader']/div")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector("li > .btnMoveFile")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".select2-selection__placeholder")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".select2-search__field")).click();
	    driver.findElement(By.cssSelector(".select2-search__field")).sendKeys("mana");
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".select2-search__field")).sendKeys(Keys.ENTER);
	    Thread.sleep(2000);
    	wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("span > a")));
		wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector("span > a")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector("span > a")).click();	    
	    Thread.sleep(2000);
	    
	    /* Search Files */
    	wait.until(ExpectedConditions.visibilityOfElementLocated(By.linkText("Search My Files")));
		wait.until(ExpectedConditions.elementToBeClickable(By.linkText("Search My Files")));Thread.sleep(2000);
	    driver.findElement(By.linkText("Search My Files")).click();
	    Thread.sleep(2000);	    
	    driver.findElement(By.id("SearchedTags")).click();
	    driver.findElement(By.id("SearchedTags")).sendKeys("pbc");
	    Thread.sleep(2000);
	    driver.findElement(By.id("SearchedTags")).sendKeys(Keys.ENTER);
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".btn-link:nth-child(2)")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".btn-blue")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".text-icon")).click(); // remove tag
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".ui-autocomplete-input")).click();
	    driver.findElement(By.cssSelector(".ui-autocomplete-input")).sendKeys("File1");
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".ui-autocomplete-input")).sendKeys(Keys.ENTER);
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".btn-blue")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.linkText("Search My Files")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.linkText("Search My Files")).click();	   
	    Thread.sleep(2000);
	    
	    /* FILE VIEW - Handle Windows - New Window */ 
    	String winHandleBefore3 = driver.getWindowHandle(); 
    	Thread.sleep(2000);
	    driver.findElement(By.id("SearchedTags")).click();
	    driver.findElement(By.id("SearchedTags")).sendKeys("File1");
	    Thread.sleep(2000);
	    driver.findElement(By.id("SearchedTags")).sendKeys(Keys.ENTER);
	    Thread.sleep(2000);
	    driver.findElement(By.linkText("File1.jpg")).click();
    	for(String winHandle : driver.getWindowHandles()){
            driver.switchTo().window(winHandle);
        	}
    	Thread.sleep(2000);
    	driver.close();	    	
    	driver.switchTo().window(winHandleBefore3);
	    
    	/* Switch back to original Window (first window) and Logout */
    	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'My Profile')]")));
   	 	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'My Profile')]")));Thread.sleep(2000);
   	 	driver.findElement(By.xpath("//div[contains(text(),'My Profile')]")).click();
   	 	Thread.sleep(2000);
   	 	driver.findElement(By.xpath("(//div[contains(text(),'Logout')])[2]")).click();
   	 	Thread.sleep(2000);
	  }
	}

