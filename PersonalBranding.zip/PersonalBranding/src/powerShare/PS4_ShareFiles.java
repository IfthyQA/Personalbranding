package powerShare;

import java.io.IOException;
import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import screenshotOnFailure.FailScreenshot;

@Listeners(screenshotListners.EventList.class)
public class PS4_ShareFiles extends FailScreenshot {

	@Test
	public void Member_Powershare() throws InterruptedException, IOException {		
		
		/* Login to the Application - PBC */ 		
	  	driver.findElement(By.xpath("(//button[normalize-space()='Login'])[1]")).click();
		driver.findElement(By.xpath("//input[@id='Username']")).click();
		driver.findElement(By.xpath("//input[@id='Username']")).sendKeys("test.doe002");
		driver.findElement(By.xpath("//input[@id='password-field']")).click();
		driver.findElement(By.xpath("//input[@id='password-field']")).sendKeys("Rockon123");
		driver.findElement(By.xpath("//button[@id='loginButton']")).click();
		Thread.sleep(2000);
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(120));
		 
		/* Navigate to the Power Share */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'My Profile')]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'My Profile')]")));Thread.sleep(2000);
		{
		     WebElement element = driver.findElement(By.xpath("//div[@class='menu-item menu-item-active']"));
		     Actions builder = new Actions(driver);
		     builder.moveToElement(element).perform();
		}
		Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'Power Share')]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'Power Share')]")));Thread.sleep(2000);
		driver.findElement(By.xpath("//div[contains(text(),'Power Share')]")).click();	
	    
	    /* Share One File */ 
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div/div[3]/div/div/div/div/div[2]/div/div")));
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div/div[3]/div/div/div/div/div[2]/div/div")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//div/div[3]/div/div/div/div/div[2]/div/div")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("li > .btnShareFile")));
	    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector("li > .btnShareFile")));Thread.sleep(2000);	
	    driver.findElement(By.cssSelector("li > .btnShareFile")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".SPbtnshare")));
	    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".SPbtnshare")));Thread.sleep(2000);	
	    driver.findElement(By.cssSelector(".SPbtnshare")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".txtMemberInvite")).click();
	    driver.findElement(By.cssSelector(".txtMemberInvite")).sendKeys("Adam Mus");
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".autocompleteSugLoc:nth-child(3)")));
	    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".autocompleteSugLoc:nth-child(3)")));Thread.sleep(2000);	
	    driver.findElement(By.cssSelector(".autocompleteSugLoc:nth-child(3)")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".SPbtnshare")).click();
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@class='toast-message']")));
	    driver.findElement(By.xpath("//div[@class='toast-message']")).click(); 
	    Thread.sleep(2000);
	    
	    /* Share Same File - 2nd Time */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div/div[3]/div/div/div/div/div[2]/div/div")));
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div/div[3]/div/div/div/div/div[2]/div/div")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//div/div[3]/div/div/div/div/div[2]/div/div")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector("li > .btnShareFile")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".SPbtnshare")));
	    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".SPbtnshare")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".SPbtnshare")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".txtMemberInvite")).click();
	    driver.findElement(By.cssSelector(".txtMemberInvite")).sendKeys("Adam");
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".autocompleteSugLoc:nth-child(3)")));
	    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".autocompleteSugLoc:nth-child(3)")));Thread.sleep(2000);	
	    driver.findElement(By.cssSelector(".autocompleteSugLoc:nth-child(3)")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".SPbtnshare")).click();
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@class='toast-message']")));
	    driver.findElement(By.xpath("//div[@class='toast-message']")).click(); 
	    Thread.sleep(2000);
	    
	    /* Share with me Menu it open Detailed view */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[3]/div/div/div/div/div[2]/div/div[2]/a/i")));
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[3]/div/div/div/div/div[2]/div/div[2]/a/i")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[3]/div/div/div/div/div[2]/div/div[2]/a/i")).click();	    
	    Thread.sleep(2000);
	    /* Scroll the Page Up */
	    JavascriptExecutor jse = (JavascriptExecutor)driver;
	    jse.executeScript("scroll(0, -250);");
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("(//span[contains(text(),'Share')])[3]")).click();	    
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".txtMemberInvite")).click();
	    driver.findElement(By.cssSelector(".txtMemberInvite")).sendKeys("ahmed");
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".autocompleteSugLoc:nth-child(3)")));
	    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".autocompleteSugLoc:nth-child(3)")));Thread.sleep(2000);	
	    driver.findElement(By.cssSelector(".autocompleteSugLoc:nth-child(3)")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("//form[@id=\'formSelectedContacts\']/div/div[3]/div[2]/div/div/i")).click(); // Remove the Tag - selected
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".SPbtnshare")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".SPcontent > .modal-header .fa")).click();
	    Thread.sleep(2000);
	    
	    /* Download - FILE VIEW - Handle Windows - New Window */
	    {
	      WebElement element = driver.findElement(By.xpath("//span[@class='file-name']"));
	      Actions builder = new Actions(driver);
	      builder.moveToElement(element).perform();
	    }
	    Thread.sleep(2000);
    	String winHandleBefore2 = driver.getWindowHandle();    
    	driver.findElement(By.cssSelector(".file-download > .d-none")).click();	
    	for(String winHandle : driver.getWindowHandles()){
            driver.switchTo().window(winHandle);
        	}    
    	Thread.sleep(2000);
    	driver.close();Thread.sleep(2000);	    	
    	driver.switchTo().window(winHandleBefore2);
	      	 
    	/* Switch back to original Window (first window) and Logout */
    	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'My Profile')]")));
   	 	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'My Profile')]")));Thread.sleep(2000);
   	 	driver.findElement(By.xpath("//div[contains(text(),'My Profile')]")).click();
   	 	Thread.sleep(2000);
   	 	driver.findElement(By.xpath("(//div[contains(text(),'Logout')])[2]")).click();
   	 	Thread.sleep(2000);
	  }
	}

