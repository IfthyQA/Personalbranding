package assessmentTechnicalNew;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import screenshotOnFailure.FailScreenshot;

@Listeners(screenshotListners.EventList.class)
public class T5_CreateDlt_JobSkill extends FailScreenshot{

	  	@Test
	  	public void TA_Test_WithJOBSkill() throws InterruptedException{
	  	
  		/* Login to the Application - PBC */ 		
	  	driver.findElement(By.xpath("(//button[normalize-space()='Login'])[1]")).click();
  		driver.findElement(By.xpath("//input[@id='Username']")).click();
  		driver.findElement(By.xpath("//input[@id='Username']")).sendKeys("john.doe005");
  		driver.findElement(By.xpath("//input[@id='password-field']")).click();
  		driver.findElement(By.xpath("//input[@id='password-field']")).sendKeys("Rockon123");
  		driver.findElement(By.xpath("//button[@id='loginButton']")).click();
  		Thread.sleep(2000);
  		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(120));
	    
	    /* Naviagte to the Business Page */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[normalize-space()='Business Automati...']")));
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()='Business Automati...']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//span[normalize-space()='Business Automati...']")).click();
	    Thread.sleep(2000);
	    
	    /* Navigate to the Technical Assessment */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[normalize-space()=\'Administer Test\']")));
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()=\'Administer Test\']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//span[normalize-space()=\'Administer Test\']")).click();
	    Thread.sleep(2000);
	    
	    /* Create New Test - Job Association */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[normalize-space()=\'Create New Test\']")));
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[normalize-space()=\'Create New Test\']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//button[normalize-space()=\'Create New Test\']")).click();Thread.sleep(2000);
	    driver.findElement(By.xpath("//label[normalize-space()=\'Yes\']//input[@name=\'optradio\']")).click();Thread.sleep(2000);
	    driver.findElement(By.xpath("//button[@class=\'next-btn-share-test\']")).click();Thread.sleep(2000);
	    
	    /* Create Test Overlay */
	    driver.findElement(By.name("testInfoModel.name")).click();Thread.sleep(2000);
	    driver.findElement(By.name("testInfoModel.name")).sendKeys("Automation Test Skill Job");
	    Thread.sleep(2000);
	    driver.findElement(By.name("duration")).click();Thread.sleep(2000);
	    driver.findElement(By.name("duration")).sendKeys("90");Thread.sleep(2000);
	    driver.findElement(By.xpath("//input[@value=\'Deadline\']")).click();Thread.sleep(2000);
	    driver.findElement(By.id("createTestNextBtn")).click();Thread.sleep(2000);
	    
	    /* Video Proctoring and Performance Categories */
	    driver.findElement(By.cssSelector(".custom-control-label")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".custom-control-label")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".close > span")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".btn-primary")).click();Thread.sleep(2000);
	    driver.findElement(By.xpath("//button[@class=\'next-btn-share-test\']")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".close > span")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".btn-primary")).click();Thread.sleep(2000);
	    driver.findElement(By.xpath("//button[@class=\'next-btn-share-test\']")).click();Thread.sleep(2000);	    	    
	    
	    /* Add First Skill - ACHNET */
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".form-input")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".form-input")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".form-input")).sendKeys("BDD");Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("react-autowhatever-1")));Thread.sleep(2000);
		driver.findElement(By.xpath("//div[contains(text(),'BDD')]")).click();
	    
		/* Source - ACHNET */ 
	    driver.findElement(By.xpath("//div[@id=\'root\']/div[2]/div/div/div[2]/div[3]/div/div[2]/div[2]/div/div/div/div[2]/table/tbody/tr/td[2]/div/div")).click();Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'Achnet')]")));
  		driver.findElement(By.xpath("//div[contains(text(),'Achnet')]")).click();
  		
	    /* Difficulty Level */
  		driver.findElement(By.xpath("/html/body/div[1]/div[2]/div/div/div[2]/div[3]/div/div[2]/div[2]/div/div/div/div[2]/table/tbody/tr[1]/td[3]/div/div[1]/div[2]/div")).click();Thread.sleep(2000);
  		driver.findElement(By.xpath("//div[contains(text(),'Medium')]")).click();Thread.sleep(2000);
	    
	    /* Question Type */
  		driver.findElement(By.xpath("/html/body/div[1]/div[2]/div/div/div[2]/div[3]/div/div[2]/div[2]/div/div/div/div[2]/table/tbody/tr[1]/td[4]/div/div/div[2]/div")).click();Thread.sleep(2000);
  		wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath("/html/body/div[1]/div[2]/div/div/div[2]/div[3]/div/div[2]/div[2]/div/div/div/div[2]/table/tbody/tr[1]/td[4]/div/div[2]")));
  		driver.findElement(By.xpath("/html/body/div[1]/div[2]/div/div/div[2]/div[3]/div/div[2]/div[2]/div/div/div/div[2]/table/tbody/tr[1]/td[4]/div/div[2]/div/div")).click();Thread.sleep(2000);
	    
	    /* Select Questions */
	    driver.findElement(By.cssSelector(".skillSelectedQ")).click();Thread.sleep(2000);
	    {
	      WebElement dropdown = driver.findElement(By.cssSelector(".skillSelectedQ"));
	      dropdown.findElement(By.xpath("//option[. = '1']")).click();Thread.sleep(2000);
	    }
	    
	    /* Scores Field */
	    driver.findElement(By.cssSelector(".skillScoreCorrect")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".skillScoreCorrect")).sendKeys("2");
	    driver.findElement(By.cssSelector(".skillScoreIncorrect")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".skillScoreIncorrect")).sendKeys("-1");
	    
	    /* Section Name */
	    driver.findElement(By.cssSelector(".col-2 > input")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".col-2 > input")).clear();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".col-2 > input")).sendKeys("Medium");Thread.sleep(2000);
	    
	    /* Delete or Non - Select Questions */
	    driver.findElement(By.cssSelector(".skillActions > .fa-trash")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".btn-primary")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".skillSelectedQ")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".skillTotalQ")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".selectAllContainer > input")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".doneButton")).click();Thread.sleep(2000);
	    
	    /* Delete Skill? but NO */
	    driver.findElement(By.cssSelector(".skillActions > .fa-trash")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".btn-primary")).click();Thread.sleep(2000);
	    
	    /* Save Skill */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".skillActions > .fa-floppy-o")));
	    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".skillActions > .fa-floppy-o")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".skillActions > .fa-floppy-o")).click();Thread.sleep(2000);
	    Thread.sleep(2000);
	    
	    /* Delete Skill? but NO */
	    driver.findElement(By.cssSelector(".skillActions > .fa-trash")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".btn-primary")).click();Thread.sleep(2000);
	    
	    /* Add Second Skill - from Question Bank */
	    driver.findElement(By.xpath("//button[@class=\'addSkillButton mt-1\']")).click();
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".form-input")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".form-input")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".form-input")).sendKeys("BDD");Thread.sleep(2000);	    
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("react-autowhatever-1")));Thread.sleep(2000);
		driver.findElement(By.xpath("//div[contains(text(),'BDD - Ifthy')]")).click();
		
		/* Select Source */
		driver.findElement(By.xpath("/html/body/div[1]/div[2]/div/div/div[2]/div[3]/div/div[2]/div[2]/div/div/div/div[2]/table/tbody/tr[1]/td[2]/div/div/div[2]/div")).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'Business Automation')]")));Thread.sleep(2000);
		driver.findElement(By.xpath("//div[contains(text(),'Business Automation')]")).click();

		/* Difficulty Level */
		driver.findElement(By.xpath("/html/body/div[1]/div[2]/div/div/div[2]/div[3]/div/div[2]/div[2]/div/div/div/div[2]/table/tbody/tr[1]/td[3]/div/div[1]/div[2]/div")).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'Easy')]")));Thread.sleep(2000);
		driver.findElement(By.xpath("//div[contains(text(),'Easy')]")).click();

		/* Questions Type */
		driver.findElement(By.xpath("/html/body/div[1]/div[2]/div/div/div[2]/div[3]/div/div[2]/div[2]/div/div/div/div[2]/table/tbody/tr[1]/td[4]/div/div/div[2]/div")).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'SC-Single Choice')]")));Thread.sleep(2000);
		driver.findElement(By.xpath("//div[contains(text(),'SC-Single Choice')]")).click();			    
	    
	    /* Delete Skill? but NO */
	    driver.findElement(By.cssSelector(".skillActions > .fa-trash")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".btn-primary")).click();Thread.sleep(2000);
	    
	    /* Select Questions */
	    driver.findElement(By.cssSelector(".skillSelectedQ")).click();Thread.sleep(2000);
	    {
	      WebElement dropdown = driver.findElement(By.cssSelector(".skillSelectedQ"));
	      dropdown.findElement(By.xpath("//option[. = '2']")).click();Thread.sleep(2000);
	    }
	    
	    /* Scores Field */
	    driver.findElement(By.cssSelector(".skillScoreCorrect")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".skillScoreCorrect")).sendKeys("2");
	    driver.findElement(By.cssSelector(".skillScoreIncorrect")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".skillScoreIncorrect")).sendKeys("-1");
	    
	    /* Section Name */
	    driver.findElement(By.cssSelector(".col-2 > input")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".col-2 > input")).clear();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".col-2 > input")).sendKeys("Easy");Thread.sleep(2000);
	    
	    /* Save Skill */
	    driver.findElement(By.cssSelector(".skillActions > .fa-floppy-o")).click();Thread.sleep(2000);
	    
	    /* Save & Exit  */
	    driver.findElement(By.cssSelector(".mr-3")).click();Thread.sleep(2000);
	    	   
	    /* Sign Out */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//i[@class='fa fa-sign-out menu-logout-icon']")));
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//i[@class='fa fa-sign-out menu-logout-icon']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//i[@class='fa fa-sign-out menu-logout-icon']")).click();
	    Thread.sleep(2000);
	  	}
	  	}






