package assessmentTechnicalNew;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import screenshotOnFailure.FailScreenshot;

@Listeners(screenshotListners.EventList.class)
public class T1_CreateDlt_Test extends FailScreenshot{

	  	@Test
	  	public void TA_Test_NoJOB_NoSkill() throws InterruptedException{
	  	
  		/* Login to the Application - PBC */ 		
	  	driver.findElement(By.xpath("(//button[normalize-space()='Login'])[1]")).click();
  		driver.findElement(By.xpath("//input[@id='Username']")).click();
  		driver.findElement(By.xpath("//input[@id='Username']")).sendKeys("john.doe005");
  		driver.findElement(By.xpath("//input[@id='password-field']")).click();
  		driver.findElement(By.xpath("//input[@id='password-field']")).sendKeys("Rockon123");
  		driver.findElement(By.xpath("//button[@id='loginButton']")).click();
  		Thread.sleep(1500);
  		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(120));
	    
	    /* Naviagte to the Business Page */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[normalize-space()='Business Automati...']")));
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()='Business Automati...']")));Thread.sleep(1500);
	    driver.findElement(By.xpath("//span[normalize-space()='Business Automati...']")).click();
	    Thread.sleep(1500);
	    
	    /* Naviagte to the Technical Assessment */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[normalize-space()=\'Administer Test\']")));
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()=\'Administer Test\']")));Thread.sleep(1500);
	    driver.findElement(By.xpath("//span[normalize-space()=\'Administer Test\']")).click();
	    Thread.sleep(1500);
	    
	    /* Cancel the Create Test */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[normalize-space()=\'Create New Test\']")));
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[normalize-space()=\'Create New Test\']")));
	    driver.findElement(By.xpath("//button[normalize-space()=\'Create New Test\']")).click();Thread.sleep(1500);
	    driver.findElement(By.cssSelector(".close > span")).click();Thread.sleep(1500);
	    driver.findElement(By.xpath("//button[normalize-space()=\'Create New Test\']")).click();Thread.sleep(1500);
	    driver.findElement(By.xpath("//label[normalize-space()=\'No\']//input[@name=\'optradio\']")).click();Thread.sleep(1500);
	    driver.findElement(By.xpath("//label[normalize-space()=\'Yes\']//input[@name=\'optradio\']")).click();Thread.sleep(1500);
	    driver.findElement(By.cssSelector(".close > span")).click();Thread.sleep(1500);
	    
	    /* Create New Test - No Job Association */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[normalize-space()=\'Create New Test\']")));
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[normalize-space()=\'Create New Test\']")));
	    driver.findElement(By.xpath("//button[normalize-space()=\'Create New Test\']")).click();Thread.sleep(1500);
	    driver.findElement(By.xpath("//label[normalize-space()=\'No\']//input[@name=\'optradio\']")).click();Thread.sleep(1500);
	    driver.findElement(By.cssSelector(".form-input")).click();Thread.sleep(1500);
	    driver.findElement(By.cssSelector(".form-input")).sendKeys("Software Engineer");
	    Thread.sleep(1500);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("#react-autowhatever-1--item-0 > div")));
	    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector("#react-autowhatever-1--item-0 > div")));Thread.sleep(1500);
	    driver.findElement(By.cssSelector("#react-autowhatever-1--item-0 > div")).click();
	    Thread.sleep(1500);
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[@class=\'next-btn-share-test\']")));Thread.sleep(1500);
	    driver.findElement(By.xpath("//button[@class=\'next-btn-share-test\']")).click();Thread.sleep(1500);
	    
	    /* Create Test Overlay */
	    driver.findElement(By.name("testInfoModel.name")).click();Thread.sleep(1500);
	    driver.findElement(By.name("testInfoModel.name")).sendKeys("Automation Test");
	    Thread.sleep(1500);
	    driver.findElement(By.name("duration")).click();Thread.sleep(1500);
	    driver.findElement(By.name("duration")).sendKeys("30");Thread.sleep(1500);
	    driver.findElement(By.id("createTestNextBtn")).click();Thread.sleep(1500);
	    
	    /* Video Proctoring and PErformance Categories */
	    driver.findElement(By.cssSelector(".custom-control-label")).click();Thread.sleep(1500);
	    driver.findElement(By.cssSelector(".custom-control-label")).click();Thread.sleep(1500);
	    driver.findElement(By.cssSelector(".close > span")).click();Thread.sleep(1500);
	    driver.findElement(By.cssSelector(".btn-primary")).click();Thread.sleep(1500);
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[@class=\'next-btn-share-test\']")));Thread.sleep(1500);
	    driver.findElement(By.xpath("//button[@class=\'next-btn-share-test\']")).click();Thread.sleep(1500);
	    driver.findElement(By.cssSelector(".close > span")).click();Thread.sleep(1500);
	    driver.findElement(By.cssSelector(".btn-primary")).click();Thread.sleep(1500);
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[@class=\'next-btn-share-test\']")));Thread.sleep(1500);
	    driver.findElement(By.xpath("//button[@class=\'next-btn-share-test\']")).click();
	    Thread.sleep(1500);
	    
	    /* Edit and Update Test */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//i[@title=\'Edit\']")));
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//i[@title=\'Edit\']")));
	    driver.findElement(By.xpath("//i[@title=\'Edit\']")).click();
	    Thread.sleep(1500);
	    driver.findElement(By.xpath("//label[normalize-space()=\'Yes\']//input[@name=\'optradio\']")).click();Thread.sleep(1500);
	    driver.findElement(By.xpath("//label[normalize-space()=\'No\']//input[@name=\'optradio\']")).click();Thread.sleep(1500);
	    driver.findElement(By.xpath("//button[@class=\'next-btn-share-test\']")).click();
	    Thread.sleep(1500);
	    driver.findElement(By.name("testInfoModel.name")).click();
	    driver.findElement(By.name("testInfoModel.name")).clear();Thread.sleep(1500);
	    driver.findElement(By.name("testInfoModel.name")).sendKeys(" Edit");
	    Thread.sleep(1500);
	    driver.findElement(By.name("duration")).click();
	    driver.findElement(By.name("duration")).clear();Thread.sleep(1500);
	    driver.findElement(By.name("duration")).sendKeys("0");
	    Thread.sleep(1500);
	    driver.findElement(By.xpath("//input[@value=\'Timed\']")).click();
	    Thread.sleep(1500);
	    driver.findElement(By.xpath("//button[@id=\'createTestNextBtn\']")).click();
	    Thread.sleep(1500);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[@class=\'next-btn-share-test\']")));
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[@class=\'next-btn-share-test\']")));Thread.sleep(1500);
	    driver.findElement(By.xpath("//button[@class=\'next-btn-share-test\']")).click();
	    Thread.sleep(1500);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[@class=\'next-btn-share-test\']")));
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[@class=\'next-btn-share-test\']")));Thread.sleep(1500);
	    driver.findElement(By.xpath("//button[@class=\'next-btn-share-test\']")).click();Thread.sleep(1500);
	    
	    /* Delete Test */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[@class=\'deleteBtn\']//i[@class=\'fa fa-trash\']")));
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[@class=\'deleteBtn\']//i[@class=\'fa fa-trash\']")));
	    driver.findElement(By.xpath("//button[@class=\'deleteBtn\']//i[@class=\'fa fa-trash\']")).click();
	    Thread.sleep(1500);
	    driver.findElement(By.cssSelector(".margin-right-10")).click();
	    Thread.sleep(1500);
	    
	    /* Sign Out */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".achnetLogo")));
	    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".achnetLogo")));
	    driver.findElement(By.cssSelector(".achnetLogo")).click();
	    Thread.sleep(1500);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[normalize-space()='Business Automati...']")));
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()='Business Automati...']")));Thread.sleep(1500);
	    driver.findElement(By.xpath("//span[normalize-space()='Business Automati...']")).click();
	    Thread.sleep(1500);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[normalize-space()=\'Administer Test\']")));
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()=\'Administer Test\']")));Thread.sleep(1500);
	    driver.findElement(By.xpath("//span[normalize-space()=\'Administer Test\']")).click();
	    Thread.sleep(1500);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//i[@class='fa fa-sign-out menu-logout-icon']")));
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//i[@class='fa fa-sign-out menu-logout-icon']")));Thread.sleep(1500);
	    driver.findElement(By.xpath("//i[@class='fa fa-sign-out menu-logout-icon']")).click();
	    Thread.sleep(1500);
	  }
	}

