package assessmentTechnicalNew;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import screenshotOnFailure.FailScreenshot;

@Listeners(screenshotListners.EventList.class)
public class T3_QuestionBank extends FailScreenshot{	
	
	@Test
  	public void TA_AddEdit_Delete() throws InterruptedException{

  		/* Login to the Application - PBC */ 		
		driver.findElement(By.xpath("(//button[normalize-space()='Login'])[1]")).click();
  		driver.findElement(By.xpath("//input[@id='Username']")).click();
  		driver.findElement(By.xpath("//input[@id='Username']")).sendKeys("john.doe005");
  		driver.findElement(By.xpath("//input[@id='password-field']")).click();
  		driver.findElement(By.xpath("//input[@id='password-field']")).sendKeys("Rockon123");
  		driver.findElement(By.xpath("//button[@id='loginButton']")).click();
  		Thread.sleep(2000);
  		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(120));
	    
	    /* Naviagte to the Business Page */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[normalize-space()='Business Automati...']")));
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()='Business Automati...']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//span[normalize-space()='Business Automati...']")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[normalize-space()=\'Administer Test\']")));
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()=\'Administer Test\']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//span[normalize-space()=\'Administer Test\']")).click();
	    Thread.sleep(2000);
	    
	    /* Upload Question and Cancel */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[1]/div[2]/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/a[3]/div[1]/span[2]")));
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[1]/div[2]/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/a[3]/div[1]/span[2]")));Thread.sleep(2000);
		driver.findElement(By.xpath("//div[1]/div[2]/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/a[3]/div[1]/span[2]")).click();
		Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[@id='createNewQuestionBtn']")));
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[@id='createNewQuestionBtn']")));Thread.sleep(2000);
		driver.findElement(By.xpath("//button[@id='createNewQuestionBtn']")).click();
		Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".close > span")));
	    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".close > span")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".close > span")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("//a[@id='uploadQuestionsBtn']")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".backButton > .margin-left-5")).click();Thread.sleep(2000);
	    
	    /* Add Questions - Qustion Bank */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[1]/div[2]/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/a[3]/div[1]/span[2]")));
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[1]/div[2]/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/a[3]/div[1]/span[2]")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[1]/div[2]/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/a[3]/div[1]/span[2]")).click();Thread.sleep(2000);
	    driver.findElement(By.xpath("//button[@title=\'Delete Skill\']//i[@class=\'fa fa-trash\']")).click();Thread.sleep(2000);
	    driver.findElement(By.xpath("//button[@class=\'btn-primary modal-error-btny\']")).click();Thread.sleep(2000);
	    driver.findElement(By.xpath("//span[normalize-space()=\'Add to Question Bank\']")).click();Thread.sleep(2000);
	    driver.findElement(By.xpath("//button[@class=\'btn-primary noBtn\']")).click();Thread.sleep(2000);
	    driver.findElement(By.xpath("//span[normalize-space()=\'Add to Question Bank\']")).click();Thread.sleep(2000);
	    driver.findElement(By.xpath("//button[@class=\'margin-right-15 yesBtn\']")).click();
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@role=\'alert\']")));
		driver.findElement(By.xpath("//div[@role=\'alert\']")).click();
		Thread.sleep(2000);
	    
	    /* My Questions */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[normalize-space()=\'Create Questions\']")));
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()=\'Create Questions\']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//span[normalize-space()=\'Create Questions\']")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".close > span")));
	    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".close > span")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".close > span")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("//span[contains(.,\'Upload Questions\')]")).click();Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".backButton > .margin-left-5")));
	    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".backButton > .margin-left-5")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".backButton > .margin-left-5")).click();Thread.sleep(2000);
	    
	    /* Question Bank Menu */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[1]/div[2]/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/a[2]/div[1]/span[2]")));
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[1]/div[2]/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/a[2]/div[1]/span[2]")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[1]/div[2]/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/a[2]/div[1]/span[2]")).click();Thread.sleep(2000);
	    
	    /* Download Question - mouse hover*/
	    {
	      WebElement element = driver.findElement(By.xpath("//i[@class=\'fa fa-download\']"));Thread.sleep(2000);
	      Actions builder = new Actions(driver);
	      builder.moveToElement(element).perform();
	    }
	    Thread.sleep(2000);
	    
	    /* View and Edit */
	    driver.findElement(By.xpath("//i[@class=\'fa fa-eye\']")).click();Thread.sleep(2000);
	    driver.findElement(By.xpath("//span[@class=\'margin-left-5\']")).click();Thread.sleep(2000);
	    driver.findElement(By.xpath("//i[@class=\'fa fa-pencil-square-o\']")).click();Thread.sleep(2000);
	    driver.findElement(By.xpath("//button[@title=\'Edit Skill Name\']//i[@class=\'fa fa-pencil-square-o\']")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".close > span")).click();Thread.sleep(2000);
	    
	    /* Edit Skill */
	    driver.findElement(By.xpath("//button[@title=\'Edit Skill Name\']//i[@class=\'fa fa-pencil-square-o\']")).click();Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[@class=\'firstSubskill margin-top-30\']//input[contains(@placeholder,\'\')]")).click();Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[@class=\'firstSubskill margin-top-30\']//input[contains(@placeholder,\'\')]")).clear();Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[@class=\'firstSubskill margin-top-30\']//input[contains(@placeholder,\'\')]")).sendKeys("Testing");
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[@class=\'secondSubskill margin-top-30\']//input[contains(@placeholder,\'\')]")).click();Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[@class=\'secondSubskill margin-top-30\']//input[contains(@placeholder,\'\')]")).clear();Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[@class=\'secondSubskill margin-top-30\']//input[contains(@placeholder,\'\')]")).sendKeys("Ifthy");
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("//button[@class=\'saveBtn\']")).click();Thread.sleep(2000);
	    driver.findElement(By.xpath("//button[@title=\'Delete Skill\']//i[@class=\'fa fa-trash\']")).click();Thread.sleep(2000);
	    driver.findElement(By.xpath("//button[@class=\'btn-primary modal-error-btny\']")).click();Thread.sleep(2000);
	    
	    /* Edit and Update Questions */
	    driver.findElement(By.xpath("//div[1]/div[2]/div[1]/div[1]/div[2]/div[3]/div[3]/div[2]/div[2]/div[3]/div[4]/button[1]/i[1]")).click();Thread.sleep(2000);
	    driver.findElement(By.xpath("/html[1]/body[1]/div[1]/div[2]/div[1]/div[1]/div[2]/div[3]/div[3]/div[2]/div[2]/div[3]/div[3]/div[4]/div[2]/input[1]")).click();Thread.sleep(2000);
	    driver.findElement(By.xpath("/html[1]/body[1]/div[1]/div[2]/div[1]/div[1]/div[2]/div[3]/div[3]/div[2]/div[2]/div[3]/div[3]/div[3]/div[2]/input[1]")).click();Thread.sleep(2000);
	    driver.findElement(By.xpath("//i[@class='fa fa-plus-circle']")).click();Thread.sleep(2000);
	    driver.findElement(By.xpath("/html[1]/body[1]/div[1]/div[2]/div[1]/div[1]/div[2]/div[3]/div[3]/div[2]/div[2]/div[3]/div[3]/div[4]/div[1]/div[1]")).click();Thread.sleep(2000);
	    driver.findElement(By.xpath("//span[normalize-space()='Update']")).click();
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@role=\'alert\']")));
		driver.findElement(By.xpath("//div[@role=\'alert\']")).click();
	    Thread.sleep(2000);
	    
	    /* Scroll Up the page */
	    JavascriptExecutor jse = (JavascriptExecutor)driver;
	    jse.executeScript("scroll(0, -250);");	    	    
	    Thread.sleep(2000);  
	    /* Click Back Button */
	    driver.findElement(By.xpath("//span[@class=\'margin-left-5\']")).click();Thread.sleep(2000);
	    
	    /* Delete Question Bank */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//i[@class=\'fa fa-trash\']")));
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//i[@class=\'fa fa-trash\']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//i[@class=\'fa fa-trash\']")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[@class=\'btn-primary modal-error-btny\']")));
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[@class=\'btn-primary modal-error-btny\']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//button[@class=\'btn-primary modal-error-btny\']")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//i[@class=\'fa fa-trash\']")));
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//i[@class=\'fa fa-trash\']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//i[@class=\'fa fa-trash\']")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[@class=\'margin-right-10 modal-error-btnn\']")));
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[@class=\'margin-right-10 modal-error-btnn\']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//button[@class=\'margin-right-10 modal-error-btnn\']")).click();
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@role=\'alert\']")));
		driver.findElement(By.xpath("//div[@role=\'alert\']")).click();
	    Thread.sleep(2000);
	    
	    /* Navigate back to My Questions */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[@class=\'ml-1\']")));
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[@class=\'ml-1\']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//span[@class=\'ml-1\']")).click();Thread.sleep(2000);
	    	    
	    /* Logout */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//i[@class='fa fa-sign-out menu-logout-icon']")));
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//i[@class='fa fa-sign-out menu-logout-icon']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//i[@class='fa fa-sign-out menu-logout-icon']")).click();
	    Thread.sleep(2000);
	 }
}