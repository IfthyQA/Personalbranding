package disputeCancel;

import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import screenshotOnFailure.FailScreenshot;

@Listeners(screenshotListners.EventList.class)
public class DC20_AcceptProposal extends FailScreenshot{

	@Test
	public void DC_AcceptProposal() throws InterruptedException {

		/* Login to the Application - PBC */ 		
	  	driver.findElement(By.xpath("(//button[normalize-space()='Login'])[1]")).click();
		driver.findElement(By.xpath("//input[@id='Username']")).click();
		driver.findElement(By.xpath("//input[@id='Username']")).sendKeys("john.doe002");
		driver.findElement(By.xpath("//input[@id='password-field']")).click();
		driver.findElement(By.xpath("//input[@id='password-field']")).sendKeys("Rockon123");
		driver.findElement(By.xpath("//button[@id='loginButton']")).click();
		Thread.sleep(2000);
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(120));		
	    
		/* Navigate to Coaching Support */
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'My Profile')]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'My Profile')]")));
		Thread.sleep(2000);
		{
		     WebElement element = driver.findElement(By.xpath("//div[@class='menu-item menu-item-active']"));
		     Actions builder = new Actions(driver);
		     builder.moveToElement(element).perform();
		}
		Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'Coaching Support')]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'Coaching Support')]")));Thread.sleep(2000);
		driver.findElement(By.xpath("//div[contains(text(),'Coaching Support')]")).click();
	    Thread.sleep(2000);	
	    
	    /* Deny Proposal of Adam Musa- But Cancel */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("a > .btn-blue-link-12")));;	
	    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector("a > .btn-blue-link-12")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector("a > .btn-blue-link-12")).click();Thread.sleep(2000);
	    driver.findElement(By.linkText("Back To My Requests")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".btn-outline-grey")));;	
	    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".btn-outline-grey")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".btn-outline-grey")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.id("btnNoConfirmYesNo")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".form-inline .d-none")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".d-none > .coaching-bold-font span")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".form-inline:nth-child(2) > .btn-sm")));;	
	    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".form-inline:nth-child(2) > .btn-sm")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".form-inline:nth-child(2) > .btn-sm")).click();Thread.sleep(2000);
	    driver.findElement(By.id("btnNoConfirmYesNo")).click();
	    Thread.sleep(2000);
	    
	    /* Deny Proposal of Adam Musa from Detailed View */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[normalize-space()=\'Proposal: Automation Deny Testing\']")));;	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()=\'Proposal: Automation Deny Testing\']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//span[normalize-space()=\'Proposal: Automation Deny Testing\']")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".btn-outline-grey")));;	
	    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".btn-outline-grey")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".btn-outline-grey")).click();Thread.sleep(2000);
	    driver.findElement(By.id("btnYesConfirmYesNo")).click();Thread.sleep(2000);
	    
	    /* View the Proposal */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".proposal-title")));;	
	    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".proposal-title")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".proposal-title")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[contains(.,\'Accept\')]")));;	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[contains(.,\'Accept\')]")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//button[contains(.,\'Accept\')]")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector("#coachingacceptpopup > .modal-header .fa")));
	    driver.findElement(By.cssSelector("#coachingacceptpopup > .modal-header .fa")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()='Discussion']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//span[normalize-space()='Discussion']")).click();	    
	    Thread.sleep(2000);		    	  
	    
	    /* Accept Proposal */
	    driver.findElement(By.cssSelector(".d-none:nth-child(2) > a")).click();Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[contains(.,\'Accept\')]")));;	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[contains(.,\'Accept\')]")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//button[contains(.,\'Accept\')]")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".btn-sm:nth-child(3)")).click();Thread.sleep(2000);
	    driver.findElement(By.id("addBtnStripe")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".btn-grey")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".credit-card-list > div")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".btn-blue:nth-child(3)")).click();Thread.sleep(2000);
	    driver.findElement(By.id("btnNoConfirmYesNo")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".btn-blue:nth-child(3)")).click();Thread.sleep(2000);
	    driver.findElement(By.id("btnYesConfirmYesNo")).click();Thread.sleep(2000);
	    
	    /* Work in Progress after Accepting Proposal */
	    driver.findElement(By.cssSelector(".btn-outline-blue:nth-child(1)")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".modal-lg .modal-header .fa")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".btn-outline-blue:nth-child(1)")).click();Thread.sleep(2000);
	    driver.findElement(By.xpath("//span[@class=\'titleAttach\']")).click();
	    Thread.sleep(2000);	 
	    driver.findElement(By.xpath("//button[@type=\'button\']//span[contains(text(),\'Power Share\')]")).click();
	    Thread.sleep(2000);	 
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("#file5ee2fc5eb4d985c1a0eda237 .fa")));;	
	    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector("#file5ee2fc5eb4d985c1a0eda237 .fa")));
	    driver.findElement(By.cssSelector("#file5ee2fc5eb4d985c1a0eda237 .fa")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".modal-social > .modal-header .fa")));;	
	    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".modal-social > .modal-header .fa")));
	    driver.findElement(By.cssSelector(".modal-social > .modal-header .fa")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("//span[@class=\'titleAttach\']")).click();
	    Thread.sleep(2000);	 
	    driver.findElement(By.xpath("//button[@type=\'button\']//span[contains(text(),\'Power Share\')]")).click();
	    Thread.sleep(2000);	 
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("#file5ee2fc5eb4d985c1a0eda237 .fa")));;	
	    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector("#file5ee2fc5eb4d985c1a0eda237 .fa")));
	    driver.findElement(By.cssSelector("#file5ee2fc5eb4d985c1a0eda237 .fa")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[normalize-space()='ADD FILES']")));;	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()='ADD FILES']")));
	    driver.findElement(By.xpath("//span[normalize-space()='ADD FILES']")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("#modalMyFiles .modal-header .fa")));;	
	    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector("#modalMyFiles .modal-header .fa")));
	    driver.findElement(By.cssSelector("#modalMyFiles .modal-header .fa")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@id='divLeftMenu']/div[4]/a")));;	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@id='divLeftMenu']/div[4]/a")));
	    driver.findElement(By.xpath("//div[@id='divLeftMenu']/div[4]/a")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".margin-top-10 > .btn-blue-link-12")));;	
	    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".margin-top-10 > .btn-blue-link-12")));
	    driver.findElement(By.cssSelector(".margin-top-10 > .btn-blue-link-12")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector("#coachingcancelpopup > .modal-header .fa")).click();Thread.sleep(2000);
	    
	    /* Discussion Menu */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//a[contains(.,'Discussions')])[1]")));;	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//a[contains(.,'Discussions')])[1]")));
	    driver.findElement(By.xpath("(//a[contains(.,'Discussions')])[1]")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.linkText("Active")));;	
	    wait.until(ExpectedConditions.elementToBeClickable(By.linkText("Active")));
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("//i[@class='fa expand fa-angle-up']")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".form-inline span:nth-child(2)")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//li[@id='lnkArchiveDiscussion']//a")));;	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//li[@id='lnkArchiveDiscussion']//a")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//li[@id='lnkArchiveDiscussion']//a")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//span//span[contains(text(),'Discussion')])[1]")));;	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//span//span[contains(text(),'Discussion')])[1]")));
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.linkText("Active")));;	
	    wait.until(ExpectedConditions.elementToBeClickable(By.linkText("Active")));Thread.sleep(2000);
	    driver.findElement(By.linkText("Active")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//strong[contains(text(),'Software Engineer at Rockon LLC')]")));;	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//strong[contains(text(),'Software Engineer at Rockon LLC')]")));
	    driver.findElement(By.xpath("//strong[contains(text(),'Software Engineer at Rockon LLC')]")).click();
	    Thread.sleep(2000);	  
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("discussiontextarea")));;	
	    wait.until(ExpectedConditions.elementToBeClickable(By.id("discussiontextarea")));Thread.sleep(2000);
	    driver.findElement(By.id("discussiontextarea")).click();Thread.sleep(2000);
	    driver.findElement(By.id("discussiontextarea")).sendKeys("Let me read your Proposal");Thread.sleep(2000);
	    driver.findElement(By.xpath("//button[contains(.,\'Send Message\')]")).click();
	    Thread.sleep(2000);	    	   
	    
	    /* Logout */
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'My Profile')]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'My Profile')]")));Thread.sleep(2000);
		driver.findElement(By.xpath("//div[contains(text(),'My Profile')]")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("(//div[contains(text(),'Logout')])[2]")).click();
		Thread.sleep(2000);
	  }
	}
