package disputeCancel;

import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import screenshotOnFailure.FailScreenshot;

@Listeners(screenshotListners.EventList.class)
public class DC31_CompleteMilestone extends FailScreenshot{
	
	@Test
	public void DC_CompleteMilestone() throws InterruptedException {

		/* Login to the Application - PBC */ 		
	  	driver.findElement(By.xpath("(//button[normalize-space()='Login'])[1]")).click();
		driver.findElement(By.xpath("//input[@id='Username']")).click();
		driver.findElement(By.xpath("//input[@id='Username']")).sendKeys("john.doe003");
		driver.findElement(By.xpath("//input[@id='password-field']")).click();
		driver.findElement(By.xpath("//input[@id='password-field']")).sendKeys("Rockon123");
		driver.findElement(By.xpath("//button[@id='loginButton']")).click();
		Thread.sleep(2000);
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(120));	    
	    
		/* Navigate to the Coach Page */
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[2]/div[1]/div[1]/div[2]/div[1]/div[1]/a[1]/span[1]")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[2]/div[1]/div[1]/div[2]/div[1]/div[1]/a[1]/span[1]")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[2]/div[1]/div[1]/div[2]/div[1]/div[1]/a[1]/span[1]")).click();
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[normalize-space()='Menu']")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()='Menu']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//span[normalize-space()='Menu']")).click();
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[normalize-space()='Coaching Services']")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[normalize-space()='Coaching Services']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//a[normalize-space()='Coaching Services']")).click();
	    Thread.sleep(2000);
	    
	    /* My Files in Complete Milestone page */
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("menuiteminprogress")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.id("menuiteminprogress")));Thread.sleep(2000);
	    driver.findElement(By.id("menuiteminprogress")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".float-md-right > .btn-sm")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".fa-trash-o")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.id("btnNoConfirmYesNo")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".fa-trash-o")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.id("btnYesConfirmYesNo")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[@class=\'titleAttach\']")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[@class=\'titleAttach\']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//span[@class=\'titleAttach\']")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("//button[@type=\'button\']//span[contains(text(),\'Business Vault\')]")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".btn")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".btn")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector("#file5ee2f220b4d985c1a0ed3a7b .fa")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".btn")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector("#modalMyFiles .modal-header .fa")).click();
	    Thread.sleep(2000);
	    
	    /* Detailed View - Click on proposal Title */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".proposal-title")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".proposal-title")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".proposal-title")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[3]/div/span")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector("#coachingcancelpopup > .modal-header .fa")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".btn-outline-blue")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".fa-arrow-circle-o-left")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".btn-lg")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[@id=\'coachingcancelpopup\']/div[2]/div/form/div[3]/span/button")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector("#coachingcancelpopup > .modal-header .fa")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[2]/div/form/button")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector("#divWorkInProgressModal .modal-header .fa")).click();
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("menuiteminprogress")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.id("menuiteminprogress")));Thread.sleep(2000);
	    driver.findElement(By.id("menuiteminprogress")).click();
	    Thread.sleep(2000);
	    
	    /* Complete Milestone */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[2]/div/form/button")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[2]/div/form/button")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[2]/div/form/button")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@id=\'divWorkInProgressModal\']/div/div/div[2]/div/div[5]/form/button")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@id=\'divWorkInProgressModal\']/div/div/div[2]/div/div[5]/form/button")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[@id=\'divWorkInProgressModal\']/div/div/div[2]/div/div[5]/form/button")).click();
	    Thread.sleep(2000);
	    
	    /* Logout */
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'My Profile')]")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'My Profile')]")));Thread.sleep(2000);
		driver.findElement(By.xpath("//div[contains(text(),'My Profile')]")).click();  
		Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//div[contains(text(),'Logout')])[1]")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//div[contains(text(),'Logout')])[1]")));Thread.sleep(2000);
		driver.findElement(By.xpath("(//div[contains(text(),'Logout')])[1]")).click();  
		Thread.sleep(2000);
	  }
	}

	
