package disputeCancel;

import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import screenshotOnFailure.FailScreenshot;

@Listeners(screenshotListners.EventList.class)
public class DC12_SendProposal extends FailScreenshot{
	
	@Test
	public void DC_SendProposal() throws InterruptedException {

	/* Login to the Application - PBC */ 		
	driver.findElement(By.xpath("(//button[normalize-space()='Login'])[1]")).click();
	driver.findElement(By.xpath("//input[@id='Username']")).click();
	driver.findElement(By.xpath("//input[@id='Username']")).sendKeys("john.doe003");
	driver.findElement(By.xpath("//input[@id='password-field']")).click();
	driver.findElement(By.xpath("//input[@id='password-field']")).sendKeys("Rockon123");
	driver.findElement(By.xpath("//button[@id='loginButton']")).click();
	Thread.sleep(2000);
	WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(120));    
    
	/* Navigate to the Coach Page */
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[2]/div[1]/div[1]/div[2]/div[1]/div[1]/a[1]/span[1]")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[2]/div[1]/div[1]/div[2]/div[1]/div[1]/a[1]/span[1]")));Thread.sleep(2000);
    driver.findElement(By.xpath("//div[2]/div[1]/div[1]/div[2]/div[1]/div[1]/a[1]/span[1]")).click();
    Thread.sleep(2000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[normalize-space()='Menu']")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()='Menu']")));Thread.sleep(2000);
    driver.findElement(By.xpath("//span[normalize-space()='Menu']")).click();
    Thread.sleep(2000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[normalize-space()='Coaching Services']")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[normalize-space()='Coaching Services']")));Thread.sleep(2000);
    driver.findElement(By.xpath("//a[normalize-space()='Coaching Services']")).click();
    Thread.sleep(2000);
    
    /* Send proposal from Draft */
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("menuitemdraft")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.id("menuitemdraft")));Thread.sleep(2000);
    driver.findElement(By.id("menuitemdraft")).click();
    Thread.sleep(2000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".form-inline > .btn-maroon")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".form-inline > .btn-maroon")));Thread.sleep(2000);
    driver.findElement(By.cssSelector(".form-inline > .btn-maroon")).click();
    Thread.sleep(2000);
    driver.findElement(By.xpath("//div[@id='lblconfirmbody']/div/button/span/i")).click();
    Thread.sleep(2000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".form-inline > .btn-maroon")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".form-inline > .btn-maroon")));Thread.sleep(2000);
    driver.findElement(By.cssSelector(".form-inline > .btn-maroon")).click();
    Thread.sleep(2000);
    driver.findElement(By.id("btnYesConfirmYesNo")).click();
    Thread.sleep(2000);
    
    /* My Files and Attach Files */
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".float-md-right > .btn-sm")));
	wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".float-md-right > .btn-sm")));Thread.sleep(2000);
    driver.findElement(By.cssSelector(".float-md-right > .btn-sm")).click();
    Thread.sleep(2000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".modal-lg .modal-header .fa")));
	wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".modal-lg .modal-header .fa")));Thread.sleep(2000);
    driver.findElement(By.cssSelector(".modal-lg .modal-header .fa")).click();
    Thread.sleep(2000);
    driver.findElement(By.cssSelector(".float-md-right > .btn-sm")).click();Thread.sleep(2000);
    driver.findElement(By.xpath("//span[@class=\'titleAttach\']")).click();Thread.sleep(2000);
    driver.findElement(By.xpath("//button[@type=\'button\']//span[contains(text(),\'Business Vault\')]")).click();Thread.sleep(2000);
    driver.findElement(By.cssSelector(".btn")).click();Thread.sleep(2000);
    driver.findElement(By.cssSelector("#file5ee2f220b4d985c1a0ed3a7b .fa")).click();Thread.sleep(2000);
    driver.findElement(By.cssSelector("#file5ee2f22db4d985c1a0ed3a81 .fa")).click();Thread.sleep(2000);
    driver.findElement(By.cssSelector("#file5ee2f22db4d985c1a0ed3a81 .fa-picture-o")).click();Thread.sleep(2000);
    driver.findElement(By.cssSelector(".btn")).click();Thread.sleep(2000);
    
    	String winHandleBefore = driver.getWindowHandle();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".fa-download")).click();
	    Thread.sleep(2000);
    	// Navigate to New window
    	for(String winHandle : driver.getWindowHandles()){
        driver.switchTo().window(winHandle);Thread.sleep(2000);
    	}
    	Thread.sleep(2000);	    
	    driver.close();Thread.sleep(2000);
	    driver.switchTo().window(winHandleBefore);
	    Thread.sleep(2000);  
    driver.findElement(By.cssSelector("#modalMyFiles .modal-header .fa")).click();Thread.sleep(2000);
    
    /* Navigate to the Hub and Coach Dashboard */
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@title='Coach Disputes']")));	// Business Hub Logo Bavigation
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@title='Coach Disputes']")));Thread.sleep(2000);
	driver.findElement(By.xpath("//div[@title='Coach Disputes']")).click();
	Thread.sleep(2000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[normalize-space()='Menu']")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()='Menu']")));Thread.sleep(2000);
    driver.findElement(By.xpath("//span[normalize-space()='Menu']")).click();
    Thread.sleep(2000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[normalize-space()='Coaching Services']")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[normalize-space()='Coaching Services']")));Thread.sleep(2000);
    driver.findElement(By.xpath("//a[normalize-space()='Coaching Services']")).click();
    Thread.sleep(2000);
    
    /* Edit Proposal from Pending Menu*/
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("menuitemreview")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.id("menuitemreview")));Thread.sleep(2000);
    driver.findElement(By.id("menuitemreview")).click();
    Thread.sleep(2000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.linkText("Edit")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.linkText("Edit")));Thread.sleep(2000);
    driver.findElement(By.linkText("Edit")).click();
    Thread.sleep(2000);
    driver.findElement(By.id("ProposalTitle")).click();Thread.sleep(2000);
    driver.findElement(By.id("ProposalTitle")).clear();Thread.sleep(2000);
    driver.findElement(By.id("ProposalTitle")).sendKeys("Thumbor with Python and NLP");
    Thread.sleep(2000);
    driver.findElement(By.id("HourlyRate")).click();Thread.sleep(2000);
    driver.findElement(By.id("HourlyRate")).clear();Thread.sleep(2000);
    driver.findElement(By.id("HourlyRate")).sendKeys("5");Thread.sleep(2000);
    driver.findElement(By.cssSelector(".btn-blue")).click();Thread.sleep(2000);
    driver.findElement(By.cssSelector(".menu-list-active > a")).click();Thread.sleep(2000);
    driver.findElement(By.cssSelector(".col-12 > .form-inline > .btn-blue-link-12")).click();Thread.sleep(2000);
    driver.findElement(By.cssSelector(".btn-outline-grey")).click();Thread.sleep(2000);
    driver.findElement(By.id("btnNoConfirmYesNo")).click();Thread.sleep(2000);
    driver.findElement(By.cssSelector(".btn-outline-blue:nth-child(1)")).click();Thread.sleep(2000);
    driver.findElement(By.cssSelector(".btn-blue-link-14 > span")).click();Thread.sleep(2000);
    driver.findElement(By.xpath("//div[3]/div/span")).click();Thread.sleep(2000);
    driver.findElement(By.cssSelector("#coachingcancelpopup > .modal-header .fa")).click();Thread.sleep(2000);
    driver.findElement(By.linkText("Back to Pending Proposals")).click();Thread.sleep(2000);
    driver.findElement(By.linkText("Edit")).click();Thread.sleep(2000);
    driver.findElement(By.id("ProposalTitle")).click();Thread.sleep(2000);
    driver.findElement(By.id("ProposalTitle")).clear();Thread.sleep(2000);
    driver.findElement(By.id("ProposalTitle")).sendKeys("Nothing");Thread.sleep(2000);
    driver.findElement(By.id("ProposalTitle")).clear();Thread.sleep(2000);
    driver.findElement(By.id("ProposalTitle")).sendKeys("Coaching on Natural Language Process and Thumbor with Python");Thread.sleep(2000);
    driver.findElement(By.cssSelector(".btn-blue")).click();Thread.sleep(2000);
    
    /* Send Discussion from Pending Proposal */
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("menuitemreview")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.id("menuitemreview")));Thread.sleep(2000);
    driver.findElement(By.id("menuitemreview")).click();
    Thread.sleep(2000);
    driver.findElement(By.cssSelector(".form-inline .d-none")).click();Thread.sleep(2000);
    driver.findElement(By.id("discussiontextarea")).click();Thread.sleep(2000);
    driver.findElement(By.id("discussiontextarea")).sendKeys("Hello i have created the proposal, please revert back here");Thread.sleep(2000);
    driver.findElement(By.xpath("//button[contains(.,\'Send Message\')]")).click();Thread.sleep(2000);
    driver.findElement(By.xpath("//button[contains(.,\'Send Message\')]")).click();Thread.sleep(2000);
    driver.findElement(By.cssSelector(".btn-blue-link-12")).click();Thread.sleep(2000);
    
    /* Logout */
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'My Profile')]")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'My Profile')]")));Thread.sleep(2000);
	driver.findElement(By.xpath("//div[contains(text(),'My Profile')]")).click();  
	Thread.sleep(2000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//div[contains(text(),'Logout')])[1]")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//div[contains(text(),'Logout')])[1]")));Thread.sleep(2000);
	driver.findElement(By.xpath("(//div[contains(text(),'Logout')])[1]")).click();  
	Thread.sleep(2000);
  }
}

