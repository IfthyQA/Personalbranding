package disputeCancel;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import screenshotOnFailure.FailScreenshot;

@Listeners(screenshotListners.EventList.class)
public class DC5_CancelDispute extends FailScreenshot{

	@Test
	public void DC_CancelDispute() throws InterruptedException {

		/* Login to the Application - PBC */ 		
	  	driver.findElement(By.xpath("(//button[normalize-space()='Login'])[1]")).click();
		driver.findElement(By.xpath("//input[@id='Username']")).click();
		driver.findElement(By.xpath("//input[@id='Username']")).sendKeys("john.doe002");
		driver.findElement(By.xpath("//input[@id='password-field']")).click();
		driver.findElement(By.xpath("//input[@id='password-field']")).sendKeys("Rockon123");
		driver.findElement(By.xpath("//button[@id='loginButton']")).click();
		Thread.sleep(2000);
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(120));
		
	    /* Navigate to Coaching Support */
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'My Profile')]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'My Profile')]")));
		Thread.sleep(2000);
		{
		     WebElement element = driver.findElement(By.xpath("//div[@class='menu-item menu-item-active']"));
		     Actions builder = new Actions(driver);
		     builder.moveToElement(element).perform();
		}
		Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'Coaching Support')]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'Coaching Support')]")));Thread.sleep(2000);
		driver.findElement(By.xpath("//div[contains(text(),'Coaching Support')]")).click();
	    Thread.sleep(2000);	
	    
	    /* Work in Progress */
	    driver.findElement(By.xpath("//div[@id=\'divLeftMenu\']/div[4]/a")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".float-md-right > .btn-blue-link-12 > .d-none")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".float-md-right > .btn-blue-link-12 > .d-none")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".float-md-right > .btn-blue-link-12 > .d-none")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.id("submitbtn")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".biz-admin-overlay > .modal-header .fa")).click();
	    Thread.sleep(2000);
	    
	    /* Cancel Discussions */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".form-inline .d-none")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".form-inline .d-none")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".form-inline .d-none")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".d-none > .coaching-bold-font span")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector("span:nth-child(2) > .d-none")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector("span:nth-child(2) > .d-none")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".btn-outline-blue:nth-child(1)")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("//span[@class=\'titleAttach\']")).click();
	    Thread.sleep(2000);	 
	    driver.findElement(By.xpath("//button[@type=\'button\']//span[contains(text(),\'Power Share\')]")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector("#file5ee2fc02b4d985c1a0eda20c .fa")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".col-12 > .btn")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".modal-lg .modal-header .fa")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".col-md-12 > .btn-blue-link-12")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector("#coachingcancelpopup > .modal-header .fa")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".btn-blue-link-12 > .d-none")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.id("submitbtn")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".biz-admin-overlay > .modal-header .fa")).click();
	    Thread.sleep(2000);
	    
	    /* Discussions */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".form-inline .d-none")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".form-inline .d-none")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".form-inline .d-none")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.id("discussiontextarea")).click();
	    driver.findElement(By.id("discussiontextarea")).sendKeys("Excuse me for the Conflicts, am taking my words back.");
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("//button[contains(.,\'Send Message\')]")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".btn-blue-link-12 > span")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector("form > .btn-sm")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".coaching-selected-task-title .fa")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".btn-outline-grey")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.id("CancelDetails")).click();
	    driver.findElement(By.id("CancelDetails")).sendKeys("compromised");
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".margin-bottom-20 .btn-sm")).click();
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.stalenessOf(driver.findElement(By.xpath("//div[@class='toast-message']"))));
		Thread.sleep(2000);
	    
	    /* Scroll Down to the Page */
	    JavascriptExecutor jse = (JavascriptExecutor)driver;
	    jse.executeScript("scroll(0, 250);");
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".col-12:nth-child(3) .btn-sm")).click();
	    Thread.sleep(2000);
	    
	    /* Logout */
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'My Profile')]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'My Profile')]")));Thread.sleep(2000);
		driver.findElement(By.xpath("//div[contains(text(),'My Profile')]")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("(//div[contains(text(),'Logout')])[2]")).click();
		Thread.sleep(2000);	    
	  }
	}

