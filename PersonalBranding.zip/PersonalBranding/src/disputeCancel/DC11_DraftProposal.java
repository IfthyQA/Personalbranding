package disputeCancel;

import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import screenshotOnFailure.FailScreenshot;

@Listeners(screenshotListners.EventList.class)
public class DC11_DraftProposal extends FailScreenshot{

	@Test
	public void DC_DraftProposal() throws InterruptedException {
		
	/* Login to the Application - PBC */ 		
	driver.findElement(By.xpath("(//button[normalize-space()='Login'])[1]")).click();
	driver.findElement(By.xpath("//input[@id='Username']")).click();
	driver.findElement(By.xpath("//input[@id='Username']")).sendKeys("john.doe003");
	driver.findElement(By.xpath("//input[@id='password-field']")).click();
	driver.findElement(By.xpath("//input[@id='password-field']")).sendKeys("Rockon123");
	driver.findElement(By.xpath("//button[@id='loginButton']")).click();
	Thread.sleep(2000);
	WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(120));    
    
	/* Navigate to the Coach Page */
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[2]/div[1]/div[1]/div[2]/div[1]/div[1]/a[1]/span[1]")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[2]/div[1]/div[1]/div[2]/div[1]/div[1]/a[1]/span[1]")));Thread.sleep(2000);
    driver.findElement(By.xpath("//div[2]/div[1]/div[1]/div[2]/div[1]/div[1]/a[1]/span[1]")).click();
    Thread.sleep(2000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[normalize-space()='Menu']")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()='Menu']")));Thread.sleep(2000);
    driver.findElement(By.xpath("//span[normalize-space()='Menu']")).click();
    Thread.sleep(2000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[normalize-space()='Coaching Services']")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[normalize-space()='Coaching Services']")));Thread.sleep(2000);
    driver.findElement(By.xpath("//a[normalize-space()='Coaching Services']")).click();
    Thread.sleep(2000);
    
    /* Intitiate the Discussions */
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div/div/div/div/div/div[3]/div/span")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div/div/div/div/div/div[3]/div/span")));Thread.sleep(2000);
	driver.findElement(By.xpath("//span[normalize-space()=\'Image and Natural Language Processing\']")).click();
    Thread.sleep(2000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".btn-blue-link-12 > .d-none")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".btn-blue-link-12 > .d-none")));Thread.sleep(2000);
    driver.findElement(By.cssSelector(".btn-blue-link-12 > .d-none")).click();
    Thread.sleep(2000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("TermsAndCondition")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.id("TermsAndCondition")));Thread.sleep(2000);
    driver.findElement(By.id("TermsAndCondition")).click();
    Thread.sleep(2000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".btn-lg")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".btn-lg")));Thread.sleep(2000);
    driver.findElement(By.cssSelector(".btn-lg")).click();
    Thread.sleep(2000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("discussiontextarea")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.id("discussiontextarea")));Thread.sleep(2000);
    driver.findElement(By.id("discussiontextarea")).click();Thread.sleep(2000);
    driver.findElement(By.id("discussiontextarea")).sendKeys("Hello John, I saw your Coaching request, can you please brief your requirement");Thread.sleep(2000);
    driver.findElement(By.xpath("//button[contains(.,\'Send Message\')]")).click();Thread.sleep(2000);
    driver.findElement(By.cssSelector(".btn-blue-link-12 > span")).click();
    Thread.sleep(2000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".margin-right-15")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".margin-right-15")));Thread.sleep(2000);
    driver.findElement(By.cssSelector(".margin-right-15")).click();
    Thread.sleep(2000);
	wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".coach-terms .fa")));Thread.sleep(2000);
    driver.findElement(By.cssSelector(".coach-terms .fa")).click();Thread.sleep(2000);
    
    /* Create and Draft the proposal */
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".margin-right-15")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".margin-right-15")));Thread.sleep(2000);
    driver.findElement(By.cssSelector(".margin-right-15")).click();Thread.sleep(2000);
    driver.findElement(By.id("TermsAndCondition")).click();Thread.sleep(2000);
    driver.findElement(By.cssSelector(".btn-lg")).click();Thread.sleep(2000);
    driver.findElement(By.cssSelector(".float-right > .btn-sm")).click();Thread.sleep(2000);
    driver.findElement(By.id("ProposalTitle")).click();Thread.sleep(2000);
    driver.findElement(By.id("ProposalTitle")).sendKeys("Natural Language Processing");Thread.sleep(2000);
    driver.findElement(By.id("HourlyRate")).click();Thread.sleep(2000);
    driver.findElement(By.id("HourlyRate")).sendKeys("10");Thread.sleep(2000);
    driver.findElement(By.cssSelector("#mceu_6 .mce-ico")).click();Thread.sleep(2000);
    driver.findElement(By.cssSelector("#mceu_3 .mce-ico")).click();Thread.sleep(2000);
    
    /* Attach files for proposal from Vault*/
    driver.findElement(By.xpath("//span[@class=\'titleAttach\']")).click();Thread.sleep(2000);
    driver.findElement(By.xpath("//button[@type=\'button\']//span[contains(text(),\'Business Vault\')]")).click();Thread.sleep(2000);
    driver.findElement(By.xpath("//div[3]/div/div/div[2]/span")).click();Thread.sleep(2000);
    driver.findElement(By.cssSelector(".btn")).click();Thread.sleep(2000);
    driver.findElement(By.xpath("//div[@id=\'addblanktask\']/div/div/input")).click();Thread.sleep(2000);
    driver.findElement(By.xpath("//div[@id=\'addblanktask\']/div/div/input")).clear();Thread.sleep(2000);
    driver.findElement(By.xpath("//div[@id=\'addblanktask\']/div/div/input")).sendKeys("123456789abcdefghijklmnopqrstuvwxyz12345678ABCDEFGI");Thread.sleep(2000);
    driver.findElement(By.xpath("//div[@id=\'addblanktask\']/div/div/input")).clear();Thread.sleep(2000);
    driver.findElement(By.xpath("//div[@id=\'addblanktask\']/div/div/input")).sendKeys("NLP & The Thumbor Server");Thread.sleep(2000);
    driver.findElement(By.xpath("//div[@id=\'addblanktask\']/div/div/input")).click();Thread.sleep(2000);
    driver.findElement(By.xpath("//div/div/div/div[2]/div/div/div/div/div/div/div/div/div/div[4]/div/div/button/i")).click();Thread.sleep(2000);
    driver.findElement(By.xpath("//div/div/div/div[2]/div/div/div/div/div/div/div/div/div/div[3]/div/div/button/i")).click();Thread.sleep(2000);
    driver.findElement(By.cssSelector(".divStartDatePicker .fa")).click();Thread.sleep(2000);
    driver.findElement(By.cssSelector(".year:nth-child(12)")).click();Thread.sleep(2000);
    driver.findElement(By.cssSelector(".month:nth-child(9)")).click();Thread.sleep(2000);
    driver.findElement(By.cssSelector("tr:nth-child(2) > .day:nth-child(1)")).click();Thread.sleep(2000);
    driver.findElement(By.xpath("//div[@id=\'addblanktask\']/div/div[2]/div[2]/div/div[4]/div/label")).click();Thread.sleep(2000);
    driver.findElement(By.xpath("//div[@id=\'addblanktask\']/div/div[2]/div[2]/div/div[4]/div/input")).sendKeys("24");Thread.sleep(2000);
    driver.findElement(By.xpath("//div[@id=\'addblanktask\']/div/div/input")).click();
    Thread.sleep(2000);
    driver.findElement(By.linkText("Add Milestone")).click();
    Thread.sleep(2000);
    driver.findElement(By.cssSelector(".col-9 > .btn-outline-blue")).click();
    Thread.sleep(2000);
    driver.findElement(By.linkText("Delete Milestone")).click();
    Thread.sleep(2000);
    driver.findElement(By.cssSelector(".col-9 > .btn-outline-blue")).click();
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@class='toast-message']")));
    driver.findElement(By.xpath("//div[@class='toast-message']")).click(); 
    Thread.sleep(2000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[@class=\'btn-sm btn-outline-blue\']")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[@class=\'btn-sm btn-outline-blue\']")));Thread.sleep(2000);
    
    /* Logout */
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'My Profile')]")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'My Profile')]")));Thread.sleep(2000);
	driver.findElement(By.xpath("//div[contains(text(),'My Profile')]")).click();  
	Thread.sleep(2000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//div[contains(text(),'Logout')])[1]")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//div[contains(text(),'Logout')])[1]")));Thread.sleep(2000);
	driver.findElement(By.xpath("(//div[contains(text(),'Logout')])[1]")).click();  
	Thread.sleep(2000);
  }
}

