package disputeCancel;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import screenshotOnFailure.FailScreenshot;

@Listeners(screenshotListners.EventList.class)
public class DC10_NewRequest extends FailScreenshot{
	
	@Test
	public void DC_CoachRequest() throws InterruptedException {

		/* Login to the Application - PBC */ 		
	  	driver.findElement(By.xpath("(//button[normalize-space()='Login'])[1]")).click();
		driver.findElement(By.xpath("//input[@id='Username']")).click();
		driver.findElement(By.xpath("//input[@id='Username']")).sendKeys("john.doe002");
		driver.findElement(By.xpath("//input[@id='password-field']")).click();
		driver.findElement(By.xpath("//input[@id='password-field']")).sendKeys("Rockon123");
		driver.findElement(By.xpath("//button[@id='loginButton']")).click();
		Thread.sleep(2000);
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(120));		
	    
		/* Navigate to Coaching Support */
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'My Profile')]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'My Profile')]")));
		Thread.sleep(2000);
		{
		     WebElement element = driver.findElement(By.xpath("//div[@class='menu-item menu-item-active']"));
		     Actions builder = new Actions(driver);
		     builder.moveToElement(element).perform();
		}
		Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'Coaching Support')]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'Coaching Support')]")));Thread.sleep(2000);
		driver.findElement(By.xpath("//div[contains(text(),'Coaching Support')]")).click();
	    Thread.sleep(2000);	  
	    
	    /* Create a Coach Request */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".btn-blue")));
	    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".btn-blue")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".btn-blue")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("TermsAndCondition")));
	    wait.until(ExpectedConditions.elementToBeClickable(By.id("TermsAndCondition")));Thread.sleep(2000);
	    driver.findElement(By.id("TermsAndCondition")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".btn-lg")));
	    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".btn-lg")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".btn-lg")).click();
	    Thread.sleep(2000);	    
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("Title")));
	    wait.until(ExpectedConditions.elementToBeClickable(By.id("Title")));Thread.sleep(2000);
	    driver.findElement(By.id("Title")).click();Thread.sleep(2000);
	    driver.findElement(By.id("Title")).clear();Thread.sleep(2000);
	    driver.findElement(By.id("Title")).sendKeys("Image and Natural Language Processing");
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".next-btn")).click();
	    Thread.sleep(2000);
	    
	    /* Specialities */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("RequestSpecialities")));
	    wait.until(ExpectedConditions.elementToBeClickable(By.id("RequestSpecialities")));Thread.sleep(2000);
	    driver.findElement(By.id("RequestSpecialities")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector("li:nth-child(2) .text-muted")).click();Thread.sleep(2000);
	    driver.findElement(By.id("RequestSpecialities")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector("li:nth-child(3) .text-muted")).click();Thread.sleep(2000);
	    driver.findElement(By.id("RequestSpecialities")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector("li:nth-child(6) .text-muted")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".mce-i-bold")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".mce-i-bullist")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".back-btn")).click();Thread.sleep(2000);
	    driver.findElement(By.id("btnNoConfirmYesNo")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".next-btn")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.name("Countries[All]")));
	    wait.until(ExpectedConditions.elementToBeClickable(By.name("Countries[All]")));Thread.sleep(2000);
	    driver.findElement(By.name("Countries[All]")).click();Thread.sleep(2000);
	    driver.findElement(By.id("Countries_India_")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".next-btn")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("select2-Frequency-container")));
	    wait.until(ExpectedConditions.elementToBeClickable(By.id("select2-Frequency-container")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".next-btn")).click();Thread.sleep(2000);
	    driver.findElement(By.id("select2-Frequency-container")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".select2-search__field")).sendKeys("Weekly");Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".select2-search__field")).sendKeys(Keys.ENTER);Thread.sleep(2000);
	    driver.findElement(By.id("select2-Preference_TimeZone-container")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".select2-search__field")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".select2-search__field")).sendKeys("Dhaka");Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".select2-search__field")).sendKeys(Keys.ENTER);Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".days:nth-child(1)")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".days:nth-child(7)")).click();Thread.sleep(2000);
	    driver.findElement(By.id("Preference_Evening")).click();Thread.sleep(2000);
	    driver.findElement(By.id("Preference_IsConnectPerson")).click();Thread.sleep(2000);
	    driver.findElement(By.id("Preference_IsConnectPhone")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".next-btn")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".btn-outline-blue")));
	    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".btn-outline-blue")));
	    
	    /* Close the Edit Overlay */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div/form/button")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div/form/button")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//div/form/button")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".modal-lg .modal-header .fa")).click();
	    
	    /* Send Request */
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".float-right > .btn-blue")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".float-right > .btn-blue")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".float-right > .btn-blue")).click();
	    wait.until(ExpectedConditions.invisibilityOfElementLocated(By.cssSelector(".float-right > .btn-blue")));
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[@class=\'btn-sm btn-outline-blue margin-right-15\']")));
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[@class=\'btn-sm btn-outline-blue margin-right-15\']")));Thread.sleep(2000);
	    
	    /* Logout */
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'My Profile')]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'My Profile')]")));Thread.sleep(2000);
		driver.findElement(By.xpath("//div[contains(text(),'My Profile')]")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("(//div[contains(text(),'Logout')])[2]")).click();
		Thread.sleep(2000); 
	  }
	}
