package coachRazorPay;

import java.time.Duration;
import java.util.Iterator;
import java.util.Set;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import screenshotOnFailure.FailScreenshot;

@Listeners(screenshotListners.EventList.class)
public class CR30_ApprovePayment extends FailScreenshot{

	@Test
	public void Razorpay_Payment_Approving() throws InterruptedException {
		
		/* Login to the Application - PBC */ 		
	  	driver.findElement(By.xpath("(//button[normalize-space()='Login'])[1]")).click();
		driver.findElement(By.xpath("//input[@id='Username']")).click();
		driver.findElement(By.xpath("//input[@id='Username']")).sendKeys("john.doe009");
		driver.findElement(By.xpath("//input[@id='password-field']")).click();
		driver.findElement(By.xpath("//input[@id='password-field']")).sendKeys("Rockon123");
		driver.findElement(By.xpath("//button[@id='loginButton']")).click();
		Thread.sleep(2000);
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(120));
		
		/* Coaching Support */
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'My Profile')]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'My Profile')]")));
		Thread.sleep(2000);
		{
		     WebElement element = driver.findElement(By.xpath("//div[@class='menu-item menu-item-active']"));
		     Actions builder = new Actions(driver);
		     builder.moveToElement(element).perform();
		}
		Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'Coaching Support')]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'Coaching Support')]")));Thread.sleep(2000);
		driver.findElement(By.xpath("//div[contains(text(),'Coaching Support')]")).click();
	    Thread.sleep(2000);
		
		/* Work in Progress */
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@id=\'divLeftMenu\']/div[4]/a")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@id=\'divLeftMenu\']/div[4]/a")));Thread.sleep(2000);
		driver.findElement(By.xpath("//div[@id=\'divLeftMenu\']/div[4]/a")).click();				
		
		/* Approve payment razor pay*/
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//span[contains(.,\'Approve Payment\')])[2]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//span[contains(.,\'Approve Payment\')])[2]")));Thread.sleep(2000);
		driver.findElement(By.xpath("(//span[contains(.,\'Approve Payment\')])[2]")).click();
		Thread.sleep(2000);		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[contains(.,\'Confirm\')]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[contains(.,\'Confirm\')]")));Thread.sleep(2000);
        driver.findElement(By.xpath("//span[contains(.,\'Confirm\')]")).click();
        Thread.sleep(2000);
		driver.switchTo().frame(0);Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[contains(text(),'Netbanking')]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[contains(text(),'Netbanking')]")));Thread.sleep(2000);
		driver.findElement(By.xpath("//span[contains(text(),'Netbanking')]")).click();
		Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//div[normalize-space()='HDFC Bank'])[1]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//div[normalize-space()='HDFC Bank'])[1]")));Thread.sleep(2000);
		driver.findElement(By.xpath("//span[contains(text(),'HDFC Bank')]")).click();
		Thread.sleep(5000);	
		
//		if(driver.findElements(By.xpath("//form[1]/div[3]/span[2]")).isEmpty())			  
//		{	    		    
//			Thread.sleep(2000);
//		    driver.findElement(By.xpath("//button[@id='redesign-v15-cta']")).click();	    		    
//		}			
//		else {
//			Thread.sleep(2000);
//		    driver.findElement(By.xpath("//form[1]/div[3]/span[2]")).click();
//		}		
//		Thread.sleep(2000);	
		
		Set <String> ids=driver.getWindowHandles();
		Iterator <String> itr=ids.iterator();
		String parentId=itr.next();Thread.sleep(2000);
		String childId=itr.next();Thread.sleep(2000);
		driver.switchTo().window(childId);Thread.sleep(2000);
		System.out.println("Title of the child page:" + driver.getTitle());
		Thread.sleep(5000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[contains(.,\'Success\')]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[contains(.,\'Success\')]")));Thread.sleep(2000);
		driver.findElement(By.xpath("//button[contains(.,\'Success\')]")).click();
		Thread.sleep(5000);
		driver.switchTo().window(parentId);
		Thread.sleep(5000);
		wait.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath("//div[@id=\'divWorkInProgressModal\']/div/div/div[2]/div/div[5]/div/div[2]/form/button")));
		wait.until(ExpectedConditions.invisibilityOfElementLocated(By.cssSelector(".form-inline > .btn-blue")));
		Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[contains(text(),'Work in progress - waiting for coach to complete milestone')]")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[contains(text(),'Work in progress - waiting for coach to complete milestone')]")));Thread.sleep(2000);
					
		/* Logout */
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'My Profile')]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'My Profile')]")));
		driver.findElement(By.xpath("//div[contains(text(),'My Profile')]")).click();
		Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//div[contains(text(),'Logout')])[2]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//div[contains(text(),'Logout')])[2]")));
		driver.findElement(By.xpath("(//div[contains(text(),'Logout')])[2]")).click();
		Thread.sleep(2000);
		}
	}
