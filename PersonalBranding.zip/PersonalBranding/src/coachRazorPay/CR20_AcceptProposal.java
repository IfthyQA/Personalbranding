package coachRazorPay;

import java.time.Duration;
import java.util.Iterator;
import java.util.Set;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import screenshotOnFailure.FailScreenshot;

@Listeners(screenshotListners.EventList.class)
public class CR20_AcceptProposal extends FailScreenshot{

	@Test
	public void Razorpay_AcceptProposal() throws InterruptedException {

		/* Login to the Application - PBC */ 		
	  	driver.findElement(By.xpath("(//button[normalize-space()='Login'])[1]")).click();
		driver.findElement(By.xpath("//input[@id='Username']")).click();
		driver.findElement(By.xpath("//input[@id='Username']")).sendKeys("john.doe009");
		driver.findElement(By.xpath("//input[@id='password-field']")).click();
		driver.findElement(By.xpath("//input[@id='password-field']")).sendKeys("Rockon123");
		driver.findElement(By.xpath("//button[@id='loginButton']")).click();
		Thread.sleep(2000);
		 WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(120));
		
		/* Coaching Support */
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'My Profile')]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'My Profile')]")));
		Thread.sleep(2000);
		{
		     WebElement element = driver.findElement(By.xpath("//div[@class='menu-item menu-item-active']"));
		     Actions builder = new Actions(driver);
		     builder.moveToElement(element).perform();
		}
		Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'Coaching Support')]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'Coaching Support')]")));Thread.sleep(2000);
		driver.findElement(By.xpath("//div[contains(text(),'Coaching Support')]")).click();
	    Thread.sleep(2000);
		
		/* My Requests with Pending proposal */
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("a > .btn-blue-link-12")));
		wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector("a > .btn-blue-link-12")));Thread.sleep(2000);
		driver.findElement(By.cssSelector("a > .btn-blue-link-12")).click();
		Thread.sleep(2000);
		wait.until(ExpectedConditions.elementToBeClickable(By.linkText("Back To My Requests")));Thread.sleep(2000);
		driver.findElement(By.linkText("Back To My Requests")).click();
		Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".btn-outline-grey")));
		wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".btn-outline-grey")));Thread.sleep(2000);
		driver.findElement(By.cssSelector(".btn-outline-grey")).click();
		Thread.sleep(2000);
		driver.findElement(By.id("btnNoConfirmYesNo")).click();
		Thread.sleep(2000);	
							
		/* Accept Proposal razor pay */ 
		/* Random Sleep - Delay only for the payments to avoid automation */
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[contains(.,\'Accept\')]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[contains(.,\'Accept\')]")));Thread.sleep(2000);
		driver.findElement(By.xpath("//button[contains(.,\'Accept\')]")).click();
		Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[contains(.,\'Accept Proposal\')]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[contains(.,\'Accept Proposal\')]")));Thread.sleep(2000);
		driver.findElement(By.xpath("//button[contains(.,\'Accept Proposal\')]")).click();
		Thread.sleep(2000);
		driver.switchTo().frame(0);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[contains(text(),'Netbanking')]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[contains(text(),'Netbanking')]")));Thread.sleep(2000);
		driver.findElement(By.xpath("//span[contains(text(),'Netbanking')]")).click();
		Thread.sleep(5000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//div[normalize-space()='HDFC Bank'])[1]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//div[normalize-space()='HDFC Bank'])[1]")));Thread.sleep(2000);
		driver.findElement(By.xpath("//span[contains(text(),'HDFC Bank')]")).click();
		Thread.sleep(5000);	
	  
//			if(driver.findElements(By.xpath("(//span[contains(.,\'Pay ₹ 1\')])[2]")).isEmpty())			  
//			{	    		    
//				Thread.sleep(2000);
//			    driver.findElement(By.xpath("//button[@id='redesign-v15-cta']")).click();	    		    
//			}			
//			else 
//			{
//				Thread.sleep(2000);
//			    driver.findElement(By.xpath("(//span[contains(.,\'Pay ₹ 1\')])[2]")).click();
//			}	
//			Thread.sleep(2000);
		
		Set <String> ids=driver.getWindowHandles();
		Iterator <String> itr=ids.iterator();
		String parentId=itr.next();Thread.sleep(2000);
		String childId=itr.next();Thread.sleep(2000);
		driver.switchTo().window(childId);Thread.sleep(2000);
		System.out.println("Title of the child page:" + driver.getTitle());
		Thread.sleep(5000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[contains(.,\'Success\')]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[contains(.,\'Success\')]")));Thread.sleep(2000);
		driver.findElement(By.xpath("//button[contains(.,\'Success\')]")).click();
		Thread.sleep(5000);
		driver.switchTo().window(parentId);
		Thread.sleep(5000);
		
		/* Landing on the Work in progress page */
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//span[contains(text(),'New Request')])[2]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//span[contains(text(),'New Request')])[2]")));
		Thread.sleep(5000);
		
		/* Discussions After Accepting Proposal */
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[normalize-space()='Discussion']")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()='Discussion']")));Thread.sleep(2000);
		driver.findElement(By.xpath("//span[normalize-space()='Discussion']")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//button[contains(.,\'Send Message\')]")).click();
		Thread.sleep(2000);
		driver.findElement(By.id("discussiontextarea")).click();
		driver.findElement(By.id("discussiontextarea")).sendKeys("Accepted the Coaching Proposal. thanks for the details");
		Thread.sleep(2000);
		driver.findElement(By.xpath("//button[contains(.,\'Send Message\')]")).click();
		Thread.sleep(2000);
	    JavascriptExecutor jse = (JavascriptExecutor)driver;
	    jse.executeScript("scroll(0, -250);");
	    Thread.sleep(2000);
		driver.findElement(By.cssSelector(".btn-blue-link-12")).click();
		Thread.sleep(2000);
		
		/* Logout */
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'My Profile')]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'My Profile')]")));
		driver.findElement(By.xpath("//div[contains(text(),'My Profile')]")).click();
		Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//div[contains(text(),'Logout')])[2]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//div[contains(text(),'Logout')])[2]")));
		driver.findElement(By.xpath("(//div[contains(text(),'Logout')])[2]")).click();
		Thread.sleep(2000);
		}
	}