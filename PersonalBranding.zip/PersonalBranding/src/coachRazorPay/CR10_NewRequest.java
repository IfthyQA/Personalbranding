package coachRazorPay;

import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import screenshotOnFailure.FailScreenshot;

@Listeners(screenshotListners.EventList.class)
public class CR10_NewRequest extends FailScreenshot{
	
	@Test
	public void Razorpay_CoachRequest() throws InterruptedException {

		/* Login to the Application - PBC */ 		
	  	driver.findElement(By.xpath("(//button[normalize-space()='Login'])[1]")).click();
		driver.findElement(By.xpath("//input[@id='Username']")).click();
		driver.findElement(By.xpath("//input[@id='Username']")).sendKeys("john.doe009");
		driver.findElement(By.xpath("//input[@id='password-field']")).click();
		driver.findElement(By.xpath("//input[@id='password-field']")).sendKeys("Rockon123");
		driver.findElement(By.xpath("//button[@id='loginButton']")).click();
		Thread.sleep(2000);
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(120));
	    
	    /* Coaching Support Page - Send Coaching Request */
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'My Profile')]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'My Profile')]")));
		Thread.sleep(2000);
		{
		     WebElement element = driver.findElement(By.xpath("//div[@class='menu-item menu-item-active']"));
		     Actions builder = new Actions(driver);
		     builder.moveToElement(element).perform();
		}
		Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'Coaching Support')]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'Coaching Support')]")));Thread.sleep(2000);
		driver.findElement(By.xpath("//div[contains(text(),'Coaching Support')]")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[contains(text(),\'New Request\')]")));
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[contains(text(),\'New Request\')]")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//span[contains(text(),\'New Request\')]")).click();
	    Thread.sleep(2000);	
	    
	    /* Send New Coaching Request */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("TermsAndCondition")));
	    wait.until(ExpectedConditions.elementToBeClickable(By.id("TermsAndCondition")));Thread.sleep(2000);
	    driver.findElement(By.id("TermsAndCondition")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".btn-lg")));
	    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".btn-lg")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".btn-lg")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("Title")));
	    wait.until(ExpectedConditions.elementToBeClickable(By.id("Title")));Thread.sleep(2000);
	    driver.findElement(By.id("Title")).click();Thread.sleep(2000);
	    driver.findElement(By.id("Title")).sendKeys("Razorpay Salesforce Enterprise");Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".next-btn")).click();Thread.sleep(2000);
	    driver.findElement(By.id("RequestSpecialities")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector("li:nth-child(2) .text-muted")).click();Thread.sleep(2000);
	    driver.findElement(By.id("RequestSpecialities")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector("li:nth-child(3) .text-muted")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".mce-i-bold")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".mce-i-bullist")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".back-btn")).click();Thread.sleep(2000);
	    driver.findElement(By.id("btnNoConfirmYesNo")).click();Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".next-btn")));
	    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".next-btn")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".next-btn")).click();Thread.sleep(2000);
	    
	    /* Choosing Countries */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("Countries_All_")));
	    wait.until(ExpectedConditions.elementToBeClickable(By.id("Countries_All_")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".next-btn")).click();Thread.sleep(2000);
	    driver.findElement(By.id("Countries_All_")).click();Thread.sleep(2000);
	    driver.findElement(By.id("Countries_India_")).click();Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".next-btn")));
	    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".next-btn")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".next-btn")).click();Thread.sleep(2000);
	    
	    /* Prefrences */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("Preference_Morning")));
	    wait.until(ExpectedConditions.elementToBeClickable(By.id("Preference_Morning")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".days:nth-child(1)")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".days:nth-child(7)")).click();Thread.sleep(2000);
	    driver.findElement(By.id("Preference_Evening")).click();Thread.sleep(2000);
	    driver.findElement(By.id("Preference_IsConnectPerson")).click();Thread.sleep(2000);
	    driver.findElement(By.id("Preference_IsConnectPhone")).click();Thread.sleep(2000);
	    driver.findElement(By.id("Preference_IsConnectOnline")).click();Thread.sleep(2000);	    
	    driver.findElement(By.cssSelector(".next-btn")).click();Thread.sleep(2000);
	    driver.findElement(By.id("Preference_IsConnectPerson")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".form-group > label:nth-child(2)")).click();Thread.sleep(2000);
	    driver.findElement(By.id("pac-input")).click();Thread.sleep(2000);
	    driver.findElement(By.id("pac-input")).sendKeys("Bengaluru");
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id=\"divConnectPersonBox\"]/div/div/div[2]")));
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@id=\"divConnectPersonBox\"]/div/div/div[2]")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//*[@id=\"divConnectPersonBox\"]/div/div/div[2]")).click();Thread.sleep(2000);
	    driver.findElement(By.id("pac-input")).sendKeys(Keys.ENTER);Thread.sleep(2000);
	    
	    /* Review Detials */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".btn-outline-blue")));
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".float-right > .btn-blue")));Thread.sleep(2000);	
	    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".float-right > .btn-blue")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".float-right > .btn-blue")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[@class=\'btn-sm btn-outline-blue margin-right-15\']")));
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[@class=\'btn-sm btn-outline-blue margin-right-15\']")));Thread.sleep(2000);
	    
	    /* Logout */
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'My Profile')]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'My Profile')]")));
		driver.findElement(By.xpath("//div[contains(text(),'My Profile')]")).click();
		Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//div[contains(text(),'Logout')])[2]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//div[contains(text(),'Logout')])[2]")));
		driver.findElement(By.xpath("(//div[contains(text(),'Logout')])[2]")).click();
		Thread.sleep(2000);
	  }
	}
