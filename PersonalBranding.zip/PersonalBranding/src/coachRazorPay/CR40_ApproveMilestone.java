package coachRazorPay;

import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import screenshotOnFailure.FailScreenshot;

@Listeners(screenshotListners.EventList.class)
public class CR40_ApproveMilestone extends FailScreenshot{
	
	@Test
	public void Razorpay_Milestone_Approve() throws InterruptedException {
		
		/* Login to the Application - PBC */ 		
	  	driver.findElement(By.xpath("(//button[normalize-space()='Login'])[1]")).click();
		driver.findElement(By.xpath("//input[@id='Username']")).click();
		driver.findElement(By.xpath("//input[@id='Username']")).sendKeys("john.doe009");
		driver.findElement(By.xpath("//input[@id='password-field']")).click();
		driver.findElement(By.xpath("//input[@id='password-field']")).sendKeys("Rockon123");
		driver.findElement(By.xpath("//button[@id='loginButton']")).click();
		Thread.sleep(2000);
		 WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(120));
	    
	    /* Coaching Support */
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'My Profile')]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'My Profile')]")));
		Thread.sleep(2000);
	    {
		     WebElement element = driver.findElement(By.xpath("//div[@class='menu-item menu-item-active']"));
		     Actions builder = new Actions(driver);
		     builder.moveToElement(element).perform();
		}
		Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'Coaching Support')]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'Coaching Support')]")));Thread.sleep(2000);
		driver.findElement(By.xpath("//div[contains(text(),'Coaching Support')]")).click();
	    Thread.sleep(2000);
	    
	    /* Work in Progress */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@id=\'divLeftMenu\']/div[4]/a")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@id=\'divLeftMenu\']/div[4]/a")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[@id=\'divLeftMenu\']/div[4]/a")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".form-inline .d-none")));
	    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".form-inline .d-none")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".form-inline .d-none")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".fa-arrow-left")));
	    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".fa-arrow-left")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".fa-arrow-left")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[2]/button")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[2]/button")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//span[2]/button")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".modal-lg .fa")));
	    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".modal-lg .fa")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".modal-lg .fa")).click();
	    Thread.sleep(2000);
	    
	    /* Complete Milestone */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[contains(.,\'Complete Milestone\')]")));
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[contains(.,\'Complete Milestone\')]")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//button[contains(.,\'Complete Milestone\')]")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@id=\'divWorkInProgressModal\']/div/div/div[2]/div/div[5]/form/button")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@id=\'divWorkInProgressModal\']/div/div/div[2]/div/div[5]/form/button")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[@id=\'divWorkInProgressModal\']/div/div/div[2]/div/div[5]/form/button")).click();
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@class='toast-message']")));
	    driver.findElement(By.xpath("//div[@class='toast-message']")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[contains(text(),'Milestone completed - Paid')]")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[contains(text(),'Milestone completed - Paid')]")));
	    
	    /* Archived Work */
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".d-none:nth-child(5) > a")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".d-none:nth-child(5) > a")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".d-none:nth-child(5) > a")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//span[contains(text(),'Meetings History')])[1]")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//span[contains(text(),'Meetings History')])[1]")));Thread.sleep(2000);
	    driver.findElement(By.xpath("(//span[contains(text(),'Meetings History')])[1]")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".biz-admin-overlay > .modal-header .fa")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".biz-admin-overlay > .modal-header .fa")).click();
	    Thread.sleep(2000);
	    
	    /* Archived Work */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".d-none:nth-child(5) > a")));
	    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".d-none:nth-child(5) > a")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".d-none:nth-child(5) > a")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".pb-pointer > span")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".pb-pointer > span")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".pb-pointer > span")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("TermsAndCondition")));
	    wait.until(ExpectedConditions.elementToBeClickable(By.id("TermsAndCondition")));Thread.sleep(2000);
	    driver.findElement(By.id("TermsAndCondition")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".btn-lg")));
	    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".btn-lg")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".btn-lg")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".back-btn")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.id("btnYesConfirmYesNo")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".d-none:nth-child(5) > a")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".btn-blue-link-12 > span:nth-child(2)")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".biz-admin-overlay > .modal-header .fa")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".btn-blue-link-12")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector("#coachingcancelpopup > .modal-header .fa")).click();
	    Thread.sleep(2000);
	    
	    /* Discussions Menu */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".d-none:nth-child(7) > a")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".d-none:nth-child(7) > a")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".d-none:nth-child(7) > a")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("#lnkArchiveDiscussion .social-heading")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector("#lnkArchiveDiscussion .social-heading")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector("#lnkArchiveDiscussion .social-heading")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector("#lnkActiveDiscussion .social-heading")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector("#lnkArchiveDiscussion .social-heading")).click();
	    Thread.sleep(2000);
	    
	    /* Logout */
		 wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'My Profile')]")));
		 wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'My Profile')]")));
		 driver.findElement(By.xpath("//div[contains(text(),'My Profile')]")).click();
		 Thread.sleep(2000);
		 wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//div[contains(text(),'Logout')])[2]")));
		 wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//div[contains(text(),'Logout')])[2]")));
		 driver.findElement(By.xpath("(//div[contains(text(),'Logout')])[2]")).click();
		 Thread.sleep(2000);
	  }
	}



