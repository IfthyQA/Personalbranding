package coachRazorPay;

import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import screenshotOnFailure.FailScreenshot;

@Listeners(screenshotListners.EventList.class)
public class CR50_ClientPayment extends FailScreenshot {
	
	@Test
	public void Razorpay_ClientPayment() throws InterruptedException {

		/* Login to the Application - PBC */ 		
	  	driver.findElement(By.xpath("(//button[normalize-space()='Login'])[1]")).click();
		driver.findElement(By.xpath("//input[@id='Username']")).click();
		driver.findElement(By.xpath("//input[@id='Username']")).sendKeys("john.doe009");
		driver.findElement(By.xpath("//input[@id='password-field']")).click();
		driver.findElement(By.xpath("//input[@id='password-field']")).sendKeys("Rockon123");
		driver.findElement(By.xpath("//button[@id='loginButton']")).click();
		Thread.sleep(2000);
		 WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(120));
	    
	    /* Subscription & Payment from Strategic Hub */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'My Profile')]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'My Profile')]")));Thread.sleep(2000);
		driver.findElement(By.xpath("//div[contains(text(),'My Profile')]")).click();
	    Thread.sleep(2000);	
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'Subscription and Orders')]")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'Subscription and Orders')]")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[contains(text(),'Subscription and Orders')]")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[normalize-space()='ORDERS']")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()='ORDERS']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//span[normalize-space()='ORDERS']")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[contains(text(),\'Add Payment Method\')]")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[contains(text(),\'Add Payment Method\')]")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//span[contains(text(),\'Add Payment Method\')]")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[normalize-space()='Add Card']")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()='Add Card']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//span[normalize-space()='Add Card']")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[@class='modal-content modal-prime']//i[@class='fa fa-times']")).click();
	    Thread.sleep(2000);
	  
	    /* Recent Transactions and its Reciept */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".col-12:nth-child(2) > .history-list span .fa")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".col-12:nth-child(2) > .history-list span .fa")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".col-12:nth-child(2) > .history-list span .fa")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".col-12:nth-child(2) > .history-list .history-coaching-title")).click();
	    Thread.sleep(2000);
	    	String winHandleBefore = driver.getWindowHandle();
		    driver.findElement(By.linkText("Razorpay Salesforce ERP Domain")).click();
		    Thread.sleep(2000);
	    	// Navigate to New window
	    	for(String winHandle : driver.getWindowHandles()){
	        driver.switchTo().window(winHandle);
	    	}
	    	Thread.sleep(2000);
		    driver.close();
		    driver.switchTo().window(winHandleBefore);
		    Thread.sleep(2000);
	    driver.findElement(By.cssSelector("#modalsettingtaskdetailpopup .fa")).click();
	    Thread.sleep(2000);
	    
	    /* Transactions  */
	    driver.findElement(By.cssSelector(".dropdown > .invisibleButton")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[2]/div/ul/li[2]")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("//span[contains(.,\'Current (Within 30 days)\')]")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[2]/div/ul/li[3]")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("//span[contains(.,\'Past (30 days and older)\')]")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[2]/div/ul/li")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector("#lnkPaymentTransactions .social-heading")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".history-coaching-title")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector("#modalsettingtaskdetailpopup .fa")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("//span/form/button/i")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".fa-minus-circle")).click();
	    Thread.sleep(2000);	    
	    
	    /* Scroll up to the page */
	    JavascriptExecutor jse = (JavascriptExecutor)driver;
	    jse.executeScript("scroll(0, -250);");	    	    
	    Thread.sleep(2000);
	    
	    /* Logout */
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'My Profile')]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'My Profile')]")));
		driver.findElement(By.xpath("//div[contains(text(),'My Profile')]")).click();
		Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//div[contains(text(),'Logout')])[2]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//div[contains(text(),'Logout')])[2]")));
		driver.findElement(By.xpath("(//div[contains(text(),'Logout')])[2]")).click();
		Thread.sleep(2000);
		}
	}

