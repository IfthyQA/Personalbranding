package coachRazorPay;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import screenshotOnFailure.FailScreenshot;

@Listeners(screenshotListners.EventList.class)
public class CR11_CreateProposal extends FailScreenshot{
	
	@Test
	public void Razorpay_CreateProposal() throws InterruptedException {

	/* Login to the Application - PBC */ 		
	driver.findElement(By.xpath("(//button[normalize-space()='Login'])[1]")).click();
	driver.findElement(By.xpath("//input[@id='Username']")).click();
	driver.findElement(By.xpath("//input[@id='Username']")).sendKeys("john.doe008");
	driver.findElement(By.xpath("//input[@id='password-field']")).click();
	driver.findElement(By.xpath("//input[@id='password-field']")).sendKeys("Rockon123");
	driver.findElement(By.xpath("//button[@id='loginButton']")).click();
	Thread.sleep(2000);
	WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(120));
    
    /* Navigate to the Coach Page */
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[2]/div[1]/div[1]/div[2]/div[1]/div[1]/a[1]/span[1]")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[2]/div[1]/div[1]/div[2]/div[1]/div[1]/a[1]/span[1]")));Thread.sleep(2000);
    driver.findElement(By.xpath("//div[2]/div[1]/div[1]/div[2]/div[1]/div[1]/a[1]/span[1]")).click();
    Thread.sleep(2000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[normalize-space()='Menu']")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()='Menu']")));Thread.sleep(2000);
    driver.findElement(By.xpath("//span[normalize-space()='Menu']")).click();
    Thread.sleep(2000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[normalize-space()='Coaching Services']")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[normalize-space()='Coaching Services']")));Thread.sleep(2000);
    driver.findElement(By.xpath("//a[normalize-space()='Coaching Services']")).click();
    Thread.sleep(2000);
    
    /* Create Hourly Rate Proposal */
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[normalize-space()=\'Razorpay Salesforce Enterprise\']")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()=\'Razorpay Salesforce Enterprise\']")));Thread.sleep(2000);   
    driver.findElement(By.xpath("//span[normalize-space()=\'Razorpay Salesforce Enterprise\']")).click();
    Thread.sleep(2000); 
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[contains(.,\'Create Proposal\')]")));Thread.sleep(2000);  
    driver.findElement(By.xpath("//button[contains(.,\'Create Proposal\')]")).click();
    Thread.sleep(2000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("TermsAndCondition")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.id("TermsAndCondition")));Thread.sleep(2000); 
    driver.findElement(By.id("TermsAndCondition")).click();
    Thread.sleep(2000);
    driver.findElement(By.cssSelector(".btn-lg")).click();
    Thread.sleep(2000);
    driver.findElement(By.cssSelector(".float-right > .btn-sm")).click();
    Thread.sleep(2000);
    driver.findElement(By.id("ProposalTitle")).click();
    driver.findElement(By.id("ProposalTitle")).sendKeys("M");
    driver.findElement(By.id("ProposalTitle")).clear();Thread.sleep(2000);
    driver.findElement(By.id("ProposalTitle")).sendKeys("abcdefghijklmnopqrstuvwxyz-abcdefghijklmnopqrstuvwxyz");
    driver.findElement(By.id("ProposalTitle")).clear();Thread.sleep(2000);
    driver.findElement(By.id("ProposalTitle")).sendKeys("Razorpay Salesforce ERP Domain");
    Thread.sleep(2000);
    driver.findElement(By.id("HourlyRate")).click();
    driver.findElement(By.id("HourlyRate")).sendKeys("15");
    Thread.sleep(2000);
    JavascriptExecutor js = (JavascriptExecutor) driver;
    js.executeScript("document.querySelector(\'textarea.proposalHourlyDescription\').value=\"hi\";");
    Thread.sleep(2000);
    
    /* Milestone Details */
    driver.findElement(By.xpath("//div[@id=\'addblanktask\']/div/div/input")).click();
    driver.findElement(By.xpath("//div[@id=\'addblanktask\']/div/div/input")).sendKeys("123456789abcdefghijklmnopqrstuvwxyz12345678ABCDEFGI");
    driver.findElement(By.xpath("//div[@id=\'addblanktask\']/div/div/input")).clear();Thread.sleep(2000);
    driver.findElement(By.xpath("//div[@id=\'addblanktask\']/div/div/input")).sendKeys("Coach for Razorpay & Salesforce");
    driver.findElement(By.xpath("//div[@id=\'addblanktask\']/div/div/input")).click();
    Thread.sleep(2000);
    js.executeScript("document.querySelector(\'textarea.proposalFixedTaskDescription\').value=\"hi\";");
    js.executeScript("document.querySelector(\'textarea.proposalFixedTaskDescription\').value");
    Thread.sleep(2000);
    driver.findElement(By.cssSelector(".divStartDatePicker .fa")).click();
    Thread.sleep(2000);
    driver.findElement(By.cssSelector(".year:nth-child(12)")).click();
    Thread.sleep(2000);
    driver.findElement(By.cssSelector(".month:nth-child(9)")).click();
    Thread.sleep(2000);
    driver.findElement(By.cssSelector("tr:nth-child(2) > .day:nth-child(1)")).click();
    Thread.sleep(2000);
    driver.findElement(By.xpath("//div[@id=\'addblanktask\']/div/div[2]/div[2]/div/div[4]/div/label")).click();
    driver.findElement(By.xpath("//div[@id=\'addblanktask\']/div/div[2]/div[2]/div/div[4]/div/input")).sendKeys("150");
    Thread.sleep(2000);
    driver.findElement(By.xpath("//div[@id=\'addblanktask\']/div/div/input")).click();
    Thread.sleep(2000);
    driver.findElement(By.linkText("Add Milestone")).click();
    Thread.sleep(2000);
    driver.findElement(By.linkText("Delete Milestone")).click();
    Thread.sleep(2000);
	wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".btn-blue")));
    driver.findElement(By.cssSelector(".btn-blue")).click();
    wait.until(ExpectedConditions.invisibilityOfElementLocated(By.cssSelector(".btn-blue")));       
    Thread.sleep(2000);
    
    /* Scroll Up the page */
    JavascriptExecutor jse = (JavascriptExecutor)driver;
    jse.executeScript("scroll(0, -250);");	    	    
    Thread.sleep(2000);  
    
    /* Start Discussion after Sending Proposal*/
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//span[contains(text(), \'Discussion\')])[3]")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//span[contains(text(), \'Discussion\')])[3]")));Thread.sleep(2000);
    driver.findElement(By.xpath("(//span[contains(text(), \'Discussion\')])[3]")).click();
    Thread.sleep(2000);
    driver.findElement(By.xpath("//button[contains(.,\'Send Message\')]")).click();
    Thread.sleep(2000);
    driver.findElement(By.id("discussiontextarea")).click();
    driver.findElement(By.id("discussiontextarea")).sendKeys("Hello, Please check the for the proposal against your Coaching request, let me know if you have any concerns");
    Thread.sleep(2000);
    driver.findElement(By.xpath("//span[@class=\'titleAttach\']")).click();Thread.sleep(2000);
    driver.findElement(By.xpath("//button[@type=\'button\']//span[contains(text(),\'Business Vault\')]")).click();Thread.sleep(2000);
    Thread.sleep(2000);
    driver.findElement(By.xpath("//div[3]/div/div/div[2]/span")).click();
    Thread.sleep(2000);
    driver.findElement(By.cssSelector(".btn")).click();
    Thread.sleep(2000);
    driver.findElement(By.xpath("//div[@id=\'outfineuploader\']/div/span/i[2]")).click();
    Thread.sleep(2000);
    driver.findElement(By.xpath("//button[contains(.,\'Send Message\')]")).click();
    Thread.sleep(2000);
  	wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".btn-blue-link-12")));Thread.sleep(2000);
    driver.findElement(By.cssSelector(".btn-blue-link-12")).click();
    
    /* Logout */
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'My Profile')]")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'My Profile')]")));Thread.sleep(2000);
	driver.findElement(By.xpath("//div[contains(text(),'My Profile')]")).click();  
	Thread.sleep(2000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//div[contains(text(),'Logout')])[1]")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//div[contains(text(),'Logout')])[1]")));Thread.sleep(2000);
	driver.findElement(By.xpath("(//div[contains(text(),'Logout')])[1]")).click();  
	Thread.sleep(2000);
  }
}

