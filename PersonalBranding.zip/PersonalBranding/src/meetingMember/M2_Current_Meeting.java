package meetingMember;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import screenshotOnFailure.FailScreenshot;

@Listeners(screenshotListners.EventList.class)
public class M2_Current_Meeting extends FailScreenshot{

	@Test
	public void Member_Current_Meet() throws InterruptedException {

	/* Login to the Application - PBC */ 		
	driver.findElement(By.xpath("(//button[normalize-space()='Login'])[1]")).click();
	driver.findElement(By.xpath("//input[@id='Username']")).click();
	driver.findElement(By.xpath("//input[@id='Username']")).sendKeys("john.doe001");
	driver.findElement(By.xpath("//input[@id='password-field']")).click();
	driver.findElement(By.xpath("//input[@id='password-field']")).sendKeys("Rockon123");
	driver.findElement(By.xpath("//button[@id='loginButton']")).click();
	Thread.sleep(2000);
	WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(120));
    
    /* Navigate to the Meeting dashboard - Non Prime - 1 meeting per day */ 
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'Meetings')]")));Thread.sleep(2000);
	driver.findElement(By.xpath("//div[contains(text(),'Meetings')]")).click();
	Thread.sleep(2000); 
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.linkText("Meeting History")));
    wait.until(ExpectedConditions.elementToBeClickable(By.linkText("Meeting History")));Thread.sleep(2000);
    driver.findElement(By.linkText("Meeting History")).click();
    Thread.sleep(2000);
    wait.until(ExpectedConditions.elementToBeClickable(By.linkText("My Meetings")));Thread.sleep(2000);
    driver.findElement(By.linkText("My Meetings")).click();
    Thread.sleep(2000);
    
    /* Create Scheduled Meeting */
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("btnCreateMeeting")));
    wait.until(ExpectedConditions.elementToBeClickable(By.id("btnCreateMeeting")));Thread.sleep(2000);
    driver.findElement(By.id("btnCreateMeeting")).click();
    Thread.sleep(2000);
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("MeetingName")));
    wait.until(ExpectedConditions.elementToBeClickable(By.id("MeetingName")));Thread.sleep(2000);
    driver.findElement(By.id("MeetingName")).click();Thread.sleep(2000);
    driver.findElement(By.id("MeetingName")).sendKeys("Current Meeting - Automation");Thread.sleep(2000);
    driver.findElement(By.id("submitbtn")).click();Thread.sleep(2000);
    driver.findElement(By.cssSelector(".txtMemberInvite")).sendKeys("neeraj@tescra.com");Thread.sleep(2000);
    driver.findElement(By.cssSelector(".txtMemberInvite")).sendKeys(Keys.ENTER);Thread.sleep(2000);
    driver.findElement(By.xpath("//form[@id=\'myForm\']//div[@class=\'SPdetailsshare\']/i")).click();Thread.sleep(2000); 
    
    /* Current date and Time */
    driver.findElement(By.xpath("//span[@class=\'input-group-append set-date set-date-birth\']//i[@class=\'fa fa-calendar set-date-icon\']")).click();Thread.sleep(2000);
    driver.findElement(By.xpath("//div[contains(@class, \'datetimepicker datetimepicker-\')][last()]/div[3]/table/tbody/tr/td[@class=\'day active\']")).click();Thread.sleep(2000);
    driver.findElement(By.xpath("//div[contains(@class, \'datetimepicker datetimepicker-\')][last()]/div[2]/table/tbody/tr/td/fieldset/span[contains(@class,\'hour active \')]")).click();Thread.sleep(2000);

    if(!driver.findElements(By.xpath("//div[contains(@class, 'datetimepicker datetimepicker-')][last()]/div[1]/table/tbody/tr/td/fieldset/span[12][contains(@class, 'minute disabled')]")).isEmpty())
	{	    		    
		Thread.sleep(2000);
		driver.findElement(By.xpath("//div[@class='datetimepicker-minutes']//th[@class='next']")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[contains(@class, \'datetimepicker datetimepicker-\')][last()]/div[1]/table/tbody/tr/td/fieldset/span[@class=\'minute\'][1]")).click();	    		    
	}
	
	else {
		Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[contains(@class, \'datetimepicker datetimepicker-\')][last()]/div[1]/table/tbody/tr/td/fieldset/span[@class=\'minute\'][1]")).click();
	}
    Thread.sleep(2000);   
    
    /* Add Connections and Make Moderator */
    driver.findElement(By.cssSelector(".txtMemberInvite")).click();Thread.sleep(2000);
    driver.findElement(By.cssSelector(".txtMemberInvite")).sendKeys("Akilesh");
    Thread.sleep(2000);
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".autocompleteSugLoc")));
    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".autocompleteSugLoc")));Thread.sleep(2000);
    driver.findElement(By.cssSelector(".autocompleteSugLoc")).click();
    Thread.sleep(2000); 
    driver.findElement(By.cssSelector(".SPconnectname > span:nth-child(1)")).click();Thread.sleep(2000);
    driver.findElement(By.xpath("//span[@class=\'SPConnectModerator margin-left-5 margin-right-5\']")).click();Thread.sleep(2000);
    
    /* Add Emails */
    driver.findElement(By.cssSelector(".txtMemberInvite")).click();Thread.sleep(2000);
    driver.findElement(By.cssSelector(".txtMemberInvite")).sendKeys("john.tescras0101+at5@gmail.com");Thread.sleep(2000);
    driver.findElement(By.cssSelector(".txtMemberInvite")).sendKeys(Keys.ENTER);   
    Thread.sleep(2000);
    driver.findElement(By.id("crossjohn.tescras0101+at5@gmail.com")).click();Thread.sleep(2000);
    
    /* Access Contacts while creating Meeting */
    driver.findElement(By.id("contactsbtn")).click();Thread.sleep(2000);
    driver.findElement(By.id("selectAll")).click();Thread.sleep(2000);
    driver.findElement(By.id("selectAll")).click();Thread.sleep(2000);
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[@id=\'submitContacts\']")));Thread.sleep(2000);
    driver.findElement(By.xpath("//button[@id=\'submitContacts\']")).click();
    wait.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath("//button[@id=\'submitContacts\']")));
    Thread.sleep(2000);
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("submitbtn")));
    wait.until(ExpectedConditions.elementToBeClickable(By.id("submitbtn")));Thread.sleep(2000);
    driver.findElement(By.id("submitbtn")).click();  
    wait.until(ExpectedConditions.invisibilityOfElementLocated(By.id("submitbtn")));
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//i[@class='editmeeting-icon']")));	  
    Thread.sleep(2000);
    
    /* Add Participants - One Contact and One Email */
    driver.findElement(By.cssSelector(".addParticipant-icon")).click();Thread.sleep(2000);   
    Thread.sleep(2000);
    driver.findElement(By.xpath("//form[@id=\'myForm\']//div[@class=\'SPdetailsshare\']/i")).click();Thread.sleep(2000);
    {
        WebElement element = driver.findElement(By.cssSelector(".txtMemberInvite"));
        Actions builder = new Actions(driver);
        builder.doubleClick(element).perform();
    }
    driver.findElement(By.cssSelector(".txtMemberInvite")).click();Thread.sleep(2000);
    driver.findElement(By.cssSelector(".txtMemberInvite")).sendKeys("akilesh");
    Thread.sleep(2000);
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".autocompleteSugLoc")));
    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".autocompleteSugLoc")));Thread.sleep(2000);
    driver.findElement(By.cssSelector(".autocompleteSugLoc")).click();
    Thread.sleep(2000);
    driver.findElement(By.cssSelector(".txtMemberInvite")).click();Thread.sleep(2000);  
    driver.findElement(By.cssSelector(".txtMemberInvite")).sendKeys("john.tescras0101+at5@gmail.com");Thread.sleep(2000);  
    driver.findElement(By.cssSelector(".txtMemberInvite")).sendKeys(Keys.ENTER);Thread.sleep(2000);  
    driver.findElement(By.id("crossjohn.tescras0101+at5@gmail.com")).click();
    Thread.sleep(2000); 
    wait.until(ExpectedConditions.elementToBeClickable(driver.findElement(By.id("btnAddAttendee")))); 
    driver.findElement(By.id("btnAddAttendee")).click();
    Thread.sleep(2000);
    
    /* Try to Edit Meeting */
    wait.until(ExpectedConditions.invisibilityOfElementLocated(By.id("btnAddAttendee")));
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//i[@class='editmeeting-icon']")));Thread.sleep(2000);	
    driver.findElement(By.xpath("//i[@class='editmeeting-icon']")).click();Thread.sleep(2000);
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("MeetingName")));
    wait.until(ExpectedConditions.elementToBeClickable(By.id("MeetingName")));Thread.sleep(2000);
    driver.findElement(By.id("MeetingName")).click(); Thread.sleep(2000);
    driver.findElement(By.id("MeetingName")).clear();Thread.sleep(2000);
    driver.findElement(By.id("MeetingName")).sendKeys("Edited Current Automation Meeting");Thread.sleep(2000);
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("submitUpdatebtn")));
    wait.until(ExpectedConditions.elementToBeClickable(By.id("submitUpdatebtn")));Thread.sleep(2000);
    driver.findElement(By.id("submitUpdatebtn")).click();
    Thread.sleep(2000);
    wait.until(ExpectedConditions.invisibilityOfElementLocated(By.id("submitUpdatebtn")));
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//i[@class='editmeeting-icon']")));Thread.sleep(2000);
    
    /* Edit Meeting */
    driver.findElement(By.xpath("//i[@class='editmeeting-icon']")).click();
    Thread.sleep(2000);
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("MeetingName")));
    wait.until(ExpectedConditions.elementToBeClickable(By.id("MeetingName")));Thread.sleep(2000);
    driver.findElement(By.id("MeetingName")).click();Thread.sleep(2000);
    driver.findElement(By.id("MeetingName")).clear();
    Thread.sleep(2000);
    driver.findElement(By.id("MeetingName")).sendKeys("Edited Member Current Meet");
    Thread.sleep(2000);
    driver.findElement(By.xpath("//form[@id=\'myForm\']//div[@class=\'SPdetailsshare\']/i")).click();
    Thread.sleep(2000);
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".txtMemberInvite")));
    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".txtMemberInvite")));Thread.sleep(2000);
    driver.findElement(By.cssSelector(".txtMemberInvite")).click();Thread.sleep(2000);
    driver.findElement(By.cssSelector(".txtMemberInvite")).sendKeys("Akile");
    Thread.sleep(2000);
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".autocompleteSugLoc")));
    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".autocompleteSugLoc")));Thread.sleep(2000);
    driver.findElement(By.cssSelector(".autocompleteSugLoc")).click();
    Thread.sleep(2000);
    driver.findElement(By.id("contactsbtn")).click();Thread.sleep(2000);
    driver.findElement(By.id("selectAll")).click();Thread.sleep(2000);
    driver.findElement(By.id("selectAll")).click();Thread.sleep(2000);
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[@id=\'submitContacts\']")));Thread.sleep(2000);
    driver.findElement(By.xpath("//button[@id=\'submitContacts\']")).click();Thread.sleep(2000);
    Thread.sleep(2000);
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("submitUpdatebtn")));
    wait.until(ExpectedConditions.elementToBeClickable(By.id("submitUpdatebtn")));Thread.sleep(2000);
    driver.findElement(By.id("submitUpdatebtn")).click();Thread.sleep(2000);
    wait.until(ExpectedConditions.invisibilityOfElementLocated(By.id("submitUpdatebtn")));
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//i[@class='editmeeting-icon']")));Thread.sleep(2000);
    
    /* One Meeting Per Day Lock and Subscription */
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".btn-blue")));
    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".btn-blue")));Thread.sleep(2000);
    driver.findElement(By.cssSelector(".btn-blue")).click();
    Thread.sleep(2000);
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".modal-prime > .modal-header .fa")));
    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".modal-prime > .modal-header .fa")));Thread.sleep(2000);
    driver.findElement(By.cssSelector(".modal-prime > .modal-header .fa")).click();
    Thread.sleep(2000);
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".meeting-subscription > span")));
    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".meeting-subscription > span")));Thread.sleep(2000);
    driver.findElement(By.cssSelector(".meeting-subscription > span")).click();
    Thread.sleep(2000);
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".modal-dialog:nth-child(3) .modal-header .fa")));
    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".modal-dialog:nth-child(3) .modal-header .fa")));Thread.sleep(2000);
    driver.findElement(By.cssSelector(".modal-dialog:nth-child(3) .modal-header .fa")).click();
    Thread.sleep(2000);
    
    /* Delete Meeting */
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//i[@class='editmeeting-icon']")));Thread.sleep(2000);	
    driver.findElement(By.cssSelector(".deletemeeting-icon")).click();
    Thread.sleep(2000);
    driver.findElement(By.id("btnYesConfirmYesNo")).click();
    Thread.sleep(2000);
    wait.until(ExpectedConditions.elementToBeClickable(By.linkText("My Meetings")));Thread.sleep(2000);	
    driver.findElement(By.linkText("My Meetings")).click();
    Thread.sleep(2000);
    
    /* Logout from the meeting */
	 wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'My Profile')]")));
	 wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'My Profile')]")));Thread.sleep(2000);
	 driver.findElement(By.xpath("//div[contains(text(),'My Profile')]")).click();
	 Thread.sleep(2000);
	 driver.findElement(By.xpath("(//div[contains(text(),'Logout')])[2]")).click();
	 Thread.sleep(2000);
  }
}

