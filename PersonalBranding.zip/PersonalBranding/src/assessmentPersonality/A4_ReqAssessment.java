package assessmentPersonality;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import screenshotOnFailure.FailScreenshot;

@Listeners(screenshotListners.EventList.class)
public class A4_ReqAssessment extends FailScreenshot {
	
	@Test
	public void PA_RequestAssessment() throws InterruptedException {
	
	/* Login to the Application - PBC */ 		
	driver.findElement(By.xpath("(//button[normalize-space()='Login'])[1]")).click();
	driver.findElement(By.xpath("//input[@id='Username']")).click();
	driver.findElement(By.xpath("//input[@id='Username']")).sendKeys("john.doe006");
	driver.findElement(By.xpath("//input[@id='password-field']")).click();
	driver.findElement(By.xpath("//input[@id='password-field']")).sendKeys("Rockon123");
	driver.findElement(By.xpath("//button[@id='loginButton']")).click();
	Thread.sleep(2000);
	WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(120));
    
    /* Navigate the Coach Page to Request the Assessment from a client */
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[normalize-space()='Coach Assessment']")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()='Coach Assessment']")));Thread.sleep(2000);
    driver.findElement(By.xpath("//span[normalize-space()='Coach Assessment']")).click();
    Thread.sleep(2000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[normalize-space()='Menu']")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()='Menu']")));Thread.sleep(2000);
    driver.findElement(By.xpath("//span[normalize-space()='Menu']")).click();
    Thread.sleep(2000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[normalize-space()='Coaching Services']")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[normalize-space()='Coaching Services']")));Thread.sleep(2000);
    driver.findElement(By.xpath("//a[normalize-space()='Coaching Services']")).click();
    Thread.sleep(2000);
    driver.navigate().refresh();
    
    /* Search Criteria */
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@class='ui-widget-content ui-autocomplete-input']")));	
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@class='ui-widget-content ui-autocomplete-input']")));Thread.sleep(2000);
    driver.findElement(By.xpath("//input[@class='ui-widget-content ui-autocomplete-input']")).click();
    Thread.sleep(2000);
    driver.findElement(By.id("Business & Executive")).click();Thread.sleep(2000);
    
    /* Vew Details of Request and Ask Assessment */
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[@class='btn-blue-link-12']")));	
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[@class='btn-blue-link-12']")));Thread.sleep(2000);
    driver.findElement(By.xpath("(//span[@class='btn-blue-link-12'])[1]")).click();
    Thread.sleep(2000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".assessment-btn:nth-child(1) > .text-center")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".assessment-btn:nth-child(1) > .text-center")));Thread.sleep(2000);
    driver.findElement(By.cssSelector(".assessment-btn:nth-child(1) > .text-center")).click();
    Thread.sleep(2000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("Description")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.id("Description")));Thread.sleep(2000);
    driver.findElement(By.id("Description")).click();
    driver.findElement(By.id("Description")).sendKeys("Can you Please your \"16 Personality MBTI Reports\"");
    Thread.sleep(2000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".float-right > .btn-sm")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".float-right > .btn-sm")));Thread.sleep(2000);   
    driver.findElement(By.cssSelector(".float-right > .btn-sm")).click();
    wait.until(ExpectedConditions.invisibilityOfElementLocated(By.cssSelector(".float-right > .btn-sm"))); 
    Thread.sleep(2000); 
    
    /* Assessment Menu */
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("menuitemassessments")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.id("menuitemassessments")));Thread.sleep(2000);
    driver.findElement(By.id("menuitemassessments")).click();
    Thread.sleep(2000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".d-none > .fa")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".d-none > .fa")));Thread.sleep(2000);
    driver.findElement(By.cssSelector(".d-none > .fa")).click();
    Thread.sleep(2000);
    driver.findElement(By.cssSelector(".fa-times-circle")).click();Thread.sleep(2000);
    driver.findElement(By.id("btnYesConfirmYesNo")).click();Thread.sleep(2000);
    wait.until(ExpectedConditions.invisibilityOfElementLocated(By.cssSelector(".fa-times-circle"))); 
    
    /* Opportunities - Menu */
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("menuitemopportunities")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.id("menuitemopportunities")));Thread.sleep(2000);
    driver.findElement(By.id("menuitemopportunities")).click();
    Thread.sleep(2000);
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@class='ui-widget-content ui-autocomplete-input']")));	
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@class='ui-widget-content ui-autocomplete-input']")));Thread.sleep(2000);
    driver.findElement(By.xpath("//input[@class='ui-widget-content ui-autocomplete-input']")).click();
    Thread.sleep(2000);
    driver.findElement(By.id("Business & Executive")).click();
    Thread.sleep(2000);
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[@class='btn-blue-link-12']")));	
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[@class='btn-blue-link-12']")));Thread.sleep(2000);
    driver.findElement(By.xpath("//span[@class='btn-blue-link-12']")).click();
    Thread.sleep(2000);
    driver.findElement(By.cssSelector(".assessment-btn:nth-child(2) .assessment-btn-title")).click();
    Thread.sleep(2000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".float-right > .btn-sm")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".float-right > .btn-sm")));Thread.sleep(2000);
    driver.findElement(By.cssSelector(".float-right > .btn-sm")).click();
    Thread.sleep(2000);
    driver.findElement(By.cssSelector("#assessment-overlay .fa")).click();
    Thread.sleep(2000);
    driver.findElement(By.cssSelector(".assessment-btn:nth-child(2)")).click();
    Thread.sleep(2000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("Description")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.id("Description")));Thread.sleep(2000);
    driver.findElement(By.id("Description")).click();
    driver.findElement(By.id("Description")).sendKeys("Hello Adam, Can you please share your DISC Report. Thank you");Thread.sleep(2000);
    driver.findElement(By.cssSelector(".float-right > .btn-sm")).click();
    wait.until(ExpectedConditions.invisibilityOfElementLocated(By.cssSelector(".float-right > .btn-sm"))); 
    Thread.sleep(2000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div/div/div/div/div/div[3]/div/span")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div/div/div/div/div/div[3]/div/span")));Thread.sleep(2000);
    driver.findElement(By.xpath("//div/div/div/div/div/div[3]/div/span")).click();
    Thread.sleep(2000);
    driver.findElement(By.cssSelector(".margin-top-minus-5 > span:nth-child(2)")).click();
    Thread.sleep(2000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("Description")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.id("Description")));Thread.sleep(2000);
    driver.findElement(By.id("Description")).click();
    driver.findElement(By.id("Description")).sendKeys("Hello Adam, I would like to see your \"16 Personality\" Report, before starting the Coaching. can you please send it asap. Thanks");Thread.sleep(2000);
    driver.findElement(By.cssSelector(".float-right > .btn-sm")).click();
    wait.until(ExpectedConditions.invisibilityOfElementLocated(By.cssSelector(".float-right > .btn-sm"))); 
    
    /* Navigate to the Assessment Menu */
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("menuitemassessments")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.id("menuitemassessments")));Thread.sleep(2000);
    driver.findElement(By.id("menuitemassessments")).click();
    Thread.sleep(2000);
    driver.findElement(By.cssSelector(".d-none > .fa-chevron-down")).click();Thread.sleep(2000);
    driver.findElement(By.cssSelector(".d-none > .fa-chevron-down")).click();Thread.sleep(2000);
    driver.findElement(By.cssSelector(".col-lg-4 > span")).click();Thread.sleep(2000);
    driver.findElement(By.cssSelector("#coachingcancelpopup > .modal-header .fa")).click();Thread.sleep(2000);
    
    /* Cancel the 16 Personality & Request again */
    driver.findElement(By.cssSelector(".fa-times-circle")).click();Thread.sleep(2000);
    driver.findElement(By.id("btnNoConfirmYesNo")).click();
    Thread.sleep(2000);
    driver.findElement(By.cssSelector(".fa-times-circle")).click();Thread.sleep(2000);
    driver.findElement(By.id("btnYesConfirmYesNo")).click();
    wait.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath("//div[2]/div[2]/div[1]/div[1]/div[1]/div[2]/div[1]/div[1]/span[1]/form[1]/span[1]/i[1]"))); 
    Thread.sleep(2000);
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".btn-outline-blue")));	
    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".btn-outline-blue")));Thread.sleep(2000);
    driver.findElement(By.cssSelector(".btn-outline-blue")).click();
    Thread.sleep(2000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("Description")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.id("Description")));Thread.sleep(2000);
    driver.findElement(By.id("Description")).click();
    driver.findElement(By.id("Description")).sendKeys("Please share your Report");
    Thread.sleep(2000);
    driver.findElement(By.cssSelector(".float-right > .btn-sm")).click();Thread.sleep(2000);
    wait.until(ExpectedConditions.invisibilityOfElementLocated(By.cssSelector(".float-right > .btn-sm")));    
    
    /* Start a Discussion */
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".btn-blue-link-12 > .d-none")));	
    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".btn-blue-link-12 > .d-none")));Thread.sleep(2000);
    driver.findElement(By.cssSelector(".btn-blue-link-12 > .d-none")).click();Thread.sleep(2000);
    driver.findElement(By.cssSelector(".btn-lg")).click();Thread.sleep(2000);
    driver.findElement(By.id("TermsAndCondition")).click();Thread.sleep(2000);
    driver.findElement(By.cssSelector(".btn-lg")).click();Thread.sleep(2000);
    driver.findElement(By.id("discussiontextarea")).click();
    driver.findElement(By.id("discussiontextarea")).sendKeys("Hello Sulaiman, Can you please share your Assessment Report. to further to create proposals.");
    Thread.sleep(2000);
    driver.findElement(By.xpath("//button[contains(.,\'Send Message\')]")).click();Thread.sleep(2000);
    driver.findElement(By.cssSelector(".btn-blue-link-12")).click();Thread.sleep(2000);
    driver.findElement(By.cssSelector("#lnkPersonalityInformation .social-heading")).click();Thread.sleep(2000);
    driver.findElement(By.xpath("//section/div/ul/li/a/span")).click();
    Thread.sleep(2000);
    
    /* Cancel the DISC Request */
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".xs-center > .assessment-btn-pending > .assessment-btn-title .fa")));	
    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".xs-center > .assessment-btn-pending > .assessment-btn-title .fa")));Thread.sleep(2000);
    driver.findElement(By.cssSelector(".xs-center > .assessment-btn-pending > .assessment-btn-title .fa")).click();
    Thread.sleep(2000);
    driver.findElement(By.id("btnYesConfirmYesNo")).click();
    wait.until(ExpectedConditions.invisibilityOfElementLocated(By.cssSelector(".xs-center > .assessment-btn-pending > .assessment-btn-title .fa"))); 
    
    /* Request the Assessment again */
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".btn-outline-blue")));	
    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".btn-outline-blue")));Thread.sleep(2000);
    driver.findElement(By.cssSelector(".btn-outline-blue")).click();
    Thread.sleep(2000);   
    driver.findElement(By.id("Description")).click();
    driver.findElement(By.id("Description")).sendKeys("Please share your DISC Assessment Report");Thread.sleep(2000);
    driver.findElement(By.cssSelector(".float-right > .btn-sm")).click();Thread.sleep(2000);
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".xs-center > .assessment-btn-pending > .assessment-btn-title .fa")));
    
    /* Logout from Coach Page */
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'My Profile')]")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'My Profile')]")));Thread.sleep(2000);
	driver.findElement(By.xpath("//div[contains(text(),'My Profile')]")).click();  
	Thread.sleep(2000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//div[contains(text(),'Logout')])[1]")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//div[contains(text(),'Logout')])[1]")));Thread.sleep(2000);
	driver.findElement(By.xpath("(//div[contains(text(),'Logout')])[1]")).click();  
	Thread.sleep(2000);
  }
}

