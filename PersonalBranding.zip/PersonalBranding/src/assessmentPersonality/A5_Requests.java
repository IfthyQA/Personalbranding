package assessmentPersonality;

import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import screenshotOnFailure.FailScreenshot;

@Listeners(screenshotListners.EventList.class)
public class A5_Requests extends FailScreenshot {

	@Test
	public void PA_SendAssessment() throws InterruptedException {
	
	/* Login to the Application - PBC */ 		
	driver.findElement(By.xpath("(//button[normalize-space()='Login'])[1]")).click();
	driver.findElement(By.xpath("//input[@id='Username']")).click();
	driver.findElement(By.xpath("//input[@id='Username']")).sendKeys("test.doe002");
	driver.findElement(By.xpath("//input[@id='password-field']")).click();
	driver.findElement(By.xpath("//input[@id='password-field']")).sendKeys("Rockon123");
	driver.findElement(By.xpath("//button[@id='loginButton']")).click();
	Thread.sleep(2000);
	WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(120));
    
	/* Navigate to the Assessment */
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'My Profile')]")));
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'My Profile')]")));
	Thread.sleep(2000);
	{
	     WebElement element = driver.findElement(By.xpath("//div[@class='menu-item menu-item-active']"));
	     Actions builder = new Actions(driver);
	     builder.moveToElement(element).perform();
	}
	Thread.sleep(2000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'Personality Assessment')]")));
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'Personality Assessment')]")));Thread.sleep(2000);
	driver.findElement(By.cssSelector(".menu-item:nth-child(11) .menu-label")).click();
	
    /* Check the Assessment requests from Coach */
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".d-none:nth-child(2) > a")));
	wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".d-none:nth-child(2) > a")));Thread.sleep(2000);
    driver.findElement(By.cssSelector(".d-none:nth-child(2) > a")).click();
    Thread.sleep(2000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[2]/div[2]/div/div[2]/div/div/div[2]/span")));
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[2]/div[2]/div/div[2]/div/div/div[2]/span")));Thread.sleep(2000);
    driver.findElement(By.xpath("//div[2]/div[2]/div/div[2]/div/div/div[2]/span")).click();
    Thread.sleep(2000); 
    
    /* Public View - Handle Windows - New Window */ 
	String winHandleBefore = driver.getWindowHandle();
	driver.findElement(By.linkText("Adam Sulaiman")).click();
	Thread.sleep(2000);
	for(String winHandle : driver.getWindowHandles()){
    driver.switchTo().window(winHandle);
    Thread.sleep(2000);
	}
	driver.close();
	Thread.sleep(2000);	    	
	driver.switchTo().window(winHandleBefore);
	Thread.sleep(2000);	
	driver.findElement(By.cssSelector("#coachingcancelpopup > .modal-header .fa")).click();
	Thread.sleep(2000);  
	
	/* Assessment ID - Request Details */ 
	String winHandleBefore1 = driver.getWindowHandle();
	driver.findElement(By.xpath("//strong[normalize-space()='Assessment ID:']")).click();
	Thread.sleep(2000);
	for(String winHandle : driver.getWindowHandles())
	{
	driver.switchTo().window(winHandle);
	Thread.sleep(2000);
	}
    driver.findElement(By.cssSelector(".btn-outline-maroon")).click();
    Thread.sleep(9000);
    driver.findElement(By.cssSelector("td .btn:nth-child(2)")).click();
    Thread.sleep(2000);
    driver.findElement(By.cssSelector("td .btn:nth-child(1)")).click();
    Thread.sleep(2000);
    driver.findElement(By.cssSelector(".modal-prime > .modal-header .fa")).click();
    Thread.sleep(2000);
    driver.findElement(By.cssSelector(".print-machine")).click();
    Thread.sleep(2000);
    driver.findElement(By.cssSelector(".modal-prime > .modal-header .fa")).click();
	Thread.sleep(2000);
    driver.close();    	
	driver.switchTo().window(winHandleBefore1);
	Thread.sleep(2000);
 
	/* Back to Main Page */
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//section[2]/div[2]/div[1]/div[2]/div[1]/div[1]/div[3]/div[1]/span[1]/span[1]")));
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//section[2]/div[2]/div[1]/div[2]/div[1]/div[1]/div[3]/div[1]/span[1]/span[1]")));Thread.sleep(2000);
    driver.findElement(By.xpath("//section[2]/div[2]/div[1]/div[2]/div[1]/div[1]/div[3]/div[1]/span[1]/span[1]")).click();Thread.sleep(2000);
    driver.findElement(By.id("btnNoConfirmYesNo")).click();Thread.sleep(2000);
    driver.findElement(By.xpath("//section[2]/div[2]/div[1]/div[2]/div[1]/div[1]/div[3]/div[1]/span[1]/span[1]")).click();Thread.sleep(2000);
    driver.findElement(By.id("btnYesConfirmYesNo")).click();
    Thread.sleep(2000);
    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".request-id:nth-child(2) > span")));Thread.sleep(2000);
    driver.findElement(By.cssSelector(".request-id:nth-child(2) > span")).click();
    Thread.sleep(2000);
    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector("#coachingcancelpopup > .modal-header .fa")));Thread.sleep(2000);
    driver.findElement(By.cssSelector("#coachingcancelpopup > .modal-header .fa")).click();
    Thread.sleep(2000);
    
    /* Assessment ID - Request Details */ 
 	String winHandleBefore2 = driver.getWindowHandle();Thread.sleep(2000);
 	driver.findElement(By.xpath("//strong[normalize-space()='Assessment ID:']")).click();
 	Thread.sleep(2000);
 	for(String winHandle : driver.getWindowHandles()){
 	driver.switchTo().window(winHandle);
 	Thread.sleep(2000);
	}
 	driver.findElement(By.linkText("Back")).click();	
 	Thread.sleep(2000);	    	
 	driver.close();
 	Thread.sleep(2000);	 	
 	driver.switchTo().window(winHandleBefore2);
 	Thread.sleep(2000);

 	/* Back to Main View - Share the Second Report */
    driver.findElement(By.cssSelector(".btn-green")).click();
    Thread.sleep(2000);
    driver.findElement(By.id("btnYesConfirmYesNo")).click();
    Thread.sleep(2000);   
    
    /* Share and Unshare the Report */
    driver.findElement(By.cssSelector(".d-none:nth-child(3) > a")).click();
    Thread.sleep(2000);
    {
      WebElement element = driver.findElement(By.xpath("//img[@title=\'Benelli Sebastian\']"));
      Actions builder = new Actions(driver);Thread.sleep(2000);
      builder.moveToElement(element).perform();Thread.sleep(2000);
    }
    driver.findElement(By.xpath("//form/i")).click();
    Thread.sleep(2000);
    driver.findElement(By.id("btnNoConfirmYesNo")).click();
    Thread.sleep(2000);
    {
      WebElement element = driver.findElement(By.xpath("//img[@title=\'Benelli Sebastian\']"));
      Actions builder = new Actions(driver);Thread.sleep(2000);
      builder.moveToElement(element).perform();
      Thread.sleep(2000);
    }
    driver.findElement(By.xpath("//form/i")).click();
    Thread.sleep(2000);
    driver.findElement(By.id("btnYesConfirmYesNo")).click();
	wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".toast-message")));Thread.sleep(2000);
    wait.until(ExpectedConditions.stalenessOf(driver.findElement(By.xpath("//div[@class=\'toast-message\']"))));
    Thread.sleep(2000);
    
    /* Logout */
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'My Profile')]")));
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'My Profile')]")));Thread.sleep(2000);
	driver.findElement(By.xpath("//div[contains(text(),'My Profile')]")).click();
	Thread.sleep(2000);
	driver.findElement(By.xpath("(//div[contains(text(),'Logout')])[2]")).click();
	Thread.sleep(2000);
  }
}

