package assessmentPersonality;

import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import screenshotOnFailure.FailScreenshot;

@Listeners(screenshotListners.EventList.class)
public class A6_CoachViewReport extends FailScreenshot {
	
	@Test
	public void PA_ViewsReport() throws InterruptedException {

	/* Login to the Application - PBC */ 		
	driver.findElement(By.xpath("(//button[normalize-space()='Login'])[1]")).click();
	driver.findElement(By.xpath("//input[@id='Username']")).click();
	driver.findElement(By.xpath("//input[@id='Username']")).sendKeys("john.doe006");
	driver.findElement(By.xpath("//input[@id='password-field']")).click();
	driver.findElement(By.xpath("//input[@id='password-field']")).sendKeys("Rockon123");
	driver.findElement(By.xpath("//button[@id='loginButton']")).click();
	Thread.sleep(2000);
	WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(120));
    
    /* Navigate to the Coach Page to see the shared Report */
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[normalize-space()='Coach Assessment']")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()='Coach Assessment']")));Thread.sleep(2000);
    driver.findElement(By.xpath("//span[normalize-space()='Coach Assessment']")).click();
    Thread.sleep(2000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[normalize-space()='Menu']")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()='Menu']")));Thread.sleep(2000);
    driver.findElement(By.xpath("//span[normalize-space()='Menu']")).click();
    Thread.sleep(2000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[normalize-space()='Coaching Services']")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[normalize-space()='Coaching Services']")));Thread.sleep(2000);
    driver.findElement(By.xpath("//a[normalize-space()='Coaching Services']")).click();
    Thread.sleep(2000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("menuitemopportunities")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.id("menuitemopportunities")));Thread.sleep(2000);
    driver.findElement(By.id("menuitemopportunities")).click();
    Thread.sleep(2000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div/div/div/div/div/div[3]/div/span")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div/div/div/div/div/div[3]/div/span")));Thread.sleep(2000);
    driver.findElement(By.xpath("//div/div/div/div/div/div[3]/div/span")).click();
    Thread.sleep(2000);         
    String winHandleBefore2 = driver.getWindowHandle();Thread.sleep(2000);
    driver.findElement(By.cssSelector("a > .assessment-btn")).click();Thread.sleep(2000);
    for(String winHandle : driver.getWindowHandles())
    {
     	driver.switchTo().window(winHandle);Thread.sleep(2000);
    }
    driver.findElement(By.cssSelector(".btn-outline-blue")).click();Thread.sleep(2000);
    driver.findElement(By.cssSelector(".btn-outline-blue")).click();Thread.sleep(2000);
    driver.findElement(By.cssSelector(".margin-left-20")).click();Thread.sleep(2000);
    
		    String winHandleBefore21 = driver.getWindowHandle();Thread.sleep(2000);
		    
		    /* Scroll up to the page to Click Print PDF and Back icons */
		    JavascriptExecutor jse = (JavascriptExecutor)driver;
		    jse.executeScript("scroll(0, -250);");Thread.sleep(2000);
		    driver.findElement(By.cssSelector(".print-machine")).click();Thread.sleep(2000);
		    for(String winHandle : driver.getWindowHandles()){
		        driver.switchTo().window(winHandle);Thread.sleep(2000);
		    	}
		    Thread.sleep(2000);
		    driver.close();Thread.sleep(2000);	    	
		 	driver.switchTo().window(winHandleBefore21); 
		 	Thread.sleep(2000);
		 	// Scroll the page up
		    jse.executeScript("scroll(0, -250);");Thread.sleep(2000);		    
    driver.findElement(By.linkText("Back")).click();
    Thread.sleep(2000);
    driver.close();Thread.sleep(2000);	    	
 	driver.switchTo().window(winHandleBefore2);Thread.sleep(2000);
    
    driver.findElement(By.cssSelector(".col-12 > .btn-blue-link-12 > span")).click();
    Thread.sleep(2000);
    
    /* Request ID and Cancel */
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("menuitemassessments")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.id("menuitemassessments")));Thread.sleep(2000);
    driver.findElement(By.id("menuitemassessments")).click();
    Thread.sleep(2000);
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//b[normalize-space()='Req. ID:']")));	
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//b[normalize-space()='Req. ID:']")));
    driver.findElement(By.xpath("//b[normalize-space()='Req. ID:']")).click();
    Thread.sleep(2000);
    driver.findElement(By.cssSelector("#coachingcancelpopup > .modal-header .fa")).click();
    Thread.sleep(2000);
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.linkText("View Report")));	
    wait.until(ExpectedConditions.elementToBeClickable(By.linkText("View Report")));
    driver.findElement(By.linkText("View Report")).click();
    Thread.sleep(2000);
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".btn-outline-blue")));	
    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".btn-outline-blue")));
    driver.findElement(By.cssSelector(".btn-outline-blue")).click();
    Thread.sleep(2000);
    driver.findElement(By.cssSelector(".btn-outline-blue")).click();Thread.sleep(2000);
    
    /* Scroll Up the page */
    jse.executeScript("scroll(0, -250);");
    
    		String winHandleBefore3 = driver.getWindowHandle();Thread.sleep(2000);
		    driver.findElement(By.cssSelector(".print-machine")).click();Thread.sleep(2000);
		    for(String winHandle : driver.getWindowHandles()){
		        driver.switchTo().window(winHandle);
		    	}
		    Thread.sleep(2000);
		    driver.close();Thread.sleep(2000);	    	
		 	driver.switchTo().window(winHandleBefore3);
		 	Thread.sleep(2000);    
    
    driver.findElement(By.linkText("Back")).click();
    Thread.sleep(2000);
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".btn-outline-blue")));	
    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".btn-outline-blue")));Thread.sleep(2000);
    driver.findElement(By.cssSelector(".btn-outline-blue")).click();
    Thread.sleep(2000);
    driver.findElement(By.id("Description")).click();
    driver.findElement(By.id("Description")).sendKeys("Please Share the Assessment");
    Thread.sleep(2000);
    driver.findElement(By.cssSelector(".float-right > .btn-sm")).click();
    wait.until(ExpectedConditions.invisibilityOfElementLocated(By.cssSelector(".float-right > .btn-sm")));
    Thread.sleep(2000);
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".btn-blue-link-12 > .d-none")));
    wait.until(ExpectedConditions.elementToBeClickable(driver.findElement(By.cssSelector(".btn-blue-link-12 > .d-none"))));Thread.sleep(2000);   
    driver.findElement(By.cssSelector(".btn-blue-link-12 > .d-none")).click();Thread.sleep(2000);
    driver.findElement(By.id("discussiontextarea")).click();
    driver.findElement(By.id("discussiontextarea")).sendKeys("Hello Adam send the Assesssment");
    Thread.sleep(2000);
    driver.findElement(By.xpath("//button[contains(.,\'Send Message\')]")).click();
    Thread.sleep(2000);
    driver.findElement(By.cssSelector(".btn-blue-link-12")).click();
    Thread.sleep(2000);
    driver.findElement(By.cssSelector("#lnkPersonalityInformation .social-heading")).click();
    Thread.sleep(2000);
    driver.findElement(By.xpath("//section/div/ul/li/a/span")).click();
    Thread.sleep(2000);
    
    /* Create Meeting */
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".float-right > .btn-blue-link-12")));
    wait.until(ExpectedConditions.elementToBeClickable(driver.findElement(By.cssSelector(".float-right > .btn-blue-link-12"))));Thread.sleep(2000);
    driver.findElement(By.cssSelector(".float-right > .btn-blue-link-12")).click();
    Thread.sleep(2000);
    driver.findElement(By.id("submitbtn")).click();
    Thread.sleep(2000);       
    driver.findElement(By.cssSelector(".fa-user-plus")).click();
    Thread.sleep(2000);
    driver.findElement(By.id("MeetingName")).click();
    driver.findElement(By.id("MeetingName")).sendKeys("Assessment Meet");
    Thread.sleep(2000);
    driver.findElement(By.xpath("//span[@class=\'input-group-append set-date set-date-birth\']//i[@class=\'fa fa-calendar set-date-icon\']")).click();Thread.sleep(2000);
    driver.findElement(By.xpath("//div[contains(@class, \'datetimepicker datetimepicker-\')][last()]/div[3]/table/tbody/tr/td[@class=\'day active\']")).click();Thread.sleep(2000);
    driver.findElement(By.xpath("//div[contains(@class, \'datetimepicker datetimepicker-\')][last()]/div[2]/table/tbody/tr/td/fieldset/span[contains(@class,\'hour active \')]")).click();Thread.sleep(2000);
    if(!driver.findElements(By.xpath("//div[contains(@class, 'datetimepicker datetimepicker-')][last()]/div[1]/table/tbody/tr/td/fieldset/span[11][contains(@class, 'minute disabled')]")).isEmpty())
	{	    		    
		Thread.sleep(2000);
		driver.findElement(By.xpath("//div[@class='datetimepicker-minutes']//th[@class='next']")).click();
    	Thread.sleep(2000);
    	driver.findElement(By.xpath("//div[contains(@class, \'datetimepicker datetimepicker-\')][last()]/div[1]/table/tbody/tr/td/fieldset/span[@class=\'minute\'][2]")).click();	    		    
	}
	
	else {
		Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[contains(@class, \'datetimepicker datetimepicker-\')][last()]/div[1]/table/tbody/tr/td/fieldset/span[@class=\'minute\'][2]")).click();
	}
	Thread.sleep(2000);
	driver.findElement(By.xpath("//form[@id=\'myForm\']/div[2]/div[2]/div/div[2]/div/span/span/span")).click();Thread.sleep(2000);
    driver.findElement(By.cssSelector(".select2-search__field")).click();Thread.sleep(2000);
    driver.findElement(By.cssSelector(".select2-search__field")).sendKeys("30");
    driver.findElement(By.cssSelector(".select2-search__field")).sendKeys(Keys.ENTER);  
    Thread.sleep(2000);
    
    /* Add & Remove Attendees */
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".txtMemberInvite")));
    wait.until(ExpectedConditions.elementToBeClickable(driver.findElement(By.cssSelector(".txtMemberInvite"))));Thread.sleep(2000);
    driver.findElement(By.cssSelector(".txtMemberInvite")).click();
    driver.findElement(By.cssSelector(".txtMemberInvite")).sendKeys("ifthy@test.com");
    Thread.sleep(2000);
    driver.findElement(By.cssSelector(".txtMemberInvite")).sendKeys(Keys.ENTER);
    Thread.sleep(2000);
    driver.findElement(By.id("crossifthy@test.com")).click();
    Thread.sleep(2000);
    
    /* Recurrence Meeting */
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("select2-PlannedSchedule_StartSchedule_TypeOfSchedule-container")));
    wait.until(ExpectedConditions.elementToBeClickable(driver.findElement(By.id("select2-PlannedSchedule_StartSchedule_TypeOfSchedule-container"))));Thread.sleep(2000);
    driver.findElement(By.id("select2-PlannedSchedule_StartSchedule_TypeOfSchedule-container")).click();
    Thread.sleep(2000);
    driver.findElement(By.cssSelector(".select2-search__field")).click();
    driver.findElement(By.cssSelector(".select2-search__field")).sendKeys("dai");
    Thread.sleep(2000);
    driver.findElement(By.cssSelector(".select2-search__field")).sendKeys(Keys.ENTER);
    Thread.sleep(2000);
    driver.findElement(By.id("dailyCount")).click();Thread.sleep(2000);
    driver.findElement(By.cssSelector(".endInputs > div:nth-child(3) > input")).click();Thread.sleep(2000);
    Thread.sleep(2000);
    driver.findElement(By.id("submitbtn")).click();Thread.sleep(2000);
    
    /* Add Particpants after Meeting created */
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//i[@class='editmeeting-icon']")));
    wait.until(ExpectedConditions.elementToBeClickable(driver.findElement(By.xpath("//i[@class='editmeeting-icon']"))));Thread.sleep(2000);
    driver.findElement(By.xpath("//i[@class='addParticipant-icon']")).click();
    Thread.sleep(2000);
    driver.findElement(By.id("btnAddAttendee")).click();
    Thread.sleep(2000);
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//i[@class='editmeeting-icon']")));
    wait.until(ExpectedConditions.elementToBeClickable(driver.findElement(By.xpath("//i[@class='editmeeting-icon']"))));Thread.sleep(2000);
    driver.findElement(By.xpath("//i[@class='editmeeting-icon']")).click();
    Thread.sleep(2000);
    driver.findElement(By.id("MeetingName")).click();
    driver.findElement(By.id("MeetingName")).clear();Thread.sleep(2000);
    driver.findElement(By.id("MeetingName")).sendKeys("Assessment Meet 123");
    Thread.sleep(2000);
    driver.findElement(By.cssSelector(".fa-user-plus")).click();
    Thread.sleep(2000);
    driver.findElement(By.id("submitbtn")).click();
    Thread.sleep(2000);
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//i[@class='editmeeting-icon']")));
    wait.until(ExpectedConditions.elementToBeClickable(driver.findElement(By.xpath("//i[@class='editmeeting-icon']"))));Thread.sleep(2000);
    driver.findElement(By.cssSelector(".deletemeeting-icon")).click();
    Thread.sleep(2000);
    driver.findElement(By.id("btnNoConfirmYesNo")).click();
    Thread.sleep(2000);
    driver.findElement(By.cssSelector(".meeting-history-text")).click();
    Thread.sleep(2000);
    driver.findElement(By.cssSelector("li > .btn-blue-link-12 .my-meeting-text")).click();
    Thread.sleep(2000);
    driver.findElement(By.cssSelector(".myMeeting > .my-meeting-text")).click();
    Thread.sleep(2000);
    
    /* Delete Meeting */
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//i[@class='editmeeting-icon']")));
    wait.until(ExpectedConditions.elementToBeClickable(driver.findElement(By.xpath("//i[@class='editmeeting-icon']"))));Thread.sleep(2000);
    driver.findElement(By.cssSelector(".deletemeeting-icon")).click();
    Thread.sleep(2000);
    driver.findElement(By.id("btnYesConfirmYesNo")).click();
    Thread.sleep(2000);
    driver.findElement(By.cssSelector(".biz-admin-overlay > .modal-header .fa")).click();Thread.sleep(2000);
    
    /* Logout from Coach Page */
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'My Profile')]")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'My Profile')]")));Thread.sleep(2000);
	driver.findElement(By.xpath("//div[contains(text(),'My Profile')]")).click();  
	Thread.sleep(2000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//div[contains(text(),'Logout')])[1]")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//div[contains(text(),'Logout')])[1]")));Thread.sleep(2000);
	driver.findElement(By.xpath("(//div[contains(text(),'Logout')])[1]")).click();  
	Thread.sleep(2000);
  }
}
