package assessmentPersonality;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import screenshotOnFailure.FailScreenshot;

@Listeners(screenshotListners.EventList.class)
public class A3_CoachingReq extends FailScreenshot{

	@Test
	public void PA_CoachRequest() throws InterruptedException {
	
		/* Login to the Application - PBC */ 		
		driver.findElement(By.xpath("(//button[normalize-space()='Login'])[1]")).click();
		driver.findElement(By.xpath("//input[@id='Username']")).click();
		driver.findElement(By.xpath("//input[@id='Username']")).sendKeys("test.doe002");
		driver.findElement(By.xpath("//input[@id='password-field']")).click();
		driver.findElement(By.xpath("//input[@id='password-field']")).sendKeys("Rockon123");
		driver.findElement(By.xpath("//button[@id='loginButton']")).click();
		Thread.sleep(2000);
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(120));
		
	    /* Send Coaching Request */
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'My Profile')]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'My Profile')]")));
		Thread.sleep(2000);
		{
		     WebElement element = driver.findElement(By.xpath("//div[@class='menu-item menu-item-active']"));
		     Actions builder = new Actions(driver);
		     builder.moveToElement(element).perform();
		}
		Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'Coaching Support')]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'Coaching Support')]")));Thread.sleep(2000);
		driver.findElement(By.xpath("//div[contains(text(),'Coaching Support')]")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".btn-blue")));
	    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".btn-blue")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".btn-blue")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("TermsAndCondition")));
	    wait.until(ExpectedConditions.elementToBeClickable(By.id("TermsAndCondition")));Thread.sleep(2000);
	    driver.findElement(By.id("TermsAndCondition")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".btn-lg")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("Title")));
	    wait.until(ExpectedConditions.elementToBeClickable(By.id("Title")));Thread.sleep(2000);
	    driver.findElement(By.id("Title")).click();	    
	    driver.findElement(By.id("Title")).sendKeys("Auto Coach Assessment");
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector("#mceu_3 > button")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".mce-i-bullist")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.id("RequestSpecialities")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector("#bs-select-1-1 .text-muted")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".next-btn")));
	    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".next-btn")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".next-btn")).click();
	    Thread.sleep(2000);
	    
	    /* Choosing Countries */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("Countries_All_")));
	    wait.until(ExpectedConditions.elementToBeClickable(By.id("Countries_All_")));Thread.sleep(2000);
	    driver.findElement(By.id("Countries_All_")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".next-btn")));
	    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".next-btn")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".next-btn")).click();
	    Thread.sleep(2000);
	    
	    /* Prefrences */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("Preference_Morning")));
	    wait.until(ExpectedConditions.elementToBeClickable(By.id("Preference_Morning")));Thread.sleep(2000);
	    driver.findElement(By.id("Preference_Morning")).click();Thread.sleep(2000);
	    driver.findElement(By.id("Preference_IsConnectPerson")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".next-btn")).click();
	    Thread.sleep(2000);	    
	    
	    /* Draft Button  and then Send Request button */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".btn-outline-blue")));
	    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".btn-outline-blue")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".btn-outline-blue")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[@class=\'btn-sm btn-outline-blue margin-right-15\']")));
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[@class=\'btn-sm btn-outline-blue margin-right-15\']")));
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.linkText("Send Request")));
	    wait.until(ExpectedConditions.elementToBeClickable(By.linkText("Send Request")));Thread.sleep(2000);
	    driver.findElement(By.linkText("Send Request")).click();
	    wait.until(ExpectedConditions.invisibilityOfElementLocated(By.linkText("Send Request")));
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[@class=\'btn-sm btn-outline-blue margin-right-15\']")));Thread.sleep(2000);
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[@class=\'btn-sm btn-outline-blue margin-right-15\']")));Thread.sleep(2000);
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()='Delete']")));
	    Thread.sleep(2000);
	    
	    /* Logout */
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'My Profile')]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'My Profile')]")));Thread.sleep(2000);
		driver.findElement(By.xpath("//div[contains(text(),'My Profile')]")).click();
		Thread.sleep(2000);
		WebElement Logout = driver.findElement(By.xpath("//div[@onclick='logout()']//div[@class='menu-label ml-1'][normalize-space()='Logout']"));
		JavascriptExecutor jse = (JavascriptExecutor)driver;
		jse.executeScript("arguments[0].click()", Logout);	    
		Thread.sleep(2000);
	  }
}

