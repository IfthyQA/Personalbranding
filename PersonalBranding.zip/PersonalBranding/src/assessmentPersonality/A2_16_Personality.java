package assessmentPersonality;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import screenshotOnFailure.FailScreenshot;

@Listeners(screenshotListners.EventList.class)
public class A2_16_Personality extends FailScreenshot{
	
	@Test
	public void PA_TakesMBTI() throws InterruptedException {

		/* Login to the Application - PBC */ 		
		driver.findElement(By.xpath("(//button[normalize-space()='Login'])[1]")).click();
		driver.findElement(By.xpath("//input[@id='Username']")).click();
		driver.findElement(By.xpath("//input[@id='Username']")).sendKeys("test.doe002");
		driver.findElement(By.xpath("//input[@id='password-field']")).click();
		driver.findElement(By.xpath("//input[@id='password-field']")).sendKeys("Rockon123");
		driver.findElement(By.xpath("//button[@id='loginButton']")).click();
		Thread.sleep(2000);
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(120));
	    
	    /* Take & Cancel MBTI Assessment */
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'My Profile')]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'My Profile')]")));
		Thread.sleep(2000);
		 {
		     WebElement element = driver.findElement(By.xpath("//div[@class='menu-item menu-item-active']"));
		     Actions builder = new Actions(driver);
		     builder.moveToElement(element).perform();
		 }
		 Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'Personality Assessment')]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'Personality Assessment')]")));Thread.sleep(2000);
		driver.findElement(By.cssSelector(".menu-item:nth-child(11) .menu-label")).click();
		Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".d-none:nth-child(4) > a")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".btn-blue")).click();
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".btn-outline-grey")));
	    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".btn-outline-grey")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".btn-outline-grey")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.id("btnYesConfirmYesNo")).click();
	    Thread.sleep(2000);
	    
	    /* Sample Report */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".d-none:nth-child(1) > a")));
	    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".d-none:nth-child(1) > a")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".d-none:nth-child(1) > a")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.linkText("Sample Report")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".fa-arrow-left")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".col-12:nth-child(1) > .row > .d-none > .float-right span")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".btn-outline-grey")).click();Thread.sleep(2000);
	    driver.findElement(By.id("btnYesConfirmYesNo")).click();
	    Thread.sleep(2000);
	    
	    /* Take MBTI Assessment */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".btn-blue")));
	    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".btn-blue")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".btn-blue")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.id("Answers_0__ScoreData")).click();Thread.sleep(2000);
	    driver.findElement(By.xpath("(//input[@id=\'Answers_1__ScoreData\'])[2]")).click();Thread.sleep(2000);
	    driver.findElement(By.xpath("(//input[@id=\'Answers_2__ScoreData\'])[3]")).click();Thread.sleep(2000);
	    driver.findElement(By.xpath("(//input[@id=\"Answers_3__ScoreData\"])[4]")).click();Thread.sleep(2000);
	    driver.findElement(By.xpath("(//input[@id=\"Answers_4__ScoreData\"])[5]")).click();Thread.sleep(2000);
	    driver.findElement(By.xpath("(//input[@id=\"Answers_5__ScoreData\"])[4]")).click();Thread.sleep(2000);
	    driver.findElement(By.xpath("(//input[@id=\"Answers_6__ScoreData\"])[3]")).click();Thread.sleep(2000);
	    driver.findElement(By.xpath("(//input[@id=\'Answers_7__ScoreData\'])[2]")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".btn-outline-grey")).click();Thread.sleep(2000);
	    driver.findElement(By.id("btnNoConfirmYesNo")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".fa-angle-right")).click();Thread.sleep(2000);
	    driver.findElement(By.xpath("(//input[@id=\"Answers_8__ScoreData\"])[2]")).click();Thread.sleep(2000);
	    driver.findElement(By.xpath("(//input[@id=\"Answers_9__ScoreData\"])[3]")).click();Thread.sleep(2000);
	    driver.findElement(By.xpath("(//input[@id=\"Answers_10__ScoreData\"])[4]")).click();Thread.sleep(2000);
	    driver.findElement(By.xpath("(//input[@id=\'Answers_11__ScoreData\'])[5]")).click();Thread.sleep(2000);
	    driver.findElement(By.xpath("(//input[@id=\'Answers_12__ScoreData\'])[1]")).click();Thread.sleep(2000);
	    driver.findElement(By.xpath("(//input[@id=\'Answers_13__ScoreData\'])[2]")).click();Thread.sleep(2000);
	    driver.findElement(By.xpath("(//input[@id=\'Answers_14__ScoreData\'])[3]")).click();Thread.sleep(2000);
	    driver.findElement(By.xpath("(//input[@id=\'Answers_15__ScoreData\'])[4]")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".fa-angle-right")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("(//input[@id=\"Answers_16__ScoreData\"])[2]")).click();Thread.sleep(2000);
	    driver.findElement(By.xpath("(//input[@id=\"Answers_17__ScoreData\"])[3]")).click();Thread.sleep(2000);
	    driver.findElement(By.xpath("(//input[@id=\"Answers_18__ScoreData\"])[4]")).click();Thread.sleep(2000);
	    driver.findElement(By.xpath("(//input[@id=\'Answers_19__ScoreData\'])[5]")).click();Thread.sleep(2000);
	    driver.findElement(By.xpath("(//input[@id=\'Answers_20__ScoreData\'])[1]")).click();Thread.sleep(2000);
	    driver.findElement(By.xpath("(//input[@id=\'Answers_21__ScoreData\'])[2]")).click();Thread.sleep(2000);
	    driver.findElement(By.xpath("(//input[@id=\'Answers_22__ScoreData\'])[3]")).click();Thread.sleep(2000);
	    driver.findElement(By.xpath("(//input[@id=\'Answers_23__ScoreData\'])[4]")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".fa-angle-right")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("(//input[@id=\"Answers_24__ScoreData\"])[1]")).click();Thread.sleep(2000);
	    driver.findElement(By.xpath("(//input[@id=\"Answers_25__ScoreData\"])[3]")).click();Thread.sleep(2000);
	    driver.findElement(By.xpath("(//input[@id=\"Answers_26__ScoreData\"])[1]")).click();Thread.sleep(2000);
	    driver.findElement(By.xpath("(//input[@id=\'Answers_27__ScoreData\'])[5]")).click();Thread.sleep(2000);
	    driver.findElement(By.xpath("(//input[@id=\'Answers_28__ScoreData\'])[2]")).click();Thread.sleep(2000);
	    driver.findElement(By.xpath("(//input[@id=\'Answers_29__ScoreData\'])[3]")).click();Thread.sleep(2000);
	    driver.findElement(By.xpath("(//input[@id=\'Answers_30__ScoreData\'])[2]")).click();Thread.sleep(2000);
	    driver.findElement(By.xpath("(//input[@id=\'Answers_31__ScoreData\'])[5]")).click();Thread.sleep(2000);
	    
	    /* Scroll down the page */
	    Thread.sleep(2000);
	    JavascriptExecutor jse = (JavascriptExecutor)driver;
	    jse.executeScript("window.scrollBy(0,250)");
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".fa-angle-left")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".fa-angle-left")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".fa-angle-left")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".fa-angle-right")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".fa-angle-right")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".fa-angle-right")).click();Thread.sleep(2000);
	    
	    /* Submit the Report */
	    driver.findElement(By.cssSelector(".btn-blue")).click();Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".fa-arrow-left")));Thread.sleep(2000);	
	    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".fa-arrow-left")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".fa-arrow-left")).click();Thread.sleep(2000);
	    
	    /* Navigate the Menu */
	    driver.findElement(By.cssSelector(".d-none:nth-child(1) > a")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".d-none:nth-child(4) > a")).click();Thread.sleep(2000);
	    
	    /* Retake Assessment - Cancel */
	    driver.findElement(By.cssSelector("form > .btn-sm")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".btn-outline-grey")).click();Thread.sleep(2000);
	    driver.findElement(By.id("btnYesConfirmYesNo")).click();Thread.sleep(2000);
	    
	    /* Logout */
		 wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'My Profile')]")));
		 wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'My Profile')]")));Thread.sleep(2000);
		 driver.findElement(By.xpath("//div[contains(text(),'My Profile')]")).click();
		 Thread.sleep(2000);
		 driver.findElement(By.xpath("(//div[contains(text(),'Logout')])[2]")).click();
		 Thread.sleep(2000);
	  }
	}
		
