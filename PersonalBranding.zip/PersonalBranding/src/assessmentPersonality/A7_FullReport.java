package assessmentPersonality;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import screenshotOnFailure.FailScreenshot;

@Listeners(screenshotListners.EventList.class)
public class A7_FullReport extends FailScreenshot {

	@Test
	public void PA_ClientViewFullReport() throws InterruptedException {
		
	/* Login to the Application - PBC */ 		
	driver.findElement(By.xpath("(//button[normalize-space()='Login'])[1]")).click();
	driver.findElement(By.xpath("//input[@id='Username']")).click();
	driver.findElement(By.xpath("//input[@id='Username']")).sendKeys("test.doe002");
	driver.findElement(By.xpath("//input[@id='password-field']")).click();
	driver.findElement(By.xpath("//input[@id='password-field']")).sendKeys("Rockon123");
	driver.findElement(By.xpath("//button[@id='loginButton']")).click();
	Thread.sleep(2000);
	WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(120));
    
	/* Navigate to the Assessment */
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'My Profile')]")));
	 wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'My Profile')]")));
	 Thread.sleep(2000);
	 {
	     WebElement element = driver.findElement(By.xpath("//div[@class='menu-item menu-item-active']"));
	     Actions builder = new Actions(driver);
	     builder.moveToElement(element).perform();
	 }
	 Thread.sleep(2000);
	 wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'Personality Assessment')]")));
	 wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'Personality Assessment')]")));Thread.sleep(2000);
	 driver.findElement(By.cssSelector(".menu-item:nth-child(11) .menu-label")).click();
	 Thread.sleep(2000);
    
    /* Navigate to reports page to see the Full Report */
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".d-none:nth-child(2) > a")));
    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".d-none:nth-child(2) > a")));Thread.sleep(2000); 
    driver.findElement(By.cssSelector(".d-none:nth-child(2) > a")).click();
    Thread.sleep(2000);
    driver.findElement(By.cssSelector(".btn-green")).click();
    Thread.sleep(2000);
    driver.findElement(By.id("btnYesConfirmYesNo")).click();
    Thread.sleep(2000);
    driver.findElement(By.cssSelector(".d-none:nth-child(3) > a")).click();
    Thread.sleep(2000);
    driver.findElement(By.cssSelector(".d-none:nth-child(4) > a")).click();
    Thread.sleep(2000);
    driver.findElement(By.cssSelector(".row:nth-child(1) > .col-12 > .row .d-none a > .fa")).click();
    Thread.sleep(2000);
    driver.findElement(By.linkText("Back")).click();
    Thread.sleep(2000);
    driver.findElement(By.cssSelector(".btn-blue")).click();
    Thread.sleep(2000);
    driver.findElement(By.cssSelector(".btn-outline-grey")).click();
    Thread.sleep(2000);
    driver.findElement(By.id("btnYesConfirmYesNo")).click();
    Thread.sleep(2000);
    
    /* Logout */
	 wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'My Profile')]")));
	 wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'My Profile')]")));
	 driver.findElement(By.xpath("//div[contains(text(),'My Profile')]")).click();
	 Thread.sleep(2000);
	 wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//div[contains(text(),'Logout')])[2]")));
	 wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//div[contains(text(),'Logout')])[2]")));
	 driver.findElement(By.xpath("(//div[contains(text(),'Logout')])[2]")).click();
	 Thread.sleep(2000);
  }
}

