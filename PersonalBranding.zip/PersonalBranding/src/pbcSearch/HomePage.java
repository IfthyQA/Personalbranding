package pbcSearch;

import java.io.IOException;
import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import screenshotOnFailure.FailScreenshot;

@Listeners(screenshotListners.EventList.class)
public class HomePage extends FailScreenshot{
	
	@Test
	public void LandingPage() throws InterruptedException, IOException {
	WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(120));
	
	/* Navgate to the PBC */	
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.linkText("Login")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.linkText("Login")));Thread.sleep(2000); 	
    driver.findElement(By.linkText("Login")).click();
    Thread.sleep(2000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".btn-lg")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".btn-lg")));Thread.sleep(2000); 	
    driver.findElement(By.cssSelector(".btn-lg")).click();
    Thread.sleep(2000);
    
    /* Forget Password */
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.linkText("Forgot Password")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.linkText("Forgot Password")));Thread.sleep(2000); 
    driver.findElement(By.linkText("Forgot Password")).click();
    Thread.sleep(2000); 
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("EmailAddress")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.id("EmailAddress")));Thread.sleep(2000);   
    driver.findElement(By.cssSelector(".btn-lg")).click();
    Thread.sleep(2000);
    driver.findElement(By.id("EmailAddress")).click();Thread.sleep(2000);
    driver.findElement(By.id("EmailAddress")).sendKeys("Ifthy@tescra.com");Thread.sleep(2000);
    driver.findElement(By.cssSelector(".btn-lg")).click();Thread.sleep(2000);
    driver.findElement(By.id("EmailAddress")).clear();Thread.sleep(2000);
    driver.findElement(By.id("EmailAddress")).sendKeys("john.tescras0101+c011@gmail.com");
    Thread.sleep(2000);
	wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".btn-lg")));Thread.sleep(2000);
    driver.findElement(By.cssSelector(".btn-lg")).click();
    Thread.sleep(2000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.linkText("Login")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.linkText("Login")));
    driver.findElement(By.linkText("Login")).click();
    Thread.sleep(2000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.linkText("Register Now!")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.linkText("Register Now!")));Thread.sleep(2000);
    driver.findElement(By.linkText("Register Now!")).click();
    Thread.sleep(2000);  
    driver.findElement(By.name("flowSelect")).click();
    Thread.sleep(2000);  
    driver.findElement(By.cssSelector(".btnUploadFile")).click();
    Thread.sleep(2000);	
    Runtime.getRuntime().exec("C:\\Users\\dev\\Documents\\AutoScripts\\Cancel.exe");
    Thread.sleep(2000);  
    
    /* Register without Resume */
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("li:nth-child(2) input")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector("li:nth-child(2) input")));Thread.sleep(2000);
    driver.findElement(By.cssSelector("li:nth-child(2) input")).click();
    Thread.sleep(2000); 
    driver.findElement(By.id("btnApplyPromoCode")).click();Thread.sleep(2000);
    driver.findElement(By.name("IsStudent")).click();Thread.sleep(2000);
    driver.findElement(By.xpath("(//input[@name=\'IsStudent\'])[2]")).click();
    Thread.sleep(2000);
    {
      WebElement element = driver.findElement(By.id("FirstName"));Thread.sleep(2000);
      Actions builder = new Actions(driver);Thread.sleep(2000);
      builder.doubleClick(element).perform();Thread.sleep(2000);
    }
    driver.findElement(By.id("FirstName")).sendKeys("Moraji");Thread.sleep(2000);
    {
      WebElement element = driver.findElement(By.id("LastName"));Thread.sleep(2000);
      Actions builder = new Actions(driver);Thread.sleep(2000);
      builder.doubleClick(element).perform();Thread.sleep(2000);
    }
    driver.findElement(By.id("LastName")).sendKeys("Desai");Thread.sleep(2000);
    driver.findElement(By.cssSelector("#divRegistrationDOB label")).click();Thread.sleep(2000);
    driver.findElement(By.id("txtRegDOB")).sendKeys("12/12/1947");Thread.sleep(2000);
    driver.findElement(By.id("Email")).click();Thread.sleep(2000);
    driver.findElement(By.id("Email")).sendKeys("desai.moraji@tescra.com");Thread.sleep(2000);    					
    driver.findElement(By.xpath("//span[@role=\'combobox\']")).click();Thread.sleep(2000);
    driver.findElement(By.xpath("//input[@role=\'textbox\']")).click();Thread.sleep(2000);
    driver.findElement(By.xpath("//input[@role=\'textbox\']")).sendKeys("+91");
    driver.findElement(By.xpath("//input[@role=\'textbox\']")).sendKeys(Keys.ENTER);Thread.sleep(2000);
    driver.findElement(By.xpath("//input[@id=\'PhoneNumber\']")).click();Thread.sleep(2000);
    driver.findElement(By.id("PhoneNumber")).sendKeys("9865434566");Thread.sleep(2000);
    driver.findElement(By.id("btnApplyPromoCode")).click();Thread.sleep(2000);
    driver.findElement(By.id("PrivacyChecked")).click();Thread.sleep(2000);
    driver.findElement(By.cssSelector(".btn-lg")).click();Thread.sleep(2000);
    driver.findElement(By.id("PrivacyChecked")).click();Thread.sleep(2000);
    driver.findElement(By.cssSelector(".btn-lg")).click();Thread.sleep(2000);
    
    	String winHandleBefore = driver.getWindowHandle();Thread.sleep(2000);
	    driver.findElement(By.linkText("Terms and Conditions of ACHNET")).click();
	    Thread.sleep(2000);
    	// Navigate to New window
    	for(String winHandle : driver.getWindowHandles()){
        driver.switchTo().window(winHandle);Thread.sleep(2000);
    	}
	    driver.close();Thread.sleep(2000);
	    driver.switchTo().window(winHandleBefore);Thread.sleep(2000);
	    
    /* Footer Links */
    driver.findElement(By.linkText("Login Now!")).click();Thread.sleep(2000);
    driver.findElement(By.linkText("About Us")).click();Thread.sleep(2000);
    driver.findElement(By.linkText("Founders")).click();Thread.sleep(2000);
    driver.findElement(By.linkText("Terms & Conditions")).click();Thread.sleep(2000);
    driver.findElement(By.linkText("Privacy Policy")).click();Thread.sleep(2000);
    driver.findElement(By.linkText("Achievers")).click();Thread.sleep(2000);
    driver.findElement(By.linkText("Coaches & Mentors")).click();Thread.sleep(2000);
    driver.findElement(By.linkText("Power Bio")).click();Thread.sleep(2000);
    driver.findElement(By.linkText("Power Connect")).click();Thread.sleep(2000);
    driver.findElement(By.linkText("Power Ratings")).click();Thread.sleep(2000);
    driver.findElement(By.linkText("Power Share")).click();Thread.sleep(2000);
    driver.findElement(By.linkText("Social Power")).click();Thread.sleep(2000);
    driver.findElement(By.linkText("Contact Us")).click();Thread.sleep(2000);
    driver.findElement(By.id("btnInvestorsSubmit")).click();Thread.sleep(2000);
    driver.findElement(By.linkText("Feedback")).click();Thread.sleep(2000);
    driver.findElement(By.id("btnFeedbackSend")).click();Thread.sleep(2000);
    
    	String winHandleBefore1 = driver.getWindowHandle();Thread.sleep(2000);
	    driver.findElement(By.linkText("ACHNET LinkedIn")).click();
	    Thread.sleep(2000);
    	// Navigate to New window
    	for(String winHandle : driver.getWindowHandles()){
        driver.switchTo().window(winHandle);Thread.sleep(2000);
    	}
	    driver.close();Thread.sleep(2000);
	    driver.switchTo().window(winHandleBefore1);Thread.sleep(2000);
	 
	/* Apply for Ambassador Program */
    driver.findElement(By.linkText("Ambassador Program")).click();Thread.sleep(2000);
    driver.findElement(By.linkText("APPLY NOW")).click();Thread.sleep(2000);
    driver.findElement(By.cssSelector(".btn-lg")).click();Thread.sleep(2000);
    driver.findElement(By.linkText("Ambassador Program")).click();Thread.sleep(2000);
    driver.findElement(By.linkText("APPLY NOW")).click();Thread.sleep(2000);
    driver.findElement(By.name("Answers[Q1].Value")).click();Thread.sleep(2000);
    driver.findElement(By.name("Answers[Q1].Value")).sendKeys("Am an Entrepreneur, am interested in this.");Thread.sleep(2000);
    driver.findElement(By.cssSelector(".btn-lg")).click();Thread.sleep(2000);
    driver.findElement(By.name("Answers[Q4].Value")).click();Thread.sleep(2000);
    driver.findElement(By.name("Answers[Q4].Value")).sendKeys("I would like be part of ACHNET Ambassador.");Thread.sleep(2000);
    driver.findElement(By.cssSelector(".btn-lg")).click();Thread.sleep(2000);
    driver.findElement(By.name("Answers[Q5].Value")).click();Thread.sleep(2000);
    driver.findElement(By.name("Answers[Q5].Value")).sendKeys("https:www.facebook.com/ifthy03");Thread.sleep(2000);
    driver.findElement(By.cssSelector(".btn-lg")).click();Thread.sleep(2000);
    
    /* Business Tab - Call for Demo */
//	    driver.findElement(By.xpath("//li[2]/a/span[2]")).click();Thread.sleep(2000);  
//	    driver.findElement(By.linkText("Call For Demo")).click();Thread.sleep(2000);  
//	    driver.findElement(By.xpath("//button[normalize-space()=\'Submit\']")).click();Thread.sleep(2000);  
//	    driver.findElement(By.id("FirstName")).click();
//	    driver.findElement(By.id("FirstName")).sendKeys("Ahmed");Thread.sleep(2000);  
//	    driver.findElement(By.id("LastName")).click();
//	    driver.findElement(By.id("LastName")).sendKeys("Selenium");Thread.sleep(2000);  
//	    driver.findElement(By.xpath("//input[@id=\'Company\']")).click();
//	    driver.findElement(By.id("Company")).sendKeys("Achnet Software");Thread.sleep(2000);  
//	    driver.findElement(By.id("select2-AreaCode-container")).click();Thread.sleep(2000);  
//	    driver.findElement(By.cssSelector(".select2-search__field")).click();Thread.sleep(2000);  
//	    driver.findElement(By.cssSelector(".select2-search__field")).sendKeys("+91");
//	    driver.findElement(By.cssSelector(".select2-search__field")).sendKeys(Keys.ENTER);Thread.sleep(2000);  
//	    driver.findElement(By.xpath("//input[@id=\'Phone\']")).click();
//	    driver.findElement(By.id("Phone")).sendKeys("987565544");Thread.sleep(2000);  
//	    driver.findElement(By.id("pac-input")).click();
//	    driver.findElement(By.id("pac-input")).sendKeys("Chennai");Thread.sleep(2000);  
//	    driver.findElement(By.id("Email")).click();
//	    driver.findElement(By.id("Email")).sendKeys("ifthy@tescra.com");Thread.sleep(2000);  
//	    driver.findElement(By.id("Comments")).click();
//	    driver.findElement(By.id("Comments")).sendKeys("Hello");Thread.sleep(2000);  
//	    driver.findElement(By.xpath("//button[normalize-space()=\'Submit\']")).click();Thread.sleep(2000);  
//	    driver.findElement(By.linkText("Close")).click();
//	    Thread.sleep(2000);  
    
    /* Business Tab - Request for Registration */
    driver.findElement(By.xpath("//li[2]/a/span[2]")).click();Thread.sleep(2000);  
    driver.findElement(By.linkText("Request for Registration")).click();Thread.sleep(2000);  
    driver.findElement(By.cssSelector(".btn-lg")).click();Thread.sleep(2000);  
    driver.findElement(By.xpath("//li[2]/a/span[2]")).click();Thread.sleep(2000);  
    driver.findElement(By.xpath("//a[contains(text(),\'How you can Promote your Business\')]")).click();Thread.sleep(2000);     
    driver.findElement(By.linkText("Request for Registration")).click();Thread.sleep(2000);  
    driver.findElement(By.cssSelector(".btn-lg")).click();Thread.sleep(2000);  
    driver.findElement(By.xpath("//li[2]/a/span[2]")).click();Thread.sleep(2000);  
    driver.findElement(By.xpath("//a[contains(text(),\'Learn more about Talent Management\')]")).click();Thread.sleep(2000);  
    driver.findElement(By.linkText("Request for Registration")).click();Thread.sleep(2000);  
    driver.findElement(By.cssSelector(".btn-lg")).click();Thread.sleep(2000);  
    driver.findElement(By.xpath("//li[2]/a/span[2]")).click();Thread.sleep(2000);  
    driver.findElement(By.xpath("//a[contains(text(),\'Learn more about Talent Management\')]")).click();Thread.sleep(2000);  
    driver.findElement(By.cssSelector(".btn-lg")).click();Thread.sleep(2000);  
    driver.findElement(By.cssSelector(".btn-lg")).click();Thread.sleep(2000);  
    driver.findElement(By.xpath("//li[2]/a/span[2]")).click();Thread.sleep(2000);  
    driver.findElement(By.xpath("//a[contains(text(),\'Learn more about Team and Work Management\')]")).click();Thread.sleep(2000);  
    driver.findElement(By.linkText("Request for Registration")).click();Thread.sleep(2000);  
    driver.findElement(By.xpath("//li[2]/a/span[2]")).click();Thread.sleep(2000);  
    driver.findElement(By.xpath("//a[contains(text(),\'Learn more about Team and Work Management\')]")).click();Thread.sleep(2000);  
    driver.findElement(By.cssSelector(".btn-lg")).click();Thread.sleep(2000);  
    driver.findElement(By.cssSelector(".btn-lg")).click();Thread.sleep(2000);
    {
        WebElement element = driver.findElement(By.id("FirstName"));Thread.sleep(2000);
        Actions builder = new Actions(driver);Thread.sleep(2000);
        builder.doubleClick(element).perform();Thread.sleep(2000);
      }
      driver.findElement(By.id("FirstName")).sendKeys("Vladimir");Thread.sleep(2000);
      {
        WebElement element = driver.findElement(By.id("LastName"));Thread.sleep(2000);
        Actions builder = new Actions(driver);Thread.sleep(2000);
        builder.doubleClick(element).perform();Thread.sleep(2000);
      }
      driver.findElement(By.id("LastName")).sendKeys("Putin");Thread.sleep(2000);
      driver.findElement(By.id("txtBizSearch")).click();Thread.sleep(2000);
      driver.findElement(By.id("txtBizSearch")).sendKeys("Ukraine War 2022");Thread.sleep(2000);
      driver.findElement(By.id("Email")).click();Thread.sleep(2000);
      driver.findElement(By.id("Email")).sendKeys("putin@tescra.com");Thread.sleep(2000);
      driver.findElement(By.cssSelector(".form-group:nth-child(2) > label")).click();Thread.sleep(2000);
      driver.findElement(By.id("PhoneNumber")).sendKeys("8668677457");Thread.sleep(2000);
      driver.findElement(By.id("PrivacyChecked")).click();Thread.sleep(2000);
      driver.findElement(By.cssSelector(".btn-lg")).click();Thread.sleep(2000);
      driver.findElement(By.id("PrivacyChecked")).click();Thread.sleep(2000);
      driver.findElement(By.cssSelector("#divRegistrationDOB label")).click();Thread.sleep(2000);
      driver.findElement(By.id("txtRegDOB")).sendKeys("10/07/1952");Thread.sleep(2000);
      driver.findElement(By.cssSelector(".btn-lg")).click();Thread.sleep(2000); 
      wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//li[2]/a/span[2]")));	
  	  wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//li[2]/a/span[2]")));Thread.sleep(2000);    
      driver.findElement(By.xpath("//li[2]/a/span[2]")).click();Thread.sleep(2000);  
   
    /* Coach Tab */
  	wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".btn-lg")));	
  	wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".btn-lg")));Thread.sleep(2000);
    driver.findElement(By.cssSelector(".btn-lg")).click();
    Thread.sleep(2000);
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//li[2]/a/span[2]")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//li[2]/a/span[2]")));Thread.sleep(2000);
    driver.findElement(By.xpath("//li[2]/a/span[2]")).click();Thread.sleep(2000);
    driver.findElement(By.linkText("COACH")).click();Thread.sleep(2000);
    	String winHandleBefore2 = driver.getWindowHandle();Thread.sleep(2000);
	    driver.findElement(By.linkText("click here")).click();
	    Thread.sleep(2000);
    	// Navigate to New window
    	for(String winHandle : driver.getWindowHandles()){
        driver.switchTo().window(winHandle);Thread.sleep(2000);
    	}
	    driver.switchTo().frame(0);Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".fa-angle-right")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".fa-angle-left")).click();Thread.sleep(2000);
	    driver.switchTo().defaultContent();Thread.sleep(2000);
	    driver.findElement(By.linkText("COACH")).click();Thread.sleep(2000);
	    driver.findElement(By.linkText("Start Free Trial")).click();Thread.sleep(2000);
	    driver.findElement(By.linkText("COACH")).click();Thread.sleep(2000);
	    driver.close();Thread.sleep(2000);
	    driver.switchTo().window(winHandleBefore2);Thread.sleep(2000);
	    
	/* Articles from the Prelogin */
    driver.findElement(By.cssSelector(".row:nth-child(2) > .article-scroller .fa")).click();Thread.sleep(2000);
    driver.findElement(By.linkText("CAREER")).click();Thread.sleep(2000);
    driver.findElement(By.linkText("FINANCE & WEALTH")).click();Thread.sleep(2000);
    driver.findElement(By.linkText("BUSINESS & EXECUTIVE")).click();Thread.sleep(2000);
    driver.findElement(By.linkText("LIFE-COACHING")).click();Thread.sleep(2000);
    driver.findElement(By.linkText("EDUCATION & ADMISSIONS")).click();Thread.sleep(2000);
    driver.findElement(By.linkText("HEALTH & WELLNESS")).click();
    Thread.sleep(2000);
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//li[3]/a/span[2]")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//li[3]/a/span[2]")));Thread.sleep(2000);
    driver.findElement(By.xpath("//li[2]/a/span[2]")).click();Thread.sleep(2000);
    driver.findElement(By.cssSelector(".row:nth-child(3) > .article-scroller .achnet-post-view-more .fa")).click();Thread.sleep(2000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.linkText("Login")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.linkText("Login")));Thread.sleep(2000);
    driver.findElement(By.linkText("Login")).click();Thread.sleep(2000);
    driver.findElement(By.cssSelector(".btn-lg")).click();Thread.sleep(2000);
    driver.findElement(By.linkText("Register Now!")).click();Thread.sleep(2000);
    driver.findElement(By.name("flowSelect")).click();   
    Thread.sleep(2000); 	    
    driver.findElement(By.cssSelector("li:nth-child(2) input")).click();
    Thread.sleep(2000); 
	wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".btn-lg")));Thread.sleep(2000);
    driver.findElement(By.cssSelector(".btn-lg")).click();Thread.sleep(2000);
    
    /* Coach Registration - Links */
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//li[3]/a/span[2]")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//li[3]/a/span[2]")));Thread.sleep(2000);
    driver.findElement(By.xpath("//li[3]/a/span[2]")).click();Thread.sleep(2000);
    driver.findElement(By.linkText("Start Free Trial")).click();Thread.sleep(2000);
    {
      WebElement element = driver.findElement(By.id("FirstName"));Thread.sleep(2000);
      Actions builder = new Actions(driver);Thread.sleep(2000);
      builder.doubleClick(element).perform();Thread.sleep(2000);
    }
    driver.findElement(By.id("FirstName")).sendKeys("Donald");Thread.sleep(2000);
    {
      WebElement element = driver.findElement(By.id("LastName"));Thread.sleep(2000);
      Actions builder = new Actions(driver);Thread.sleep(2000);
      builder.doubleClick(element).perform();Thread.sleep(2000);
    }
    driver.findElement(By.id("LastName")).sendKeys("Trump");Thread.sleep(2000);
    driver.findElement(By.id("txtBizSearch")).click();Thread.sleep(2000);
    driver.findElement(By.id("txtBizSearch")).sendKeys("Presidential Election 2020");Thread.sleep(2000);
    driver.findElement(By.id("Email")).click();Thread.sleep(2000);
    driver.findElement(By.id("Email")).sendKeys("trump@tescra.com");Thread.sleep(2000);
    driver.findElement(By.cssSelector(".form-group:nth-child(2) > label")).click();Thread.sleep(2000);
    driver.findElement(By.id("PhoneNumber")).sendKeys("8668677457");Thread.sleep(2000);
    driver.findElement(By.id("PrivacyChecked")).click();Thread.sleep(2000);
    driver.findElement(By.cssSelector(".btn-lg")).click();Thread.sleep(2000);
    driver.findElement(By.id("PrivacyChecked")).click();Thread.sleep(2000);
    driver.findElement(By.cssSelector("#divRegistrationDOB label")).click();Thread.sleep(2000);
    driver.findElement(By.id("txtRegDOB")).sendKeys("01/20/1936");Thread.sleep(2000);	
	wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".btn-lg")));Thread.sleep(2000);
    driver.findElement(By.cssSelector(".btn-lg")).click();
    Thread.sleep(2000);
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//li[3]/a/span[2]")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//li[3]/a/span[2]")));Thread.sleep(2000);
    driver.findElement(By.xpath("//li[3]/a/span[2]")).click();
    Thread.sleep(2000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".btn-lg")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".btn-lg")));Thread.sleep(2000);
    driver.findElement(By.cssSelector(".btn-lg")).click();
    Thread.sleep(2000);
    
    /* Login Pages */
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//li[3]/a/span[2]")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//li[3]/a/span[2]")));Thread.sleep(2000);
    driver.findElement(By.xpath("//li[3]/a/span[2]")).click();
    Thread.sleep(2000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".row:nth-child(2) > .article-scroller .fa")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".row:nth-child(2) > .article-scroller .fa")));Thread.sleep(2000);
    driver.findElement(By.cssSelector(".row:nth-child(2) > .article-scroller .fa")).click();
    Thread.sleep(2000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.linkText("ALL")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.linkText("ALL")));Thread.sleep(2000);
    driver.findElement(By.linkText("ALL")).click();
    Thread.sleep(2000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.linkText("Login")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.linkText("Login")));Thread.sleep(2000);
    driver.findElement(By.linkText("Login")).click();
    Thread.sleep(2000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.linkText("Register Now!")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.linkText("Register Now!")));Thread.sleep(2000);
    driver.findElement(By.linkText("Register Now!")).click();Thread.sleep(2000);  	    
    driver.findElement(By.cssSelector("li:nth-child(2) input")).click();
    Thread.sleep(2000); 
    
    /* Articles */
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//li[3]/a/span[2]")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//li[3]/a/span[2]")));Thread.sleep(2000);
    driver.findElement(By.xpath("//li[3]/a/span[2]")).click();Thread.sleep(2000);
    driver.findElement(By.cssSelector(".row:nth-child(3) .achnet-post-view-more .fa")).click();Thread.sleep(2000);
    driver.findElement(By.linkText("CAREER")).click();Thread.sleep(2000);
    driver.findElement(By.linkText("FINANCE & WEALTH")).click();Thread.sleep(2000);
    driver.findElement(By.linkText("BUSINESS & EXECUTIVE")).click();Thread.sleep(2000);
    driver.findElement(By.linkText("LIFE-COACHING")).click();Thread.sleep(2000);
    driver.findElement(By.linkText("EDUCATION & ADMISSIONS")).click();Thread.sleep(2000);
    driver.findElement(By.linkText("ALL")).click();
    Thread.sleep(2000);  
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".btn-login > span")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".btn-login > span")));Thread.sleep(2000);
    driver.findElement(By.cssSelector(".btn-login > span")).click();
    Thread.sleep(2000);
    driver.findElement(By.xpath("//img[@alt=\'ACHNET: Achiever Network\']")).click();   
    Thread.sleep(2000);
  }
}


