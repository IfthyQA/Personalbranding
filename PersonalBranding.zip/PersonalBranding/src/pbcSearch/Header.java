package pbcSearch;

import java.io.IOException;
import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import screenshotOnFailure.FailScreenshot;

@Listeners(screenshotListners.EventList.class)
public class Header extends FailScreenshot{
	
	@Test
	public void Member_Header() throws InterruptedException, IOException {

		/* Login to the Application */		
	    driver.findElement(By.linkText("Login")).click();
	    driver.findElement(By.id("Username")).click();
	    driver.findElement(By.id("Username")).sendKeys("john.doe009");
	    driver.findElement(By.id("password-field")).click();
	    driver.findElement(By.id("password-field")).sendKeys("Rockon123");
	    driver.findElement(By.cssSelector(".btn-lg")).click();
	    Thread.sleep(2000);
		 WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(120));	   
	    
	    /* Upload Profile Picture -Invalid Profile Image */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//img[@id='profilePicture']")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//img[@id='profilePicture']")));
	    driver.findElement(By.xpath("//img[@id='profilePicture']")).click();
	    Thread.sleep(2000);
	    Runtime.getRuntime().exec("C:\\Users\\dev\\Documents\\AutoScripts\\Upload.exe"); 
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[@id='btnUploadPicture']")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[@id='btnUploadPicture']")));
	    driver.findElement(By.xpath("//button[@id='btnUploadPicture']")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[normalize-space()='OK']")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[normalize-space()='OK']")));
	    driver.findElement(By.xpath("//button[normalize-space()='OK']")).click();
	    Thread.sleep(2000);	  
	    
	    /* Upload Profile Picture - Cancel Modal */
	    Runtime.getRuntime().exec("C:\\Users\\dev\\Documents\\AutoScripts\\ProfilePic.exe"); 
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[@id='btnUploadPicture']")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[@id='btnUploadPicture']")));
		Thread.sleep(2000);
		driver.findElement(By.xpath("//button[@id='btnCancelUploadPicture']//span[@aria-hidden='true'][normalize-space()='×']")).click();
		
	    /* Upload Profile Picture - Upload & Apply */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//img[@id='profilePicture']")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//img[@id='profilePicture']")));
	    driver.findElement(By.xpath("//img[@id='profilePicture']")).click();
	    Thread.sleep(2000);
	    Runtime.getRuntime().exec("C:\\Users\\dev\\Documents\\AutoScripts\\ProfilePic.exe"); 
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[@id='btnUploadPicture']")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[@id='btnUploadPicture']")));
	    Actions crop = new Actions(driver);
	    By elementBy = By.xpath("//span[@class='cropper-point point-se']");	
	    Thread.sleep(2000);
	    crop.moveToElement(driver.findElement(elementBy),5,5); // Move the Cursor to the Ponter from where we drag
	    crop.clickAndHold().moveByOffset(360,460).release().build().perform(); // Drag till the full Image
	    Thread.sleep(2000);	  
	    driver.findElement(By.xpath("//button[@id='btnUploadPicture']")).click();
		wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".toast-message")));Thread.sleep(2000);
		driver.findElement(By.cssSelector(".toast-message")).click();
	    Thread.sleep(2000);
	    
	    /* Upload Profile Picture - Cancel Upload */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//img[@id='profilePicture']")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//img[@id='profilePicture']")));
	    driver.findElement(By.xpath("//img[@id='profilePicture']")).click();
	    Thread.sleep(2000);
	    Runtime.getRuntime().exec("C:\\Users\\dev\\Documents\\AutoScripts\\Cancel.exe"); 
	    Thread.sleep(2000);
	    
	    /* Notification Modal */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//i[@class='fa fa-bell-o menu-notification-header']")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//i[@class='fa fa-bell-o menu-notification-header']")));
		WebElement Icon = driver.findElement(By.xpath("//i[@class='fa fa-bell-o menu-notification-header']")); 
		JavascriptExecutor jse = (JavascriptExecutor)driver;
		jse.executeScript("arguments[0].click()", Icon);			    
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='modal-content']//div[@class='modal-header text-center']//i[@class='fa fa-times']")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@class='modal-content']//div[@class='modal-header text-center']//i[@class='fa fa-times']")));
	    driver.findElement(By.xpath("//div[@class='modal-content']//div[@class='modal-header text-center']//i[@class='fa fa-times']")).click();
	    Thread.sleep(2000);  	
	    
	    /* Message Notification */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[@id='divMesgNotification']")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[@id='divMesgNotification']")));
	    driver.findElement(By.xpath("//a[@id='divMesgNotification']")).click();	 
	    Thread.sleep(2000);
	    
	    /* Message Icon */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//i[@class='fa fa-envelope-o menu-message-header']")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//i[@class='fa fa-envelope-o menu-message-header']")));
	    driver.findElement(By.xpath("//i[@class='fa fa-envelope-o menu-message-header']")).click();	 
	    Thread.sleep(2000); 
	    	   
	    /* Search Functionality from Header and Menu */
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("#search > .fa")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector("#search > .fa")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector("#search > .fa")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("//input[@id='id']")).click();Thread.sleep(2000);
	    driver.findElement(By.xpath("//input[@id='id']")).sendKeys("Adam Musa");  
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".search-blue-btn")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".search-blue-btn")));Thread.sleep(2000);
	    WebElement ele = driver.findElement(By.cssSelector(".search-blue-btn"));
		jse.executeScript("arguments[0].click()", ele);
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".fa-ellipsis-v")));
		wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".fa-ellipsis-v")));Thread.sleep(2000);
		driver.findElement(By.cssSelector(".fa-ellipsis-v")).click();
		Thread.sleep(2000);
	    driver.findElement(By.xpath("//input[@id='txtSearchConnection']")).click();Thread.sleep(2000);
	    driver.findElement(By.xpath("//input[@id='txtSearchConnection']")).sendKeys("Adam Musa");
	    Thread.sleep(2000);	
	    driver.findElement(By.xpath("//span[@id='btnSearch']//i[@class='fa fa-search']")).click();
	    Thread.sleep(2000);	  
	    
	    /* Help Modal, Minimise, Maximise & Close */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//i[@title='Help']")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//i[@title='Help']")));
	    driver.findElement(By.xpath("//i[@title='Help']")).click();	
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//i[@class='fa fa-minus']")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//i[@class='fa fa-minus']")));
	    driver.findElement(By.xpath("//i[@class='fa fa-minus']")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//i[@class='fa fa-window-restore']")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//i[@class='fa fa-window-restore']")));
	    driver.findElement(By.xpath("//i[@class='fa fa-window-restore']")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[@class='helpModal-controls float-right']//i[@class='fa fa-close']")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[@class='helpModal-controls float-right']//i[@class='fa fa-close']")));
	    driver.findElement(By.xpath("//span[@class='helpModal-controls float-right']//i[@class='fa fa-close']")).click();
	    Thread.sleep(2000); 
	    
	    /* Help Modal & Close */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//i[@title='Help']")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//i[@title='Help']")));
	    driver.findElement(By.xpath("//i[@title='Help']")).click();	
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[@class='helpModal-controls float-right']//i[@class='fa fa-close']")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[@class='helpModal-controls float-right']//i[@class='fa fa-close']")));
	    driver.findElement(By.xpath("//span[@class='helpModal-controls float-right']//i[@class='fa fa-close']")).click();
	    Thread.sleep(2000);
	    
	    /* 3 vertical Menu - Prime for Free */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".fa-ellipsis-v")));
		wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".fa-ellipsis-v")));Thread.sleep(2000);
		driver.findElement(By.cssSelector(".fa-ellipsis-v")).click();
		Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[@id='btnTryPrime']")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[@id='btnTryPrime']")));
	    driver.findElement(By.xpath("//button[@id='btnTryPrime']")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='modal-content modal-prime']//i[@class='fa fa-times']")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@class='modal-content modal-prime']//i[@class='fa fa-times']")));
	    driver.findElement(By.xpath("//div[@class='modal-content modal-prime']//i[@class='fa fa-times']")).click();
	    Thread.sleep(2000);
	    
	    /* Artciles Menu - Prime for Free */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".fa-ellipsis-v")));
		wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".fa-ellipsis-v")));Thread.sleep(2000);
		driver.findElement(By.cssSelector(".fa-ellipsis-v")).click();
		Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[normalize-space()='ACHNET Articles']")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[normalize-space()='ACHNET Articles']")));Thread.sleep(2000);
		driver.findElement(By.xpath("//a[normalize-space()='ACHNET Articles']")).click();
		Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".fa-ellipsis-v")));
		wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".fa-ellipsis-v")));Thread.sleep(2000);
		driver.findElement(By.cssSelector(".fa-ellipsis-v")).click();
		Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[@id='btnTryPrime']")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[@id='btnTryPrime']")));
	    driver.findElement(By.xpath("//button[@id='btnTryPrime']")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='modal-content modal-prime']//i[@class='fa fa-times']")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@class='modal-content modal-prime']//i[@class='fa fa-times']")));
	    driver.findElement(By.xpath("//div[@class='modal-content modal-prime']//i[@class='fa fa-times']")).click();
	    Thread.sleep(2000);	
	    
	    /* Article Card from Hub - Prime for Free */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//img[@alt='ACHNET identity']")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//img[@alt='ACHNET identity']")));Thread.sleep(2000);
		driver.findElement(By.xpath("//img[@alt='ACHNET identity']")).click();
		Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[normalize-space()='View Articles']")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[normalize-space()='View Articles']")));Thread.sleep(2000);
		driver.findElement(By.xpath("//a[normalize-space()='View Articles']")).click();
		Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".fa-ellipsis-v")));
		wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".fa-ellipsis-v")));Thread.sleep(2000);
		driver.findElement(By.cssSelector(".fa-ellipsis-v")).click();
		Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[@id='btnTryPrime']")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[@id='btnTryPrime']")));
	    driver.findElement(By.xpath("//button[@id='btnTryPrime']")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='modal-content modal-prime']//i[@class='fa fa-times']")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@class='modal-content modal-prime']//i[@class='fa fa-times']")));
	    driver.findElement(By.xpath("//div[@class='modal-content modal-prime']//i[@class='fa fa-times']")).click();
	    Thread.sleep(2000);	
	    
	    /* Logout */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".fa-ellipsis-v")));
		wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".fa-ellipsis-v")));Thread.sleep(2000);	
		WebElement ele1 = driver.findElement(By.cssSelector(".fa-ellipsis-v"));
		jse.executeScript("arguments[0].click()", ele1);	
	    Thread.sleep(2000);
	    driver.findElement(By.linkText("Log off")).click();
	    Thread.sleep(2000);
	  }
	}



