package pbcSearch;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import screenshotOnFailure.FailScreenshot;

@Listeners(screenshotListners.EventList.class)
public class PostLogin extends FailScreenshot{
	
	@Test
	public void SearchPostlogin() throws InterruptedException {

		/* Login to the Application */		
	    driver.findElement(By.linkText("Login")).click();
	    driver.findElement(By.id("Username")).click();
	    driver.findElement(By.id("Username")).sendKeys("john.doe009");
	    driver.findElement(By.id("password-field")).click();
	    driver.findElement(By.id("password-field")).sendKeys("Rockon123");
	    driver.findElement(By.cssSelector(".btn-lg")).click();
	    Thread.sleep(2000);
		 WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(120));
	    
	    /* Search Functionality */
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("#search > .fa")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector("#search > .fa")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector("#search > .fa")).click();
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".search-blue-btn")));
	    driver.findElement(By.cssSelector(".search-blue-btn")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.id("id")).click();Thread.sleep(2000);
	    driver.findElement(By.id("id")).sendKeys("CHIGUMBURA");
	    Thread.sleep(2000);	   
		wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".search-blue-btn")));
	    driver.findElement(By.cssSelector(".search-blue-btn")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.id("id")).clear();
	    driver.findElement(By.id("id")).sendKeys("Sulaiman");
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".search-blue-btn")));
	    driver.findElement(By.cssSelector(".search-blue-btn")).click();Thread.sleep(2000);
	    
			    String winHandleBefore1 = driver.getWindowHandle();
			    driver.findElement(By.linkText("Adam Sulaiman")).click();
			    Thread.sleep(2000);
		    	// Navigate to New window
		    	for(String winHandle : driver.getWindowHandles()){
		        driver.switchTo().window(winHandle);
		    	}
			    driver.close();Thread.sleep(2000);
			    driver.switchTo().window(winHandleBefore1);
			    Thread.sleep(2000);	    
			    
	    /* Search Business */
	    driver.findElement(By.id("SearchType")).click();Thread.sleep(2000);
	    {
	      WebElement dropdown = driver.findElement(By.id("SearchType"));Thread.sleep(2000);
	      dropdown.findElement(By.xpath("//option[. = 'Business']")).click();Thread.sleep(2000);
	    }
	    driver.findElement(By.id("SearchType")).click();Thread.sleep(2000);
	    driver.findElement(By.xpath("//span[2]/button")).click();Thread.sleep(2000);
	    driver.findElement(By.id("id")).click();Thread.sleep(2000);
	    driver.findElement(By.id("id")).clear();
	    driver.findElement(By.id("id")).sendKeys("Business");Thread.sleep(2000);
	    driver.findElement(By.xpath("//span[2]/button")).click();Thread.sleep(2000);
	    driver.findElement(By.id("id")).clear();
	    Thread.sleep(2000);
	    driver.findElement(By.id("id")).click();Thread.sleep(2000);
	    driver.findElement(By.id("id")).sendKeys("Business Automation");Thread.sleep(2000);
	    driver.findElement(By.xpath("//span[2]/button")).click();Thread.sleep(2000);
	    
	    		String winHandleBefore2 = driver.getWindowHandle();
	    		Thread.sleep(2000);
			    driver.findElement(By.linkText("Business Automation")).click();
			    Thread.sleep(2000);
			    
		    	// Navigate to New window
		    	for(String winHandle : driver.getWindowHandles()){
		        driver.switchTo().window(winHandle);Thread.sleep(2000);
		    	}
		    	Thread.sleep(2000);
			    driver.findElement(By.cssSelector(".float-right > .btn-sm:nth-child(1) > span")).click();Thread.sleep(2000);
			    driver.findElement(By.cssSelector(".SPbtnshare")).click();
			    Thread.sleep(2000);
			    driver.close();Thread.sleep(2000);
			    driver.switchTo().window(winHandleBefore2);
			    Thread.sleep(2000);
			    
	    /* Search Coach */
	    driver.findElement(By.id("SearchType")).click();Thread.sleep(2000);
	    {
	      WebElement dropdown = driver.findElement(By.id("SearchType"));Thread.sleep(2000);
	      dropdown.findElement(By.xpath("//option[. = 'Coach']")).click();Thread.sleep(2000);
	    }
	    driver.findElement(By.id("SearchType")).click();Thread.sleep(2000);
	    driver.findElement(By.id("id")).clear();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".search-blue-btn")).click();Thread.sleep(2000);
	    driver.findElement(By.id("id")).clear();Thread.sleep(2000);
	    driver.findElement(By.id("id")).click();Thread.sleep(2000);
	    driver.findElement(By.id("id")).sendKeys("Sidra");Thread.sleep(2000);
	    driver.findElement(By.id("id")).sendKeys(Keys.ENTER);
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".search-blue-btn")));
	    driver.findElement(By.cssSelector(".search-blue-btn")).click();Thread.sleep(2000);
	    
	    		String winHandleBefore3 = driver.getWindowHandle();Thread.sleep(2000);
			    driver.findElement(By.linkText("Sidra Sennorita")).click();
			    Thread.sleep(2000);		    
		    	// Navigate to New window
		    	for(String winHandle : driver.getWindowHandles()){
		        driver.switchTo().window(winHandle);
		    	}
			    driver.close();Thread.sleep(2000);
			    driver.switchTo().window(winHandleBefore3);Thread.sleep(2000);
			    
	    /* Click Coach Pages from member search - public view */
	    driver.findElement(By.cssSelector(".col-md-9 > .btn-sm")).click();Thread.sleep(2000);
	    
	    	String winHandleBefore4 = driver.getWindowHandle();Thread.sleep(2000);
		    driver.findElement(By.linkText("Evening Coffee Coach")).click();
		    Thread.sleep(2000);
		    // Navigate to New window
	    	for(String winHandle : driver.getWindowHandles()){
	        driver.switchTo().window(winHandle);
	    	}
		    driver.close();
		    Thread.sleep(2000);		    	    	
		    driver.switchTo().window(winHandleBefore4);
		    Thread.sleep(2000);
	    
		    	String winHandleBefore5 = driver.getWindowHandle();Thread.sleep(2000);
			    driver.findElement(By.linkText("Student Career Coach")).click();
			    Thread.sleep(2000);
		    	// Navigate to New window
		    	for(String winHandle : driver.getWindowHandles()){
		        driver.switchTo().window(winHandle);Thread.sleep(2000);
		    	}
			    driver.close();Thread.sleep(2000);
			    driver.switchTo().window(winHandleBefore5);
			    Thread.sleep(2000);
			    
			String winHandleBefore6 = driver.getWindowHandle();	Thread.sleep(2000);
		    driver.findElement(By.linkText("Recheck the Life")).click();
		    Thread.sleep(2000);
	    	for(String winHandle : driver.getWindowHandles()){
	        driver.switchTo().window(winHandle);Thread.sleep(2000);
	    	}
		    driver.close();Thread.sleep(2000);
		    driver.switchTo().window(winHandleBefore6);
		    Thread.sleep(2000);
	    
	    driver.findElement(By.cssSelector(".fa-times-circle-o")).click();Thread.sleep(2000);
	    driver.findElement(By.id("id")).click();Thread.sleep(2000);
	    driver.findElement(By.id("id")).clear();
	    Thread.sleep(2000);
	    driver.findElement(By.id("id")).sendKeys("Adam");
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".search-blue-btn")));
	    driver.findElement(By.cssSelector(".search-blue-btn")).click();Thread.sleep(2000);
	    
	    	String winHandleBefore7 = driver.getWindowHandle();Thread.sleep(2000);
		    driver.findElement(By.linkText("Business Profile")).click();
		    Thread.sleep(2000);
	    	// Navigate to New window
	    	for(String winHandle : driver.getWindowHandles()){
	        driver.switchTo().window(winHandle);Thread.sleep(2000);
	    	}
		    driver.findElement(By.cssSelector(".float-right > .btn-sm:nth-child(1)")).click();Thread.sleep(2000);
		    driver.findElement(By.xpath("//div[@id=\'modalShare\']/div/div/div[2]/div[2]/div/button/span")).click();Thread.sleep(2000);
		    driver.close();Thread.sleep(2000);
		    driver.switchTo().window(winHandleBefore7);Thread.sleep(2000);
	    
	    driver.findElement(By.cssSelector(".col-12:nth-child(1) .col-6:nth-child(2) > .btn-sm")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector("div:nth-child(3) > label > input")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".modal-lg .fa")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".col-12:nth-child(1) .col-6:nth-child(2) > .btn-sm")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".non-private")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".coach-terms .fa")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".modal-lg .fa")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".col-12:nth-child(1) .col-6:nth-child(2) > .btn-sm > span")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector("div:nth-child(3) > label > input")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".private")).click();Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[@id=\'PrivateCoachingTermsOverlay\']/div/div/div[2]/form/div/div/div[2]/div/input")).click();Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[@id=\'PrivateCoachingTermsOverlay\']/div/div/div[2]/form/div/div/div[4]/button")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".next-btn")).click();Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".back-btn")).click();Thread.sleep(2000);
	    driver.findElement(By.id("btnYesConfirmYesNo")).click();
	    Thread.sleep(2000);
	    
	    /* Logout */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".fa-ellipsis-v")));
		wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".fa-ellipsis-v")));Thread.sleep(2000);	
		WebElement ele = driver.findElement(By.cssSelector(".fa-ellipsis-v"));
		JavascriptExecutor jse = (JavascriptExecutor)driver;
		jse.executeScript("arguments[0].click()", ele);	
	    Thread.sleep(2000);
	    driver.findElement(By.linkText("Log off")).click();
	    Thread.sleep(2000);
	  }
	}



