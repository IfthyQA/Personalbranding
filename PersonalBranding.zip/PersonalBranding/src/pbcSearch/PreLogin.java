package pbcSearch;

import java.io.IOException;
import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import screenshotOnFailure.FailScreenshot;

@Listeners(screenshotListners.EventList.class)
public class PreLogin extends FailScreenshot{
	
	@Test
	public void SearchPrelogin() throws InterruptedException, IOException {
	
	/* Navgate to the PBC */
	WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(120));
    
    /* Search Member */
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".fa-search")));
	wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".fa-search")));
    driver.findElement(By.cssSelector(".fa-search")).click();
    Thread.sleep(2000);
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("id")));
	wait.until(ExpectedConditions.elementToBeClickable(By.id("id")));
    driver.findElement(By.id("id")).click();Thread.sleep(2000);
    driver.findElement(By.id("id")).sendKeys("neeraj");
    Thread.sleep(2000);
	wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".search-blue-btn")));
    driver.findElement(By.cssSelector(".search-blue-btn")).click();Thread.sleep(2000);
    
    /* Search Business */
    driver.findElement(By.id("SearchType")).click();Thread.sleep(2000);
    {
      WebElement dropdown = driver.findElement(By.id("SearchType"));Thread.sleep(2000);
      dropdown.findElement(By.xpath("//option[. = 'Business']")).click();Thread.sleep(2000);
    }
    driver.findElement(By.id("SearchType")).click();
    Thread.sleep(2000);
    driver.findElement(By.id("id")).clear();
    Thread.sleep(2000);
	wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".search-blue-btn")));
    driver.findElement(By.cssSelector(".search-blue-btn")).click();
    Thread.sleep(2000);
    driver.findElement(By.id("id")).click();Thread.sleep(2000);
    driver.findElement(By.id("id")).sendKeys("Automation");
    Thread.sleep(2000);   
	wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".search-blue-btn")));
    driver.findElement(By.cssSelector(".search-blue-btn")).click();
    Thread.sleep(2000);
    
    	String winHandleBefore3 = driver.getWindowHandle();
	    driver.findElement(By.linkText("Stripe Test Automation")).click();
	    Thread.sleep(2000);   	// Navigate to New window
    	for(String winHandle : driver.getWindowHandles()){
        driver.switchTo().window(winHandle);Thread.sleep(2000);
    	}
	    driver.close();
	    Thread.sleep(2000);
	    driver.switchTo().window(winHandleBefore3);
	 
	    /* Scroll Up the page */
	    JavascriptExecutor jse = (JavascriptExecutor)driver;
	    jse.executeScript("scroll(0, -250);");	    	    
	    Thread.sleep(2000);
	    
	/* Search Coach */    
    driver.findElement(By.id("SearchType")).click();Thread.sleep(2000);
    {
      WebElement dropdown = driver.findElement(By.id("SearchType"));Thread.sleep(2000);
      dropdown.findElement(By.xpath("//option[. = 'Coach']")).click();Thread.sleep(2000);
    }
    driver.findElement(By.id("SearchType")).click();Thread.sleep(2000);
    driver.findElement(By.id("id")).clear();Thread.sleep(2000);
	wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".search-blue-btn")));
    driver.findElement(By.cssSelector(".search-blue-btn")).click();Thread.sleep(2000);
    driver.findElement(By.id("id")).click();Thread.sleep(2000);
    driver.findElement(By.id("id")).sendKeys("John Tescra");
    Thread.sleep(2000);
	wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".search-blue-btn")));
    driver.findElement(By.cssSelector(".search-blue-btn")).click();Thread.sleep(2000);
    
    	String winHandleBefore4 = driver.getWindowHandle();
	    driver.findElement(By.linkText("John Tescra")).click();Thread.sleep(2000);
	    Thread.sleep(2000);    	// Navigate to New window
    	for(String winHandle : driver.getWindowHandles()){
        driver.switchTo().window(winHandle);Thread.sleep(2000);
    	}
	    driver.close();
	    driver.switchTo().window(winHandleBefore4);Thread.sleep(2000);
    
    driver.findElement(By.id("SearchType")).click();Thread.sleep(2000);
    {
      WebElement dropdown = driver.findElement(By.id("SearchType"));Thread.sleep(2000);
      dropdown.findElement(By.xpath("//option[. = 'Member']")).click();Thread.sleep(2000);
    }
    driver.findElement(By.id("SearchType")).click();
    Thread.sleep(2000);
	wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".search-blue-btn")));
    driver.findElement(By.cssSelector(".search-blue-btn")).click();Thread.sleep(2000);
    driver.findElement(By.xpath("//img")).click();Thread.sleep(2000);
    driver.findElement(By.cssSelector(".fa-search")).click();Thread.sleep(2000);
    driver.findElement(By.cssSelector(".btn-login > span")).click();
    Thread.sleep(2000);
    driver.findElement(By.xpath("//img[@alt=\'ACHNET: Achiever Network\']")).click();   
    Thread.sleep(2000);
  }
}


