package powerRatings;

import java.io.IOException;
import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import screenshotOnFailure.FailScreenshot;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

@Listeners(screenshotListners.EventList.class)
public class T2_View_Testimonials extends FailScreenshot {

	@Test
	public void Testimonials_View() throws InterruptedException, IOException {
			
		/* Login to the Application */ 			
	  	driver.findElement(By.xpath("(//button[normalize-space()='Login'])[1]")).click();
		driver.findElement(By.xpath("//input[@id='Username']")).click();
		driver.findElement(By.xpath("//input[@id='Username']")).sendKeys("john.doe001");
		driver.findElement(By.xpath("//input[@id='password-field']")).click();
		driver.findElement(By.xpath("//input[@id='password-field']")).sendKeys("Rockon123");
		driver.findElement(By.xpath("//button[@id='loginButton']")).click();
		Thread.sleep(2000);
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(120));
		
		/* Navigate to Power Ratings - Invite */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'My Profile')]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'My Profile')]")));Thread.sleep(2000);
	    {
		     WebElement element = driver.findElement(By.xpath("//div[@class='menu-item menu-item-active']"));
		     Actions builder = new Actions(driver);
		     builder.moveToElement(element).perform();
		}
		Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'Power Ratings')]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'Power Ratings')]")));Thread.sleep(2000);
		driver.findElement(By.xpath("//div[contains(text(),'Power Ratings')]")).click();
		Thread.sleep(2000);
		
		/* View Testimonials */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[normalize-space()='See Logs']")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[normalize-space()='See Logs']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//button[normalize-space()='See Logs']")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[normalize-space()='Invites Sent']")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[normalize-space()='Invites Sent']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[normalize-space()='Invites Sent']")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//tbody/tr[2]/td[6]/button[1]")));	// View Adam Musa Testimonial
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//tbody/tr[2]/td[6]/button[1]")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//tbody/tr[2]/td[6]/button[1]")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[normalize-space()='Back']")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[normalize-space()='Back']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//button[normalize-space()='Back']")).click();
	    Thread.sleep(2000);
	    /* Scroll out from menu */
	    {
		     WebElement element = driver.findElement(By.xpath("//div[@id='logo']//a//*[name()='svg']"));
		     Actions builder = new Actions(driver);
		     builder.moveToElement(element).perform();
		}
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//tbody/tr[1]/td[6]/button[1]")));	// View Adam Isa Testimonial
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//tbody/tr[1]/td[6]/button[1]")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//tbody/tr[1]/td[6]/button[1]")).click();
	    Thread.sleep(2000); 
	    
	    /* Click Name and Opens in New Window */ 
    	String winHandleBefore = driver.getWindowHandle();
    	driver.findElement(By.xpath("(//a[normalize-space()='Adam Isa'])[2]")).click();
    	Thread.sleep(2000);	    	// Navigate to New window
    	for(String winHandle : driver.getWindowHandles()){
        driver.switchTo().window(winHandle);
    	}
    	Thread.sleep(2000);
    	driver.close();	
    	Thread.sleep(2000);    	
    	driver.switchTo().window(winHandleBefore);
    	Thread.sleep(2000);
    	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[@aria-hidden='true']")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[@aria-hidden='true']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//span[@aria-hidden='true']")).click();
	    Thread.sleep(2000);
	    
	    /* View Testimonials on Video Testimonial Tab */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[normalize-space()='Testimonials']")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[normalize-space()='Testimonials']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//a[normalize-space()='Testimonials']")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("//p[normalize-space()='User']//*[name()='svg']")).click();
	    Thread.sleep(2000); 
	    driver.findElement(By.xpath("//p[normalize-space()='User']//*[name()='svg']")).click();
	    Thread.sleep(2000); 
	    driver.findElement(By.xpath("//p[normalize-space()='Type']//*[name()='svg']")).click();
	    Thread.sleep(2000); 
	    driver.findElement(By.xpath("//p[normalize-space()='Type']//*[name()='svg']")).click();
	    Thread.sleep(2000);     
 	    
	    WebElement link = driver.findElement(By.xpath("//a[normalize-space()='Adam Musa']"));
	    ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", link);
	    Thread.sleep(2000);
	    
	    /* Click Name and Opens in New Window */ 
    	String winHandleBefore1 = driver.getWindowHandle();
    	driver.findElement(By.xpath("//a[normalize-space()='Adam Isa']")).click();
    	Thread.sleep(2000);	    	// Navigate to New window
    	for(String winHandle : driver.getWindowHandles()){
        driver.switchTo().window(winHandle);
    	}
    	Thread.sleep(2000);
    	driver.close();	
    	Thread.sleep(2000);    	
    	driver.switchTo().window(winHandleBefore1);
    	Thread.sleep(2000);
    	
    	/* Scroll Up the page */
    	JavascriptExecutor jse = (JavascriptExecutor)driver;
	    jse.executeScript("scroll(0, -250);");	    	    
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[normalize-space()='Video Testimonials']")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[normalize-space()='Video Testimonials']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[normalize-space()='Video Testimonials']")).click();
	    Thread.sleep(2000);	
	    
	    /* Play the Video Testimonial */
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[3]/div[1]/div[3]/div[2]/div[2]/div[1]/div[1]/video[1]")));
		{
		     WebElement element = driver.findElement(By.xpath("//div[3]/div[1]/div[3]/div[2]/div[2]/div[1]/div[1]/video[1]"));
		     Actions builder = new Actions(driver);
		     builder.moveToElement(element).perform();		
		}	
		WebElement ele = driver.findElement(By.xpath("//div[3]/div[1]/div[3]/div[2]/div[2]/div[1]/div[1]/button[1]"));
		jse.executeScript("arguments[0].scrollIntoView(true);",ele);
		jse.executeScript("arguments[0].click()", ele);	
		Thread.sleep(1500);
	    driver.findElement(By.xpath("//button[@title='Pause']")).click(); // Pause Button
	    Thread.sleep(2000);
	    
	    /* Scroll Up the page */
	    jse.executeScript("scroll(0, -250);");	    	    
	    Thread.sleep(2000);   
	    
	    /* Click Name and Opens in New Window */ 
    	String winHandleBefore2 = driver.getWindowHandle();
    	driver.findElement(By.linkText("Sidra Sennorita")).click();
    	Thread.sleep(2000);	    	// Navigate to New window
    	for(String winHandle : driver.getWindowHandles()){
        driver.switchTo().window(winHandle);
    	}
    	Thread.sleep(2000);
    	driver.close();	
    	Thread.sleep(2000);    	
    	driver.switchTo().window(winHandleBefore2);
    	Thread.sleep(2000);
	    driver.findElement(By.xpath("//p[normalize-space()='User']//*[name()='svg']")).click();
	    Thread.sleep(2000); 
	    driver.findElement(By.xpath("//p[normalize-space()='User']//*[name()='svg']")).click();
	    Thread.sleep(2000); 
	    driver.findElement(By.xpath("//p[normalize-space()='Type']//*[name()='svg']")).click();
	    Thread.sleep(2000); 
	    driver.findElement(By.xpath("//p[normalize-space()='Type']//*[name()='svg']")).click();
	    Thread.sleep(2000);
	    
	    /* Scroll Up the page */
	    jse.executeScript("scroll(0, -250);");	    	    
	    Thread.sleep(2000);
	    
	    /* View Testimonials on Skills / Ratings  Tab */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[normalize-space()='Skills / Rating']")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[normalize-space()='Skills / Rating']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[normalize-space()='Skills / Rating']")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("//p[normalize-space()='User']//*[name()='svg']")).click();
	    Thread.sleep(2000);
	    
	    WebElement link2 = driver.findElement(By.linkText("Ifthy Testers"));
	    ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", link2);
	    Thread.sleep(2000); 
	    
	    /* Click Name and Opens in New Window */ 
    	String winHandleBefore3 = driver.getWindowHandle();
    	driver.findElement(By.linkText("Shane Watson")).click();
    	Thread.sleep(2000);	    	// Navigate to New window
    	for(String winHandle : driver.getWindowHandles()){
        driver.switchTo().window(winHandle);
    	}
    	Thread.sleep(2000);
    	driver.close();	
    	Thread.sleep(2000);    	
    	driver.switchTo().window(winHandleBefore3);
    	Thread.sleep(2000);
    	
    	/* Scroll Up the page */
	    jse.executeScript("scroll(0, -250);");	    	    
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("//p[normalize-space()='User']//*[name()='svg']")).click();
	    Thread.sleep(2000); 
	    driver.findElement(By.xpath("//p[normalize-space()='Type']//*[name()='svg']")).click();
	    Thread.sleep(2000); 
	    driver.findElement(By.xpath("//p[normalize-space()='Type']//*[name()='svg']")).click();
	    Thread.sleep(2000);
	    
	    /* Logout */
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'My Profile')]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'My Profile')]")));Thread.sleep(2000);
		driver.findElement(By.xpath("//div[contains(text(),'My Profile')]")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//div[contains(text(),'Logout')]")).click();
		Thread.sleep(2000);
	  }
	}

