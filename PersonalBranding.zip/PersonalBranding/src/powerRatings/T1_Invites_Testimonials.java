package powerRatings;

import java.io.IOException;
import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import screenshotOnFailure.FailScreenshot;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

@Listeners(screenshotListners.EventList.class)
public class T1_Invites_Testimonials extends FailScreenshot {

	@Test
	public void Testimonials_InviteUsers() throws InterruptedException, IOException {
			
		/* Login to the Application */ 			
	  	driver.findElement(By.xpath("(//button[normalize-space()='Login'])[1]")).click();
		driver.findElement(By.xpath("//input[@id='Username']")).click();
		driver.findElement(By.xpath("//input[@id='Username']")).sendKeys("john.doe001");
		driver.findElement(By.xpath("//input[@id='password-field']")).click();
		driver.findElement(By.xpath("//input[@id='password-field']")).sendKeys("Rockon123");
		driver.findElement(By.id("loginButton")).click();
		Thread.sleep(2000);
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(120));	    
	    
		/* Navigate to Power Ratings - Invite */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'My Profile')]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'My Profile')]")));Thread.sleep(2000);
	    {
		     WebElement element = driver.findElement(By.xpath("//div[@class='menu-item menu-item-active']"));
		     Actions builder = new Actions(driver);
		     builder.moveToElement(element).perform();
		}
		Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'Power Ratings')]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'Power Ratings')]")));Thread.sleep(2000);
		driver.findElement(By.xpath("//div[contains(text(),'Power Ratings')]")).click();
		Thread.sleep(2000);
		
		/* See Logs Tabs */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[normalize-space()='See Logs']")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[normalize-space()='See Logs']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//button[normalize-space()='See Logs']")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[normalize-space()='Invites Sent']")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[normalize-space()='Invites Sent']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[normalize-space()='Invites Sent']")).click();
	    Thread.sleep(2000);	
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[normalize-space()='Request Received']")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[normalize-space()='Request Received']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[normalize-space()='Request Received']")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[normalize-space()='All']")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[normalize-space()='All']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[normalize-space()='All']")).click();
	    Thread.sleep(2000);
	    
	    /* Testimonials Tabs */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[normalize-space()='Testimonials']")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[normalize-space()='Testimonials']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//a[normalize-space()='Testimonials']")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[normalize-space()='Video Testimonials']")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[normalize-space()='Video Testimonials']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[normalize-space()='Video Testimonials']")).click();
	    Thread.sleep(2000);	
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[normalize-space()='Skills / Rating']")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[normalize-space()='Skills / Rating']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[normalize-space()='Skills / Rating']")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[normalize-space()='All']")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[normalize-space()='All']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[normalize-space()='All']")).click();
	    Thread.sleep(2000);	  	
	    
	    /* CANCEL - Invites - Testimonial */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[normalize-space()='Invite Skills Testimonial']")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[normalize-space()='Invite Skills Testimonial']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//button[normalize-space()='Invite Skills Testimonial']")).click();	  
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[@class='close-img']")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("//button[@class='modal-btn btn-black-outlined btn-common']")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[normalize-space()='Invite Skills Testimonial']")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[normalize-space()='Invite Skills Testimonial']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//button[normalize-space()='Invite Skills Testimonial']")).click();	  
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[normalize-space()='Cancel']")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[normalize-space()='Cancel']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//button[normalize-space()='Cancel']")).click();
	    Thread.sleep(2000);	
	    driver.findElement(By.xpath("//button[normalize-space()='Go Back']")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("//input[@id='email']")).click();
	    driver.findElement(By.xpath("//input[@id='email']")).sendKeys("Akilesh");
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'Akilesh Sharma')]")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'Akilesh Sharma')]")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[contains(text(),'Akilesh Sharma')]")).click(); // select from the dropdown
	    Thread.sleep(2000);	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[normalize-space()='Cancel']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//button[normalize-space()='Cancel']")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("//button[@class='modal-btn btn-black-outlined btn-common']")).click();
	    Thread.sleep(2000);	    
	   	    
	    /* Invites - Testimonial Request */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[normalize-space()='Invite Skills Testimonial']")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[normalize-space()='Invite Skills Testimonial']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//button[normalize-space()='Invite Skills Testimonial']")).click();
	    Thread.sleep(2000);	 
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@id='email']")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@id='email']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//input[@id='email']")).click();
	    driver.findElement(By.xpath("//input[@id='email']")).sendKeys("Akilesh");
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'Akilesh Sharma')]")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'Akilesh Sharma')]")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[contains(text(),'Akilesh Sharma')]")).click(); // select from the dropdown
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[2]/div[1]/div[1]/div[1]/span[1]/button[1]")).click(); // Remove the tag
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("//input[@id='email']")).click();
	    driver.findElement(By.xpath("//input[@id='email']")).sendKeys("Akilesh");
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'Akilesh Sharma')]")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'Akilesh Sharma')]")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[contains(text(),'Akilesh Sharma')]")).click(); // select from the dropdown
	    Thread.sleep(2000);
	    driver.findElement(By.id("email")).click();
	    driver.findElement(By.id("email")).sendKeys("Ifthytest@gmail.com");
	    driver.findElement(By.id("email")).sendKeys(Keys.ENTER);
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("//span[2]//button[1]")).click(); // Remove Email
	    Thread.sleep(2000);
	    driver.findElement(By.id("email")).click();
	    driver.findElement(By.id("email")).sendKeys("Ifthytest@gmail.com");
	    driver.findElement(By.id("email")).sendKeys(Keys.ENTER);
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[normalize-space()='Invite']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//button[normalize-space()='Invite']")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("//button[normalize-space()='OK']")).click();
	    Thread.sleep(2000);
	    
	    /* Delete Invites - Testimonial */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[normalize-space()='See Logs']")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[normalize-space()='See Logs']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//button[normalize-space()='See Logs']")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[normalize-space()='Invites Sent']")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[normalize-space()='Invites Sent']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[normalize-space()='Invites Sent']")).click();
	    Thread.sleep(2000);	
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[normalize-space()='Delete']")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[normalize-space()='Delete']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//button[normalize-space()='Delete']")).click();
	    Thread.sleep(2000);	
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[@class='modal-btn btn-black-outlined btn-common']")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[@class='modal-btn btn-black-outlined btn-common']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//button[@class='modal-btn btn-black-outlined btn-common']")).click();
	    Thread.sleep(2000);	
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[normalize-space()='Delete']")));	// Delete Contact 
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[normalize-space()='Delete']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//button[normalize-space()='Delete']")).click();
	    Thread.sleep(2000);	
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[@class='modal-btn btn-delete-fill']")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[@class='modal-btn btn-delete-fill']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//button[@class='modal-btn btn-delete-fill']")).click();
	    Thread.sleep(2000);		
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[normalize-space()='Delete']")));	// Delete Email 
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[normalize-space()='Delete']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//button[normalize-space()='Delete']")).click();
	    Thread.sleep(2000);	
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[@class='modal-btn btn-delete-fill']")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[@class='modal-btn btn-delete-fill']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//button[@class='modal-btn btn-delete-fill']")).click();
	    Thread.sleep(2000);	
	    
	    /* Logout */
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'My Profile')]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'My Profile')]")));Thread.sleep(2000);
		driver.findElement(By.xpath("//div[contains(text(),'My Profile')]")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//div[contains(text(),'Logout')]")).click();
		Thread.sleep(2000);
	  }
	}

