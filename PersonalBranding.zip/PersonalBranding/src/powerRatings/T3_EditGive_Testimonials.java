package powerRatings;

import java.io.IOException;
import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import screenshotOnFailure.FailScreenshot;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

@Listeners(screenshotListners.EventList.class)
public class T3_EditGive_Testimonials extends FailScreenshot {

	@Test
	public void Testimonials_Edit_Give() throws InterruptedException, IOException {
			
		/* Login to the Application */ 			
	  	driver.findElement(By.xpath("(//button[normalize-space()='Login'])[1]")).click();
		driver.findElement(By.xpath("//input[@id='Username']")).click();
		driver.findElement(By.xpath("//input[@id='Username']")).sendKeys("john.doe001");
		driver.findElement(By.xpath("//input[@id='password-field']")).click();
		driver.findElement(By.xpath("//input[@id='password-field']")).sendKeys("Rockon123");
		driver.findElement(By.xpath("//button[@id='loginButton']")).click();
		Thread.sleep(2000);
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(120));	
		 
	    /* Navigate to Power Connect - Inite Friends */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'My Profile')]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'My Profile')]")));Thread.sleep(2000);
	    {
		     WebElement element = driver.findElement(By.xpath("//div[@class='menu-item menu-item-active']"));
		     Actions builder = new Actions(driver);
		     builder.moveToElement(element).perform();
		}
		Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'Power Ratings')]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'Power Ratings')]")));Thread.sleep(2000);
		driver.findElement(By.xpath("//div[contains(text(),'Power Ratings')]")).click();
		Thread.sleep(2000);
		
		/* Give Testimonial and Cancel - Request Recieved Tab */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[normalize-space()='See Logs']")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[normalize-space()='See Logs']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//button[normalize-space()='See Logs']")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[normalize-space()='Request Received']")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[normalize-space()='Request Received']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[normalize-space()='Request Received']")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//button[normalize-space()='Give Testimonial'])[1]")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//button[normalize-space()='Give Testimonial'])[1]")));Thread.sleep(2000);
	    driver.findElement(By.xpath("(//button[normalize-space()='Give Testimonial'])[1]")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//form[1]/div[1]/div[1]/div[1]/div[1]")));	// Close Icon
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//form[1]/div[1]/div[1]/div[1]/div[1]")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//form[1]/div[1]/div[1]/div[1]/div[1]")).click();
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[normalize-space()='Yes, Cancel']")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[normalize-space()='Yes, Cancel']")));
	    driver.findElement(By.xpath("//button[normalize-space()='Yes, Cancel']")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//button[normalize-space()='Give Testimonial'])[1]")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//button[normalize-space()='Give Testimonial'])[1]")));Thread.sleep(2000);
	    driver.findElement(By.xpath("(//button[normalize-space()='Give Testimonial'])[1]")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[normalize-space()='Cancel']")));	// Cancel Button
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[normalize-space()='Cancel']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//button[normalize-space()='Cancel']")).click();
	    Thread.sleep(2000);	
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[normalize-space()='Yes, Cancel']")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[normalize-space()='Yes, Cancel']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//button[normalize-space()='Yes, Cancel']")).click();
	    Thread.sleep(2000);
	    
	    /* Give Testimonial and Cancel - Request Recieved Tab - Cancel at last modal */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//button[normalize-space()='Give Testimonial'])[1]")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//button[normalize-space()='Give Testimonial'])[1]")));Thread.sleep(2000);
	    driver.findElement(By.xpath("(//button[normalize-space()='Give Testimonial'])[1]")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("//form[1]/div[1]/div[2]/div[1]/div[1]/div[1]/div[1]/div[1]")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[2]/div/div/div/div[2]/div/div/div")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("//form[1]/div[1]/div[2]/div[2]/div[1]/div[1]/div[1]/div[1]")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[2]/div/div/div[2]/div/div/div[2]")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("//button[@type=\'submit\']")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[@type='submit']")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[@type='submit']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//button[@type='submit']")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[@type='submit']")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[@type='submit']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//button[@type='submit']")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//textarea[@name='description']")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//textarea[@name='description']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//textarea[@name='description']")).click();
	    driver.findElement(By.xpath("//textarea[@name='description']")).sendKeys("Hi Hello");
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[normalize-space()='Cancel']")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[normalize-space()='Cancel']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//button[normalize-space()='Cancel']")).click();
	    Thread.sleep(2000);	
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[normalize-space()='Yes, Cancel']")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[normalize-space()='Yes, Cancel']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//button[normalize-space()='Yes, Cancel']")).click();
	    Thread.sleep(2000);
	    
	    /* Give Testimonial and Cancel - All - Cancel at last modal */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[normalize-space()='All']")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[normalize-space()='All']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[normalize-space()='All']")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//button[normalize-space()='Give Testimonial'])[1]")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//button[normalize-space()='Give Testimonial'])[1]")));Thread.sleep(2000);
	    driver.findElement(By.xpath("(//button[normalize-space()='Give Testimonial'])[1]")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("//form[1]/div[1]/div[2]/div[1]/div[1]/div[1]/div[1]/div[1]/div[2]")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[2]/div/div/div/div[2]/div/div/div")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("//form[1]/div[1]/div[2]/div[2]/div[1]/div[1]/div[1]/div[1]/div[2]")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[2]/div/div/div[2]/div/div/div[2]")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[@type='submit']")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[@type='submit']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//button[@type='submit']")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[@type='submit']")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[@type='submit']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//button[@type='submit']")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[@type='submit']")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[@type='submit']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//button[@type='submit']")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//textarea[@name='description']")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//textarea[@name='description']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//textarea[@name='description']")).click();
	    driver.findElement(By.xpath("//textarea[@name='description']")).sendKeys("Hi Hello");
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[normalize-space()='Cancel']")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[normalize-space()='Cancel']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//button[normalize-space()='Cancel']")).click();
	    Thread.sleep(2000);	
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[normalize-space()='Yes, Cancel']")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[normalize-space()='Yes, Cancel']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//button[normalize-space()='Yes, Cancel']")).click();
	    Thread.sleep(2000);
	    
	    /* Edit Testimonial and Cancel from All Tabs */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//button[normalize-space()='Edit Testimonial'])[1]")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//button[normalize-space()='Edit Testimonial'])[1]")));Thread.sleep(2000);
	    driver.findElement(By.xpath("(//button[normalize-space()='Edit Testimonial'])[1]")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[normalize-space()='Cancel']")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[normalize-space()='Cancel']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//button[normalize-space()='Cancel']")).click();
	    Thread.sleep(2000);	
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[normalize-space()='Yes, Cancel']")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[normalize-space()='Yes, Cancel']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//button[normalize-space()='Yes, Cancel']")).click();
	    Thread.sleep(2000);
	    
	    /* Edit Video Testimonial and Give from All Tabs */ // to Akilesh Sharma //
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//button[normalize-space()='Edit Testimonial'])[1]")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//button[normalize-space()='Edit Testimonial'])[1]")));Thread.sleep(2000);
	    driver.findElement(By.xpath("(//button[normalize-space()='Edit Testimonial'])[1]")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[@type='submit']")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[@type='submit']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//button[@type='submit']")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[normalize-space()='Remove Video']")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()='Remove Video']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//span[normalize-space()='Remove Video']")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[normalize-space()='Cancel']")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[normalize-space()='Cancel']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//button[normalize-space()='Cancel']")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[normalize-space()='Remove Video']")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()='Remove Video']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//span[normalize-space()='Remove Video']")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[normalize-space()='Delete']")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[normalize-space()='Delete']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[1]/div[2]/div[1]/div[2]/button[1]")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("//span[normalize-space()='Record Video Testimonial']")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[normalize-space()='Okay!']")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[normalize-space()='Okay!']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//button[normalize-space()='Okay!']")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("//span[normalize-space()='Upload Video Testimonial']")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='browse-blue']")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@class='browse-blue']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[@class='browse-blue']")).click();
	    Thread.sleep(2000);
		Runtime.getRuntime().exec("C:\\Users\\dev\\Documents\\AutoScripts\\Upload1.exe");
		Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[normalize-space()='Confirm']")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[normalize-space()='Confirm']")));
	    Thread.sleep(2000);	    
		     WebElement element = driver.findElement(By.xpath("//button[normalize-space()='Confirm']"));
		     JavascriptExecutor js = (JavascriptExecutor)driver;
		     js.executeScript("arguments[0].click();", element);	
	    Thread.sleep(2000);
	    
	    /* Edit Skill Testimonial and Give from All Tabs */  // to George Williamson //
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//button[normalize-space()='Edit Testimonial'])[2]")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//button[normalize-space()='Edit Testimonial'])[2]")));Thread.sleep(2000);
	    driver.findElement(By.xpath("(//button[normalize-space()='Edit Testimonial'])[2]")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[@type='submit']")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[@type='submit']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//button[@type='submit']")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[contains(text(),'Next')]")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[contains(text(),'Next')]")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//button[contains(text(),'Next')]")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[@type='submit']")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[@type='submit']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//button[@type='submit']")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//form[1]/div[1]/div[2]/div[1]/div[1]/textarea[1]")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//form[1]/div[1]/div[2]/div[1]/div[1]/textarea[1]")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//form[1]/div[1]/div[2]/div[1]/div[1]/textarea[1]")).click();
	    driver.findElement(By.xpath("//form[1]/div[1]/div[2]/div[1]/div[1]/textarea[1]")).clear();
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("//form[1]/div[1]/div[2]/div[1]/div[1]/textarea[1]")).sendKeys("I have 4 years of experience working in elementary-level education, and have seen many great teachers come and go. Henry is one individual I have worked with who uniquely stands out, I have 4 years of experience working in elementary-level education, and have seen many great teachers come and go. Henry is one individual I have worked with who uniquely stands out");
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("//button[normalize-space()='Cancel']")).click();
	    Thread.sleep(2000);	
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[normalize-space()='Go Back']")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[normalize-space()='Go Back']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//button[normalize-space()='Go Back']")).click();
	    Thread.sleep(2000);
	    WebElement toClear = driver.findElement(By.xpath("//textarea[@name='description']"));
	    toClear.sendKeys(Keys.CONTROL + "a");
	    toClear.sendKeys(Keys.DELETE);
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("//form[1]/div[1]/div[2]/div[1]/div[1]/textarea[1]")).sendKeys("I have 4 years of experience working in elementary-level education, and have seen many great teachers come and go. Henry is one individual I have worked with who uniquely stands out, I have 4 years of experience working in elementary-level education, and have seen many great teachers come and go. Henry is one individual I have worked with who uniquely stands out");
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[@type='submit']")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[@type='submit']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//button[@type='submit']")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[normalize-space()='Confirm']")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[normalize-space()='Confirm']")));Thread.sleep(2000);
	    Thread.sleep(2000);	    
	    WebElement element1 = driver.findElement(By.xpath("//button[normalize-space()='Confirm']"));
	    js.executeScript("arguments[0].click();", element1);
	    Thread.sleep(2000);
	    
	    /* Logout */
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'My Profile')]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'My Profile')]")));Thread.sleep(2000);
		driver.findElement(By.xpath("//div[contains(text(),'My Profile')]")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//div[contains(text(),'Logout')]")).click();
		Thread.sleep(2000);
	  }
	}

