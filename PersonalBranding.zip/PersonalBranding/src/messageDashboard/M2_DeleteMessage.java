package messageDashboard;

import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import screenshotOnFailure.FailScreenshot;

@Listeners(screenshotListners.EventList.class)
public class M2_DeleteMessage extends FailScreenshot {

	@Test
	public void Msg_Create_Delete() throws InterruptedException {
		 
		/* Login to the Application - PBC */ 		
	  	driver.findElement(By.xpath("(//button[normalize-space()='Login'])[1]")).click();
		driver.findElement(By.xpath("//input[@id='Username']")).click();
		driver.findElement(By.xpath("//input[@id='Username']")).sendKeys("john.doe004");
		driver.findElement(By.xpath("//input[@id='password-field']")).click();
		driver.findElement(By.xpath("//input[@id='password-field']")).sendKeys("Rockon123");
		driver.findElement(By.xpath("//button[@id='loginButton']")).click();
		Thread.sleep(2000);
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(120));
		
		/* Navigate to the Messages */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'My Profile')]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'My Profile')]")));
		Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[contains(text(),'Messages')]")).click();
	    Thread.sleep(2000);
		    
	    /* Start a New Message */ 
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[contains(text(),'Start a new chat')]")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[contains(text(),'Start a new chat')]")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//span[contains(text(),'Start a new chat')]")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//li[contains(text(),'Personal')]")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//li[contains(text(),'Personal')]")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//li[contains(text(),'Personal')]")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[contains(text(),'New Chat')]")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[contains(text(),'New Chat')]")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//span[contains(text(),'New Chat')]")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("//textarea[@placeholder='Say something']")).click();
	    driver.findElement(By.xpath("//textarea[@placeholder='Say something']")).sendKeys("Hello Mr. Vignesh! How Do you Do in this Pandemic");
	    Thread.sleep(2000);
	    driver.findElement(By.id("inputbox")).click();
	    driver.findElement(By.id("inputbox")).sendKeys("Sadam");
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@title='Sadam Eve']")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@title='Sadam Eve']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[@title='Sadam Eve']")).click();	    
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='close-icon-blue']")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@class='close-icon-blue']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[@class='close-icon-blue']")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.id("inputbox")).click();
	    driver.findElement(By.id("inputbox")).sendKeys("Sadam");
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@title='Sadam Eve']")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@title='Sadam Eve']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[@title='Sadam Eve']")).click();	
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'Send')]")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[contains(text(),'Send')]")).click();
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@role='alert']"))); // Toaster Message Click
	    driver.findElement(By.xpath("//button[@aria-label='close']")).click();
	    Thread.sleep(2000);
	    
	    /* Delete Message */ 
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='chat-name-text']")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@class='chat-name-text']")));Thread.sleep(2000);
		{
		     WebElement element = driver.findElement(By.xpath("//div[@class='chat-name-text']"));
		     Actions builder = new Actions(driver);
		     builder.moveToElement(element).perform();
		}	
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//div[@class='icon-on-hover']//*[name()='svg'])[1]")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//div[@class='icon-on-hover']//*[name()='svg'])[1]")));Thread.sleep(2000);
	    driver.findElement(By.xpath("(//div[@class='icon-on-hover']//*[name()='svg'])[1]")).click();	
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("//li[normalize-space()='Delete']")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("//button[normalize-space()='Cancel']")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//div[@class='icon-on-hover']//*[name()='svg'])[1]")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//div[@class='icon-on-hover']//*[name()='svg'])[1]")));Thread.sleep(2000);
	    driver.findElement(By.xpath("(//div[@class='icon-on-hover']//*[name()='svg'])[1]")).click();	
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("//li[normalize-space()='Delete']")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("//button[normalize-space()='Delete']")).click();
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@role='alert']"))); // Toaster Message Click
	    driver.findElement(By.xpath("//button[@aria-label='close']")).click();
	    Thread.sleep(2000);
	    
	    /* Send a New Message - After Deletion */ 
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[contains(text(),'New Chat')]")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[contains(text(),'New Chat')]")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//span[contains(text(),'New Chat')]")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.id("inputbox")).click();
	    driver.findElement(By.id("inputbox")).sendKeys("Sadam");
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@title='Sadam Eve']")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@title='Sadam Eve']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[@title='Sadam Eve']")).click();	    
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='close-icon-blue']")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@class='close-icon-blue']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[@class='close-icon-blue']")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.id("inputbox")).click();
	    driver.findElement(By.id("inputbox")).sendKeys("Sadam");
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@title='Sadam Eve']")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@title='Sadam Eve']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[@title='Sadam Eve']")).click();	
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("//textarea[@placeholder='Say something']")).click();
	    driver.findElement(By.xpath("//textarea[@placeholder='Say something']")).sendKeys("Hello Mr. Vignesh! How Do you Do in this Pandemic");
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'Send')]")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[contains(text(),'Send')]")).click();
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@role='alert']"))); // Toaster Message Click
	    driver.findElement(By.xpath("//button[@aria-label='close']")).click();
	    Thread.sleep(2000);
	    
	    /* Logout from the Message */ 
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'My Profile')]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'My Profile')]")));Thread.sleep(2000);
		driver.findElement(By.xpath("//div[contains(text(),'My Profile')]")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("(//div[contains(text(),'Logout')])[1]")).click();
		Thread.sleep(2000); 
	}
}