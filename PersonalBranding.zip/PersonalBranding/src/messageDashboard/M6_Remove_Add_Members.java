package messageDashboard;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import screenshotOnFailure.FailScreenshot;

@Listeners(screenshotListners.EventList.class)
public class M6_Remove_Add_Members extends FailScreenshot {

	@Test
	public void Msg_Remove_Add() throws InterruptedException {
		 
		/* Login to the Application */ 			
	  	driver.findElement(By.xpath("(//button[normalize-space()='Login'])[1]")).click();
		driver.findElement(By.xpath("//input[@id='Username']")).click();
		driver.findElement(By.xpath("//input[@id='Username']")).sendKeys("john.doe004");
		driver.findElement(By.xpath("//input[@id='password-field']")).click();
		driver.findElement(By.xpath("//input[@id='password-field']")).sendKeys("Rockon123");
		driver.findElement(By.xpath("//button[@id='loginButton']")).click();
		Thread.sleep(2000);
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(120));
		
		/* Navigate to the Messages */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'My Profile')]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'My Profile')]")));
		Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[contains(text(),'Messages')]")).click();
	    Thread.sleep(2000);    
	     
	    /* Remove members from the group */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//div[@class='chat-number'][normalize-space()='+2'])[1]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//div[@class='chat-number'][normalize-space()='+2'])[1]")));
	    driver.findElement(By.xpath("(//div[@class='chat-number'][normalize-space()='+2'])[1]")).click();
		Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//div[@class='chat-number'][normalize-space()='+2'])[1]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//div[@class='chat-number'][normalize-space()='+2'])[1]")));
	    driver.findElement(By.xpath("(//div[@class='chat-number'][normalize-space()='+2'])[1]")).click();
		Thread.sleep(2000); 
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='chat-name-text']")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@class='chat-name-text']")));Thread.sleep(2000);
		{
		     WebElement element = driver.findElement(By.xpath("//div[@class='chat-name-text']"));
		     Actions builder = new Actions(driver);
		     builder.moveToElement(element).perform();
		} 
		Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//div[@class='icon-on-hover']//*[name()='svg'])[1]")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//div[@class='icon-on-hover']//*[name()='svg'])[1]")));Thread.sleep(2000);
	    driver.findElement(By.xpath("(//div[@class='icon-on-hover']//*[name()='svg'])[1]")).click();	
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("//li[normalize-space()='Delete']")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("//button[normalize-space()='Cancel']")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//div[@class='icon-on-hover']//*[name()='svg'])[1]")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//div[@class='icon-on-hover']//*[name()='svg'])[1]")));Thread.sleep(2000);
	    driver.findElement(By.xpath("(//div[@class='icon-on-hover']//*[name()='svg'])[1]")).click();	
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("//li[normalize-space()='Add/Remove Members']")).click();
	    Thread.sleep(2000);	
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@title='Adam Luqman']//div[@class='close-icon-blue']")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@title='Adam Luqman']//div[@class='close-icon-blue']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[@title='Adam Luqman']//div[@class='close-icon-blue']")).click(); // Removing Adam by clicking X icon
	    Thread.sleep(2000);	    
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[contains(text(),'Save')]")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[contains(text(),'Save')]")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//span[contains(text(),'Save')]")).click();
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@role='alert']"))); // Toaster Message Click
	    driver.findElement(By.xpath("//button[@aria-label='close']")).click();	    
	    Thread.sleep(2000);
	             
	    /* Add Participant into Individual Chat */  
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//div[@class='icon-on-hover']//*[name()='svg'])[2]")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//div[@class='icon-on-hover']//*[name()='svg'])[2]")));Thread.sleep(2000);
	    driver.findElement(By.xpath("(//div[@class='icon-on-hover']//*[name()='svg'])[2]")).click();	
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("//li[normalize-space()='Add/Remove Members']")).click();
	    Thread.sleep(2000);	 
	    driver.findElement(By.id("inputbox")).click();
	    driver.findElement(By.id("inputbox")).sendKeys("adam");
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@title='Adam Luqman']")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@title='Adam Luqman']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[@title='Adam Luqman']")).click();	    
	    Thread.sleep(2000); 
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[contains(text(),'Save')]")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[contains(text(),'Save')]")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//span[contains(text(),'Save')]")).click();
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@role='alert']"))); // Toaster Message Click
	    driver.findElement(By.xpath("//button[@aria-label='close']")).click();	    
	    Thread.sleep(2000);
	    
	    /* Reply to the Message after updating the Participants*/
	    driver.findElement(By.xpath("//textarea[@placeholder='Say something']")).click();
	    driver.findElement(By.xpath("//textarea[@placeholder='Say something']")).sendKeys("Hello All, i have a created a group. thanks");
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'Send')]")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[contains(text(),'Send')]")).click();
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@role='alert']"))); // Toaster Message Click
	    driver.findElement(By.xpath("//button[@aria-label='close']")).click();
	    Thread.sleep(2000);
	    
	    /* Logout from the Message */ 
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'My Profile')]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'My Profile')]")));Thread.sleep(2000);
		driver.findElement(By.xpath("//div[contains(text(),'My Profile')]")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("(//div[contains(text(),'Logout')])[1]")).click();
		Thread.sleep(2000);      
	}
}