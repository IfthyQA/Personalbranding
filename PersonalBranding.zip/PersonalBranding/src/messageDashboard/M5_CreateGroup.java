package messageDashboard;

import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import screenshotOnFailure.FailScreenshot;

@Listeners(screenshotListners.EventList.class)
public class M5_CreateGroup extends FailScreenshot {

	@Test
	public void Msg_GroupChat() throws InterruptedException {
		 
		/* Login to the Application */ 			
	  	driver.findElement(By.xpath("(//button[normalize-space()='Login'])[1]")).click();
		driver.findElement(By.xpath("//input[@id='Username']")).click();
		driver.findElement(By.xpath("//input[@id='Username']")).sendKeys("john.doe004");
		driver.findElement(By.xpath("//input[@id='password-field']")).click();
		driver.findElement(By.xpath("//input[@id='password-field']")).sendKeys("Rockon123");
		driver.findElement(By.xpath("//button[@id='loginButton']")).click();
		Thread.sleep(2000);
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(120));
		
		/* Navigate to the Messages */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'My Profile')]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'My Profile')]")));
		Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[contains(text(),'Messages')]")).click();
	    Thread.sleep(2000);
	     
	    /* Group Chat Message from Menu */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[contains(text(),'New Chat')]")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[contains(text(),'New Chat')]")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//span[contains(text(),'New Chat')]")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.id("inputbox")).click();
	    driver.findElement(By.id("inputbox")).sendKeys("Sadam");
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@title='Sadam Eve']")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@title='Sadam Eve']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[@title='Sadam Eve']")).click();	    
	    Thread.sleep(2000);
	    
	    driver.findElement(By.id("inputbox")).click();
	    driver.findElement(By.id("inputbox")).sendKeys("adam");
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@title='Adam Luqman']")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@title='Adam Luqman']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[@title='Adam Luqman']")).click();	    
	    Thread.sleep(2000);
		driver.findElement(By.id("inputbox")).sendKeys(Keys.BACK_SPACE); // Removing Adam by clicking backspace
		Thread.sleep(2000);
		
	    driver.findElement(By.id("inputbox")).click();
	    driver.findElement(By.id("inputbox")).sendKeys("adam");
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@title='Adam Luqman']")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@title='Adam Luqman']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[@title='Adam Luqman']")).click();	    
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@title='Adam Luqman']//div[@class='close-icon-blue']")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@title='Adam Luqman']//div[@class='close-icon-blue']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[@title='Adam Luqman']//div[@class='close-icon-blue']")).click(); // Removing Adam by clicking X icon
	    Thread.sleep(2000);
	    
	    driver.findElement(By.id("inputbox")).click();
	    driver.findElement(By.id("inputbox")).sendKeys("adam");
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@title='Adam Luqman']")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@title='Adam Luqman']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[@title='Adam Luqman']")).click();	    
	    Thread.sleep(2000);	    

	    driver.findElement(By.id("inputbox")).click();
	    driver.findElement(By.id("inputbox")).sendKeys("Amrita");
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@title='Amrita Raj Olivia']")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@title='Amrita Raj Olivia']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[@title='Amrita Raj Olivia']")).click();	    
	    Thread.sleep(2000);
	    
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[contains(text(),'Clear all')]")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[contains(text(),'Clear all')]")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//span[contains(text(),'Clear all')]")).click();	    
	    Thread.sleep(2000);
	    
	    /* Create a New Group and Delete */
	    driver.findElement(By.id("inputbox")).click();
	    driver.findElement(By.id("inputbox")).sendKeys("Sadam");
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@title='Sadam Eve']")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@title='Sadam Eve']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[@title='Sadam Eve']")).click();	    
	    Thread.sleep(2000);
	    
	    driver.findElement(By.id("inputbox")).click();
	    driver.findElement(By.id("inputbox")).sendKeys("adam");
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@title='Adam Luqman']")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@title='Adam Luqman']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[@title='Adam Luqman']")).click();	    
	    Thread.sleep(2000);    

	    driver.findElement(By.id("inputbox")).click();
	    driver.findElement(By.id("inputbox")).sendKeys("Amrita");
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@title='Amrita Raj Olivia']")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@title='Amrita Raj Olivia']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[@title='Amrita Raj Olivia']")).click();	    
	    Thread.sleep(2000);
	    
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[contains(text(),'Save')]")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[contains(text(),'Save')]")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//span[contains(text(),'Save')]")).click();
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@role='alert']"))); // Toaster Message Click
	    driver.findElement(By.xpath("//button[@aria-label='close']")).click();	    

	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//div[@class='icon-on-hover']//*[name()='svg'])[2]")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//div[@class='icon-on-hover']//*[name()='svg'])[2]")));Thread.sleep(2000);
	    driver.findElement(By.xpath("(//div[@class='icon-on-hover']//*[name()='svg'])[2]")).click();	
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("//li[normalize-space()='Delete']")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("//button[normalize-space()='Cancel']")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//div[@class='icon-on-hover']//*[name()='svg'])[2]")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//div[@class='icon-on-hover']//*[name()='svg'])[2]")));Thread.sleep(2000);
	    driver.findElement(By.xpath("(//div[@class='icon-on-hover']//*[name()='svg'])[2]")).click();	
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("//li[normalize-space()='Delete']")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("//button[normalize-space()='Delete']")).click();
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@role='alert']"))); // Toaster Message Click
	    driver.findElement(By.xpath("//button[@aria-label='close']")).click();
	    Thread.sleep(2000);
	    
	    /* Create a New Group and Add Members */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[contains(text(),'New Chat')]")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[contains(text(),'New Chat')]")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//span[contains(text(),'New Chat')]")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.id("inputbox")).click();
	    driver.findElement(By.id("inputbox")).sendKeys("Sadam");
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@title='Sadam Eve']")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@title='Sadam Eve']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[@title='Sadam Eve']")).click();	    
	    Thread.sleep(2000);
	    
	    driver.findElement(By.id("inputbox")).click();
	    driver.findElement(By.id("inputbox")).sendKeys("adam");
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@title='Adam Luqman']")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@title='Adam Luqman']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[@title='Adam Luqman']")).click();	    
	    Thread.sleep(2000);    

	    driver.findElement(By.id("inputbox")).click();
	    driver.findElement(By.id("inputbox")).sendKeys("Amrita");
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@title='Amrita Raj Olivia']")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@title='Amrita Raj Olivia']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[@title='Amrita Raj Olivia']")).click();	    
	    Thread.sleep(2000);
	    
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[contains(text(),'Save')]")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[contains(text(),'Save')]")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//span[contains(text(),'Save')]")).click();
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@role='alert']"))); // Toaster Message Click
	    driver.findElement(By.xpath("//button[@aria-label='close']")).click();	    
	    Thread.sleep(2000);
	    
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//div[@class='icon-on-hover']//*[name()='svg'])[2]")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//div[@class='icon-on-hover']//*[name()='svg'])[2]")));Thread.sleep(2000);
	    driver.findElement(By.xpath("(//div[@class='icon-on-hover']//*[name()='svg'])[2]")).click();	
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("//li[normalize-space()='Add/Remove Members']")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@title='Adam Luqman']//div[@class='close-icon-blue']")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@title='Adam Luqman']//div[@class='close-icon-blue']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[@title='Adam Luqman']//div[@class='close-icon-blue']")).click(); // Removing Adam by clicking X icon
	    Thread.sleep(2000);
	    
	    driver.findElement(By.id("inputbox")).click();
	    driver.findElement(By.id("inputbox")).sendKeys("adam");
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@title='Adam Luqman']")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@title='Adam Luqman']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[@title='Adam Luqman']")).click();	    
	    Thread.sleep(2000);	 
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[contains(text(),'Save')]")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[contains(text(),'Save')]")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//span[contains(text(),'Save')]")).click();
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@role='alert']"))); // Toaster Message Click
	    driver.findElement(By.xpath("//button[@aria-label='close']")).click();	    
	    Thread.sleep(2000);
	    
	    driver.findElement(By.xpath("//textarea[@placeholder='Say something']")).click();
	    driver.findElement(By.xpath("//textarea[@placeholder='Say something']")).sendKeys("Hello All, i have a created a group. thanks");
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'Send')]")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[contains(text(),'Send')]")).click();
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@role='alert']"))); // Toaster Message Click
	    driver.findElement(By.xpath("//button[@aria-label='close']")).click();
	    Thread.sleep(2000);  
	    
	    /* Logout from the Message */ 
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'My Profile')]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'My Profile')]")));Thread.sleep(2000);
		driver.findElement(By.xpath("//div[contains(text(),'My Profile')]")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("(//div[contains(text(),'Logout')])[1]")).click();
		Thread.sleep(2000);	     
	}
}