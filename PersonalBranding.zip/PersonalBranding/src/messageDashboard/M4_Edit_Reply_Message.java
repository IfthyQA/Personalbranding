package messageDashboard;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import screenshotOnFailure.FailScreenshot;

@Listeners(screenshotListners.EventList.class)
public class M4_Edit_Reply_Message extends FailScreenshot {

	@Test
	public void Msg_EditReply() throws InterruptedException {
		 
		/* Login to the Application */ 			
	  	driver.findElement(By.xpath("(//button[normalize-space()='Login'])[1]")).click();
		driver.findElement(By.xpath("//input[@id='Username']")).click();
		driver.findElement(By.xpath("//input[@id='Username']")).sendKeys("john.doe004");
		driver.findElement(By.xpath("//input[@id='password-field']")).click();
		driver.findElement(By.xpath("//input[@id='password-field']")).sendKeys("Rockon123");
		driver.findElement(By.xpath("//button[@id='loginButton']")).click();
		Thread.sleep(2000);
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(120));
		
		/* Navigate to the Messages */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'My Profile')]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'My Profile')]")));
		Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[contains(text(),'Messages')]")).click();
	    Thread.sleep(2000);
	    
	    /* Edit Message & Reply */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//li[contains(text(),'Personal')]")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//li[contains(text(),'Personal')]")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//li[contains(text(),'Personal')]")).click();
	    Thread.sleep(2000); 
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='chat-name-text']")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@class='chat-name-text']")));Thread.sleep(2000);
		{
		     WebElement element = driver.findElement(By.xpath("//div[@class='message-text']"));
		     Actions builder = new Actions(driver);
		     builder.moveToElement(element).perform();
		}	
	   	Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[2]/div[2]/div[2]/div[1]/*[name()='svg'][1]")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[2]/div[2]/div[2]/div[1]/*[name()='svg'][1]")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[2]/div[2]/div[2]/div[1]/*[name()='svg'][1]")).click();	
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("//li[normalize-space()='Edit']")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("//textarea[@placeholder='Say something']")).click();
	    driver.findElement(By.xpath("//textarea[@placeholder='Say something']")).sendKeys("Lets Edit the Message, which sent while ago!");
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'Send')]")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[contains(text(),'Send')]")).click();
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@role='alert']"))); // Toaster Message Click
	    driver.findElement(By.xpath("//button[@aria-label='close']")).click();
	    Thread.sleep(2000);
	     
	    /* Delete / Message/ Reply */ 
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='chat-name-text']")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@class='chat-name-text']")));Thread.sleep(2000);
		{
		     WebElement element = driver.findElement(By.xpath("//div[@class='message-text']"));
		     Actions builder = new Actions(driver);
		     builder.moveToElement(element).perform();
		}	
	   	Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[2]/div[2]/div[2]/div[1]/*[name()='svg'][1]")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[2]/div[2]/div[2]/div[1]/*[name()='svg'][1]")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[2]/div[2]/div[2]/div[1]/*[name()='svg'][1]")).click();	
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("//li[normalize-space()='Delete']")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("//button[normalize-space()='Delete']")).click();
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@role='alert']"))); // Toaster Message Click
	    driver.findElement(By.xpath("//button[@aria-label='close']")).click();
	    Thread.sleep(2000);
	     
	    /* Reply after Delete */ 
	    driver.findElement(By.xpath("//textarea[@placeholder='Say something']")).click();
	    driver.findElement(By.xpath("//textarea[@placeholder='Say something']")).sendKeys("Just, Deleted, Hello Baba! How is your work?");
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'Send')]")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[contains(text(),'Send')]")).click();
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@role='alert']"))); // Toaster Message Click
	    driver.findElement(By.xpath("//button[@aria-label='close']")).click();
	    Thread.sleep(2000);	 
	    
	    /* Delete Message */ 
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='chat-name-text']")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@class='chat-name-text']")));Thread.sleep(2000);
		{
		     WebElement element = driver.findElement(By.xpath("//div[@class='chat-name-text']"));
		     Actions builder = new Actions(driver);
		     builder.moveToElement(element).perform();
		}	
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//div[@class='icon-on-hover']//*[name()='svg'])[1]")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//div[@class='icon-on-hover']//*[name()='svg'])[1]")));Thread.sleep(2000);
	    driver.findElement(By.xpath("(//div[@class='icon-on-hover']//*[name()='svg'])[1]")).click();	
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("//li[normalize-space()='Delete']")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("//button[normalize-space()='Delete']")).click();
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@role='alert']"))); // Toaster Message Click
	    driver.findElement(By.xpath("//button[@aria-label='close']")).click();
	    Thread.sleep(2000);
	     
	    /* Logout from the Message */ 
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'My Profile')]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'My Profile')]")));Thread.sleep(2000);
		driver.findElement(By.xpath("//div[contains(text(),'My Profile')]")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("(//div[contains(text(),'Logout')])[1]")).click();
		Thread.sleep(2000);	 	     
	}
}