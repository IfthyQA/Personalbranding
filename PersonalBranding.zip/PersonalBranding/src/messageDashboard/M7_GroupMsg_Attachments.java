package messageDashboard;

import java.io.IOException;
import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import screenshotOnFailure.FailScreenshot;

@Listeners(screenshotListners.EventList.class)
public class M7_GroupMsg_Attachments extends FailScreenshot {

	@Test
	public void Msg_Attach_Star_Seen() throws InterruptedException, IOException {
		 
		/* Login to the Application */ 			
	  	driver.findElement(By.xpath("(//button[normalize-space()='Login'])[1]")).click();
		driver.findElement(By.xpath("//input[@id='Username']")).click();
		driver.findElement(By.xpath("//input[@id='Username']")).sendKeys("john.doe004");
		driver.findElement(By.xpath("//input[@id='password-field']")).click();
		driver.findElement(By.xpath("//input[@id='password-field']")).sendKeys("Rockon123");
		driver.findElement(By.xpath("//button[@id='loginButton']")).click();
		Thread.sleep(2000);
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(120));
		
		/* Navigate to the Messages */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'My Profile')]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'My Profile')]")));
		Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[contains(text(),'Messages')]")).click();
	    Thread.sleep(2000);    
	     
	    /* Remove members from the group */ 
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//li[contains(text(),'Personal')]")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//li[contains(text(),'Personal')]")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//li[contains(text(),'Personal')]")).click();
	    Thread.sleep(2000); 
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//li[contains(text(),'Group')]")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//li[contains(text(),'Group')]")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//li[contains(text(),'Group')]")).click();
	    Thread.sleep(2000);
	    
	    /* Add Emoji */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[@class='message-emoji']")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[@class='message-emoji']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//span[@class='message-emoji']")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//div[@class='accessories-container'])[1]")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//div[@class='accessories-container'])[1]")));Thread.sleep(2000);
	    driver.findElement(By.xpath("(//div[@class='accessories-container'])[1]")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='reaction-container-blue d-flex justify-content-center align-items-center']")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@class='reaction-container-blue d-flex justify-content-center align-items-center']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[@class='reaction-container-blue d-flex justify-content-center align-items-center']")).click();
	    Thread.sleep(2000);
	    
	    /* Send Emoji */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@title='Add Emojies']")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@title='Add Emojies']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[@title='Add Emojies']")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//ul[1]/li[3]/div[1]/button[1]/span[1]")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//ul[1]/li[3]/div[1]/button[1]/span[1]")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//ul[1]/li[3]/div[1]/button[1]/span[1]")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("//textarea[@placeholder='Say something']")).click();
	    Thread.sleep(2000);
	    
	    /* Send Attachment */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@title='Attach Files']")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@title='Attach Files']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[@title='Attach Files']")).click();
	    Thread.sleep(2000);	    
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[contains(text(),'Click to upload')]")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[contains(text(),'Click to upload')]")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//span[contains(text(),'Click to upload')]")).click();
	    Thread.sleep(2000);
	    Runtime.getRuntime().exec("C:\\Users\\dev\\Documents\\AutoScripts\\Upload.exe"); 
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//i[@class='fa fa-times-circle delete-img-icon']")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//i[@class='fa fa-times-circle delete-img-icon']")));
		Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'Select media to share from your Power Share folder')]")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'Select media to share from your Power Share folder')]")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[contains(text(),'Select media to share from your Power Share folder')]")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//div[@class='uploaded-img-container position-relative '])[2]")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//div[@class='uploaded-img-container position-relative '])[2]")));Thread.sleep(2000);
	    driver.findElement(By.xpath("(//div[@class='uploaded-img-container position-relative '])[2]")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[normalize-space()='Upload']")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[normalize-space()='Upload']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//button[normalize-space()='Upload']")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[normalize-space()='Upload']")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[normalize-space()='Upload']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//button[normalize-space()='Upload']")).click();
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'Send')]")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[contains(text(),'Send')]")).click();
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@role='alert']"))); // Toaster Message Click
	    driver.findElement(By.xpath("//button[@aria-label='close']")).click();
	    Thread.sleep(2000);
	    
	    /* View Files */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='message-image-2 message-img']//img")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@class='message-image-2 message-img']//img")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[@class='message-image-2 message-img']//img")).click();
	    Thread.sleep(2000);	
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[@class='swiper-button-next-custom']//*[name()='svg']")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[@class='swiper-button-next-custom']//*[name()='svg']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//button[@class='swiper-button-next-custom']//*[name()='svg']")).click();
	    Thread.sleep(2000);	
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[@class='swiper-button-prev-custom']//*[name()='svg']")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[@class='swiper-button-prev-custom']//*[name()='svg']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//button[@class='swiper-button-prev-custom']//*[name()='svg']")).click();
	    Thread.sleep(2000);	
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='close-img-video']//*[name()='svg']")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@class='close-img-video']//*[name()='svg']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[@class='close-img-video']//*[name()='svg']")).click();
	    Thread.sleep(2000);	
	    
	    /* Seen By */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='message-image-2 message-img']//img")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@class='message-image-2 message-img']//img")));Thread.sleep(2000);
		{
		     WebElement element = driver.findElement(By.xpath("//div[@class='message-image-2 message-img']//img"));
		     Actions builder = new Actions(driver);
		     builder.moveToElement(element).perform();
		}
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[2]/div[1]/div[2]/div[1]/*[name()='svg'][1]")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[2]/div[1]/div[2]/div[1]/*[name()='svg'][1]")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[2]/div[1]/div[2]/div[1]/*[name()='svg'][1]")).click();	
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("//li[normalize-space()='Seen By']")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='seen-by-cross-icon']//*[name()='svg']")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@class='seen-by-cross-icon']//*[name()='svg']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[@class='seen-by-cross-icon']//*[name()='svg']")).click();
	    Thread.sleep(2000);	    

	    /* Star the Message */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='message-image-2 message-img']//img")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@class='message-image-2 message-img']//img")));Thread.sleep(2000);
		{
		     WebElement element = driver.findElement(By.xpath("//div[@class='message-image-2 message-img']//img"));
		     Actions builder = new Actions(driver);
		     builder.moveToElement(element).perform();
		}
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[2]/div[1]/div[2]/div[1]/*[name()='svg'][1]")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[2]/div[1]/div[2]/div[1]/*[name()='svg'][1]")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[2]/div[1]/div[2]/div[1]/*[name()='svg'][1]")).click();	
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("//li[normalize-space()='Star']")).click();
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@role='alert']"))); // Toaster Message Click
	    driver.findElement(By.xpath("//button[@aria-label='close']")).click();
	    Thread.sleep(2000);
	    
	    /* Unstar the Message */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='message-image-2 message-img']//img")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@class='message-image-2 message-img']//img")));Thread.sleep(2000);
		{
		     WebElement element = driver.findElement(By.xpath("//div[@class='message-image-2 message-img']//img"));
		     Actions builder = new Actions(driver);
		     builder.moveToElement(element).perform();
		}
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[2]/div[1]/div[2]/div[1]/*[name()='svg'][1]")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[2]/div[1]/div[2]/div[1]/*[name()='svg'][1]")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[2]/div[1]/div[2]/div[1]/*[name()='svg'][1]")).click();	
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("//li[normalize-space()='Unstar']")).click();
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@role='alert']"))); // Toaster Message Click
	    driver.findElement(By.xpath("//button[@aria-label='close']")).click();
	    Thread.sleep(2000);
	    
	    /* Delete Message */ 
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='chat-name-text']")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@class='chat-name-text']")));Thread.sleep(2000);
		{
		     WebElement element = driver.findElement(By.xpath("//div[@class='chat-name-text']"));
		     Actions builder = new Actions(driver);
		     builder.moveToElement(element).perform();
		}	
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//div[@class='icon-on-hover']//*[name()='svg'])[1]")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//div[@class='icon-on-hover']//*[name()='svg'])[1]")));Thread.sleep(2000);
	    driver.findElement(By.xpath("(//div[@class='icon-on-hover']//*[name()='svg'])[1]")).click();	
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("//li[normalize-space()='Delete']")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("//button[normalize-space()='Delete']")).click();
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@role='alert']"))); // Toaster Message Click
	    driver.findElement(By.xpath("//button[@aria-label='close']")).click();
	    Thread.sleep(2000);
	    
	    /* Delete From Power Share*/
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'My Profile')]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'My Profile')]")));Thread.sleep(2000);
		{
		     WebElement element = driver.findElement(By.xpath("//div[@id='desktopMenu']"));
		     Actions builder = new Actions(driver);
		     builder.moveToElement(element).perform();
		}
		Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'Power Share')]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'Power Share')]")));Thread.sleep(2000);
		driver.findElement(By.xpath("//div[contains(text(),'Power Share')]")).click();
		Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[normalize-space()='ArtUpload.jpg']")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()='ArtUpload.jpg']")));Thread.sleep(2000);
		driver.findElement(By.xpath("//div[2]/div[1]/div[1]/div[6]/div[1]/div[2]")).click();		
		Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("li .btnDeleteFile")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector("li .btnDeleteFile")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector("li .btnDeleteFile")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("btnYesConfirmYesNo")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.id("btnYesConfirmYesNo")));Thread.sleep(2000);	
	    driver.findElement(By.id("btnYesConfirmYesNo")).click();
		wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".toast-message")));
	    driver.findElement(By.cssSelector(".toast-message")).click();
	    Thread.sleep(2000);		
	    
	    /* Logout from the Power Share page */ 
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'My Profile')]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'My Profile')]")));Thread.sleep(2000);
		driver.findElement(By.xpath("//div[contains(text(),'My Profile')]")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("(//div[contains(text(),'Logout')])[2]")).click();
		Thread.sleep(2000);      
	}
}