package messageDashboard;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import screenshotOnFailure.FailScreenshot;

@Listeners(screenshotListners.EventList.class)
public class M3_Archive_Unarchive extends FailScreenshot {

	@Test
	public void Msg_Archive_Unarhive() throws InterruptedException {
		 
/* Login to the Application */ 			
	  	driver.findElement(By.xpath("(//button[normalize-space()='Login'])[1]")).click();
		driver.findElement(By.xpath("//input[@id='Username']")).click();
		driver.findElement(By.xpath("//input[@id='Username']")).sendKeys("john.doe004");
		driver.findElement(By.xpath("//input[@id='password-field']")).click();
		driver.findElement(By.xpath("//input[@id='password-field']")).sendKeys("Rockon123");
		driver.findElement(By.xpath("//button[@id='loginButton']")).click();
		Thread.sleep(2000);
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(120));
		
		/* Navigate to the Messages */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'My Profile')]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'My Profile')]")));
		Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[contains(text(),'Messages')]")).click();
	    Thread.sleep(2000);
	    
	    /* Archive a Chat */ 
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//li[contains(text(),'Personal')]")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//li[contains(text(),'Personal')]")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//li[contains(text(),'Personal')]")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='chat-name-text']")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@class='chat-name-text']")));Thread.sleep(2000);
		 {
		     WebElement element = driver.findElement(By.xpath("//div[@class='chat-name-text']"));
		     Actions builder = new Actions(driver);
		     builder.moveToElement(element).perform();
		}	
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//div[@class='icon-on-hover']//*[name()='svg'])[1]")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//div[@class='icon-on-hover']//*[name()='svg'])[1]")));Thread.sleep(2000);
	    driver.findElement(By.xpath("(//div[@class='icon-on-hover']//*[name()='svg'])[1]")).click();	
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("//li[normalize-space()='Archive']")).click();
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@role='alert']"))); // Toaster Message Click
	    driver.findElement(By.xpath("//button[@aria-label='close']")).click();
	    Thread.sleep(2000);
	    
	    /* Unarchive a Chat */
	    wait.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath("//textarea[@placeholder='Say something']")));
	    Thread.sleep(2000); 
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='chat-name-text']")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@class='chat-name-text']")));Thread.sleep(2000);
		 {
		     WebElement element = driver.findElement(By.xpath("//div[@class='chat-name-text']"));
		     Actions builder = new Actions(driver);
		     builder.moveToElement(element).perform();
		}	
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//div[@class='icon-on-hover']//*[name()='svg'])[1]")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//div[@class='icon-on-hover']//*[name()='svg'])[1]")));Thread.sleep(2000);
	    driver.findElement(By.xpath("(//div[@class='icon-on-hover']//*[name()='svg'])[1]")).click();	
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("//li[normalize-space()='Unarchive']")).click();
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@role='alert']"))); // Toaster Message Click
	    driver.findElement(By.xpath("//button[@aria-label='close']")).click();
	    Thread.sleep(2000);   
	    
	    /* Reply after Unarchived Chat */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//textarea[@placeholder='Say something']")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//textarea[@placeholder='Say something']")));Thread.sleep(2000); 
	    driver.findElement(By.xpath("//textarea[@placeholder='Say something']")).click();
	    driver.findElement(By.xpath("//textarea[@placeholder='Say something']")).sendKeys("Hello Mr. Sdam! Am Unarchiving the Chat during the Pandemic");
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'Send')]")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[contains(text(),'Send')]")).click();
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@role='alert']"))); // Toaster Message Click
	    driver.findElement(By.xpath("//button[@aria-label='close']")).click();
	    Thread.sleep(2000);
	     
	    /* Logout from the Message */ 
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'My Profile')]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'My Profile')]")));Thread.sleep(2000);
		driver.findElement(By.xpath("//div[contains(text(),'My Profile')]")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("(//div[contains(text(),'Logout')])[1]")).click();
		Thread.sleep(2000);	     
	}
}