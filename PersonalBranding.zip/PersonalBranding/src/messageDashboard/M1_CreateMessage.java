package messageDashboard;

import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import screenshotOnFailure.FailScreenshot;

@Listeners(screenshotListners.EventList.class)
public class M1_CreateMessage extends FailScreenshot {

	@Test
	public void Msg_Create() throws InterruptedException {
		 
		/* Login to the Application - PBC */ 		
	  	driver.findElement(By.xpath("(//button[normalize-space()='Login'])[1]")).click();
		driver.findElement(By.xpath("//input[@id='Username']")).click();
		driver.findElement(By.xpath("//input[@id='Username']")).sendKeys("test.doe002");
		driver.findElement(By.xpath("//input[@id='password-field']")).click();
		driver.findElement(By.xpath("//input[@id='password-field']")).sendKeys("Rockon123");
		driver.findElement(By.xpath("//button[@id='loginButton']")).click();
		Thread.sleep(2000);
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(120));
		
		/* Navigate to the Messages */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'My Profile')]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'My Profile')]")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[contains(text(),'Messages')]")).click();
	    Thread.sleep(2000);
	    
	    /* Delete Message */ 	
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".dropdown > .dropdown")));Thread.sleep(2000);	
		wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".dropdown > .dropdown")));Thread.sleep(10000);
	    driver.findElement(By.cssSelector(".dropdown > .dropdown")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector("form:nth-child(2) > .dropdown-item")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.id("btnYesConfirmYesNo")).click();
		wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".toast-message")));Thread.sleep(2000);
		driver.findElement(By.cssSelector(".toast-message")).click();
	    Thread.sleep(2000);	    
	    
	    /* Start a New Message */ 
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("newMessage")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.id("newMessage")));Thread.sleep(2000);
	    driver.findElement(By.id("newMessage")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".fa-pencil-square-o")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.id("TextContent")).click();
	    driver.findElement(By.id("TextContent")).sendKeys("Hello Ms. How are you Doing in this Pandemic");
	    Thread.sleep(2000);
	    driver.findElement(By.id("searchMessage")).click();
	    driver.findElement(By.id("searchMessage")).sendKeys("Emiley");
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".divInfo > div > div")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".divInfo > div > div")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".divInfo > div > div")).click();	    
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("//section[1]/div[2]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/i[1]")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.id("btnYesConfirmYesNo")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.id("searchMessage")).click();
	    driver.findElement(By.id("searchMessage")).sendKeys("Emiley");
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".divInfo > div > div")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".divInfo > div > div")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".divInfo > div > div")).click();
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.elementToBeClickable(By.id("sendButton")));Thread.sleep(2000);
	    driver.findElement(By.id("sendButton")).click();
	    Thread.sleep(2000);
	             
	    /* Logout from the Message */
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'My Profile')]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'My Profile')]")));Thread.sleep(2000);
		driver.findElement(By.xpath("//div[contains(text(),'My Profile')]")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//div[contains(text(),'Logout')]")).click();
		Thread.sleep(2000);	     
	}
}