package screenshotOnFailure;

import java.time.Duration;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;

public class FailScreenshot {

	public  FileLib flib=new FileLib();
	public  WebDriver driver=null;	
	public  String path="C:\\Users\\dev\\eclipse-workspace\\Personalbranding\\src\\screenshot\\data\\commonData.properties";
	public static  WebDriver listenerDriver=null;
	
	@BeforeClass
	public  void setUp() throws InterruptedException, Exception 
	{		
        /* Kill the Chrome and driver on every test case execution */
		String batchFilePath = "C:\\Users\\dev\\eclipse-workspace\\PersonalBranding\\ChromeKill.bat";
        Process process = Runtime.getRuntime().exec(batchFilePath);
        Thread.sleep(2000); // 
        int exitCode = process.waitFor();
        System.out.println("All Chrome Instances are killed: " + exitCode);
		
        ChromeOptions options = new ChromeOptions();
        options.addArguments("start-maximized"); // open Browser in maximized mode
        options.addArguments("--remote-allow-origins=*");
        options.addArguments("--ignore-certificate-errors");
        options.addArguments("--disable-extensions");
        options.addArguments("disable-infobars");
        options.addArguments("--disable-dev-shm-usage");
        options.addArguments("--no-sandbox");
        options.addArguments("--dns-prefetch-disable");
        options.addArguments("enable-automation");
        options.addArguments("disable-features=NetworkService");
        options.addArguments("--webview-log-js-console-messages");

        /*Initialize ChromeDriver*/
        driver = new ChromeDriver(options);       
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(120)); // Implicit Wait
        listenerDriver = driver;
    }				
	
	@BeforeMethod
	public void navigateToHomePage() throws Exception
	{
		/*Step 1 : Launch & Navigate to the Application*/	
        String url = "https://www.personalbrandingcouncil.com/";
        driver.get(url);		

        /*Verify the HomePage Landed successfully or not*/
		String expHomePage = "AI-driven Professional Development Platform | ACHNET".replaceAll(" ", "");
		String actHomePage = driver.getTitle().replaceAll(" ", "");		
	    
		if(actHomePage.equals(expHomePage))
		{
			System.out.println("Homepage Landed Successfully: Testing Continues!");			
		}
		else
		{	
			driver.quit();	 
			setUp(); 
			navigateToHomePage();
			System.out.println("Restarting the'setUp' method, since the 'navigateToHomePage' is failed!");	
		}
    }
	
	@AfterMethod
	public void verifyLogout()
	{			
		/*Verify the Logout Successful or Failed*/
		String expLogoutTitle = "AI-driven Professional Development Platform | ACHNET".replaceAll(" ", "");
		String actLogoutTitle = driver.getTitle().replaceAll(" ", "");

		if(actLogoutTitle.equals(expLogoutTitle))
		{
			System.out.println("Oh Beauty! Logout is successful. Applause, the test case is PASSED.");
		}
		else
		{
			System.out.println("Ohh Noo! Logout is not Successful - Test Case FAILED");
		}
	}
	
	@AfterClass	
	public void tearDown() throws InterruptedException		
	{
        /* Ensure any remaining WebDriver instance is closed, after the test suite has run */
        if (driver != null) {
            driver.quit();
            driver = null;
        }

        /* After driver has been closed */
        System. out.println("All tests are completed. Cleaned up resources.");
    }
}
