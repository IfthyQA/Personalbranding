package settings;

import static org.testng.Assert.assertTrue;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.Keys;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import screenshotOnFailure.FailScreenshot;

@Listeners(screenshotListners.EventList.class)
public class FooterSettings extends FailScreenshot {

	@Test 
	public void Member_Settings() throws InterruptedException {
	
		/* Login to the Application - PBC */ 		
	  	driver.findElement(By.xpath("(//button[normalize-space()='Login'])[1]")).click();
		driver.findElement(By.xpath("//input[@id='Username']")).click();
		driver.findElement(By.xpath("//input[@id='Username']")).sendKeys("john.doe004");
		driver.findElement(By.xpath("//input[@id='password-field']")).click();
		driver.findElement(By.xpath("//input[@id='password-field']")).sendKeys("Rockon123");
		driver.findElement(By.xpath("//button[@id='loginButton']")).click();
		Thread.sleep(2000);
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(120));
	   
	    /* Footer - Apply for Ambassador Program */
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'My Profile')]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'My Profile')]")));Thread.sleep(2000);
//	    driver.findElement(By.xpath("//div[contains(text(),'My Profile')]")).click();
//	    Thread.sleep(2000);
//	    driver.findElement(By.cssSelector(".col-12 > .btn-lg")).click();
//	    Thread.sleep(2000);
//	    driver.findElement(By.linkText("Ok")).click();
//	    Thread.sleep(2000);
//	    driver.findElement(By.linkText("Ambassador Program")).click();
//	    Thread.sleep(2000);
//	    driver.findElement(By.linkText("Learn more about the program")).click();
//	    Thread.sleep(2000);
//	    driver.findElement(By.cssSelector(".btn-lg")).click();
//	    Thread.sleep(2000);
//	    driver.findElement(By.linkText("Ok")).click();
//	    Thread.sleep(2000);
	    
	    /* Footer - Give Feedback */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[normalize-space()='Feedback']")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[normalize-space()='Feedback']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//a[normalize-space()='Feedback']")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.id("Name")).click();
	    driver.findElement(By.id("Name")).sendKeys("Lolita Ilhan");
	    driver.findElement(By.id("Email")).click();
	    driver.findElement(By.id("Email")).sendKeys("Ifthytest@gmail.com");
	    Thread.sleep(2000);
	    driver.findElement(By.id("textFeedback")).click();
	    driver.findElement(By.id("textFeedback")).sendKeys("Good Creation, Finale Created your dream product");
	    Thread.sleep(2000);
	    driver.findElement(By.id("textFeedback")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.id("IsUseful")).click();
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()='SEND']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//span[normalize-space()='SEND']")).click();
	    Thread.sleep(2000);
	    
	    /* Footer - Contact us */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.linkText("Contact Us")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.linkText("Contact Us")));Thread.sleep(2000);
	    driver.findElement(By.linkText("Contact Us")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.id("Name")).click();
	    driver.findElement(By.id("Name")).sendKeys("Lolita Ilhan");
	    driver.findElement(By.id("Email")).click();
	    driver.findElement(By.id("Email")).sendKeys("Ifthytest@gmail.com");
	    driver.findElement(By.id("Company")).click();
	    driver.findElement(By.id("Company")).sendKeys("Tescras");
	    driver.findElement(By.id("Phone")).click();
	    driver.findElement(By.id("Phone")).sendKeys("9886755210");
	    driver.findElement(By.id("Comments")).click();
	    driver.findElement(By.id("Comments")).sendKeys("Need to Discussion on investments");
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.elementToBeClickable(By.id("btnInvestorsSubmit")));Thread.sleep(2000);
	    driver.findElement(By.id("btnInvestorsSubmit")).click();
	    Thread.sleep(2000);
	    
	    /* Navigate to Settings page */
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'My Profile')]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'My Profile')]")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[contains(text(),'My Profile')]")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.linkText("Settings")).click();
	    
	    /* Add & Change Username */	    
	    {
	      WebElement element = driver.findElement(By.cssSelector(".set-add-user-link-btn"));
	      Boolean isEditable = element.isEnabled() && element.getAttribute("readonly") == null;
	      assertTrue(isEditable);
	    }
	    driver.findElement(By.cssSelector(".set-add-user-link-btn")).click();
	    Thread.sleep(2000);
	    
	    /* BVA with 2 character and 16 characters */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("UserName")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.id("UserName")));Thread.sleep(2000);
	    driver.findElement(By.id("UserName")).click();
	    driver.findElement(By.id("UserName")).clear();Thread.sleep(2000);
	    driver.findElement(By.id("UserName")).sendKeys("ab");
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("//span[normalize-space()='Update']")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.id("UserName")).clear();Thread.sleep(2000);
	    driver.findElement(By.id("UserName")).sendKeys("abcdefghijklmnop");
		wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".toast-message")));
	    driver.findElement(By.cssSelector(".toast-message")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.id("UserName")).clear();Thread.sleep(2000);
	    driver.findElement(By.id("UserName")).sendKeys("personal");
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@id='userName']/form/div/div/div/div[2]/div")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[@id='userName']/form/div/div/div/div[2]/div")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("CurrentPassword")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.id("CurrentPassword")));Thread.sleep(2000);
	    driver.findElement(By.id("CurrentPassword")).sendKeys("Rockon123");
	    driver.findElement(By.id("CurrentPassword")).sendKeys(Keys.ENTER);
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".set-add-user-link-btn")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".set-add-user-link-btn")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".set-add-user-link-btn")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("UserName")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.id("UserName")));Thread.sleep(2000);
	    driver.findElement(By.id("UserName")).click();
	    driver.findElement(By.id("UserName")).clear();
	    Thread.sleep(2000);
	    driver.findElement(By.id("UserName")).sendKeys("john.doe004");
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("CurrentPassword")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.id("CurrentPassword")));Thread.sleep(2000);
	    driver.findElement(By.id("CurrentPassword")).sendKeys("Rockon123");
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".row:nth-child(2) .btn-sm")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".row:nth-child(2) .btn-sm")).click();
	    Thread.sleep(2000);
	    
	    /* Change First and Last name */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("FirstName")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.id("FirstName")));Thread.sleep(2000);
	    driver.findElement(By.id("FirstName")).click();
	    driver.findElement(By.id("FirstName")).clear();
	    Thread.sleep(2000);
	    driver.findElement(By.id("FirstName")).sendKeys("mmmmmmmmmmmmmmmmmmmm");
	    Thread.sleep(2000);
	    driver.findElement(By.id("FirstName")).clear();
	    Thread.sleep(2000);
	    driver.findElement(By.id("FirstName")).sendKeys("Ilhan");
	    Thread.sleep(2000);
	    driver.findElement(By.id("LastName")).click();
	    driver.findElement(By.id("LastName")).clear();
	    Thread.sleep(2000);
	    driver.findElement(By.id("LastName")).sendKeys("kkkkkkkkkkkkkkkkkkkk");
	    Thread.sleep(2000);
	    driver.findElement(By.id("LastName")).clear();
	    Thread.sleep(2000);
	    driver.findElement(By.id("LastName")).sendKeys("Lolita");
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".fa-calendar")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".year:nth-child(3)")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".month:nth-child(8)")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector("tr > .active")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.id("SecondaryEmail")).click();
	    driver.findElement(By.id("SecondaryEmail")).clear();
	    driver.findElement(By.id("SecondaryEmail")).sendKeys("ahmed.tescra.com");
	    driver.findElement(By.id("PrimaryEmail")).click();
	    driver.findElement(By.id("SecondaryEmail")).clear();
	    driver.findElement(By.id("SecondaryEmail")).sendKeys("iftikhar12@tescra.com");
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".input-validation-valid > .select2-selection__arrow")).click();
	    driver.findElement(By.cssSelector(".select2-search__field")).sendKeys("+98");
	    driver.findElement(By.cssSelector(".select2-search__field")).sendKeys(Keys.ENTER);
	    Thread.sleep(2000);
	    driver.findElement(By.id("PrimaryPhoneNumber")).click();
	    driver.findElement(By.id("PrimaryPhoneNumber")).clear();
	    driver.findElement(By.id("PrimaryPhoneNumber")).sendKeys("98765");
	    Thread.sleep(2000);
	    driver.findElement(By.id("PrimaryPhoneNumber")).clear();
	    driver.findElement(By.id("PrimaryPhoneNumber")).sendKeys("9876543276543769");
	    Thread.sleep(2000);
	    driver.findElement(By.id("PrimaryPhoneNumber")).clear();
	    driver.findElement(By.id("PrimaryPhoneNumber")).sendKeys("9876594327");
	    Thread.sleep(2000);
	    driver.findElement(By.id("select2-SecondaryAreaCode-container")).click();
	    driver.findElement(By.cssSelector(".select2-search__field")).sendKeys("+91");
	    driver.findElement(By.cssSelector(".select2-search__field")).sendKeys(Keys.ENTER);
	    Thread.sleep(2000);
	    driver.findElement(By.id("SecondaryPhoneNumber")).click();
	    driver.findElement(By.id("SecondaryPhoneNumber")).clear();
	    driver.findElement(By.id("SecondaryPhoneNumber")).sendKeys("986756");
	    Thread.sleep(2000);
	    driver.findElement(By.id("SecondaryPhoneNumber")).clear();
	    driver.findElement(By.id("SecondaryPhoneNumber")).sendKeys("9867566765656564");
	    Thread.sleep(2000);
	    driver.findElement(By.id("SecondaryPhoneNumber")).clear();
	    driver.findElement(By.id("SecondaryPhoneNumber")).sendKeys("9867566546");
	    Thread.sleep(2000);
	    driver.findElement(By.id("pac-input")).click();	  
	    driver.findElement(By.id("pac-input")).clear();
	    Thread.sleep(2000);
	    driver.findElement(By.id("pac-input")).sendKeys("Bangalore");
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id=\"formPersonalSettings\"]/div/div[3]/div[3]/div[1]/div[2]/div[1]/div[2]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@id=\"formPersonalSettings\"]/div/div[3]/div[3]/div[1]/div[2]/div[1]/div[2]")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//*[@id=\"formPersonalSettings\"]/div/div[3]/div[3]/div[1]/div[2]/div[1]/div[2]")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.id("pac-input1")).click();
	    driver.findElement(By.id("pac-input1")).clear();
	    Thread.sleep(2000);
	    driver.findElement(By.id("pac-input1")).sendKeys("San Ramon");
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id=\"formPersonalSettings\"]/div/div[3]/div[3]/div[2]/div[2]/div/div[1]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@id=\"formPersonalSettings\"]/div/div[3]/div[3]/div[2]/div[2]/div/div[1]")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//form/div/div[3]/div[3]/div[2]/div[2]/div/div[3]")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".set-personal-savebtn")).click();
		wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".toast-message")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".toast-message")).click();
	    Thread.sleep(2000);
	    
	    /* Try to Delete Account */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("linkSocialSettings")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.id("linkSocialSettings")));Thread.sleep(2000);
	    driver.findElement(By.id("linkSocialSettings")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.id("delete-btn")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".form-group:nth-child(2) > #Password")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".form-group:nth-child(2) > #Password")).sendKeys("Rockon12345");
	    driver.findElement(By.cssSelector(".form-group:nth-child(2) > #Password")).sendKeys(Keys.ENTER);
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".modal-error-btnn:nth-child(1)")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.id("deny-btn")).click();
	    Thread.sleep(2000);
	    
	    /* Subscription & Orders from Menu and Cancel the Modal */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[normalize-space()='Subscription & Orders']")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[normalize-space()='Subscription & Orders']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//button[normalize-space()='Subscription & Orders']")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[contains(text(),'Verify')]")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[contains(text(),'Verify')]")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//span[contains(text(),'Verify')]")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@id='paymentPasswordModal']//i[@class='fa fa-times']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[@id='paymentPasswordModal']//i[@class='fa fa-times']")).click();
	    
	    /* Work Preference */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[contains(text(),\'Work Preference\')]")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[contains(text(),\'Work Preference\')]")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//button[contains(text(),\'Work Preference\')]")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.name("CurrentlyLooking")).click();
	    driver.findElement(By.xpath("//div[@id=\'preferenceModal\']/div/div/div[2]/form/div[2]/div[2]/div/div[2]/label/input")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.id("Remote")).click();Thread.sleep(2000);
	    driver.findElement(By.id("WillingToTravel")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.id("WillingToRelocate")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[@id=\'preferenceModal\']/div/div/div[2]/form/div[2]/div[4]/div/div[2]")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.id("WillingToTravel")).click();Thread.sleep(2000);
	    driver.findElement(By.id("Remote")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.id("NoticePeriod")).click();
	    driver.findElement(By.id("NoticePeriod")).clear();
	    driver.findElement(By.id("NoticePeriod")).sendKeys("68");
	    Thread.sleep(2000);
	    driver.findElement(By.id("NoticePeriod")).click();
	    driver.findElement(By.id("NoticePeriod")).clear();
	    driver.findElement(By.id("NoticePeriod")).sendKeys("2");
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector("#btnPreferenceCancel .fa")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.id("btnNoConfirmYesNo")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.id("NoticePeriod")).click();
	    driver.findElement(By.id("NoticePeriod")).clear();
	    driver.findElement(By.id("NoticePeriod")).sendKeys("4");
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector("#btnPreferenceCancel .fa")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.id("btnYesConfirmYesNo")).click();
	    Thread.sleep(2000);
	    
	    /* Manage Payments - Member side from Header */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'My Profile')]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'My Profile')]")));Thread.sleep(1500);
		driver.findElement(By.xpath("//div[contains(text(),'My Profile')]")).click();
	    Thread.sleep(1500);	
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'Subscription and Orders')]")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'Subscription and Orders')]")));Thread.sleep(1500);
	    driver.findElement(By.xpath("//div[contains(text(),'Subscription and Orders')]")).click();
	    Thread.sleep(1500);	
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[normalize-space()='Subscription & Orders']")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[normalize-space()='Subscription & Orders']")));Thread.sleep(1500);
	    driver.findElement(By.xpath("//button[normalize-space()='Subscription & Orders']")).click();
	    Thread.sleep(1500);	
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("Password")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.id("Password")));Thread.sleep(2000);
	    driver.findElement(By.id("Password")).click();
	    driver.findElement(By.id("Password")).sendKeys("Rockon123");
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@id=\'paymentPasswordModal\']/div[2]/div[2]/div[2]/span/button")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[@id=\'paymentPasswordModal\']/div[2]/div[2]/div[2]/span/button")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.linkText("ORDERS")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.linkText("ORDERS")));Thread.sleep(2000);
	    driver.findElement(By.linkText("ORDERS")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".history-coaching-title")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".history-coaching-title")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".history-coaching-title")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector("#modalsettingtaskdetailpopup .fa")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.elementToBeClickable(By.linkText("SUBSCRIPTION")));Thread.sleep(2000);
	    driver.findElement(By.linkText("SUBSCRIPTION")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[3]/div[2]/div/div/span/a/i")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[3]/div[2]/div/div/span/a/i")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[3]/div[2]/div/div/span/a/i")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("btnPrimeMembership")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.id("btnPrimeMembership")));Thread.sleep(2000);
	    driver.findElement(By.id("btnPrimeMembership")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("td .btn:nth-child(2)")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector("td .btn:nth-child(2)")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector("td .btn:nth-child(2)")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("td .btn:nth-child(1)")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector("td .btn:nth-child(1)")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector("td .btn:nth-child(1)")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("td > .biz-plans-head .btn-sm")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector("td > .biz-plans-head .btn-sm")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector("td > .biz-plans-head .btn-sm")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("btnReviewOrder")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.id("btnReviewOrder")));Thread.sleep(2000);
	    driver.findElement(By.id("btnReviewOrder")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("btnEditOrder")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.id("btnEditOrder")));Thread.sleep(2000);
	    driver.findElement(By.id("btnEditOrder")).click();Thread.sleep(2000);
	    wait.until(ExpectedConditions.invisibilityOfElementLocated(By.id("btnEditOrder")));
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".modal-prime > .modal-header .fa")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".modal-prime > .modal-header .fa")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".modal-prime > .modal-header .fa")).click();
	    Thread.sleep(5000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("btnPrimeMembership")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.id("btnPrimeMembership")));Thread.sleep(2000);
	    driver.findElement(By.id("btnPrimeMembership")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("btnPrimeFAQ")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.id("btnPrimeFAQ")));Thread.sleep(2000);
	    driver.findElement(By.id("btnPrimeFAQ")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector("#modalPrimeFAQ .fa")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector("#modalPrimeFAQ .fa")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".modal-dialog:nth-child(3) .modal-header .fa")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".modal-dialog:nth-child(3) .modal-header .fa")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("#divAddPaymentMethod > .btnAddPaymentMethod")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector("#divAddPaymentMethod > .btnAddPaymentMethod")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector("#divAddPaymentMethod > .btnAddPaymentMethod")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("addBtn")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.id("addBtn")));Thread.sleep(2000);
	    driver.findElement(By.id("addBtn")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".modal-dialog:nth-child(2) .modal-header .fa")));Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".modal-dialog:nth-child(2) .modal-header .fa")).click();
	    Thread.sleep(2000);
	    
	    /* Logout from Settings */
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'My Profile')]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'My Profile')]")));Thread.sleep(2000);
		driver.findElement(By.xpath("//div[contains(text(),'My Profile')]")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("(//div[contains(text(),'Logout')])[2]")).click();
		Thread.sleep(2000);
	  }
	}

