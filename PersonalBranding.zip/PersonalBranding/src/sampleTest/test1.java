package sampleTest;

import org.testng.annotations.Test;
import java.io.IOException;
import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Listeners;
import screenshotOnFailure.FailScreenshot;

@Listeners(screenshotListners.EventList.class)
public class test1 extends FailScreenshot {
	
@Test
public void VaultPagination() throws InterruptedException, IOException {			
		
	/* Login to the Application */ 		
  	driver.findElement(By.xpath("(//button[normalize-space()='Login'])[1]")).click();
	driver.findElement(By.xpath("//input[@id='Username']")).click();
	driver.findElement(By.xpath("//input[@id='Username']")).sendKeys("ifthy");
	driver.findElement(By.xpath("//input[@id='password-field']")).click();
	driver.findElement(By.xpath("//input[@id='password-field']")).sendKeys("Rockon123");
	driver.findElement(By.xpath("//button[@id='loginButton']")).click();
	Thread.sleep(2000);
	WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(120));	 
		 
		/* Navigate to the Profile Builder */
	 wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'My Profile')]")));
	 wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'My Profile')]")));
	 Thread.sleep(2000);
	 {
	     WebElement element = driver.findElement(By.xpath("//div[@class='menu-item menu-item-active']"));
	     Actions builder = new Actions(driver);
	     builder.moveToElement(element).perform();
	 }
	 Thread.sleep(2000);
	 wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'Personality Assessment')]")));
	 wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'Personality Assessment')]")));Thread.sleep(2000);
	 driver.findElement(By.cssSelector(".menu-item:nth-child(11) .menu-label")).click();
	 Thread.sleep(2000);
	 
	 /* Logout */
	 wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'My Profile')]")));
	 wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'My Profile')]")));
	 driver.findElement(By.xpath("//div[contains(text(),'My Profile')]")).click();
	 Thread.sleep(2000);
	 wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//div[contains(text(),'Logout')])[2]")));
	 wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//div[contains(text(),'Logout')])[2]")));
	 driver.findElement(By.xpath("(//div[contains(text(),'Logout')])[2]")).click();
	 Thread.sleep(2000);
				
		// 	
	    
}	    

}

