package sampleTest;

import org.testng.annotations.Test;
import java.io.IOException;
import java.time.Duration;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Listeners;
import screenshotOnFailure.FailScreenshot;

@Listeners(screenshotListners.EventList.class)
public class test3 extends FailScreenshot {
	
@Test
public void XpathChanges() throws InterruptedException, IOException {
		driver.manage().window().maximize();
		
		/* Navigate to the PBC */ 		
		
		/* Open Dev tools */
		String openDevTools = Keys.chord(Keys.ALT, Keys.CONTROL, "i");
		driver.findElement(By.tagName("body")).sendKeys(openDevTools);
		
		/* Login to the Application */ 			
		driver.findElement(By.xpath("//button[normalize-space()='Login']")).click();
		driver.findElement(By.xpath("//input[@id='Username']")).click();
		driver.findElement(By.xpath("//input[@id='Username']")).sendKeys("ifthy");
		driver.findElement(By.xpath("//input[@id='password-field']")).click();
		driver.findElement(By.xpath("//input[@id='password-field']")).sendKeys("Rockon123");
		driver.findElement(By.xpath("//button[@id='loginButton']")).click();
		Thread.sleep(2000);
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(120));
	    
	    /* Navigate to the Resume from Hub */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'My Profile')]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'My Profile')]")));Thread.sleep(2000);
		
		/* Navigate to the Coach page */   
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[2]/div[1]/div[1]/div[2]/div[1]/div[1]/a[1]/span[1]")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[2]/div[1]/div[1]/div[2]/div[1]/div[1]/a[1]/span[1]")));Thread.sleep(2000);
		driver.findElement(By.xpath("//div[2]/div[1]/div[1]/div[2]/div[1]/div[1]/a[1]/span[1]")).click();
		Thread.sleep(2000);	
		
		/* Standard Trail */
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[normalize-space()='Manage Payments']")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()='Manage Payments']")));Thread.sleep(2000);
		driver.findElement(By.xpath("//span[normalize-space()='Manage Payments']")).click();
		Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[normalize-space()='RECEIVING BANK']")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()='RECEIVING BANK']")));Thread.sleep(2000);
		driver.findElement(By.xpath("//span[normalize-space()='RECEIVING BANK']")).click();
		Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[@class='close btnPreferenceCancel']//i[@class='fa fa-times']")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[@class='close btnPreferenceCancel']//i[@class='fa fa-times']")));Thread.sleep(2000);
		driver.findElement(By.xpath("//button[@class='close btnPreferenceCancel']//i[@class='fa fa-times']")).click();
		Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[normalize-space()='Edit']")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()='Edit']")));Thread.sleep(2000);
		driver.findElement(By.xpath("//span[normalize-space()='Edit']")).click();
		Thread.sleep(2000);
		
		/* Return from STRIPE Page */
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[contains(text(),\'Return to Achnet Inc\')]")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[contains(text(),\'Return to Achnet Inc\')]")));Thread.sleep(2000);
		driver.findElement(By.xpath("//span[contains(text(),\'Return to Achnet Inc\')]")).click();
		Thread.sleep(2000);
		
		try {
            // Check for the presence of an alert
            Alert alert = driver.switchTo().alert();

            // If an alert is present, handle it by clicking OK
            System.out.println("Alert is present!");
            alert.accept();
        } catch (Exception e) {
            // No alert is present, move on to the next element
            System.out.println("No alert is present. Moving on to the next element.");

            // Example: Click on a button
            WebElement button = driver.findElement(By.xpath("//input[@id='AccountNumber']"));
            button.click();
        }
					
		Thread.sleep(2000);
		/* Account and Routing Number */
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("AccountNumber")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.id("AccountNumber")));Thread.sleep(2000);
		driver.findElement(By.id("AccountNumber")).click();
		driver.findElement(By.id("AccountNumber")).sendKeys("000123456789");
		Thread.sleep(2000);		
	    	    	    
	    /* Logout from the social power */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".fa-ellipsis-v")));
		wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".fa-ellipsis-v")));Thread.sleep(2000);	
	    driver.findElement(By.cssSelector(".fa-ellipsis-v")).click();
	    Thread.sleep(2000);	
	    driver.findElement(By.linkText("Log off")).click();
	    Thread.sleep(2000);	
	  }

	}

	   
