package disputeAccept;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import screenshotOnFailure.FailScreenshot;

@Listeners(screenshotListners.EventList.class)
public class DA11_CreateProposal extends FailScreenshot{
	
	@Test
	public void DA_CreateProposal() throws InterruptedException {

	/* Login to the Application - PBC */ 		
	driver.findElement(By.xpath("(//button[normalize-space()='Login'])[1]")).click();
	driver.findElement(By.xpath("//input[@id='Username']")).click();
	driver.findElement(By.xpath("//input[@id='Username']")).sendKeys("john.doe003");
	driver.findElement(By.xpath("//input[@id='password-field']")).click();
	driver.findElement(By.xpath("//input[@id='password-field']")).sendKeys("Rockon123");
	driver.findElement(By.xpath("//button[@id='loginButton']")).click();
	Thread.sleep(2000);
	WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(120));    
    
	/* Navigate to the Coach Page */
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[2]/div[1]/div[1]/div[2]/div[1]/div[1]/a[1]/span[1]")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[2]/div[1]/div[1]/div[2]/div[1]/div[1]/a[1]/span[1]")));Thread.sleep(2000);
    driver.findElement(By.xpath("//div[2]/div[1]/div[1]/div[2]/div[1]/div[1]/a[1]/span[1]")).click();
    Thread.sleep(2000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[normalize-space()='Menu']")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()='Menu']")));Thread.sleep(2000);
    driver.findElement(By.xpath("//span[normalize-space()='Menu']")).click();
    Thread.sleep(2000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[normalize-space()='Coaching Services']")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[normalize-space()='Coaching Services']")));Thread.sleep(2000);
    driver.findElement(By.xpath("//a[normalize-space()='Coaching Services']")).click();
    Thread.sleep(2000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".ui-autocomplete-input")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".ui-autocomplete-input")));Thread.sleep(2000);
    driver.findElement(By.cssSelector(".ui-autocomplete-input")).click();
    driver.findElement(By.cssSelector(".ui-autocomplete-input")).sendKeys("CAREER");
    Thread.sleep(2000);
    driver.findElement(By.cssSelector(".ui-autocomplete-input")).sendKeys(Keys.ENTER);
    Thread.sleep(2000);
    
    /* View Details of Coach Request */
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div/div/div/div/div/div[3]/div/span")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div/div/div/div/div/div[3]/div/span")));Thread.sleep(2000);   
    driver.findElement(By.xpath("//span[normalize-space()=\'Robotic Process Automation\']")).click();
    Thread.sleep(2000);
    
    /* Start a Discussion */
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".btn-blue-link-12 > .d-none")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".btn-blue-link-12 > .d-none")));Thread.sleep(2000);  
    driver.findElement(By.cssSelector(".btn-blue-link-12 > .d-none")).click();
    Thread.sleep(2000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("TermsAndCondition")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.id("TermsAndCondition")));Thread.sleep(2000);  
    driver.findElement(By.id("TermsAndCondition")).click();
    Thread.sleep(2000);
    driver.findElement(By.cssSelector(".btn-lg")).click();
    Thread.sleep(2000);
    driver.findElement(By.id("discussiontextarea")).click();
    driver.findElement(By.id("discussiontextarea")).sendKeys("Hello am interested to guide you on your request");
    Thread.sleep(2000);
    driver.findElement(By.xpath("//button[contains(.,\'Send Message\')]")).click();
    Thread.sleep(2000);
    driver.findElement(By.cssSelector(".btn-blue-link-12")).click();
    Thread.sleep(2000);
    
    /* Create Proposal fron Discussion Menu */
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[@id=\'menuitemdiscussions\']")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[@id=\'menuitemdiscussions\']")));Thread.sleep(2000);
    driver.findElement(By.xpath("//a[@id=\'menuitemdiscussions\']")).click();
    Thread.sleep(2000);
    driver.findElement(By.cssSelector(".margin-right-15")).click();
    Thread.sleep(2000);
    driver.findElement(By.id("TermsAndCondition")).click();
    Thread.sleep(2000);
    driver.findElement(By.cssSelector(".btn-lg")).click();
    Thread.sleep(2000);
    driver.findElement(By.xpath("//div[@id=\'coachproposalpopup\']/div[2]/form/div/div/span[2]/input")).click();
    Thread.sleep(2000);
    driver.findElement(By.cssSelector(".float-right > .btn-sm")).click();
    Thread.sleep(2000);
    driver.findElement(By.id("view-more")).click();
    Thread.sleep(2000);
    driver.findElement(By.cssSelector("#coachingcancelpopup > .modal-header .fa")).click();
    Thread.sleep(2000);
    driver.findElement(By.id("ProposalTitle")).click();
    Thread.sleep(2000);
    driver.findElement(By.id("ProposalTitle")).clear();
    driver.findElement(By.id("ProposalTitle")).sendKeys("P");
    Thread.sleep(2000);
    driver.findElement(By.id("ProposalTitle")).clear();
    driver.findElement(By.id("ProposalTitle")).sendKeys("abcdefghijklmnopqrstuvwxyz-abcdefghijklmnopqrstuvwxyz");
    Thread.sleep(2000);
    driver.findElement(By.id("ProposalTitle")).clear();
    driver.findElement(By.id("ProposalTitle")).sendKeys("Robotic Process Automation with Bots");
    
    /* Proposal Description - TinyMCE */
    Thread.sleep(2000);
    driver.findElement(By.cssSelector("#mceu_6 .mce-ico")).click();
    Thread.sleep(2000);
    driver.findElement(By.cssSelector("#mceu_3 > button")).click();
    Thread.sleep(2000);
    
    /* Milestone Title */
    driver.findElement(By.xpath("//div[@id=\'addblanktask\']/div/div/input")).click();
    Thread.sleep(2000);
    driver.findElement(By.xpath("//div[@id=\'addblanktask\']/div/div/input")).sendKeys("123456789abcdefghijklmnopqrstuvwxyz12345678ABCDEFGI");
    driver.findElement(By.xpath("//div[@id=\'addblanktask\']/div/div/input")).clear();Thread.sleep(2000);
    driver.findElement(By.xpath("//div[@id=\'addblanktask\']/div/div/input")).sendKeys("RPA with Bots");
    Thread.sleep(2000);
    driver.findElement(By.xpath("//div[@id=\'addblanktask\']/div/div/input")).click();
    Thread.sleep(2000);
    
    /* Milestone Description - TinyMCE */
    driver.findElement(By.cssSelector("#mceu_27 .mce-ico")).click();
    Thread.sleep(2000);
    driver.findElement(By.cssSelector("#mceu_24 .mce-ico")).click();
    Thread.sleep(2000);
    driver.findElement(By.cssSelector(".divStartDatePicker .fa")).click();
    Thread.sleep(2000);
    driver.findElement(By.cssSelector(".year:nth-child(12)")).click();Thread.sleep(2000);
    driver.findElement(By.cssSelector(".month:nth-child(9)")).click();Thread.sleep(2000);
    driver.findElement(By.cssSelector("tr:nth-child(2) > .day:nth-child(1)")).click();
    Thread.sleep(2000);
    {
      WebElement element = driver.findElement(By.xpath("//div[@id=\'addblanktask\']/div/div[2]/div[2]/div/div[4]/div/span[2]/input"));
      Actions builder = new Actions(driver);
      builder.doubleClick(element).perform();
    }
    driver.findElement(By.xpath("//div[@id=\'addblanktask\']/div/div[2]/div[2]/div/div[4]/div/span[2]/input")).sendKeys("20");
    Thread.sleep(2000);
    driver.findElement(By.xpath("//div[@id=\'addblanktask\']/div/div/input")).click();
    Thread.sleep(2000);
    driver.findElement(By.cssSelector(".btn-blue")).click();Thread.sleep(2000);
    wait.until(ExpectedConditions.invisibilityOfElementLocated(By.cssSelector(".btn-blue")));
    
    /* Logout */
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'My Profile')]")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'My Profile')]")));Thread.sleep(2000);
	driver.findElement(By.xpath("//div[contains(text(),'My Profile')]")).click();  
	Thread.sleep(2000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//div[contains(text(),'Logout')])[1]")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//div[contains(text(),'Logout')])[1]")));Thread.sleep(2000);
	driver.findElement(By.xpath("(//div[contains(text(),'Logout')])[1]")).click();  
	Thread.sleep(2000);
  }
}

