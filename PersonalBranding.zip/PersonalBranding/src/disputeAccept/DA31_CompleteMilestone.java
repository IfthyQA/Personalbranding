package disputeAccept;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import screenshotOnFailure.FailScreenshot;

@Listeners(screenshotListners.EventList.class)
public class DA31_CompleteMilestone extends FailScreenshot{
	
	@Test
	public void DA_CompleteMilestone() throws InterruptedException {

	/* Login to the Application - PBC */ 		
	driver.findElement(By.xpath("(//button[normalize-space()='Login'])[1]")).click();
	driver.findElement(By.xpath("//input[@id='Username']")).click();
	driver.findElement(By.xpath("//input[@id='Username']")).sendKeys("john.doe003");
	driver.findElement(By.xpath("//input[@id='password-field']")).click();
	driver.findElement(By.xpath("//input[@id='password-field']")).sendKeys("Rockon123");
	driver.findElement(By.xpath("//button[@id='loginButton']")).click();
	Thread.sleep(2000);
	WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(120));    
    
	/* Navigate to the Coach Page */
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[2]/div[1]/div[1]/div[2]/div[1]/div[1]/a[1]/span[1]")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[2]/div[1]/div[1]/div[2]/div[1]/div[1]/a[1]/span[1]")));Thread.sleep(2000);
    driver.findElement(By.xpath("//div[2]/div[1]/div[1]/div[2]/div[1]/div[1]/a[1]/span[1]")).click();
    Thread.sleep(2000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[normalize-space()='Menu']")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()='Menu']")));Thread.sleep(2000);
    driver.findElement(By.xpath("//span[normalize-space()='Menu']")).click();
    Thread.sleep(2000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[normalize-space()='Coaching Services']")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[normalize-space()='Coaching Services']")));Thread.sleep(2000);
    driver.findElement(By.xpath("//a[normalize-space()='Coaching Services']")).click();
    Thread.sleep(2000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("menuiteminprogress")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.id("menuiteminprogress")));Thread.sleep(2000);
    driver.findElement(By.id("menuiteminprogress")).click();
    Thread.sleep(2000);
    driver.findElement(By.cssSelector(".margin-top-10 > .btn-blue-link-12")).click();
    Thread.sleep(2000);
    driver.findElement(By.cssSelector("#coachingcancelpopup > .modal-header .fa")).click();
    Thread.sleep(2000);
    driver.findElement(By.xpath("//div[2]/div/form/button")).click();
    Thread.sleep(2000);
    driver.findElement(By.cssSelector("#divWorkInProgressModal .modal-header .fa")).click();
    Thread.sleep(2000);
    driver.findElement(By.cssSelector(".btn-outline-blue")).click();
    Thread.sleep(2000);
    driver.findElement(By.cssSelector(".btn-blue-link-14")).click();
    Thread.sleep(2000);
    driver.findElement(By.xpath("//form/button")).click();
    Thread.sleep(2000);
    driver.findElement(By.xpath("//button[contains(.,\'Send Message\')]")).click();
    Thread.sleep(2000);
    driver.findElement(By.id("discussiontextarea")).click();
    driver.findElement(By.id("discussiontextarea")).sendKeys("We have  successfully completed the course. Thanks");
    Thread.sleep(2000);
    driver.findElement(By.xpath("//span[@class=\'titleAttach\']")).click();Thread.sleep(2000);
    driver.findElement(By.xpath("//button[@type=\'button\']//span[contains(text(),\'Business Vault\')]")).click();Thread.sleep(2000);
    Thread.sleep(2000);
    driver.findElement(By.xpath("//div[2]/i")).click();
    Thread.sleep(2000);
    driver.findElement(By.cssSelector(".btn")).click();
    Thread.sleep(2000);
    driver.findElement(By.xpath("//button[contains(.,\'Send Message\')]")).click();
    Thread.sleep(2000);
    driver.findElement(By.cssSelector(".fa-arrow-left")).click();
    Thread.sleep(2000);
    
    /* Complete Milestone */
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[2]/div/form/button")));
  	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[2]/div/form/button")));
    driver.findElement(By.xpath("//div[2]/div/form/button")).click();
    Thread.sleep(2000);
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("form > .btn-blue")));
  	wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector("form > .btn-blue")));
    driver.findElement(By.cssSelector("form > .btn-blue")).click();
    Thread.sleep(2000);
       
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".fa-angle-down")));
  	wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".fa-angle-down")));
    driver.findElement(By.cssSelector(".fa-angle-down")).click();
    Thread.sleep(2000);
    driver.findElement(By.cssSelector(".fa-angle-up")).click();
    Thread.sleep(2000);
    
    /* Logout */
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'My Profile')]")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'My Profile')]")));Thread.sleep(2000);
	driver.findElement(By.xpath("//div[contains(text(),'My Profile')]")).click();  
	Thread.sleep(2000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//div[contains(text(),'Logout')])[1]")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//div[contains(text(),'Logout')])[1]")));Thread.sleep(2000);
	driver.findElement(By.xpath("(//div[contains(text(),'Logout')])[1]")).click();  
	Thread.sleep(2000);
  }
}

