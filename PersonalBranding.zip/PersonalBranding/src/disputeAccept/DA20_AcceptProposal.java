package disputeAccept;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import screenshotOnFailure.FailScreenshot;

@Listeners(screenshotListners.EventList.class)
public class DA20_AcceptProposal extends FailScreenshot {
	
	@Test
	public void DA_AcceptProposal() throws InterruptedException {

		/* Login to the Application - PBC */ 		
	  	driver.findElement(By.xpath("(//button[normalize-space()='Login'])[1]")).click();
		driver.findElement(By.xpath("//input[@id='Username']")).click();
		driver.findElement(By.xpath("//input[@id='Username']")).sendKeys("john.doe006");
		driver.findElement(By.xpath("//input[@id='password-field']")).click();
		driver.findElement(By.xpath("//input[@id='password-field']")).sendKeys("Rockon123");
		driver.findElement(By.xpath("//button[@id='loginButton']")).click();
		Thread.sleep(2000);

		 WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(120));		
	    /* Navigate to Coaching Support */
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'My Profile')]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'My Profile')]")));
		Thread.sleep(2000);
		{
		     WebElement element = driver.findElement(By.xpath("//div[@class='menu-item menu-item-active']"));
		     Actions builder = new Actions(driver);
		     builder.moveToElement(element).perform();
		}
		Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'Coaching Support')]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'Coaching Support')]")));Thread.sleep(2000);
		driver.findElement(By.xpath("//div[contains(text(),'Coaching Support')]")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("a > .btn-blue-link-12")));
	    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector("a > .btn-blue-link-12")));Thread.sleep(1000);
	    driver.findElement(By.cssSelector("a > .btn-blue-link-12")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.linkText("Back To My Requests")).click();
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[contains(.,\'Accept\')]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[contains(.,\'Accept\')]")));
	    driver.findElement(By.xpath("//button[contains(.,\'Accept\')]")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".btn-sm:nth-child(3)")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.id("addBtnStripe")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".btn-grey")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".credit-card-list > div")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".btn-blue:nth-child(3)")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.id("btnNoConfirmYesNo")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".btn-blue:nth-child(3)")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.id("btnYesConfirmYesNo")).click();
	    Thread.sleep(2000);
	    
	    /* Try to Cancel the  Work */
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@id=\'divLeftMenu\']/div[4]/a")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@id=\'divLeftMenu\']/div[4]/a")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[@id=\'divLeftMenu\']/div[4]/a")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".margin-top-10 > .btn-blue-link-12")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector("#coachingcancelpopup > .modal-header .fa")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("//span[contains(.,\'View Details\')]")).click();
	    Thread.sleep(2000);
	    JavascriptExecutor jse = (JavascriptExecutor)driver;
	    jse.executeScript("window.scrollBy(0,250)");
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector(".btn-lg")).click();
	    Thread.sleep(15000);
	    driver.findElement(By.cssSelector(".btn-blue")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.cssSelector("#modalWorkCancel .modal-header .fa")).click();
	    Thread.sleep(2000);
	    
	    /* Logout */
		 wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'My Profile')]")));
		 wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'My Profile')]")));Thread.sleep(2000);
		 driver.findElement(By.xpath("//div[contains(text(),'My Profile')]")).click();
		 Thread.sleep(2000);
		 driver.findElement(By.xpath("(//div[contains(text(),'Logout')])[2]")).click();
		 Thread.sleep(2000);
	  }
	}

