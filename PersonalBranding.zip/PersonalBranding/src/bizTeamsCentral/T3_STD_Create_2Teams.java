package bizTeamsCentral;

import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import screenshotOnFailure.FailScreenshot;

@Listeners(screenshotListners.EventList.class)
public class T3_STD_Create_2Teams extends FailScreenshot{
	
	@Test
	public void Team_Std_3Teams() throws InterruptedException {
	
	/* Login to the Application - PBC */ 		
	driver.findElement(By.xpath("(//button[normalize-space()='Login'])[1]")).click();
	driver.findElement(By.xpath("//input[@id='Username']")).click();
	driver.findElement(By.xpath("//input[@id='Username']")).sendKeys("test.doe002");
	driver.findElement(By.xpath("//input[@id='password-field']")).click();
	driver.findElement(By.xpath("//input[@id='password-field']")).sendKeys("Rockon123");
	driver.findElement(By.xpath("//button[@id='loginButton']")).click();
	Thread.sleep(2000);
	WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(120));
    
    /* Navigate to the Business page */   
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[normalize-space()='Biz Teams Automat...']")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()='Biz Teams Automat...']")));Thread.sleep(2000);
    driver.findElement(By.xpath("//span[normalize-space()='Biz Teams Automat...']")).click();
    Thread.sleep(2000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[normalize-space()='Menu']")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()='Menu']")));Thread.sleep(2000);
    driver.findElement(By.xpath("//span[normalize-space()='Menu']")).click();
    Thread.sleep(2000);
    
    /* Navigate to the Manage Teams Cards */
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//a[normalize-space()='Team Central'])[1]")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//a[normalize-space()='Team Central'])[1]")));Thread.sleep(2000);
    driver.findElement(By.xpath("(//a[normalize-space()='Team Central'])[1]")).click();
    Thread.sleep(2000);   
    
    /* Create Teams and Cancel */
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'Create New Team')]")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'Create New Team')]")));Thread.sleep(2000);
    driver.findElement(By.xpath("//div[contains(text(),'Create New Team')]")).click();
    Thread.sleep(2000);
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[normalize-space()='Cancel']")));	
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[normalize-space()='Cancel']")));Thread.sleep(2000);
    driver.findElement(By.xpath("//button[normalize-space()='Cancel']")).click();
    Thread.sleep(2000);	
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[normalize-space()='Yes, Cancel']")));	
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[normalize-space()='Yes, Cancel']")));Thread.sleep(2000);
    driver.findElement(By.xpath("//button[normalize-space()='Yes, Cancel']")).click();
    Thread.sleep(2000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'Create New Team')]")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'Create New Team')]")));Thread.sleep(2000);
    driver.findElement(By.xpath("//div[contains(text(),'Create New Team')]")).click();
    Thread.sleep(2000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='close-img']")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@class='close-img']")));Thread.sleep(2000);
    driver.findElement(By.xpath("//div[@class='close-img']")).click();
    Thread.sleep(2000);
    driver.findElement(By.xpath("//button[normalize-space()='Go Back']")).click();
    Thread.sleep(2000);
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[normalize-space()='Cancel']")));	
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[normalize-space()='Cancel']")));Thread.sleep(2000);
    driver.findElement(By.xpath("//button[normalize-space()='Cancel']")).click();
    Thread.sleep(2000);	
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[normalize-space()='Yes, Cancel']")));	
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[normalize-space()='Yes, Cancel']")));Thread.sleep(2000);
    driver.findElement(By.xpath("//button[normalize-space()='Yes, Cancel']")).click();
    Thread.sleep(2000);
    
    /* Create 2nd Team */
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'Create New Team')]")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'Create New Team')]")));Thread.sleep(2000);
    driver.findElement(By.xpath("//div[contains(text(),'Create New Team')]")).click();
    Thread.sleep(2000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("teamName")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.id("teamName")));Thread.sleep(2000);
    driver.findElement(By.id("teamName")).click();
    driver.findElement(By.id("teamName")).sendKeys("!@#$%!@$.,123");Thread.sleep(2000);
    driver.findElement(By.id("teamName")).clear();Thread.sleep(2000);
    driver.findElement(By.id("teamName")).sendKeys("Recruit 002 Team");
    Thread.sleep(2000);
    driver.findElement(By.id("team-info")).click();
    driver.findElement(By.id("team-info")).sendKeys("!@#$%!@$.,123");Thread.sleep(2000);
    driver.findElement(By.id("team-info")).clear();Thread.sleep(2000);
    driver.findElement(By.id("team-info")).sendKeys("Creating Second team from Default page admin team");
    Thread.sleep(2000);

    JavascriptExecutor executor = (JavascriptExecutor)driver;    
    WebElement toggle = driver.findElement(By.id("isPublic"));
    executor.executeScript("arguments[0].click();", toggle);
	Thread.sleep(2000);
	
	WebElement toggle1 = driver.findElement(By.id("isRecruiter"));
    executor.executeScript("arguments[0].click();", toggle1);
	Thread.sleep(2000);
	
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[normalize-space()='Proceed to add members']")));	
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[normalize-space()='Proceed to add members']")));
    driver.findElement(By.xpath("//button[normalize-space()='Proceed to add members']")).click();
    Thread.sleep(2000);  
    
    /* Add 3 Members to the Team */
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("searchEmployee")));
    wait.until(ExpectedConditions.elementToBeClickable(By.id("searchEmployee")));	
    Thread.sleep(2000);	
    driver.findElement(By.xpath("//div[contains(text(),'Back to team details')]")).click(); // Click on Back
    Thread.sleep(2000); 
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[normalize-space()='Proceed to add members']")));	
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[normalize-space()='Proceed to add members']")));
    driver.findElement(By.xpath("//button[normalize-space()='Proceed to add members']")).click();
    Thread.sleep(2000);  
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("searchEmployee")));
    wait.until(ExpectedConditions.elementToBeClickable(By.id("searchEmployee")));
    driver.findElement(By.id("searchEmployee")).click();
    driver.findElement(By.id("searchEmployee")).clear();Thread.sleep(2000);
    driver.findElement(By.id("searchEmployee")).sendKeys("Shash");
    Thread.sleep(2000);
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'Shashi 7')]")));
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'Shashi 7')]")));Thread.sleep(2000);	
    driver.findElement(By.xpath("//div[contains(text(),'Shashi 7')]")).click();
    Thread.sleep(2000);	
     
    String winHandleBefore = driver.getWindowHandle();Thread.sleep(3000);
    driver.findElement(By.xpath("//div[@title='Shashi 7']")).click();Thread.sleep(3000);  	/* VIEW PUBLIC PROFILE - Member Name */ 	
	for(String winHandle : driver.getWindowHandles()){
    driver.switchTo().window(winHandle);Thread.sleep(3000);
	}
    driver.close();Thread.sleep(3000);
    driver.switchTo().window(winHandleBefore);
    Thread.sleep(2000);	
    
    String winHandleBefore1 = driver.getWindowHandle();Thread.sleep(3000);
    driver.findElement(By.xpath("//div[@class='container-fluid emp-cont']//div[2]//div[1]//a[1]//img[1]")).click();Thread.sleep(3000);   /* VIEW PUBLIC PROFILE - Member Pic */ 	
	for(String winHandle : driver.getWindowHandles()){
    driver.switchTo().window(winHandle);Thread.sleep(3000);
	}
    driver.close();Thread.sleep(3000);
    driver.switchTo().window(winHandleBefore1);
    Thread.sleep(2000);
    
    driver.findElement(By.xpath("//*[name()='path' and @id='Icon']")).click(); // Remove the added person
    Thread.sleep(2000);	
    driver.findElement(By.id("searchEmployee")).click(); // First Member
    driver.findElement(By.id("searchEmployee")).clear();Thread.sleep(2000);
    driver.findElement(By.id("searchEmployee")).sendKeys("Shash");
    Thread.sleep(2000);
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//ul[1]/li[1]/div[1]/div[2]")));
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//ul[1]/li[1]/div[1]/div[2]")));Thread.sleep(2000);	
    driver.findElement(By.xpath("//ul[1]/li[1]/div[1]/div[2]")).click();
    Thread.sleep(2000);	
    driver.findElement(By.xpath("//div[contains(text(),'Select Access Level')]")).click();
    Thread.sleep(2000);
    driver.findElement(By.xpath("//div[@class='ml-1'][normalize-space()='Admin']")).click();
    Thread.sleep(2000);    

    driver.findElement(By.id("searchEmployee")).click(); // Second Member
    driver.findElement(By.id("searchEmployee")).clear();Thread.sleep(2000);
    driver.findElement(By.id("searchEmployee")).sendKeys("kumar");
    Thread.sleep(2000);
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//ul[1]/li[1]/div[1]/div[2]")));
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//ul[1]/li[1]/div[1]/div[2]")));Thread.sleep(2000);	
    driver.findElement(By.xpath("//ul[1]/li[1]/div[1]/div[2]")).click();
    Thread.sleep(2000);	
    driver.findElement(By.xpath("//div[contains(text(),'Select Access Level')]")).click();
    Thread.sleep(2000);
    driver.findElement(By.xpath("//div[@class='ml-1'][normalize-space()='Editor']")).click();
    Thread.sleep(2000);
 
    driver.findElement(By.id("searchEmployee")).click(); // Try to Third Member
    driver.findElement(By.id("searchEmployee")).clear();Thread.sleep(2000);
    driver.findElement(By.id("searchEmployee")).sendKeys("Adam");
    Thread.sleep(2000);
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//ul[1]/li[1]/div[1]/div[2]")));
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//ul[1]/li[1]/div[1]/div[2]")));Thread.sleep(2000);	
    driver.findElement(By.xpath("//ul[1]/li[1]/div[1]/div[2]")).click();
    Thread.sleep(2000);	
    driver.findElement(By.id("searchEmployee")).click();
    driver.findElement(By.id("searchEmployee")).clear();
    Thread.sleep(2000);	
    driver.findElement(By.xpath("//div[@class='search-icon-position']//*[name()='svg']")).click();
    Thread.sleep(2000);	
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[normalize-space()='Confirm']")));	
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[normalize-space()='Confirm']")));Thread.sleep(2000);
    driver.findElement(By.xpath("//button[normalize-space()='Confirm']")).click();
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[@class='teamName-toast']"))); // Toaster Message Click
    driver.findElement(By.xpath("//button[@aria-label='close']")).click();
    Thread.sleep(2000);	
    
    /* Create 3rd Team of STANDARD PRIME User */
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'Create New Team')]")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'Create New Team')]")));Thread.sleep(2000);
    driver.findElement(By.xpath("//div[contains(text(),'Create New Team')]")).click();
    Thread.sleep(2000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("teamName")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.id("teamName")));Thread.sleep(2000);
    driver.findElement(By.id("teamName")).click();
    driver.findElement(By.id("teamName")).sendKeys("!@#$%!@$.,123");Thread.sleep(2000);
    driver.findElement(By.id("teamName")).clear();Thread.sleep(2000);
    driver.findElement(By.id("teamName")).sendKeys("Recruit 002 Team");
    Thread.sleep(2000);
    driver.findElement(By.id("team-info")).click();
    driver.findElement(By.id("team-info")).sendKeys("!@#$%!@$.,123");Thread.sleep(2000);
    driver.findElement(By.id("team-info")).clear();Thread.sleep(2000);
    driver.findElement(By.id("team-info")).sendKeys("Creating third team from Default page admin team");
    Thread.sleep(2000);
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[normalize-space()='Proceed to add members']")));	
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[normalize-space()='Proceed to add members']")));
    driver.findElement(By.xpath("//button[normalize-space()='Proceed to add members']")).click();
    Thread.sleep(2000);
    driver.findElement(By.id("teamName")).clear();Thread.sleep(2000);
    driver.findElement(By.id("teamName")).sendKeys("Recruit 003 Team");
    Thread.sleep(2000);
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[normalize-space()='Proceed to add members']")));	
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[normalize-space()='Proceed to add members']")));
    driver.findElement(By.xpath("//button[normalize-space()='Proceed to add members']")).click();
    Thread.sleep(2000);
    
    /* Add Members to the Team */ 
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("searchEmployee")));
    wait.until(ExpectedConditions.elementToBeClickable(By.id("searchEmployee")));
    driver.findElement(By.id("searchEmployee")).click();
    driver.findElement(By.id("searchEmployee")).clear();Thread.sleep(2000);
    driver.findElement(By.id("searchEmployee")).sendKeys("Shash");
    Thread.sleep(2000);
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//ul[1]/li[1]/div[1]/div[2]")));
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//ul[1]/li[1]/div[1]/div[2]")));Thread.sleep(2000);	
    driver.findElement(By.xpath("//ul[1]/li[1]/div[1]/div[2]")).click();
    Thread.sleep(2000);	
    WebElement toggle2 = driver.findElement(By.xpath("//div[3]/div[1]/div[1]/div[3]/div[1]/div[1]/label[1]")); // Show on Public - toggle
    executor.executeScript("arguments[0].click();", toggle2);
	Thread.sleep(2000);	
    driver.findElement(By.xpath("//div[contains(text(),'Select Access Level')]")).click();
    Thread.sleep(2000);
    driver.findElement(By.xpath("//div[@class='ml-1'][normalize-space()='Editor']")).click();
    Thread.sleep(2000);    
    
    driver.findElement(By.id("searchEmployee")).click(); // Second Member
    driver.findElement(By.id("searchEmployee")).clear();Thread.sleep(2000);
    driver.findElement(By.id("searchEmployee")).sendKeys("kumar 2");
    Thread.sleep(2000);
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//ul[1]/li[1]/div[1]/div[2]")));
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//ul[1]/li[1]/div[1]/div[2]")));Thread.sleep(2000);	
    driver.findElement(By.xpath("//ul[1]/li[1]/div[1]/div[2]")).click();
    Thread.sleep(2000);	
    driver.findElement(By.xpath("//div[contains(text(),'Select Access Level')]")).click();
    Thread.sleep(2000);
    driver.findElement(By.xpath("//div[@class='ml-1'][normalize-space()='Reader']")).click();
    Thread.sleep(2000);
    WebElement toggle3 = driver.findElement(By.xpath("//div[4]/div[1]/div[1]/div[3]/div[1]/div[1]/label[1]")); // Show on Public - toggle
    executor.executeScript("arguments[0].click();", toggle3);
	Thread.sleep(2000);	
 
    driver.findElement(By.id("searchEmployee")).click(); // Try to Third Member
    driver.findElement(By.id("searchEmployee")).clear();Thread.sleep(2000);
    driver.findElement(By.id("searchEmployee")).sendKeys("Adam");
    Thread.sleep(2000);
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//ul[1]/li[1]/div[1]/div[2]")));
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//ul[1]/li[1]/div[1]/div[2]")));Thread.sleep(2000);	
    driver.findElement(By.xpath("//ul[1]/li[1]/div[1]/div[2]")).click();
    Thread.sleep(2000);	
    driver.findElement(By.id("searchEmployee")).click();
    driver.findElement(By.id("searchEmployee")).clear();
    Thread.sleep(2000);	
    driver.findElement(By.xpath("//div[@class='search-icon-position']//*[name()='svg']")).click();
    Thread.sleep(2000);	
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[normalize-space()='Confirm']")));	
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[normalize-space()='Confirm']")));Thread.sleep(2000);
    driver.findElement(By.xpath("//button[normalize-space()='Confirm']")).click();
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[@class='teamName-toast']"))); // Toaster Message Click
    driver.findElement(By.xpath("//button[@aria-label='close']")).click();
    Thread.sleep(2000);	
    
    /* Create Fourth Team for STANDARD PRIME User - Subscription Modal - Cancel */
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'Create New Team')]")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'Create New Team')]")));Thread.sleep(2000);
    driver.findElement(By.xpath("//div[contains(text(),'Create New Team')]")).click();
    Thread.sleep(2000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='close-img']")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@class='close-img']")));Thread.sleep(2000);
    driver.findElement(By.xpath("//div[@class='close-img']")).click();
    Thread.sleep(2000);
    
    /* Create Fourth Team of STANDARD PRIME User  - Subscription Modal */
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'Create New Team')]")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'Create New Team')]")));Thread.sleep(2000);
    driver.findElement(By.xpath("//div[contains(text(),'Create New Team')]")).click();
    Thread.sleep(2000);
    
    /* VIEW PUBLIC PROFILE - Subscription pages  */ 
    String winHandleBefore2 = driver.getWindowHandle();Thread.sleep(3000);
    driver.findElement(By.xpath("//button[normalize-space()='View Available Plans']")).click();Thread.sleep(3000);  	  	
	for(String winHandle : driver.getWindowHandles()){
    driver.switchTo().window(winHandle);Thread.sleep(3000);
	}
    driver.close();Thread.sleep(3000);
    driver.switchTo().window(winHandleBefore2);
    Thread.sleep(3000);
    
    String winHandleBefore3 = driver.getWindowHandle();Thread.sleep(3000);
    driver.findElement(By.xpath("//button[normalize-space()='Upgrade to Prime Teams']")).click();Thread.sleep(3000);  	  	
	for(String winHandle : driver.getWindowHandles()){
    driver.switchTo().window(winHandle);Thread.sleep(3000);
	}
    driver.close();Thread.sleep(3000);
    driver.switchTo().window(winHandleBefore3);
    Thread.sleep(3000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='close-img']")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@class='close-img']")));Thread.sleep(2000);
    driver.findElement(By.xpath("//div[@class='close-img']")).click();
    Thread.sleep(2000);
    
    /* Logout */
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'My Profile')]")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'My Profile')]")));Thread.sleep(2000);
	driver.findElement(By.xpath("//div[contains(text(),'My Profile')]")).click();  
	Thread.sleep(2000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//div[contains(text(),'Logout')])[1]")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//div[contains(text(),'Logout')])[1]")));Thread.sleep(2000);
	driver.findElement(By.xpath("(//div[contains(text(),'Logout')])[1]")).click();  
	Thread.sleep(2000);
  }
}

