package bizTeamsCentral;

import java.io.IOException;
import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import screenshotOnFailure.FailScreenshot;

@Listeners(screenshotListners.EventList.class)
public class T7_BulkInvite_Local extends FailScreenshot{
	
	@Test
	public void Team_BulkInvites_fromLocal() throws InterruptedException, IOException {

	/* Login to the Application - PBC */ 		
	driver.findElement(By.xpath("(//button[normalize-space()='Login'])[1]")).click();
	driver.findElement(By.xpath("//input[@id='Username']")).click();
	driver.findElement(By.xpath("//input[@id='Username']")).sendKeys("test.doe002");
	driver.findElement(By.xpath("//input[@id='password-field']")).click();
	driver.findElement(By.xpath("//input[@id='password-field']")).sendKeys("Rockon123");
	driver.findElement(By.xpath("//button[@id='loginButton']")).click();
	Thread.sleep(2000);
	WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(120));
    
    /* Navigate to the Business page */   
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[normalize-space()='Biz Teams Automat...']")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()='Biz Teams Automat...']")));Thread.sleep(2000);
    driver.findElement(By.xpath("//span[normalize-space()='Biz Teams Automat...']")).click();
    Thread.sleep(2000);
    
    /* Navigate to the Teams  */
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[normalize-space()='Menu']")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()='Menu']")));Thread.sleep(2000);
    driver.findElement(By.xpath("//span[normalize-space()='Menu']")).click();
    Thread.sleep(2000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//a[normalize-space()='Team Central'])[1]")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//a[normalize-space()='Team Central'])[1]")));Thread.sleep(2000);
    driver.findElement(By.xpath("(//a[normalize-space()='Team Central'])[1]")).click();
    Thread.sleep(2000);   
    
    /* Bult Invite from Employee View - Cancel */
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[contains(text(),'Bulk Invite')]")));
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[contains(text(),'Bulk Invite')]")));Thread.sleep(2000);	
    driver.findElement(By.xpath("//button[contains(text(),'Bulk Invite')]")).click();
    Thread.sleep(2000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='close-img']")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@class='close-img']")));Thread.sleep(2000);
    driver.findElement(By.xpath("//div[@class='close-img']")).click();
    Thread.sleep(2000);
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[normalize-space()='Yes, Cancel']")));	
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[normalize-space()='Yes, Cancel']")));Thread.sleep(2000);
    driver.findElement(By.xpath("//button[normalize-space()='Yes, Cancel']")).click();
    Thread.sleep(2000);
    
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[contains(text(),'Bulk Invite')]")));
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[contains(text(),'Bulk Invite')]")));Thread.sleep(2000);	
    driver.findElement(By.xpath("//button[contains(text(),'Bulk Invite')]")).click();
    Thread.sleep(2000);
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[normalize-space()='Cancel']")));	
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[normalize-space()='Cancel']")));Thread.sleep(2000);
    driver.findElement(By.xpath("//button[normalize-space()='Cancel']")).click();
    Thread.sleep(2000);	
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[normalize-space()='Yes, Cancel']")));	
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[normalize-space()='Yes, Cancel']")));Thread.sleep(2000);
    driver.findElement(By.xpath("//button[normalize-space()='Yes, Cancel']")).click();
    Thread.sleep(2000);   
    
    /* Bulk Invite from Employee View - Download Template */
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[contains(text(),'Bulk Invite')]")));
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[contains(text(),'Bulk Invite')]")));Thread.sleep(2000);	
    driver.findElement(By.xpath("//button[contains(text(),'Bulk Invite')]")).click();
    Thread.sleep(2000);
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[normalize-space()='Download template']")));
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[normalize-space()='Download template']")));Thread.sleep(2000);	
    driver.findElement(By.xpath("//a[normalize-space()='Download template']")).click();
    Thread.sleep(2000);
    
    /* Bulk Invite from - Upload From Local */
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[normalize-space()='Click to upload']")));
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()='Click to upload']")));Thread.sleep(2000);	
    driver.findElement(By.xpath("//span[normalize-space()='Click to upload']")).click();
    Thread.sleep(2000);
	Runtime.getRuntime().exec("C:\\Users\\dev\\Documents\\AutoScripts\\BulkInvite.exe");
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@role='alert']"))); // Toaster Message Click
    driver.findElement(By.xpath("//button[@aria-label='close']")).click();   
    Thread.sleep(2000);
    
    /* Remove Email tag after the Uploaded File*/
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[12]//span[2]")));
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[12]//span[2]")));Thread.sleep(2000);	
    driver.findElement(By.xpath("//div[12]//span[2]")).click();
    Thread.sleep(2000);
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("bulkinvite")));
    wait.until(ExpectedConditions.elementToBeClickable(By.id("bulkinvite")));Thread.sleep(2000);	
    driver.findElement(By.id("bulkinvite")).click();
    driver.findElement(By.id("bulkinvite")).clear();Thread.sleep(2000);
    driver.findElement(By.id("bulkinvite")).sendKeys("Ifthy11@tescra.com");
	driver.findElement(By.id("bulkinvite")).sendKeys(Keys.ENTER);    
    Thread.sleep(2000);
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[contains(text(),'Confirm')]")));
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[contains(text(),'Confirm')]")));Thread.sleep(2000);	
    driver.findElement(By.xpath("//button[contains(text(),'Confirm')]")).click();
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@role='alert']"))); // Toaster Message Click
    driver.findElement(By.xpath("//button[@aria-label='close']")).click();    
    Thread.sleep(2000);
    
    /* Pending Invites */
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'See All')]")));
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'See All')]")));Thread.sleep(2000);	
    driver.findElement(By.xpath("//div[contains(text(),'See All')]")).click();
    Thread.sleep(2000);
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[contains(text(),'All Pending Invites')]")));
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[contains(text(),'All Pending Invites')]")));Thread.sleep(2000);	
    driver.findElement(By.xpath("//span[contains(text(),'All Pending Invites')]")).click();
    Thread.sleep(2000);
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'See All')]")));
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'See All')]")));Thread.sleep(2000);	
    driver.findElement(By.xpath("//div[contains(text(),'See All')]")).click();
    Thread.sleep(2000);
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[contains(text(),'Resend All Invites')]")));
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[contains(text(),'Resend All Invites')]")));Thread.sleep(2000);	
    driver.findElement(By.xpath("//button[contains(text(),'Resend All Invites')]")).click();
    Thread.sleep(2000);
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[normalize-space()='Cancel']")));	
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[normalize-space()='Cancel']")));Thread.sleep(2000);
    driver.findElement(By.xpath("//button[normalize-space()='Cancel']")).click();
    Thread.sleep(2000);	
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[contains(text(),'Resend All Invites')]")));
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[contains(text(),'Resend All Invites')]")));Thread.sleep(2000);	
    driver.findElement(By.xpath("//button[contains(text(),'Resend All Invites')]")).click();
    Thread.sleep(2000);
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[contains(text(),'Confirm')]")));
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[contains(text(),'Confirm')]")));Thread.sleep(2000);	
    driver.findElement(By.xpath("//button[contains(text(),'Confirm')]")).click();
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@role='alert']"))); // Toaster Message Click
    driver.findElement(By.xpath("//button[@aria-label='close']")).click();    
    Thread.sleep(2000);
    
    /* Cancel Pending Invites */
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'See All')]")));
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'See All')]")));Thread.sleep(2000);	
    driver.findElement(By.xpath("//div[contains(text(),'See All')]")).click();
    Thread.sleep(2000);
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[contains(text(),'Cancel Pending Invites')]")));
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[contains(text(),'Cancel Pending Invites')]")));Thread.sleep(2000);	
    driver.findElement(By.xpath("//button[contains(text(),'Cancel Pending Invites')]")).click();
    Thread.sleep(2000);
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[normalize-space()='Cancel']")));	
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[normalize-space()='Cancel']")));Thread.sleep(2000);
    driver.findElement(By.xpath("//button[normalize-space()='Cancel']")).click();
    Thread.sleep(2000);	
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[contains(text(),'Cancel Pending Invites')]")));
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[contains(text(),'Cancel Pending Invites')]")));Thread.sleep(2000);	
    driver.findElement(By.xpath("//button[contains(text(),'Cancel Pending Invites')]")).click();
    Thread.sleep(2000);
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[normalize-space()='Delete']")));	
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[normalize-space()='Delete']")));Thread.sleep(2000);
    driver.findElement(By.xpath("//button[normalize-space()='Delete']")).click();
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@role='alert']"))); // Toaster Message Click
    driver.findElement(By.xpath("//button[@aria-label='close']")).click();   
    Thread.sleep(2000);
    
    /* Logout */
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'My Profile')]")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'My Profile')]")));Thread.sleep(2000);
	driver.findElement(By.xpath("//div[contains(text(),'My Profile')]")).click();  
	Thread.sleep(2000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//div[contains(text(),'Logout')])[1]")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//div[contains(text(),'Logout')])[1]")));Thread.sleep(2000);
	driver.findElement(By.xpath("(//div[contains(text(),'Logout')])[1]")).click();  
	Thread.sleep(2000);
  }
}
