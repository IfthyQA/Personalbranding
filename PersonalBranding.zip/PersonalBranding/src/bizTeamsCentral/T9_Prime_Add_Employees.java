package bizTeamsCentral;

import java.io.IOException;
import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import screenshotOnFailure.FailScreenshot;

@Listeners(screenshotListners.EventList.class)
public class T9_Prime_Add_Employees extends FailScreenshot{
	
	@Test
	public void Team_AddMembers_ToTeam() throws InterruptedException, IOException {

	/* Login to the Application - PBC */ 		
	driver.findElement(By.xpath("(//button[normalize-space()='Login'])[1]")).click();
	driver.findElement(By.xpath("//input[@id='Username']")).click();
	driver.findElement(By.xpath("//input[@id='Username']")).sendKeys("test.doe002");
	driver.findElement(By.xpath("//input[@id='password-field']")).click();
	driver.findElement(By.xpath("//input[@id='password-field']")).sendKeys("Rockon123");
	driver.findElement(By.xpath("//button[@id='loginButton']")).click();
	Thread.sleep(2000);
	WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(120));
    
    /* Navigate to the Business page */   
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[normalize-space()='Biz Teams Automat...']")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()='Biz Teams Automat...']")));Thread.sleep(2000);
    driver.findElement(By.xpath("//span[normalize-space()='Biz Teams Automat...']")).click();
    Thread.sleep(2000);
    
    /* Navigate to the Teams */
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[normalize-space()='Menu']")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()='Menu']")));Thread.sleep(2000);
    driver.findElement(By.xpath("//span[normalize-space()='Menu']")).click();
    Thread.sleep(2000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//a[normalize-space()='Team Central'])[1]")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//a[normalize-space()='Team Central'])[1]")));Thread.sleep(2000);
    driver.findElement(By.xpath("(//a[normalize-space()='Team Central'])[1]")).click();
    Thread.sleep(2000);
    
    /* Team View */
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[contains(text(),'Team View')]")));
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[contains(text(),'Team View')]")));Thread.sleep(2000);	
    driver.findElement(By.xpath("//span[contains(text(),'Team View')]")).click();
    Thread.sleep(2000);
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//div[contains(text(),'View Employees')])[2]")));
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//div[contains(text(),'View Employees')])[2]")));
    driver.findElement(By.xpath("(//div[contains(text(),'View Employees')])[2]")).click();
    Thread.sleep(2000);
    driver.findElement(By.xpath("//div[contains(text(),'Hide Employees')]")).click();
    Thread.sleep(2000);
    
    /* Add Members to the Team - Recruit 002 Team */
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[2]/div[1]/div[1]/div[1]/div[1]/div[1]/div[2]/div[2]/div[2]/div[1]/div[3]")));
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[2]/div[1]/div[1]/div[1]/div[1]/div[1]/div[2]/div[2]/div[2]/div[1]/div[3]")));Thread.sleep(2000);
    {
	     WebElement element = driver.findElement(By.xpath("//div[2]/div[1]/div[1]/div[1]/div[1]/div[1]/div[2]/div[2]/div[2]/div[1]/div[3]"));
	     Actions builder = new Actions(driver);
	     builder.moveToElement(element).perform();
	} 
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[2]/div[2]/div/div[3]/div[1]/div/div/div[2]/span[1]")));
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[2]/div[2]/div/div[3]/div[1]/div/div/div[2]/span[1]")));Thread.sleep(2000);	
    driver.findElement(By.xpath("//div[2]/div[2]/div/div[3]/div[1]/div/div/div[2]/span[1]")).click();
    Thread.sleep(2000);
    
    /* Add to the Above Team */ 
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("searchEmployee"))); 			// 3rd Member
    wait.until(ExpectedConditions.elementToBeClickable(By.id("searchEmployee")));
    driver.findElement(By.id("searchEmployee")).click(); 
    driver.findElement(By.id("searchEmployee")).clear();Thread.sleep(2000);
    driver.findElement(By.id("searchEmployee")).sendKeys("kumar");
    Thread.sleep(2000);
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//ul[1]/li[1]/div[1]/div[2]")));
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//ul[1]/li[1]/div[1]/div[2]")));Thread.sleep(2000);	
    driver.findElement(By.xpath("//ul[1]/li[1]/div[1]/div[2]")).click();
    Thread.sleep(2000);	
    driver.findElement(By.xpath("//span[contains(text(),'Editor')]")).click();
    Thread.sleep(2000);
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[normalize-space()='Confirm']")));	
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[normalize-space()='Confirm']")));Thread.sleep(2000);
    driver.findElement(By.xpath("//button[normalize-space()='Confirm']")).click();
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@role='alert']"))); // Toaster Message Click
    driver.findElement(By.xpath("//button[@aria-label='close']")).click(); 
    
    /* Bulk Invite Registered Members to the Team */
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[contains(text(),'Bulk Invite')]")));
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[contains(text(),'Bulk Invite')]")));Thread.sleep(2000);	
    driver.findElement(By.xpath("//button[contains(text(),'Bulk Invite')]")).click();
    Thread.sleep(2000);
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[normalize-space()='Click to upload']")));
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()='Click to upload']")));Thread.sleep(2000);	
    driver.findElement(By.xpath("//span[normalize-space()='Click to upload']")).click();
    Thread.sleep(5000);
	Runtime.getRuntime().exec("C:\\Users\\dev\\Documents\\AutoScripts\\BulkInvite1.exe");
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@role='alert']"))); // Toaster Message Click
    driver.findElement(By.xpath("//button[@aria-label='close']")).click();   
    Thread.sleep(2000);  
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[contains(text(),'Confirm')]")));
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[contains(text(),'Confirm')]")));Thread.sleep(2000);	
    driver.findElement(By.xpath("//button[contains(text(),'Confirm')]")).click();
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@role='alert']"))); // Toaster Message Click
    driver.findElement(By.xpath("//button[@aria-label='close']")).click(); 
    Thread.sleep(2000);
    
    /* Scroll the Page Up */
    JavascriptExecutor jse = (JavascriptExecutor)driver;
    jse.executeScript("scroll(0, -250);");
    Thread.sleep(2000);
    
    /* Unnassigned Members to the Teams */
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'Unassigned Employees')]")));
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'Unassigned Employees')]")));Thread.sleep(2000);	
    driver.findElement(By.xpath("//div[contains(text(),'Unassigned Employees')]")).click();
    Thread.sleep(2000);
    
    /* Add 4th Member */
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("searchTeam")));
	wait.until(ExpectedConditions.elementToBeClickable(By.id("searchTeam")));Thread.sleep(2000);
    driver.findElement(By.id("searchTeam")).click();
    driver.findElement(By.id("searchTeam")).sendKeys("!@#$%!@$.,123");Thread.sleep(2000);
	driver.findElement(By.id("searchTeam")).sendKeys(Keys.ENTER);
	Thread.sleep(2000);
    driver.findElement(By.id("searchTeam")).clear();Thread.sleep(2000);
    driver.findElement(By.id("searchTeam")).sendKeys("Amit");
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@class='search-icon-position-team-view']//*[name()='svg']")));Thread.sleep(2000);	
    driver.findElement(By.xpath("//div[@class='search-icon-position-team-view']//*[name()='svg']")).click();
    Thread.sleep(2000);	
    {
	     WebElement element = driver.findElement(By.xpath("//div[@title='tanishaa0207+6@gmail.com']"));
	     Actions builder = new Actions(driver);
	     builder.moveToElement(element).perform();
	} 
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='assign-teams-unassigned mt-16']")));
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@class='assign-teams-unassigned mt-16']")));Thread.sleep(2000);	
    driver.findElement(By.xpath("//div[@class='assign-teams-unassigned mt-16']")).click();
    Thread.sleep(2000);
    
    /* Assign Team */
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//input[@id='searchTeam'])[2]")));
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//input[@id='searchTeam'])[2]")));Thread.sleep(2000);	
    driver.findElement(By.xpath("(//input[@id='searchTeam'])[2]")).click();
    Thread.sleep(2000);
    driver.findElement(By.xpath("(//input[@id='searchTeam'])[2]")).click();
    driver.findElement(By.xpath("(//input[@id='searchTeam'])[2]")).sendKeys("Recruit 002 Team Recreated after Delete");Thread.sleep(2000);
	driver.findElement(By.xpath("(//input[@id='searchTeam'])[2]")).sendKeys(Keys.ENTER);
	Thread.sleep(2000);
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'Recruit 002 Team Recreated after Delete')]")));
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'Recruit 002 Team Recreated after Delete')]")));Thread.sleep(2000);	
    driver.findElement(By.xpath("//div[contains(text(),'Recruit 002 Team Recreated after Delete')]")).click();
    Thread.sleep(2000);
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'Select Access Level')]")));
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'Select Access Level')]")));Thread.sleep(2000);	
    driver.findElement(By.xpath("//div[contains(text(),'Select Access Level')]")).click();
    Thread.sleep(2000);
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[normalize-space()='Admin']")));
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[normalize-space()='Admin']")));Thread.sleep(2000);	
    driver.findElement(By.xpath("//div[normalize-space()='Admin']")).click();
    Thread.sleep(2000);  
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[contains(text(),'Confirm')]")));
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[contains(text(),'Confirm')]")));Thread.sleep(2000);	
    driver.findElement(By.xpath("//button[contains(text(),'Confirm')]")).click();
    wait.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath("//button[contains(text(),'Confirm')]")));
    Thread.sleep(8000);
    
    /* Add 5th Member */
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[2]")));
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[2]")));Thread.sleep(2000);	
    driver.findElement(By.xpath("//div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[2]")).click();
    Thread.sleep(2000);
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'Unassigned Employees')]")));
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'Unassigned Employees')]")));Thread.sleep(2000);	
    driver.findElement(By.xpath("//div[contains(text(),'Unassigned Employees')]")).click();
    Thread.sleep(2000);
    {
	     WebElement element = driver.findElement(By.xpath("//div[2]/div[2]/div[2]/div[1]/div[1]/div[2]"));
	     Actions builder = new Actions(driver);
	     builder.moveToElement(element).perform();
	} 
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='assign-teams-unassigned mt-16']")));
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@class='assign-teams-unassigned mt-16']")));Thread.sleep(2000);	
    driver.findElement(By.xpath("//div[@class='assign-teams-unassigned mt-16']")).click();
    Thread.sleep(2000);
    
    /* Assign Team */
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[normalize-space()='Recruit 002 Team Recreated after Delete']")));
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[normalize-space()='Recruit 002 Team Recreated after Delete']")));Thread.sleep(2000);	
    driver.findElement(By.xpath("//div[normalize-space()='Recruit 002 Team Recreated after Delete']")).click();
    Thread.sleep(2000);
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'Select Access Level')]")));
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'Select Access Level')]")));Thread.sleep(2000);	
    driver.findElement(By.xpath("(//div[contains(text(),'Select Access Level')])[3]")).click();
    Thread.sleep(2000);
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[normalize-space()='Admin']")));
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[normalize-space()='Admin']")));Thread.sleep(2000);	
    driver.findElement(By.xpath("//div[normalize-space()='Admin']")).click();
    Thread.sleep(2000);  
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[contains(text(),'Confirm')]")));
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[contains(text(),'Confirm')]")));Thread.sleep(2000);	
    driver.findElement(By.xpath("//button[contains(text(),'Confirm')]")).click();
//    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@role='alert']"))); // Toaster Message Click
//    driver.findElement(By.xpath("//button[@aria-label='close']")).click(); 
    Thread.sleep(2000);
    
    /* Add 6th Member */
    {
	     WebElement element = driver.findElement(By.xpath("//div[2]/div[2]/div[2]/div[1]/div[1]/div[2]"));
	     Actions builder = new Actions(driver);
	     builder.moveToElement(element).perform();
	} 
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='assign-teams-unassigned mt-16']")));
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@class='assign-teams-unassigned mt-16']")));Thread.sleep(2000);	
    WebElement element = driver.findElement(By.xpath("//div[@class='assign-teams-unassigned mt-16']"));
    JavascriptExecutor js = (JavascriptExecutor)driver;
    js.executeScript("arguments[0].click();", element);	
    Thread.sleep(2000);
    
    /* Assign Team */
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[normalize-space()='Recruit 002 Team Recreated after Delete']")));
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[normalize-space()='Recruit 002 Team Recreated after Delete']")));Thread.sleep(2000);	
    driver.findElement(By.xpath("//div[normalize-space()='Recruit 002 Team Recreated after Delete']")).click();
    Thread.sleep(2000);
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'Select Access Level')]")));
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'Select Access Level')]")));Thread.sleep(2000);	
    driver.findElement(By.xpath("(//div[contains(text(),'Select Access Level')])[3]")).click();
    Thread.sleep(2000);
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[normalize-space()='Admin']")));
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[normalize-space()='Admin']")));Thread.sleep(2000);	
    driver.findElement(By.xpath("//div[normalize-space()='Admin']")).click();
    Thread.sleep(2000);  
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[contains(text(),'Confirm')]")));
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[contains(text(),'Confirm')]")));Thread.sleep(2000);	
    driver.findElement(By.xpath("//button[contains(text(),'Confirm')]")).click();
//    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@role='alert']"))); // Toaster Message Click
//    driver.findElement(By.xpath("//button[@aria-label='close']")).click(); 
    Thread.sleep(2000);
    
    /* Add 7th Member */
    {
	     WebElement element7 = driver.findElement(By.xpath("//div[2]/div[2]/div[2]/div[1]/div[1]/div[2]"));
	     Actions builder = new Actions(driver);
	     builder.moveToElement(element7).perform();
	} 
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='assign-teams-unassigned mt-16']")));
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@class='assign-teams-unassigned mt-16']")));Thread.sleep(2000);	
    driver.findElement(By.xpath("//div[@class='assign-teams-unassigned mt-16']")).click();
    Thread.sleep(2000);
    
    /* Assign Team */
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[normalize-space()='Recruit 002 Team Recreated after Delete']")));
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[normalize-space()='Recruit 002 Team Recreated after Delete']")));Thread.sleep(2000);	
    driver.findElement(By.xpath("//div[normalize-space()='Recruit 002 Team Recreated after Delete']")).click();
    Thread.sleep(2000);
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'Select Access Level')]")));
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'Select Access Level')]")));Thread.sleep(2000);	
    driver.findElement(By.xpath("(//div[contains(text(),'Select Access Level')])[3]")).click();
    Thread.sleep(2000);
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[normalize-space()='Admin']")));
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[normalize-space()='Admin']")));Thread.sleep(2000);	
    driver.findElement(By.xpath("//div[normalize-space()='Admin']")).click();
    Thread.sleep(2000);  
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[contains(text(),'Confirm')]")));
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[contains(text(),'Confirm')]")));Thread.sleep(2000);	
    driver.findElement(By.xpath("//button[contains(text(),'Confirm')]")).click();
//    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@role='alert']"))); // Toaster Message Click
//    driver.findElement(By.xpath("//button[@aria-label='close']")).click(); 
    Thread.sleep(2000);
    
    /* Add 8th Member */
    {
	     WebElement element8 = driver.findElement(By.xpath("//div[2]/div[2]/div[2]/div[1]/div[1]/div[2]"));
	     Actions builder = new Actions(driver);
	     builder.moveToElement(element8).perform();
	} 
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='assign-teams-unassigned mt-16']")));
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@class='assign-teams-unassigned mt-16']")));Thread.sleep(2000);	
    driver.findElement(By.xpath("//div[@class='assign-teams-unassigned mt-16']")).click();
    Thread.sleep(2000);
    
    /* Assign Team */
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[normalize-space()='Recruit 002 Team Recreated after Delete']")));
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[normalize-space()='Recruit 002 Team Recreated after Delete']")));Thread.sleep(2000);	
    driver.findElement(By.xpath("//div[normalize-space()='Recruit 002 Team Recreated after Delete']")).click();
    Thread.sleep(2000);
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'Select Access Level')]")));
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'Select Access Level')]")));Thread.sleep(2000);	
    driver.findElement(By.xpath("(//div[contains(text(),'Select Access Level')])[3]")).click();
    Thread.sleep(2000);
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[normalize-space()='Admin']")));
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[normalize-space()='Admin']")));Thread.sleep(2000);	
    driver.findElement(By.xpath("//div[normalize-space()='Admin']")).click();
    Thread.sleep(2000);  
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[contains(text(),'Confirm')]")));
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[contains(text(),'Confirm')]")));Thread.sleep(2000);	
    driver.findElement(By.xpath("//button[contains(text(),'Confirm')]")).click();
//    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@role='alert']"))); // Toaster Message Click
//    driver.findElement(By.xpath("//button[@aria-label='close']")).click(); 
    Thread.sleep(2000);
    
    /* Add 9th Member */
    {
	     WebElement element9 = driver.findElement(By.xpath("//div[2]/div[2]/div[2]/div[1]/div[1]/div[2]"));
	     Actions builder = new Actions(driver);
	     builder.moveToElement(element9).perform();
	} 
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='assign-teams-unassigned mt-16']")));
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@class='assign-teams-unassigned mt-16']")));Thread.sleep(2000);	
    driver.findElement(By.xpath("//div[@class='assign-teams-unassigned mt-16']")).click();
    Thread.sleep(2000);
    
    /* Assign Team */
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[normalize-space()='Recruit 002 Team Recreated after Delete']")));
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[normalize-space()='Recruit 002 Team Recreated after Delete']")));Thread.sleep(2000);	
    driver.findElement(By.xpath("//div[normalize-space()='Recruit 002 Team Recreated after Delete']")).click();
    Thread.sleep(2000);
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'Select Access Level')]")));
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'Select Access Level')]")));Thread.sleep(2000);	
    driver.findElement(By.xpath("(//div[contains(text(),'Select Access Level')])[3]")).click();
    Thread.sleep(2000);
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[normalize-space()='Admin']")));
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[normalize-space()='Admin']")));Thread.sleep(2000);	
    driver.findElement(By.xpath("//div[normalize-space()='Editor']")).click();
    Thread.sleep(2000);  
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[contains(text(),'Confirm')]")));
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[contains(text(),'Confirm')]")));Thread.sleep(2000);	
    driver.findElement(By.xpath("//button[contains(text(),'Confirm')]")).click();
//    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@role='alert']"))); // Toaster Message Click
//    driver.findElement(By.xpath("//button[@aria-label='close']")).click(); 
    Thread.sleep(2000);
    
    /* Add 10th Member */
    {
	     WebElement element10 = driver.findElement(By.xpath("//div[2]/div[2]/div[2]/div[1]/div[1]/div[2]"));
	     Actions builder = new Actions(driver);
	     builder.moveToElement(element10).perform();
	} 
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='assign-teams-unassigned mt-16']")));
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@class='assign-teams-unassigned mt-16']")));Thread.sleep(2000);	
    driver.findElement(By.xpath("//div[@class='assign-teams-unassigned mt-16']")).click();
    Thread.sleep(2000);
    
    /* Assign Team */
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[normalize-space()='Recruit 002 Team Recreated after Delete']")));
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[normalize-space()='Recruit 002 Team Recreated after Delete']")));Thread.sleep(2000);	
    driver.findElement(By.xpath("//div[normalize-space()='Recruit 002 Team Recreated after Delete']")).click();
    Thread.sleep(2000);
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'Select Access Level')]")));
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'Select Access Level')]")));Thread.sleep(2000);	
    driver.findElement(By.xpath("(//div[contains(text(),'Select Access Level')])[3]")).click();
    Thread.sleep(2000);
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[normalize-space()='Admin']")));
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[normalize-space()='Admin']")));Thread.sleep(2000);	
    driver.findElement(By.xpath("//div[normalize-space()='Reader']")).click();
    Thread.sleep(2000);  
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[contains(text(),'Confirm')]")));
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[contains(text(),'Confirm')]")));Thread.sleep(2000);	
    driver.findElement(By.xpath("//button[contains(text(),'Confirm')]")).click();
//    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@role='alert']"))); // Toaster Message Click
//    driver.findElement(By.xpath("//button[@aria-label='close']")).click(); 
    Thread.sleep(2000);
    
    /* Add 11th Member */
    {
	     WebElement element11 = driver.findElement(By.xpath("//div[2]/div[2]/div[2]/div[1]/div[1]/div[2]"));
	     Actions builder = new Actions(driver);
	     builder.moveToElement(element11).perform();
	} 
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='assign-teams-unassigned mt-16']")));
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@class='assign-teams-unassigned mt-16']")));Thread.sleep(2000);	
    driver.findElement(By.xpath("//div[@class='assign-teams-unassigned mt-16']")).click();
    Thread.sleep(2000);
    
    /* Assign Team */
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[normalize-space()='Recruit 002 Team Recreated after Delete']")));
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[normalize-space()='Recruit 002 Team Recreated after Delete']")));Thread.sleep(2000);	
    driver.findElement(By.xpath("//div[normalize-space()='Recruit 002 Team Recreated after Delete']")).click();
    Thread.sleep(2000);
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'Select Access Level')]")));
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'Select Access Level')]")));Thread.sleep(2000);	
    driver.findElement(By.xpath("(//div[contains(text(),'Select Access Level')])[3]")).click();
    Thread.sleep(2000);
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[normalize-space()='Admin']")));
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[normalize-space()='Admin']")));Thread.sleep(2000);	
    driver.findElement(By.xpath("//div[normalize-space()='Reader']")).click();
    Thread.sleep(2000);  
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[contains(text(),'Confirm')]")));
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[contains(text(),'Confirm')]")));Thread.sleep(2000);	
    driver.findElement(By.xpath("//button[contains(text(),'Confirm')]")).click();
    Thread.sleep(2000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='close-img']")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@class='close-img']")));Thread.sleep(2000);
    driver.findElement(By.xpath("//div[@class='close-img']")).click(); // Close the Pop Up - Addon
    Thread.sleep(2000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='close-img']")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@class='close-img']")));Thread.sleep(2000);
    driver.findElement(By.xpath("//div[@class='close-img']")).click();  // Close the Pop Up - Assign Team
    Thread.sleep(2000);
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[normalize-space()='Yes, Cancel']")));	
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[normalize-space()='Yes, Cancel']")));Thread.sleep(2000);
    driver.findElement(By.xpath("//button[normalize-space()='Yes, Cancel']")).click();
    Thread.sleep(2000);
    
    /* Delete Extra Employees */
    {
	     WebElement delete = driver.findElement(By.xpath("//div[2]/div[2]/div[2]/div[1]/div[1]/div[2]"));
	     Actions builder = new Actions(driver);
	     builder.moveToElement(delete).perform();
	}
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@title='Remove from Organization']")));
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@title='Remove from Organization']")));Thread.sleep(2000);	
    driver.findElement(By.xpath("//div[@title='Remove from Organization']")).click();
    Thread.sleep(2000); 
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[normalize-space()='Remove']")));
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[normalize-space()='Remove']")));Thread.sleep(2000);	
    driver.findElement(By.xpath("//button[normalize-space()='Remove']")).click();
    Thread.sleep(2000); 
       
    /* Logout from Hub */
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'My Profile')]")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'My Profile')]")));Thread.sleep(2000);
	driver.findElement(By.xpath("//div[contains(text(),'My Profile')]")).click();  
	Thread.sleep(2000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//div[contains(text(),'Logout')])[1]")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//div[contains(text(),'Logout')])[1]")));Thread.sleep(2000);
	driver.findElement(By.xpath("(//div[contains(text(),'Logout')])[1]")).click();  
	Thread.sleep(2000);
  }
}
