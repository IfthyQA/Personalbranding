package bizTeamsCentral;

import org.testng.annotations.Test;
import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Listeners;
import screenshotOnFailure.FailScreenshot;

@Listeners(screenshotListners.EventList.class)
public class T6_Prime_Create_11thTeam extends FailScreenshot{

	@Test
	public void Team_Dlt_Crt_11th_Team() throws InterruptedException {

		/* Login to the Application - PBC */ 		
	  	driver.findElement(By.xpath("(//button[normalize-space()='Login'])[1]")).click();
		driver.findElement(By.xpath("//input[@id='Username']")).click();
		driver.findElement(By.xpath("//input[@id='Username']")).sendKeys("test.doe002");
		driver.findElement(By.xpath("//input[@id='password-field']")).click();
		driver.findElement(By.xpath("//input[@id='password-field']")).sendKeys("Rockon123");
		driver.findElement(By.xpath("//button[@id='loginButton']")).click();
		Thread.sleep(2000);
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(120));
	    
	    /* Navigate to the Business page */   
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[normalize-space()='Biz Teams Automat...']")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()='Biz Teams Automat...']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//span[normalize-space()='Biz Teams Automat...']")).click();
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[normalize-space()='Menu']")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()='Menu']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//span[normalize-space()='Menu']")).click();
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//a[normalize-space()='Team Central'])[1]")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//a[normalize-space()='Team Central'])[1]")));Thread.sleep(2000);
	    driver.findElement(By.xpath("(//a[normalize-space()='Team Central'])[1]")).click();
	    Thread.sleep(2000);      	        
	    
	    /* Try for 11th team and takes to Prime Enterprise overlay */ 
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'Create New Team')]")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'Create New Team')]")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[contains(text(),'Create New Team')]")).click();
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='close-img']")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@class='close-img']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[@class='close-img']")).click();
	    Thread.sleep(2000);
	    
	    /* Create Fourth Team of STANDARD PRIME User  - Subscription Modal */
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'Create New Team')]")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'Create New Team')]")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[contains(text(),'Create New Team')]")).click();
	    Thread.sleep(2000);
	    
	    /* VIEW PUBLIC PROFILE - Subscription pages  */ 
	    String winHandleBefore2 = driver.getWindowHandle();Thread.sleep(3000);
	    driver.findElement(By.xpath("//button[normalize-space()='View Available Plans']")).click();Thread.sleep(3000);  	  	
		for(String winHandle : driver.getWindowHandles()){
	    driver.switchTo().window(winHandle);Thread.sleep(3000);
		}
	    driver.close();Thread.sleep(2000);
	    driver.switchTo().window(winHandleBefore2);
	    Thread.sleep(2000);
	    
	    String winHandleBefore3 = driver.getWindowHandle();Thread.sleep(3000);
	    driver.findElement(By.xpath("//button[normalize-space()='Upgrade to Prime Enterprise']")).click();Thread.sleep(3000);  	  	
		for(String winHandle : driver.getWindowHandles()){
	    driver.switchTo().window(winHandle);Thread.sleep(3000);
		}
	    driver.close();Thread.sleep(3000);
	    driver.switchTo().window(winHandleBefore3);
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='close-img']")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@class='close-img']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[@class='close-img']")).click();
	    Thread.sleep(2000);
	    
	    /* Team View */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[contains(text(),'Team View')]")));
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[contains(text(),'Team View')]")));Thread.sleep(2000);	
	    driver.findElement(By.xpath("//span[contains(text(),'Team View')]")).click();
	    Thread.sleep(2000);
	    
	    /* Delete 2nd Team from List */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[2]/div[1]/div[1]/div[1]/div[1]/div[1]/div[2]/div[2]/div[2]/div[1]/div[3]")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[2]/div[1]/div[1]/div[1]/div[1]/div[1]/div[2]/div[2]/div[2]/div[1]/div[3]")));Thread.sleep(2000);
	    {
		     WebElement element = driver.findElement(By.xpath("//div[2]/div[1]/div[1]/div[1]/div[1]/div[1]/div[2]/div[2]/div[2]/div[1]/div[3]"));
		     Actions builder = new Actions(driver);
		     builder.moveToElement(element).perform();
		}    
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[2]/div[2]/div/div[3]/div[1]/div/div/div[2]/span[3]")));
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[2]/div[2]/div/div[3]/div[1]/div/div/div[2]/span[3]")));Thread.sleep(2000);	
	    driver.findElement(By.xpath("//div[2]/div[2]/div/div[3]/div[1]/div/div/div[2]/span[3]")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[normalize-space()='Delete']")));
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[normalize-space()='Delete']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//button[normalize-space()='Delete']")).click();
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[@class='teamName-toast']"))); // Toaster Message Click
	    driver.findElement(By.xpath("//button[@aria-label='close']")).click();
	    Thread.sleep(2000);	
	    
	    /* Create a new Team after delete Team 002 */
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'Create New Team')]")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'Create New Team')]")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[contains(text(),'Create New Team')]")).click();	    
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("teamName")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.id("teamName")));Thread.sleep(2000);
	    driver.findElement(By.id("teamName")).click();
	    driver.findElement(By.id("teamName")).sendKeys("Recruit 002 Team Recreated after Delete ");
	    Thread.sleep(2000);
	    driver.findElement(By.id("team-info")).click();
	    driver.findElement(By.id("team-info")).sendKeys("Recreating the 3rd team from Default page admin team, which i deleted ");
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[normalize-space()='Proceed to add members']")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[normalize-space()='Proceed to add members']")));
	    driver.findElement(By.xpath("//button[normalize-space()='Proceed to add members']")).click();
	    Thread.sleep(2000);  
	    
	    /* Add Member to the Created Team - Which created after Deleting */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("searchEmployee")));
	    wait.until(ExpectedConditions.elementToBeClickable(By.id("searchEmployee")));
	    driver.findElement(By.id("searchEmployee")).click();
	    driver.findElement(By.id("searchEmployee")).clear();Thread.sleep(2000);
	    driver.findElement(By.id("searchEmployee")).sendKeys("Ahmed");
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//ul[1]/li[1]/div[1]/div[2]")));
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//ul[1]/li[1]/div[1]/div[2]")));Thread.sleep(2000);	
	    driver.findElement(By.xpath("//ul[1]/li[1]/div[1]/div[2]")).click();
	    Thread.sleep(2000);	
	    WebElement toggle = driver.findElement(By.xpath("//div[3]/div[1]/div[1]/div[3]/div[1]/div[1]/label[1]")); // Show on Public - toggle
	    JavascriptExecutor executor = (JavascriptExecutor)driver; 
	    executor.executeScript("arguments[0].click();", toggle);
		Thread.sleep(2000);	
	    driver.findElement(By.xpath("//div[contains(text(),'Select Access Level')]")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[@class='ml-1'][normalize-space()='Editor']")).click();
	    Thread.sleep(2000);   
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[normalize-space()='Confirm']")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[normalize-space()='Confirm']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//button[normalize-space()='Confirm']")).click();
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[@class='teamName-toast']"))); // Toaster Message Click
	    driver.findElement(By.xpath("//button[@aria-label='close']")).click();
	    Thread.sleep(2000);	 
	    
	    /* Logout */
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'My Profile')]")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'My Profile')]")));Thread.sleep(2000);
		driver.findElement(By.xpath("//div[contains(text(),'My Profile')]")).click();  
		Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//div[contains(text(),'Logout')])[1]")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//div[contains(text(),'Logout')])[1]")));Thread.sleep(2000);
		driver.findElement(By.xpath("(//div[contains(text(),'Logout')])[1]")).click();  
		Thread.sleep(2000);
	  }
	}