package bizTeamsCentral;

import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import screenshotOnFailure.FailScreenshot;

@Listeners(screenshotListners.EventList.class)
public class T4_Prime_Upgrade extends FailScreenshot{

	@Test
	public void Team_Upgrade_Subscriptions() throws InterruptedException {

		/* Login to the Application - PBC */ 		
	  	driver.findElement(By.xpath("(//button[normalize-space()='Login'])[1]")).click();
		driver.findElement(By.xpath("//input[@id='Username']")).click();
		driver.findElement(By.xpath("//input[@id='Username']")).sendKeys("test.doe002");
		driver.findElement(By.xpath("//input[@id='password-field']")).click();
		driver.findElement(By.xpath("//input[@id='password-field']")).sendKeys("Rockon123");
		driver.findElement(By.xpath("//button[@id='loginButton']")).click();
		Thread.sleep(2000);
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(120));
	    
	    /* Navigate to the Business page */   
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[normalize-space()='Biz Teams Automat...']")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()='Biz Teams Automat...']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//span[normalize-space()='Biz Teams Automat...']")).click();
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[normalize-space()='Menu']")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()='Menu']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//span[normalize-space()='Menu']")).click();
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//a[normalize-space()='Team Central'])[1]")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//a[normalize-space()='Team Central'])[1]")));Thread.sleep(2000);
	    driver.findElement(By.xpath("(//a[normalize-space()='Team Central'])[1]")).click();
	    Thread.sleep(2000);   
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'Create New Team')]")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'Create New Team')]")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[contains(text(),'Create New Team')]")).click();	    
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[normalize-space()='Upgrade to Prime Teams']")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[normalize-space()='Upgrade to Prime Teams']")));Thread.sleep(2000);
	    String winHandleBefore3 = driver.getWindowHandle();
	    Thread.sleep(3000);
	    driver.findElement(By.xpath("//button[normalize-space()='Upgrade to Prime Teams']")).click();Thread.sleep(3000);  	  	
		for(String winHandle : driver.getWindowHandles())
		{
	    driver.switchTo().window(winHandle);Thread.sleep(3000);
		}
	    
	    /* Upgrade to Prime Teams */
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//button[contains(text(),'Upgrade Plan')])[1]")));
	    wait.until(ExpectedConditions.elementToBeClickable(driver.findElement(By.xpath("(//button[contains(text(),'Upgrade Plan')])[1]"))));Thread.sleep(2000);
	    driver.findElement(By.xpath("(//button[contains(text(),'Upgrade Plan')])[1]")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[contains(text(),'Review Order')]")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[contains(text(),'Review Order')]")));Thread.sleep(3000);
	    driver.findElement(By.cssSelector("#btnBillingDetails > .fa")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("//span[contains(text(),'Review Order')]")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[contains(text(),'Edit Order')]")));;	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[contains(text(),'Edit Order')]")));Thread.sleep(3000);	
	    driver.findElement(By.xpath("//span[contains(text(),'Edit Order')]")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[contains(text(),'Review Order')]")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[contains(text(),'Review Order')]")));Thread.sleep(3000);
	    driver.findElement(By.xpath("//span[contains(text(),'Review Order')]")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[contains(text(),'Complete Order')]")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[contains(text(),'Complete Order')]")));Thread.sleep(3000);
	    driver.findElement(By.xpath("//span[contains(text(),'Complete Order')]")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[contains(text(),'Okay')]")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[contains(text(),'Okay')]")));Thread.sleep(3000);
	    driver.findElement(By.xpath("//span[contains(text(),'Okay')]")).click();
	    Thread.sleep(2000);
	    driver.close();Thread.sleep(2000);
	    driver.switchTo().window(winHandleBefore3);
	    Thread.sleep(2000);
	    driver.navigate().refresh();Thread.sleep(2000);
	    
	    /* After Subscription - Create Teams and Cancel */
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'Create New Team')]")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'Create New Team')]")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[contains(text(),'Create New Team')]")).click();
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[normalize-space()='Cancel']")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[normalize-space()='Cancel']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//button[normalize-space()='Cancel']")).click();
	    Thread.sleep(2000);	
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[normalize-space()='Yes, Cancel']")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[normalize-space()='Yes, Cancel']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//button[normalize-space()='Yes, Cancel']")).click();
	    Thread.sleep(2000);
	    
	    /* Logout */
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'My Profile')]")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'My Profile')]")));Thread.sleep(2000);
		driver.findElement(By.xpath("//div[contains(text(),'My Profile')]")).click();  
		Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//div[contains(text(),'Logout')])[1]")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//div[contains(text(),'Logout')])[1]")));Thread.sleep(2000);
		driver.findElement(By.xpath("(//div[contains(text(),'Logout')])[1]")).click();  
		Thread.sleep(2000);
	  }
	}
