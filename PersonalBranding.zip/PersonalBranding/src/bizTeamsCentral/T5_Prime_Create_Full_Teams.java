package bizTeamsCentral;

import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import screenshotOnFailure.FailScreenshot;

@Listeners(screenshotListners.EventList.class)
public class T5_Prime_Create_Full_Teams extends FailScreenshot{

	@Test
	public void Team_Create_All_8Teams() throws InterruptedException {

		/* Login to the Application - PBC */ 		
	  	driver.findElement(By.xpath("(//button[normalize-space()='Login'])[1]")).click();
		driver.findElement(By.xpath("//input[@id='Username']")).click();
		driver.findElement(By.xpath("//input[@id='Username']")).sendKeys("test.doe002");
		driver.findElement(By.xpath("//input[@id='password-field']")).click();
		driver.findElement(By.xpath("//input[@id='password-field']")).sendKeys("Rockon123");
		driver.findElement(By.xpath("//button[@id='loginButton']")).click();
		Thread.sleep(2000);
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(120));
	    
	    /* Navigate to the Business page */   
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[normalize-space()='Biz Teams Automat...']")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()='Biz Teams Automat...']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//span[normalize-space()='Biz Teams Automat...']")).click();
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[normalize-space()='Menu']")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()='Menu']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//span[normalize-space()='Menu']")).click();
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//a[normalize-space()='Team Central'])[1]")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//a[normalize-space()='Team Central'])[1]")));Thread.sleep(2000);
	    driver.findElement(By.xpath("(//a[normalize-space()='Team Central'])[1]")).click();
	    Thread.sleep(2000);   
	    
	    /* Team 4 */
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'Create New Team')]")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'Create New Team')]")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[contains(text(),'Create New Team')]")).click();	    
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("teamName")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.id("teamName")));Thread.sleep(2000);
	    driver.findElement(By.id("teamName")).click();
	    driver.findElement(By.id("teamName")).sendKeys("Recruit 004 Team");
	    Thread.sleep(2000);
	    driver.findElement(By.id("team-info")).click();
	    driver.findElement(By.id("team-info")).sendKeys("!@#$%!@$.,123");Thread.sleep(2000);
	    driver.findElement(By.id("team-info")).clear();Thread.sleep(2000);
	    driver.findElement(By.id("team-info")).sendKeys("Creating Forth team from Default page admin team");
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[normalize-space()='Proceed to add members']")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[normalize-space()='Proceed to add members']")));
	    driver.findElement(By.xpath("//button[normalize-space()='Proceed to add members']")).click();
	    Thread.sleep(2000);  
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[normalize-space()='Confirm']")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[normalize-space()='Confirm']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//button[normalize-space()='Confirm']")).click();
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[@class='teamName-toast']"))); // Toaster Message Click
	    driver.findElement(By.xpath("//button[@aria-label='close']")).click();
	    Thread.sleep(2000);	
	    
	    /* Team 5 */
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'Create New Team')]")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'Create New Team')]")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[contains(text(),'Create New Team')]")).click();	    
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("teamName")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.id("teamName")));Thread.sleep(2000);
	    driver.findElement(By.id("teamName")).click();
	    driver.findElement(By.id("teamName")).sendKeys("Recruit 005 Team");
	    Thread.sleep(2000);
	    driver.findElement(By.id("team-info")).click();
	    driver.findElement(By.id("team-info")).sendKeys("Creating Fifth team from Default page admin team");
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[normalize-space()='Proceed to add members']")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[normalize-space()='Proceed to add members']")));
	    driver.findElement(By.xpath("//button[normalize-space()='Proceed to add members']")).click();
	    Thread.sleep(2000);  
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[normalize-space()='Confirm']")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[normalize-space()='Confirm']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//button[normalize-space()='Confirm']")).click();
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[@class='teamName-toast']"))); // Toaster Message Click
	    driver.findElement(By.xpath("//button[@aria-label='close']")).click();
	    Thread.sleep(2000);	   
	    
	    /* Team 6 */
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'Create New Team')]")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'Create New Team')]")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[contains(text(),'Create New Team')]")).click();	    
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("teamName")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.id("teamName")));Thread.sleep(2000);
	    driver.findElement(By.id("teamName")).click();
	    driver.findElement(By.id("teamName")).sendKeys("Recruit 006 Team");
	    Thread.sleep(2000);
	    driver.findElement(By.id("team-info")).click();
	    driver.findElement(By.id("team-info")).sendKeys("Creating Sixth team from Default page admin team");
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[normalize-space()='Proceed to add members']")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[normalize-space()='Proceed to add members']")));
	    driver.findElement(By.xpath("//button[normalize-space()='Proceed to add members']")).click();
	    Thread.sleep(2000);  
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[normalize-space()='Confirm']")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[normalize-space()='Confirm']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//button[normalize-space()='Confirm']")).click();
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[@class='teamName-toast']"))); // Toaster Message Click
	    driver.findElement(By.xpath("//button[@aria-label='close']")).click();
	    Thread.sleep(2000);	 
	    
	    /* Team 7 */
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'Create New Team')]")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'Create New Team')]")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[contains(text(),'Create New Team')]")).click();	    
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("teamName")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.id("teamName")));Thread.sleep(2000);
	    driver.findElement(By.id("teamName")).click();
	    driver.findElement(By.id("teamName")).sendKeys("Recruit 007 Team");
	    Thread.sleep(2000);
	    driver.findElement(By.id("team-info")).click();
	    driver.findElement(By.id("team-info")).sendKeys("Creating Seventh team from Default page admin team");
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[normalize-space()='Proceed to add members']")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[normalize-space()='Proceed to add members']")));
	    driver.findElement(By.xpath("//button[normalize-space()='Proceed to add members']")).click();
	    Thread.sleep(2000);  
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[normalize-space()='Confirm']")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[normalize-space()='Confirm']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//button[normalize-space()='Confirm']")).click();
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[@class='teamName-toast']"))); // Toaster Message Click
	    driver.findElement(By.xpath("//button[@aria-label='close']")).click();
	    Thread.sleep(2000);	 
	    
	    /* Team 8 */
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'Create New Team')]")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'Create New Team')]")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[contains(text(),'Create New Team')]")).click();	    
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("teamName")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.id("teamName")));Thread.sleep(2000);
	    driver.findElement(By.id("teamName")).click();
	    driver.findElement(By.id("teamName")).sendKeys("Recruit 008 Team");
	    Thread.sleep(2000);
	    driver.findElement(By.id("team-info")).click();
	    driver.findElement(By.id("team-info")).sendKeys("Creating Eighth team from Default page admin team");
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[normalize-space()='Proceed to add members']")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[normalize-space()='Proceed to add members']")));
	    driver.findElement(By.xpath("//button[normalize-space()='Proceed to add members']")).click();
	    Thread.sleep(2000);  
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[normalize-space()='Confirm']")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[normalize-space()='Confirm']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//button[normalize-space()='Confirm']")).click();
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[@class='teamName-toast']"))); // Toaster Message Click
	    driver.findElement(By.xpath("//button[@aria-label='close']")).click();
	    Thread.sleep(2000);	    
	    
	    /* Team 9 */
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'Create New Team')]")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'Create New Team')]")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[contains(text(),'Create New Team')]")).click();	    
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("teamName")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.id("teamName")));Thread.sleep(2000);
	    driver.findElement(By.id("teamName")).click();
	    driver.findElement(By.id("teamName")).sendKeys("Recruit 009 Team");
	    Thread.sleep(2000);
	    driver.findElement(By.id("team-info")).click();
	    driver.findElement(By.id("team-info")).sendKeys("Creating Nineth team from Default page admin team");
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[normalize-space()='Proceed to add members']")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[normalize-space()='Proceed to add members']")));
	    driver.findElement(By.xpath("//button[normalize-space()='Proceed to add members']")).click();
	    Thread.sleep(2000);  
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[normalize-space()='Confirm']")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[normalize-space()='Confirm']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//button[normalize-space()='Confirm']")).click();
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[@class='teamName-toast']"))); // Toaster Message Click
	    driver.findElement(By.xpath("//button[@aria-label='close']")).click();
	    Thread.sleep(2000);	 
	    
	    /* Team 10 */
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'Create New Team')]")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'Create New Team')]")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[contains(text(),'Create New Team')]")).click();	    
	    Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("teamName")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.id("teamName")));Thread.sleep(2000);
	    driver.findElement(By.id("teamName")).click();
	    driver.findElement(By.id("teamName")).sendKeys("Recruit 0010 Team");
	    Thread.sleep(2000);
	    driver.findElement(By.id("team-info")).click();
	    driver.findElement(By.id("team-info")).sendKeys("Creating Tenth team from Default page admin team");
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[normalize-space()='Proceed to add members']")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[normalize-space()='Proceed to add members']")));
	    driver.findElement(By.xpath("//button[normalize-space()='Proceed to add members']")).click();
	    Thread.sleep(2000);  
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[normalize-space()='Confirm']")));	
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[normalize-space()='Confirm']")));Thread.sleep(2000);
	    driver.findElement(By.xpath("//button[normalize-space()='Confirm']")).click();
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[@class='teamName-toast']"))); // Toaster Message Click
	    driver.findElement(By.xpath("//button[@aria-label='close']")).click();
	    Thread.sleep(2000);	    
	    
	    /* Logout */
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'My Profile')]")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'My Profile')]")));Thread.sleep(2000);
		driver.findElement(By.xpath("//div[contains(text(),'My Profile')]")).click();  
		Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//div[contains(text(),'Logout')])[1]")));	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//div[contains(text(),'Logout')])[1]")));Thread.sleep(2000);
		driver.findElement(By.xpath("(//div[contains(text(),'Logout')])[1]")).click();  
		Thread.sleep(2000);
	  }
	}
