package bizTeamsCentral;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import screenshotOnFailure.FailScreenshot;

@Listeners(screenshotListners.EventList.class)
public class T2_STD_Subscription extends FailScreenshot {
	
	@Test
	public void Team_Standard_Subscription() throws InterruptedException {

	/* Login to the Application - PBC */ 		
	driver.findElement(By.xpath("(//button[normalize-space()='Login'])[1]")).click();
	driver.findElement(By.xpath("//input[@id='Username']")).click();
	driver.findElement(By.xpath("//input[@id='Username']")).sendKeys("test.doe002");
	driver.findElement(By.xpath("//input[@id='password-field']")).click();
	driver.findElement(By.xpath("//input[@id='password-field']")).sendKeys("Rockon123");
	driver.findElement(By.xpath("//button[@id='loginButton']")).click();
	Thread.sleep(2000);
	WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(120));
    
    /* Navigate to the Business page */   
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[normalize-space()='Biz Teams Automat...']")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()='Biz Teams Automat...']")));Thread.sleep(2000);
    driver.findElement(By.xpath("//span[normalize-space()='Biz Teams Automat...']")).click();
    Thread.sleep(2000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[normalize-space()='Menu']")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()='Menu']")));Thread.sleep(2000);
    driver.findElement(By.xpath("//span[normalize-space()='Menu']")).click();
    Thread.sleep(2000);
    
    /* Try Free subscription */   
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[normalize-space()='Subscription']")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[normalize-space()='Subscription']")));Thread.sleep(2000);
    driver.findElement(By.xpath("//a[normalize-space()='Subscription']")).click();
    Thread.sleep(2000);   
    driver.findElement(By.cssSelector("td > .biz-plans-head > form .btn-outline-maroon")).click();
    Thread.sleep(2000);
    
    /* Review Order with Empty Form */
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("#btnBillingDetails > .fa")));	
    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector("#btnBillingDetails > .fa")));Thread.sleep(2000);	
    driver.findElement(By.cssSelector("#btnBillingDetails > .fa")).click();
    Thread.sleep(2000);
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[contains(text(),\'Review Order\')]")));	
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[contains(text(),\'Review Order\')]")));Thread.sleep(2000);
    driver.findElement(By.id("btnReviewOrder")).click();
    Thread.sleep(2000);
    driver.findElement(By.id("paypalRadioBtn")).click();
    Thread.sleep(2000);
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[contains(text(),\'Review Order\')]")));	
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[contains(text(),\'Review Order\')]")));Thread.sleep(2000);
    driver.findElement(By.id("btnReviewOrder")).click();
    Thread.sleep(2000);
    driver.findElement(By.id("cardRadioBtn")).click();
    Thread.sleep(2000);
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[contains(text(),\'Review Order\')]")));	
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[contains(text(),\'Review Order\')]")));Thread.sleep(2000);
    driver.findElement(By.id("btnReviewOrder")).click();
    Thread.sleep(2000);
    
    /* Credit Card Details */
    driver.findElement(By.id("PaymentInformation_CardHolderName")).click();
    driver.findElement(By.id("PaymentInformation_CardHolderName")).clear();
    Thread.sleep(2000);
    driver.findElement(By.id("PaymentInformation_CardHolderName")).sendKeys("Adam Mahdi");
    Thread.sleep(2000);
    driver.findElement(By.id("PaymentInformation_CreditCardNumber")).click();
    driver.findElement(By.id("PaymentInformation_CreditCardNumber")).sendKeys("4005519200000004");
    Thread.sleep(2000);
    driver.findElement(By.id("select2-PaymentInformation_ExpirationMonth-container")).click();
    Thread.sleep(2000);
    driver.findElement(By.cssSelector(".select2-search__field")).click();
    driver.findElement(By.cssSelector(".select2-search__field")).sendKeys("05");
    Thread.sleep(2000);
    driver.findElement(By.cssSelector(".select2-search__field")).sendKeys(Keys.ENTER);
    Thread.sleep(2000);
    driver.findElement(By.id("select2-PaymentInformation_ExpirationYear-container")).click();
    Thread.sleep(2000);
    driver.findElement(By.cssSelector(".select2-search__field")).click();
    driver.findElement(By.cssSelector(".select2-search__field")).sendKeys("28");
    Thread.sleep(2000);
    driver.findElement(By.cssSelector(".select2-search__field")).sendKeys(Keys.ENTER);
    Thread.sleep(2000);
    driver.findElement(By.xpath("//div[@id=\'checkoutCard\']/div/div[3]/div/div[4]/div/label")).click();
    Thread.sleep(2000);
    driver.findElement(By.id("PaymentInformation_CVV")).sendKeys("498");
    Thread.sleep(2000);
    driver.findElement(By.id("btnReviewOrder")).click();
    Thread.sleep(2000);
    driver.findElement(By.xpath("//div[@id=\'checkoutCard\']/div/div[4]/div/label")).click();
    Thread.sleep(2000);
    driver.findElement(By.id("PaymentInformation_BillingDetailsData_Address")).sendKeys("2400 Camino Ramon, San Ramon");
    Thread.sleep(2000);
    driver.findElement(By.id("PaymentInformation_BillingDetailsData_City")).click();Thread.sleep(2000);
    driver.findElement(By.id("PaymentInformation_BillingDetailsData_City")).clear();
    Thread.sleep(2000);
    driver.findElement(By.id("PaymentInformation_BillingDetailsData_City")).sendKeys("San B");
    Thread.sleep(2000);
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//body[1]/ul[1]/li[2]/div[1]")));
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//body[1]/ul[1]/li[2]/div[1]")));Thread.sleep(2000);
    driver.findElement(By.xpath("//body[1]/ul[1]/li[2]/div[1]")).click();    							
    Thread.sleep(2000);
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[contains(text(),\'Review Order\')]")));Thread.sleep(2000);
    driver.findElement(By.xpath("//span[contains(text(),\'Review Order\')]")).click();
    Thread.sleep(2000);    
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[contains(text(),\'Edit Order\')]")));
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[contains(text(),\'Edit Order\')]")));Thread.sleep(2000);	
    driver.findElement(By.xpath("//span[contains(text(),\'Edit Order\')]")).click();Thread.sleep(2000);
    
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[contains(text(),\'Review Order\')]")));	
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[contains(text(),\'Review Order\')]")));Thread.sleep(2000);
    driver.findElement(By.xpath("//span[contains(text(),\'Review Order\')]")).click();Thread.sleep(2000);
    
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[contains(text(),\'Complete Order\')]")));	
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[contains(text(),\'Complete Order\')]")));Thread.sleep(2000);
    driver.findElement(By.xpath("//span[contains(text(),\'Complete Order\')]")).click();Thread.sleep(2000);
    
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[contains(text(),\'Okay\')]")));Thread.sleep(2000);	
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[contains(text(),\'Okay\')]")));Thread.sleep(2000);
    driver.findElement(By.xpath("//span[contains(text(),\'Okay\')]")).click();
    Thread.sleep(2000);
    driver.navigate().refresh();
    Thread.sleep(2000);
    
    /* Cancel Trail Subscriptions */
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[normalize-space()='Menu']")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()='Menu']")));Thread.sleep(2000);
    driver.findElement(By.xpath("//span[normalize-space()='Menu']")).click();
    Thread.sleep(2000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[normalize-space()='Subscription']")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[normalize-space()='Subscription']")));Thread.sleep(2000);
    driver.findElement(By.xpath("//a[normalize-space()='Subscription']")).click();
    Thread.sleep(2000);   
    driver.findElement(By.linkText("Subscription & Orders")).click();
    Thread.sleep(2000);
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("#btnCancelSubscription > span")));	
    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector("#btnCancelSubscription > span")));Thread.sleep(2000);	
    driver.navigate().refresh();
    Thread.sleep(2000);
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("#btnCancelSubscription > span")));	
    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector("#btnCancelSubscription > span")));Thread.sleep(2000);	
    driver.findElement(By.cssSelector("#btnCancelSubscription > span")).click();
    Thread.sleep(2000);
    driver.findElement(By.cssSelector(".btn-maroon")).click();
    Thread.sleep(2000);
    
    /* Logout */
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'My Profile')]")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'My Profile')]")));Thread.sleep(2000);
	driver.findElement(By.xpath("//div[contains(text(),'My Profile')]")).click();  
	Thread.sleep(2000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//div[contains(text(),'Logout')])[1]")));	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//div[contains(text(),'Logout')])[1]")));Thread.sleep(2000);
	driver.findElement(By.xpath("(//div[contains(text(),'Logout')])[1]")).click();  
	Thread.sleep(2000);
  }
}

